'use client';

import React from 'react';
import { EngineStoreState } from '@/lib/engineStore';
import { MATERIAL_DATABASE } from '@/lib/syntheticData';
import { SAMPLE_METROLOGY_INSPECTIONS } from '@/lib/manufacturing/metrology';
import { SAMPLE_FASTENER_RECORDS } from '@/lib/manufacturing/assembly';
import { X, ShieldCheck, Cpu, Ruler, Activity, Wrench, CheckCircle2 } from 'lucide-react';

interface ComponentInspectorProps {
  componentId: string | null;
  onClose: () => void;
  state: EngineStoreState;
}

export function ComponentInspector({ componentId, onClose, state }: ComponentInspectorProps) {
  if (!componentId) return null;

  // Derive component metadata based on ID
  let partName = 'Crankshaft Assembly';
  let partNumber = 'CRK-H2-2000-01';
  let serialNumber = 'CRK-SN-10492';
  let material = MATERIAL_DATABASE.STEEL_4340;
  let operatingTemp = state.thermalNodes.engineOilC + 8;
  let dynamicStressMpa = 420;
  let safetyFactor = 2.4;
  let primaryDimension = 'Main Journal Dia: 52.000 mm (Actual: 49.998 mm)';

  if (componentId.includes('PISTON')) {
    partName = 'Forged Hydrogen Piston Assembly';
    partNumber = 'PST-H2-2000-01';
    serialNumber = 'PST-SN-44101';
    material = MATERIAL_DATABASE.ALSI7MG_T6;
    operatingTemp = state.thermalNodes.pistonCrownC;
    dynamicStressMpa = 185;
    safetyFactor = 1.95;
    primaryDimension = 'Crown Diameter: 85.940 mm (Cold Skirt: 85.965 mm)';
  } else if (componentId.includes('BLOCK')) {
    partName = 'Cylinder Block (Closed-Deck)';
    partNumber = 'BLK-H2-2000-01';
    serialNumber = 'BLK-SN-84920';
    material = MATERIAL_DATABASE.ALSI7MG_T6;
    operatingTemp = state.thermalNodes.cylinderLinerC;
    dynamicStressMpa = 145;
    safetyFactor = 2.8;
    primaryDimension = 'Bore: 86.004 mm | Deck Flatness: 12 um';
  } else if (componentId.includes('CYLINDER_HEAD')) {
    partName = 'DOHC 16V Cylinder Head';
    partNumber = 'HED-H2-2000-01';
    serialNumber = 'HED-SN-30219';
    material = MATERIAL_DATABASE.ALSI7MG_T6;
    operatingTemp = state.thermalNodes.cylinderHeadDeckC;
    dynamicStressMpa = 160;
    safetyFactor = 2.2;
    primaryDimension = 'Combustion Chamber: 39.95 cc';
  } else if (componentId.includes('HYDROGEN_RAIL')) {
    partName = '350-Bar Hydrogen Common Rail';
    partNumber = 'RAIL-H2-350-01';
    serialNumber = 'RAIL-SN-55021';
    material = MATERIAL_DATABASE.SS316L;
    operatingTemp = 45;
    dynamicStressMpa = 210;
    safetyFactor = 3.2;
    primaryDimension = 'Internal Dia: 8.0 mm | Test Pressure: 525 bar';
  } else if (componentId.includes('TURBOCHARGER')) {
    partName = 'Twin-Scroll Turbocharger';
    partNumber = 'TRB-TWIN-SCROLL-01';
    serialNumber = 'TRB-SN-77291';
    material = MATERIAL_DATABASE.INCONEL_718;
    operatingTemp = state.thermalNodes.turboTurbineHousingC;
    dynamicStressMpa = 380;
    safetyFactor = 2.1;
    primaryDimension = 'Shaft RPM: 112,000 | PR: 2.4';
  } else if (componentId.includes('ROD')) {
    partName = 'Connecting Rod (H-Beam Forged)';
    partNumber = 'ROD-H2-2000-01';
    serialNumber = 'ROD-SN-58190';
    material = MATERIAL_DATABASE.STEEL_4340;
    operatingTemp = state.thermalNodes.engineOilC;
    dynamicStressMpa = state.crankDynamics.bearingPeakLoadN / 1e6 * 20;
    safetyFactor = state.crankDynamics.connectingRodBucklingMargin;
    primaryDimension = 'Center-to-Center: 143.500 mm';
  }

  // Related metrology & fastener records
  const relevantMetrology = SAMPLE_METROLOGY_INSPECTIONS.find(m => m.componentSerial.includes(partNumber.split('-')[0])) || SAMPLE_METROLOGY_INSPECTIONS[0];
  const relevantFastener = SAMPLE_FASTENER_RECORDS[0];

  return (
    <div className="w-96 bg-[#0d1117] border-l border-neutral-800 flex flex-col h-full overflow-y-auto p-5 text-neutral-200 z-20 shadow-2xl">
      {/* Header */}
      <div className="flex items-start justify-between pb-4 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            <span className="text-[11px] font-mono uppercase tracking-wider text-cyan-400">
              Component Digital Twin
            </span>
          </div>
          <h2 className="text-base font-bold text-neutral-100 mt-1">{partName}</h2>
          <p className="text-xs font-mono text-neutral-400 mt-0.5">{partNumber}</p>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-md text-neutral-400 hover:text-neutral-100 hover:bg-neutral-800 transition-colors"
          title="Close Inspector"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Digital Thread Traceability */}
      <div className="mt-4 p-3 bg-neutral-900/80 rounded-lg border border-neutral-800/80 space-y-2 text-xs">
        <div className="text-[11px] font-mono text-neutral-400 font-semibold uppercase flex items-center gap-1.5">
          <Cpu className="w-3.5 h-3.5 text-cyan-400" />
          Traceability & Identity
        </div>
        <div className="grid grid-cols-2 gap-2 font-mono">
          <div>
            <span className="text-neutral-500 block text-[10px]">SERIAL NO</span>
            <span className="text-neutral-200 font-medium">{serialNumber}</span>
          </div>
          <div>
            <span className="text-neutral-500 block text-[10px]">ENGINE LINK</span>
            <span className="text-neutral-200 font-medium">{state.config.engineId}</span>
          </div>
          <div>
            <span className="text-neutral-500 block text-[10px]">BATCH</span>
            <span className="text-neutral-200 font-medium">BAT-2026-Q3</span>
          </div>
          <div>
            <span className="text-neutral-500 block text-[10px]">CAD REV</span>
            <span className="text-neutral-200 font-medium">REV-E (Released)</span>
          </div>
        </div>
      </div>

      {/* Material Science & Hydrogen Compatibility */}
      <div className="mt-4 p-3 bg-neutral-900/80 rounded-lg border border-neutral-800/80 space-y-2 text-xs">
        <div className="text-[11px] font-mono text-neutral-400 font-semibold uppercase flex items-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          Material & Hydrogen Compatibility
        </div>
        <div className="font-mono text-neutral-300 font-medium">{material.name}</div>
        <div className="grid grid-cols-2 gap-2 font-mono text-xs">
          <div>
            <span className="text-neutral-500 block text-[10px]">YIELD STRENGTH</span>
            <span className="text-neutral-200">{(material.yieldStrengthPa / 1e6).toFixed(0)} MPa</span>
          </div>
          <div>
            <span className="text-neutral-500 block text-[10px]">YOUNG&apos;S MODULUS</span>
            <span className="text-neutral-200">{(material.youngsModulusPa / 1e9).toFixed(0)} GPa</span>
          </div>
          <div>
            <span className="text-neutral-500 block text-[10px]">H₂ COMPATIBILITY</span>
            <span className="text-emerald-400 font-semibold">{material.hydrogenCompatibilityScore} / 100</span>
          </div>
          <div>
            <span className="text-neutral-500 block text-[10px]">EMBRITTLEMENT</span>
            <span className="text-emerald-400 font-semibold">{material.embrittlementRisk}</span>
          </div>
        </div>
      </div>

      {/* Live Physical & Thermal State */}
      <div className="mt-4 p-3 bg-neutral-900/80 rounded-lg border border-neutral-800/80 space-y-2 text-xs">
        <div className="text-[11px] font-mono text-neutral-400 font-semibold uppercase flex items-center gap-1.5">
          <Activity className="w-3.5 h-3.5 text-amber-400" />
          Live State & Mechanical Integrity
        </div>
        <div className="grid grid-cols-2 gap-2 font-mono">
          <div>
            <span className="text-neutral-500 block text-[10px]">TEMPERATURE</span>
            <span className="text-amber-400 font-bold">{operatingTemp} °C</span>
          </div>
          <div>
            <span className="text-neutral-500 block text-[10px]">VON MISES STRESS</span>
            <span className="text-neutral-200">{dynamicStressMpa.toFixed(0)} MPa</span>
          </div>
          <div>
            <span className="text-neutral-500 block text-[10px]">SAFETY FACTOR</span>
            <span className="text-emerald-400 font-bold">{safetyFactor.toFixed(2)}x</span>
          </div>
          <div>
            <span className="text-neutral-500 block text-[10px]">CRITICAL GEOM</span>
            <span className="text-neutral-300 text-[11px] truncate">{primaryDimension}</span>
          </div>
        </div>
      </div>

      {/* Zeiss CMM Metrology Verification */}
      <div className="mt-4 p-3 bg-neutral-900/80 rounded-lg border border-neutral-800/80 space-y-2 text-xs">
        <div className="text-[11px] font-mono text-neutral-400 font-semibold uppercase flex items-center gap-1.5">
          <Ruler className="w-3.5 h-3.5 text-blue-400" />
          CMM Metrology Inspection
        </div>
        <div className="font-mono text-neutral-300 text-xs">
          {relevantMetrology.parameterName}
        </div>
        <div className="flex items-center justify-between text-xs font-mono">
          <span className="text-neutral-500">DEVIATION:</span>
          <span className="text-neutral-200 font-bold">{relevantMetrology.deviationUm} µm</span>
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-950/70 border border-emerald-500/40 text-emerald-400 text-[10px] font-bold">
            <CheckCircle2 className="w-3 h-3" /> PASS
          </span>
        </div>
        <p className="text-[10px] text-neutral-500 font-mono mt-1">
          Scanned by {relevantMetrology.instrument}
        </p>
      </div>

      {/* Fastening Torque & Assembly Record */}
      <div className="mt-4 p-3 bg-neutral-900/80 rounded-lg border border-neutral-800/80 space-y-2 text-xs">
        <div className="text-[11px] font-mono text-neutral-400 font-semibold uppercase flex items-center gap-1.5">
          <Wrench className="w-3.5 h-3.5 text-cyan-400" />
          Assembly Fastener Log
        </div>
        <div className="text-xs font-mono text-neutral-300">{relevantFastener.location}</div>
        <div className="grid grid-cols-2 gap-2 text-xs font-mono">
          <div>
            <span className="text-neutral-500 block text-[10px]">TARGET TORQUE</span>
            <span className="text-neutral-200">{relevantFastener.targetTorqueNm} Nm</span>
          </div>
          <div>
            <span className="text-neutral-500 block text-[10px]">ACTUAL LOGGED</span>
            <span className="text-emerald-400 font-bold">{relevantFastener.actualTorqueNm} Nm</span>
          </div>
        </div>
        <p className="text-[10px] text-neutral-500 font-mono">
          Tightened by {relevantFastener.toolId} on {relevantFastener.timestamp}
        </p>
      </div>
    </div>
  );
}
