'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { EngineStoreState, ViewMode } from '@/lib/engineStore';
import { Maximize2, RotateCcw, Eye, Layers, Flame, Activity, Zap, Compass } from 'lucide-react';

interface Engine3DViewerProps {
  state: EngineStoreState;
  onSelectComponent: (componentId: string) => void;
  selectedComponentId: string | null;
  onViewModeChange: (mode: ViewMode) => void;
}

export function Engine3DViewer({
  state,
  onSelectComponent,
  selectedComponentId,
  onViewModeChange,
}: Engine3DViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);

  // Mesh and component refs
  const crankshaftGroupRef = useRef<THREE.Group | null>(null);
  const pistonsRef = useRef<THREE.Group[]>([]);
  const connectingRodsRef = useRef<THREE.Group[]>([]);
  const valvesRef = useRef<THREE.Mesh[]>([]);
  const camsRef = useRef<THREE.Group | null>(null);
  const turboRotorRef = useRef<THREE.Mesh | null>(null);
  const cylinderHeadMeshRef = useRef<THREE.Group | null>(null);
  const engineBlockMeshRef = useRef<THREE.Group | null>(null);
  const h2RailMeshRef = useRef<THREE.Group | null>(null);
  const turboMeshRef = useRef<THREE.Group | null>(null);
  const exhaustMeshRef = useRef<THREE.Group | null>(null);
  const combustionFlashesRef = useRef<THREE.Mesh[]>([]);
  const flowParticlesRef = useRef<THREE.Points | null>(null);

  const [hoveredPart, setHoveredPart] = useState<string | null>(null);
  const [cameraPreset, setCameraPreset] = useState<'ISO' | 'FRONT' | 'SIDE' | 'TOP'>('ISO');

  // Animation angle
  const animAngleRef = useRef<number>(0);

  // Keep live references for animation loop and callbacks without re-triggering scene creation
  const stateRef = useRef(state);
  const onSelectComponentRef = useRef(onSelectComponent);

  useEffect(() => {
    stateRef.current = state;
    onSelectComponentRef.current = onSelectComponent;
  }, [state, onSelectComponent]);

  useEffect(() => {
    if (!containerRef.current) return;

    const container = containerRef.current;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 550;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0c10); // Deep aerospace graphite
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    camera.position.set(4.2, 3.2, 5.5);
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Orbit Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxDistance = 18;
    controls.minDistance = 1.2;
    controls.target.set(0, 0, 0);
    controlsRef.current = controls;

    // Lighting (precision industrial studio)
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xfff6ea, 2.2);
    keyLight.position.set(6, 10, 8);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xc4e0ff, 1.4);
    fillLight.position.set(-8, 5, -6);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0x00e5ff, 0.9); // Hydrogen cyan rim
    rimLight.position.set(0, -6, 5);
    scene.add(rimLight);

    // Grid Floor
    const grid = new THREE.GridHelper(16, 32, 0x00e5ff, 0x1f2937);
    grid.position.y = -2.2;
    scene.add(grid);

    // ==========================================
    // BUILD PHYSICAL ENGINE 3D COMPONENTS
    // ==========================================

    const engineRoot = new THREE.Group();
    engineRoot.name = 'EngineAssembly';
    scene.add(engineRoot);

    // Materials
    const matBlock = new THREE.MeshStandardMaterial({
      color: 0x4a5568,
      metalness: 0.85,
      roughness: 0.35,
    });
    const matHead = new THREE.MeshStandardMaterial({
      color: 0x718096,
      metalness: 0.9,
      roughness: 0.25,
    });
    const matCrank = new THREE.MeshStandardMaterial({
      color: 0xd2d6dc,
      metalness: 0.95,
      roughness: 0.15,
    });
    const matRod = new THREE.MeshStandardMaterial({
      color: 0xa0aec0,
      metalness: 0.92,
      roughness: 0.2,
    });
    const matPiston = new THREE.MeshStandardMaterial({
      color: 0x2d3748,
      metalness: 0.8,
      roughness: 0.3,
    });
    const matH2Rail = new THREE.MeshStandardMaterial({
      color: 0x00b4d8,
      metalness: 0.95,
      roughness: 0.1,
    });
    const matTurbo = new THREE.MeshStandardMaterial({
      color: 0xb7791f,
      metalness: 0.88,
      roughness: 0.35,
    });
    const matExhaust = new THREE.MeshStandardMaterial({
      color: 0x9c4221,
      metalness: 0.8,
      roughness: 0.45,
    });

    // 1. ENGINE BLOCK
    const blockGroup = new THREE.Group();
    blockGroup.name = 'COMPONENT_BLOCK';
    const blockCasingGeom = new THREE.BoxGeometry(3.6, 1.8, 1.6);
    const blockCasing = new THREE.Mesh(blockCasingGeom, matBlock);
    blockCasing.castShadow = true;
    blockCasing.receiveShadow = true;
    blockGroup.add(blockCasing);

    // Sump oil pan
    const sumpGeom = new THREE.BoxGeometry(3.2, 0.6, 1.4);
    const sumpMesh = new THREE.Mesh(sumpGeom, new THREE.MeshStandardMaterial({ color: 0x1a202c, metalness: 0.9, roughness: 0.3 }));
    sumpMesh.position.y = -1.2;
    blockGroup.add(sumpMesh);

    engineBlockMeshRef.current = blockGroup;
    engineRoot.add(blockGroup);

    // 2. CRANKSHAFT
    const crankGroup = new THREE.Group();
    crankGroup.name = 'COMPONENT_CRANKSHAFT';
    crankGroup.position.y = -0.5;

    // Center shaft
    const shaftGeom = new THREE.CylinderGeometry(0.16, 0.16, 3.8, 24);
    shaftGeom.rotateZ(Math.PI / 2);
    const mainShaft = new THREE.Mesh(shaftGeom, matCrank);
    crankGroup.add(mainShaft);

    // Crank webs & counterweights (4 throws)
    const cylinderSpacing = 0.8;
    const strokeRadius = 0.43; // 43mm = 86mm stroke / 2
    const crankAngles = [0, Math.PI, Math.PI, 0]; // 180° flat-plane inline-4

    for (let i = 0; i < 4; i++) {
      const xPos = -1.2 + i * cylinderSpacing;
      const angle = crankAngles[i];

      // Counterweight web
      const webGeom = new THREE.BoxGeometry(0.12, 0.75, 0.38);
      const web = new THREE.Mesh(webGeom, matCrank);
      web.position.set(xPos, -Math.sin(angle) * 0.2, -Math.cos(angle) * 0.2);
      crankGroup.add(web);

      // Rod journal pin
      const pinGeom = new THREE.CylinderGeometry(0.12, 0.12, 0.25, 20);
      pinGeom.rotateZ(Math.PI / 2);
      const pin = new THREE.Mesh(pinGeom, matCrank);
      pin.position.set(xPos, Math.sin(angle) * strokeRadius, Math.cos(angle) * strokeRadius);
      crankGroup.add(pin);
    }

    crankshaftGroupRef.current = crankGroup;
    engineRoot.add(crankGroup);

    // 3. PISTONS & CONNECTING RODS (4 cylinders)
    const pistons: THREE.Group[] = [];
    const rods: THREE.Group[] = [];
    const combustionFlashes: THREE.Mesh[] = [];

    const pistonGeom = new THREE.CylinderGeometry(0.38, 0.38, 0.45, 28);
    const rodGeom = new THREE.BoxGeometry(0.08, 1.43, 0.08); // 143.5 mm rod length
    const flashGeom = new THREE.SphereGeometry(0.35, 16, 16);
    const flashMat = new THREE.MeshBasicMaterial({ color: 0x00e5ff, transparent: true, opacity: 0 });

    for (let i = 0; i < 4; i++) {
      const xPos = -1.2 + i * cylinderSpacing;

      // Piston group
      const pGroup = new THREE.Group();
      pGroup.name = `COMPONENT_PISTON_${i + 1}`;
      const pMesh = new THREE.Mesh(pistonGeom, matPiston);
      pMesh.castShadow = true;
      pGroup.add(pMesh);
      pGroup.position.set(xPos, 0.8, 0);

      // Combustion flash mesh
      const flash = new THREE.Mesh(flashGeom, flashMat.clone());
      flash.position.set(0, 0.28, 0);
      pGroup.add(flash);
      combustionFlashes.push(flash);

      engineRoot.add(pGroup);
      pistons.push(pGroup);

      // Connecting rod group
      const rGroup = new THREE.Group();
      rGroup.name = `COMPONENT_ROD_${i + 1}`;
      const rMesh = new THREE.Mesh(rodGeom, matRod);
      rMesh.position.y = 0.715; // center the rod
      rGroup.add(rMesh);
      rGroup.position.set(xPos, -0.5, 0);

      engineRoot.add(rGroup);
      rods.push(rGroup);
    }
    pistonsRef.current = pistons;
    connectingRodsRef.current = rods;
    combustionFlashesRef.current = combustionFlashes;

    // 4. CYLINDER HEAD & VALVETRAIN
    const headGroup = new THREE.Group();
    headGroup.name = 'COMPONENT_CYLINDER_HEAD';
    headGroup.position.y = 1.35;

    const headCasingGeom = new THREE.BoxGeometry(3.6, 0.8, 1.6);
    const headCasing = new THREE.Mesh(headCasingGeom, matHead);
    headCasing.castShadow = true;
    headGroup.add(headCasing);

    // Cam cover
    const coverGeom = new THREE.BoxGeometry(3.4, 0.45, 1.4);
    const coverMesh = new THREE.Mesh(coverGeom, new THREE.MeshStandardMaterial({ color: 0x2b6cb0, metalness: 0.8, roughness: 0.3 }));
    coverMesh.position.y = 0.55;
    headGroup.add(coverMesh);

    cylinderHeadMeshRef.current = headGroup;
    engineRoot.add(headGroup);

    // 5. HYDROGEN DIRECT INJECTION RAIL
    const h2RailGroup = new THREE.Group();
    h2RailGroup.name = 'COMPONENT_HYDROGEN_RAIL';
    h2RailGroup.position.set(0, 1.7, 0.75);

    // Rail tube
    const railTubeGeom = new THREE.CylinderGeometry(0.08, 0.08, 3.2, 20);
    railTubeGeom.rotateZ(Math.PI / 2);
    const railTube = new THREE.Mesh(railTubeGeom, matH2Rail);
    h2RailGroup.add(railTube);

    // 4 Injectors
    const injectorGeom = new THREE.CylinderGeometry(0.04, 0.03, 0.45, 16);
    for (let i = 0; i < 4; i++) {
      const xPos = -1.2 + i * cylinderSpacing;
      const inj = new THREE.Mesh(injectorGeom, matH2Rail);
      inj.position.set(xPos, -0.22, -0.2);
      inj.rotation.x = Math.PI / 4;
      h2RailGroup.add(inj);
    }
    h2RailMeshRef.current = h2RailGroup;
    engineRoot.add(h2RailGroup);

    // 6. TURBOCHARGER & EXHAUST MANIFOLD
    const exhaustGroup = new THREE.Group();
    exhaustGroup.name = 'COMPONENT_EXHAUST_MANIFOLD';
    exhaustGroup.position.set(0, 0.8, -1.0);

    // 4 Exhaust runners merging
    for (let i = 0; i < 4; i++) {
      const xPos = -1.2 + i * cylinderSpacing;
      const runnerGeom = new THREE.CylinderGeometry(0.07, 0.07, 0.65, 16);
      runnerGeom.rotateX(Math.PI / 2);
      const runner = new THREE.Mesh(runnerGeom, matExhaust);
      runner.position.set(xPos, 0.4, 0.2);
      exhaustGroup.add(runner);
    }

    // Collector pipe
    const collectorGeom = new THREE.CylinderGeometry(0.14, 0.14, 2.8, 20);
    collectorGeom.rotateZ(Math.PI / 2);
    const collector = new THREE.Mesh(collectorGeom, matExhaust);
    collector.position.set(0, 0.2, -0.15);
    exhaustGroup.add(collector);

    exhaustMeshRef.current = exhaustGroup;
    engineRoot.add(exhaustGroup);

    // Turbocharger unit
    const turboGroup = new THREE.Group();
    turboGroup.name = 'COMPONENT_TURBOCHARGER';
    turboGroup.position.set(0.6, 0.8, -1.5);

    // Compressor scroll (silver)
    const compGeom = new THREE.TorusGeometry(0.35, 0.15, 16, 32);
    const compMesh = new THREE.Mesh(compGeom, matHead);
    turboGroup.add(compMesh);

    // Turbine scroll (bronze/cast)
    const turbineGeom = new THREE.TorusGeometry(0.32, 0.14, 16, 32);
    const turbineMesh = new THREE.Mesh(turbineGeom, matTurbo);
    turbineMesh.position.x = -0.4;
    turboGroup.add(turbineMesh);

    // Turbo center shaft rotor
    const rotorGeom = new THREE.CylinderGeometry(0.08, 0.08, 0.5, 16);
    rotorGeom.rotateZ(Math.PI / 2);
    const rotorMesh = new THREE.Mesh(rotorGeom, matCrank);
    rotorMesh.position.x = -0.2;
    turboGroup.add(rotorMesh);
    turboRotorRef.current = rotorMesh;

    turboMeshRef.current = turboGroup;
    engineRoot.add(turboGroup);

    // 7. FLOW PARTICLES (X-Ray / Flow mode)
    const particleCount = 200;
    const particleGeom = new THREE.BufferGeometry();
    const particlePos = new Float32Array(particleCount * 3);
    for (let p = 0; p < particleCount; p++) {
      particlePos[p * 3] = (Math.random() - 0.5) * 3.0;
      particlePos[p * 3 + 1] = Math.random() * 2.0 - 0.5;
      particlePos[p * 3 + 2] = (Math.random() - 0.5) * 1.2;
    }
    particleGeom.setAttribute('position', new THREE.BufferAttribute(particlePos, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0x00f0ff,
      size: 0.08,
      transparent: true,
      opacity: 0.8,
    });
    const flowPoints = new THREE.Points(particleGeom, particleMat);
    flowPoints.visible = false;
    scene.add(flowPoints);
    flowParticlesRef.current = flowPoints;

    // Raycasting for interactive component clicking
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const handlePointerDown = (event: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(engineRoot.children, true);

      if (intersects.length > 0) {
        let currentObj: THREE.Object3D | null = intersects[0].object;
        while (currentObj && currentObj !== engineRoot) {
          if (currentObj.name && currentObj.name.startsWith('COMPONENT_')) {
            onSelectComponentRef.current(currentObj.name);
            return;
          }
          currentObj = currentObj.parent;
        }
      }
    };

    const handlePointerMove = (event: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(engineRoot.children, true);

      if (intersects.length > 0) {
        let currentObj: THREE.Object3D | null = intersects[0].object;
        while (currentObj && currentObj !== engineRoot) {
          if (currentObj.name && currentObj.name.startsWith('COMPONENT_')) {
            setHoveredPart(currentObj.name.replace('COMPONENT_', ''));
            return;
          }
          currentObj = currentObj.parent;
        }
      } else {
        setHoveredPart(null);
      }
    };

    renderer.domElement.addEventListener('pointerdown', handlePointerDown);
    renderer.domElement.addEventListener('pointermove', handlePointerMove);

    // Resize observer
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width: w, height: h } = entry.contentRect;
        if (w > 0 && h > 0) {
          camera.aspect = w / h;
          camera.updateProjectionMatrix();
          renderer.setSize(w, h);
        }
      }
    });
    resizeObserver.observe(container);

    // Animation Render Loop
    let animationFrameId: number;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const currentLive = stateRef.current;

      // Simulation clock step
      if (currentLive.simulationRunning) {
        const rpm = currentLive.liveState.rpm;
        const dTheta = (rpm * 6 * Math.PI * 0.016 * currentLive.clockSpeedMultiplier) / 60;
        animAngleRef.current = (animAngleRef.current + dTheta) % (4 * Math.PI); // 720 deg cycle
      }

      // 1. Rotate Crankshaft around X-axis
      if (crankshaftGroupRef.current) {
        crankshaftGroupRef.current.rotation.x = animAngleRef.current;
      }

      // 2. Kinematic Piston & Connecting Rod articulation
      const strokeRadius = 0.43;
      const rodLength = 1.43;
      const lambda = strokeRadius / rodLength;

      const cylOffsets = [0, Math.PI, Math.PI, 0]; // Firing pattern 1-3-4-2
      for (let i = 0; i < 4; i++) {
        const cylTheta = animAngleRef.current + cylOffsets[i];
        const sinT = Math.sin(cylTheta);
        const cosT = Math.cos(cylTheta);
        const sqrtTerm = Math.sqrt(Math.max(0.001, 1 - Math.pow(lambda * sinT, 2)));
        // Piston displacement s from TDC
        const s = strokeRadius * ((1 - cosT) + (1 / lambda) * (1 - sqrtTerm));

        // Update piston position
        if (pistonsRef.current[i]) {
          pistonsRef.current[i].position.y = 1.15 - s;
        }

        // Articulate connecting rod
        if (connectingRodsRef.current[i]) {
          const crankPinY = -0.5 + Math.sin(cylTheta) * strokeRadius;
          const crankPinZ = Math.cos(cylTheta) * strokeRadius;

          const rodAngleX = Math.asin((strokeRadius / rodLength) * sinT);
          connectingRodsRef.current[i].position.y = crankPinY;
          connectingRodsRef.current[i].position.z = crankPinZ;
          connectingRodsRef.current[i].rotation.x = rodAngleX;
        }

        // Combustion flash pulsing during power stroke (near TDC 0 deg)
        if (combustionFlashesRef.current[i]) {
          const degMod = ((cylTheta * 180) / Math.PI) % 720;
          const isFiring = degMod >= 0 && degMod <= 45;
          const flashMat = combustionFlashesRef.current[i].material as THREE.MeshBasicMaterial;
          flashMat.opacity = isFiring ? 0.85 * (1 - degMod / 45) : 0.0;
        }
      }

      // 3. Spin Turbo rotor
      if (turboRotorRef.current) {
        turboRotorRef.current.rotation.x += 0.25 * (currentLive.liveState.rpm / 3000);
      }

      // 4. Flow particle animation
      if (flowParticlesRef.current && flowParticlesRef.current.visible) {
        const positions = flowParticlesRef.current.geometry.attributes.position.array as Float32Array;
        for (let p = 0; p < positions.length; p += 3) {
          positions[p] += 0.02 * (currentLive.liveState.rpm / 3000);
          if (positions[p] > 1.8) positions[p] = -1.8;
        }
        flowParticlesRef.current.geometry.attributes.position.needsUpdate = true;
      }

      controls.update();
      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      renderer.domElement.removeEventListener('pointerdown', handlePointerDown);
      renderer.domElement.removeEventListener('pointermove', handlePointerMove);
      renderer.dispose();
    };
  }, []);

  // Update view mode changes (Cutaway, Exploded, Thermal, Flow)
  useEffect(() => {
    if (!sceneRef.current) return;
    const { viewMode, thermalNodes, liveState } = state;

    // Handle exploded view separation
    if (cylinderHeadMeshRef.current && crankshaftGroupRef.current && h2RailMeshRef.current && turboMeshRef.current) {
      if (viewMode === 'EXPLODED') {
        cylinderHeadMeshRef.current.position.y = 2.8; // Head lifts up
        h2RailMeshRef.current.position.y = 3.6; // Rail lifts higher
        crankshaftGroupRef.current.position.y = -1.6; // Crank drops
        turboMeshRef.current.position.z = -2.6; // Turbo pulls out
      } else {
        cylinderHeadMeshRef.current.position.y = 1.35;
        h2RailMeshRef.current.position.y = 1.7;
        crankshaftGroupRef.current.position.y = -0.5;
        turboMeshRef.current.position.z = -1.5;
      }
    }

    // Handle Cutaway transparency
    if (engineBlockMeshRef.current && cylinderHeadMeshRef.current) {
      const isCutaway = viewMode === 'CUTAWAY';
      const isFlow = viewMode === 'FLOW';

      engineBlockMeshRef.current.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          child.material.transparent = isCutaway || isFlow;
          child.material.opacity = isCutaway ? 0.35 : isFlow ? 0.2 : 1.0;
          child.material.wireframe = isFlow;
        }
      });

      cylinderHeadMeshRef.current.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          child.material.transparent = isCutaway || isFlow;
          child.material.opacity = isCutaway ? 0.45 : isFlow ? 0.25 : 1.0;
        }
      });
    }

    // Handle Flow particles visibility
    if (flowParticlesRef.current) {
      flowParticlesRef.current.visible = viewMode === 'FLOW';
    }

    // Handle Thermal color gradient mapping
    if (pistonsRef.current && exhaustMeshRef.current && turboMeshRef.current) {
      if (viewMode === 'THERMAL') {
        // Hot piston crown color
        const tPiston = thermalNodes.pistonCrownC;
        const pistonColor = tPiston > 320 ? 0xff2200 : tPiston > 260 ? 0xff7700 : 0xffcc00;
        pistonsRef.current.forEach((p) => {
          (p.children[0] as THREE.Mesh).material = new THREE.MeshStandardMaterial({
            color: pistonColor,
            emissive: pistonColor,
            emissiveIntensity: 0.3,
            metalness: 0.6,
          });
        });

        // Glowing exhaust manifold & turbo
        const tExhaust = thermalNodes.exhaustManifoldC;
        const exColor = tExhaust > 800 ? 0xff1100 : 0xff5500;
        exhaustMeshRef.current.traverse((c) => {
          if (c instanceof THREE.Mesh) {
            c.material = new THREE.MeshStandardMaterial({
              color: exColor,
              emissive: exColor,
              emissiveIntensity: 0.5,
            });
          }
        });
      }
    }
  }, [state]);

  // Handle Camera Presets
  const setCameraView = (preset: 'ISO' | 'FRONT' | 'SIDE' | 'TOP') => {
    if (!cameraRef.current || !controlsRef.current) return;
    setCameraPreset(preset);
    const camera = cameraRef.current;
    const controls = controlsRef.current;

    switch (preset) {
      case 'ISO':
        camera.position.set(4.2, 3.2, 5.5);
        break;
      case 'FRONT':
        camera.position.set(0, 0.5, 6.2);
        break;
      case 'SIDE':
        camera.position.set(6.2, 0.5, 0);
        break;
      case 'TOP':
        camera.position.set(0, 6.8, 0.1);
        break;
    }
    controls.target.set(0, 0, 0);
    controls.update();
  };

  const resetCamera = () => setCameraView('ISO');

  return (
    <div className="relative w-full h-full min-h-[540px] bg-[#0a0c10] border border-neutral-800 rounded-xl overflow-hidden shadow-2xl flex flex-col">
      {/* 3D Viewport Canvas Container */}
      <div ref={containerRef} className="w-full flex-1 cursor-grab active:cursor-grabbing" />

      {/* Top HUD Overlay: Live Engine Telemetry Pill */}
      <div className="absolute top-4 left-4 flex flex-wrap gap-2 pointer-events-none z-10">
        <div className="bg-neutral-900/90 backdrop-blur border border-neutral-700/80 px-3.5 py-1.5 rounded-lg flex items-center gap-3 shadow-lg">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-mono font-semibold text-neutral-200">
              {state.config.engineFamily}
            </span>
          </div>
          <span className="text-neutral-600">|</span>
          <div className="text-xs font-mono text-neutral-300">
            <span className="text-neutral-400">RPM:</span>{' '}
            <span className="text-cyan-400 font-bold">{state.liveState.rpm}</span>
          </div>
          <span className="text-neutral-600">|</span>
          <div className="text-xs font-mono text-neutral-300">
            <span className="text-neutral-400">PWR:</span>{' '}
            <span className="text-amber-400 font-bold">
              {(state.liveState.powerW / 1000).toFixed(1)} kW
            </span>
          </div>
          <span className="text-neutral-600">|</span>
          <div className="text-xs font-mono text-neutral-300">
            <span className="text-neutral-400">TRQ:</span>{' '}
            <span className="text-emerald-400 font-bold">{state.liveState.torqueNm} Nm</span>
          </div>
          <span className="text-neutral-600">|</span>
          <div className="text-xs font-mono text-neutral-300">
            <span className="text-neutral-400">H₂:</span>{' '}
            <span className="text-blue-400 font-bold">{state.liveState.hydrogenFlowKgH} kg/h</span>
          </div>
        </div>

        {hoveredPart && (
          <div className="bg-cyan-950/90 border border-cyan-500/50 text-cyan-300 px-3 py-1.5 rounded-lg text-xs font-mono shadow-lg animate-fade-in flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
            <span>Target: {hoveredPart.replace(/_/g, ' ')} (Click to inspect)</span>
          </div>
        )}
      </div>

      {/* Top Right: Camera Presets & Reset */}
      <div className="absolute top-4 right-4 flex items-center gap-1.5 bg-neutral-900/90 backdrop-blur border border-neutral-700/80 p-1.5 rounded-lg z-10 shadow-lg">
        <button
          onClick={() => setCameraView('ISO')}
          className={`px-2 py-1 text-xs font-mono rounded transition-colors ${
            cameraPreset === 'ISO' ? 'bg-cyan-600 text-white' : 'text-neutral-400 hover:text-neutral-200'
          }`}
          title="Isometric View"
        >
          ISO
        </button>
        <button
          onClick={() => setCameraView('FRONT')}
          className={`px-2 py-1 text-xs font-mono rounded transition-colors ${
            cameraPreset === 'FRONT' ? 'bg-cyan-600 text-white' : 'text-neutral-400 hover:text-neutral-200'
          }`}
          title="Front View"
        >
          FRONT
        </button>
        <button
          onClick={() => setCameraView('SIDE')}
          className={`px-2 py-1 text-xs font-mono rounded transition-colors ${
            cameraPreset === 'SIDE' ? 'bg-cyan-600 text-white' : 'text-neutral-400 hover:text-neutral-200'
          }`}
          title="Side View"
        >
          SIDE
        </button>
        <button
          onClick={() => setCameraView('TOP')}
          className={`px-2 py-1 text-xs font-mono rounded transition-colors ${
            cameraPreset === 'TOP' ? 'bg-cyan-600 text-white' : 'text-neutral-400 hover:text-neutral-200'
          }`}
          title="Top View"
        >
          TOP
        </button>
        <div className="w-[1px] h-4 bg-neutral-700 mx-1" />
        <button
          onClick={resetCamera}
          className="p-1 text-neutral-400 hover:text-neutral-200 transition-colors"
          title="Reset Camera"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Bottom Floating Toolbar: View Modes */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-1.5 bg-neutral-900/95 backdrop-blur-md border border-neutral-700/90 px-2 py-1.5 rounded-xl z-10 shadow-2xl">
        <button
          onClick={() => onViewModeChange('NORMAL')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors ${
            state.viewMode === 'NORMAL'
              ? 'bg-neutral-800 text-cyan-400 border border-cyan-500/40 shadow-sm'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Eye className="w-3.5 h-3.5" />
          <span>Solid CAD</span>
        </button>

        <button
          onClick={() => onViewModeChange('CUTAWAY')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors ${
            state.viewMode === 'CUTAWAY'
              ? 'bg-neutral-800 text-cyan-400 border border-cyan-500/40 shadow-sm'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Cutaway</span>
        </button>

        <button
          onClick={() => onViewModeChange('EXPLODED')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors ${
            state.viewMode === 'EXPLODED'
              ? 'bg-neutral-800 text-cyan-400 border border-cyan-500/40 shadow-sm'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Maximize2 className="w-3.5 h-3.5" />
          <span>Exploded</span>
        </button>

        <button
          onClick={() => onViewModeChange('FLOW')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors ${
            state.viewMode === 'FLOW'
              ? 'bg-neutral-800 text-cyan-400 border border-cyan-500/40 shadow-sm'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Zap className="w-3.5 h-3.5" />
          <span>Flow / X-Ray</span>
        </button>

        <button
          onClick={() => onViewModeChange('THERMAL')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors ${
            state.viewMode === 'THERMAL'
              ? 'bg-neutral-800 text-cyan-400 border border-cyan-500/40 shadow-sm'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Flame className="w-3.5 h-3.5" />
          <span>Thermal Heatmap</span>
        </button>
      </div>
    </div>
  );
}
