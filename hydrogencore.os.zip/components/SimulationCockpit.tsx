'use client';

import React from 'react';
import { EngineStoreState } from '@/lib/engineStore';
import {
  Play,
  Pause,
  AlertTriangle,
  Flame,
  Wind,
  Gauge,
  Activity,
  RotateCcw,
  Zap,
  ShieldAlert,
} from 'lucide-react';

interface SimulationCockpitProps {
  state: EngineStoreState;
  onUpdateParam: (key: string, value: number | boolean) => void;
  onTriggerEsd: () => void;
  onApplyPreset: (preset: 'IDLE' | 'CRUISE' | 'RATED' | 'TRANSIENT') => void;
}

export function SimulationCockpit({
  state,
  onUpdateParam,
  onTriggerEsd,
  onApplyPreset,
}: SimulationCockpitProps) {
  const isEsd = state.safetyStatus.esdTriggered;

  return (
    <div className="bg-[#0f141c] border border-neutral-800/90 rounded-xl p-4 flex flex-col gap-4 text-neutral-200 shadow-xl">
      {/* Top Header & Simulation Controls */}
      <div className="flex items-center justify-between flex-wrap gap-3 pb-3 border-b border-neutral-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-neutral-800 border border-neutral-700 flex items-center justify-center text-cyan-400">
            <Gauge className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-mono uppercase tracking-wider text-neutral-400 font-semibold">
              Simulation Control Cockpit
            </h3>
            <div className="text-sm font-bold text-neutral-100 flex items-center gap-2">
              <span>{state.config.engineFamily}</span>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-950/70 border border-cyan-500/40 text-cyan-400 font-normal">
                4-Stroke SI Hydrogen Direct Injection
              </span>
            </div>
          </div>
        </div>

        {/* Playback & Emergency Controls */}
        <div className="flex items-center gap-2">
          {/* Sim Speed */}
          <div className="flex items-center bg-neutral-900 border border-neutral-800 rounded-lg p-1">
            <button
              onClick={() => onUpdateParam('simulationRunning', !state.simulationRunning)}
              className={`p-1.5 rounded text-xs font-mono flex items-center gap-1 transition-colors ${
                state.simulationRunning
                  ? 'bg-neutral-800 text-emerald-400'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
              title={state.simulationRunning ? 'Pause Engine' : 'Run Engine'}
            >
              {state.simulationRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            </button>
            <div className="w-[1px] h-4 bg-neutral-800 mx-1" />
            <button
              onClick={() => onUpdateParam('clockSpeedMultiplier', 1)}
              className={`px-2 py-1 text-xs font-mono rounded ${
                state.clockSpeedMultiplier === 1 ? 'bg-cyan-900/60 text-cyan-300 font-bold' : 'text-neutral-500'
              }`}
            >
              1x
            </button>
            <button
              onClick={() => onUpdateParam('clockSpeedMultiplier', 5)}
              className={`px-2 py-1 text-xs font-mono rounded ${
                state.clockSpeedMultiplier === 5 ? 'bg-cyan-900/60 text-cyan-300 font-bold' : 'text-neutral-500'
              }`}
            >
              5x
            </button>
          </div>

          {/* Emergency Shutdown (ESD) Button */}
          <button
            onClick={onTriggerEsd}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-bold flex items-center gap-1.5 border transition-all ${
              isEsd
                ? 'bg-red-600 text-white border-red-500 animate-pulse'
                : 'bg-red-950/40 hover:bg-red-900/60 text-red-400 border-red-800/80 hover:border-red-600'
            }`}
          >
            <ShieldAlert className="w-4 h-4" />
            <span>{isEsd ? 'ESD ACTIVE - PURGING' : 'EMERGENCY SHUTDOWN'}</span>
          </button>
        </div>
      </div>

      {/* Preset Operating Modes */}
      <div className="flex items-center gap-2 text-xs font-mono overflow-x-auto pb-1">
        <span className="text-neutral-500 text-[11px] uppercase tracking-wider">Calibration Presets:</span>
        <button
          onClick={() => onApplyPreset('IDLE')}
          className="px-2.5 py-1 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 transition-colors"
        >
          Idle (850 RPM)
        </button>
        <button
          onClick={() => onApplyPreset('CRUISE')}
          className="px-2.5 py-1 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 transition-colors"
        >
          Cruise Economy (2400 RPM)
        </button>
        <button
          onClick={() => onApplyPreset('RATED')}
          className="px-2.5 py-1 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 transition-colors"
        >
          Rated Power (6000 RPM)
        </button>
        <button
          onClick={() => onApplyPreset('TRANSIENT')}
          className="px-2.5 py-1 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 transition-colors"
        >
          WOT Overboost (6500 RPM)
        </button>
      </div>

      {/* Primary Engineering Sliders */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* RPM */}
        <div className="p-3 bg-neutral-900/80 rounded-lg border border-neutral-800 flex flex-col justify-between">
          <div className="flex justify-between items-center text-xs font-mono">
            <span className="text-neutral-400">ENGINE SPEED</span>
            <span className="text-cyan-400 font-bold">{state.rpm} RPM</span>
          </div>
          <input
            type="range"
            min={800}
            max={7000}
            step={50}
            value={state.rpm}
            onChange={(e) => onUpdateParam('rpm', Number(e.target.value))}
            className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-cyan-400 mt-3"
          />
          <div className="flex justify-between text-[10px] font-mono text-neutral-500 mt-1">
            <span>800</span>
            <span>7000</span>
          </div>
        </div>

        {/* Load Factor */}
        <div className="p-3 bg-neutral-900/80 rounded-lg border border-neutral-800 flex flex-col justify-between">
          <div className="flex justify-between items-center text-xs font-mono">
            <span className="text-neutral-400">ENGINE LOAD</span>
            <span className="text-amber-400 font-bold">{(state.loadFactor * 100).toFixed(0)}%</span>
          </div>
          <input
            type="range"
            min={0.1}
            max={1.0}
            step={0.05}
            value={state.loadFactor}
            onChange={(e) => onUpdateParam('loadFactor', Number(e.target.value))}
            className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-400 mt-3"
          />
          <div className="flex justify-between text-[10px] font-mono text-neutral-500 mt-1">
            <span>10%</span>
            <span>100% WOT</span>
          </div>
        </div>

        {/* Lambda */}
        <div className="p-3 bg-neutral-900/80 rounded-lg border border-neutral-800 flex flex-col justify-between">
          <div className="flex justify-between items-center text-xs font-mono">
            <span className="text-neutral-400">AIR-FUEL (λ)</span>
            <span className="text-blue-400 font-bold">{state.lambda.toFixed(2)}</span>
          </div>
          <input
            type="range"
            min={1.2}
            max={2.5}
            step={0.05}
            value={state.lambda}
            onChange={(e) => onUpdateParam('lambda', Number(e.target.value))}
            className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-blue-400 mt-3"
          />
          <div className="flex justify-between text-[10px] font-mono text-neutral-500 mt-1">
            <span>1.2 (Rich)</span>
            <span>2.5 (Lean)</span>
          </div>
        </div>

        {/* Boost Pressure */}
        <div className="p-3 bg-neutral-900/80 rounded-lg border border-neutral-800 flex flex-col justify-between">
          <div className="flex justify-between items-center text-xs font-mono">
            <span className="text-neutral-400">TURBO BOOST</span>
            <span className="text-emerald-400 font-bold">{state.boostBarGauge.toFixed(2)} bar</span>
          </div>
          <input
            type="range"
            min={0.2}
            max={2.2}
            step={0.1}
            value={state.boostBarGauge}
            onChange={(e) => onUpdateParam('boostBarGauge', Number(e.target.value))}
            className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-emerald-400 mt-3"
          />
          <div className="flex justify-between text-[10px] font-mono text-neutral-500 mt-1">
            <span>0.2 bar</span>
            <span>2.2 bar</span>
          </div>
        </div>

        {/* Ignition Advance */}
        <div className="p-3 bg-neutral-900/80 rounded-lg border border-neutral-800 flex flex-col justify-between">
          <div className="flex justify-between items-center text-xs font-mono">
            <span className="text-neutral-400">IGNITION ADV</span>
            <span className="text-purple-400 font-bold">{state.ignitionAdvanceDegBtdc}° BTDC</span>
          </div>
          <input
            type="range"
            min={10}
            max={30}
            step={1}
            value={state.ignitionAdvanceDegBtdc}
            onChange={(e) => onUpdateParam('ignitionAdvanceDegBtdc', Number(e.target.value))}
            className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-purple-400 mt-3"
          />
          <div className="flex justify-between text-[10px] font-mono text-neutral-500 mt-1">
            <span>10°</span>
            <span>30°</span>
          </div>
        </div>

        {/* EGR Dilution */}
        <div className="p-3 bg-neutral-900/80 rounded-lg border border-neutral-800 flex flex-col justify-between">
          <div className="flex justify-between items-center text-xs font-mono">
            <span className="text-neutral-400">EGR RATE</span>
            <span className="text-teal-400 font-bold">{state.egrPercent}%</span>
          </div>
          <input
            type="range"
            min={0}
            max={25}
            step={1}
            value={state.egrPercent}
            onChange={(e) => onUpdateParam('egrPercent', Number(e.target.value))}
            className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-teal-400 mt-3"
          />
          <div className="flex justify-between text-[10px] font-mono text-neutral-500 mt-1">
            <span>0%</span>
            <span>25%</span>
          </div>
        </div>
      </div>
    </div>
  );
}
