'use client';

import React, { useState } from 'react';
import { EngineStoreState } from '@/lib/engineStore';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  AreaChart,
  Area,
} from 'recharts';
import { Activity, Flame, Zap, Gauge, Compass, ShieldAlert, Cpu } from 'lucide-react';

interface EngineeringConsoleProps {
  state: EngineStoreState;
}

export function EngineeringConsole({ state }: EngineeringConsoleProps) {
  const [activePlot, setActivePlot] = useState<'PV' | 'PTHETA' | 'TORQUE' | 'NOX' | 'BEARING' | 'TURBO'>('PV');

  const { combustionResult, emissions, crankDynamics, vibration, turboOperating, liveState } = state;

  // Prepare P-V diagram data (Volume in cm3 vs Pressure in bar)
  const pvData = combustionResult.cycleData.map((pt) => ({
    volumeCm3: parseFloat((pt.volumeM3 * 1e6).toFixed(1)),
    pressureBar: parseFloat(pt.pressureBar.toFixed(2)),
    tempK: Math.round(pt.temperatureK),
    crankDeg: pt.crankAngleDeg,
  }));

  // Prepare P-theta data (0° to 720° crank angle)
  const pThetaData = combustionResult.cycleData.map((pt) => ({
    crankDeg: pt.crankAngleDeg,
    pressureBar: parseFloat(pt.pressureBar.toFixed(2)),
    heatReleaseRate: parseFloat(pt.heatReleaseRateJDeg.toFixed(1)),
    tempK: Math.round(pt.temperatureK),
  }));

  // Instantaneous torque vs crank angle
  const torqueData = combustionResult.cycleData.map((pt) => {
    // 4-cylinder combined instantaneous torque approximation
    const thetaRad = (pt.crankAngleDeg * Math.PI) / 180;
    const singleCylTorque = Math.sin(thetaRad) * (pt.pressureBar * 12);
    // Combined 4-cylinder firing every 180°
    const multiCylTorque = singleCylTorque + Math.sin(2 * thetaRad) * 45 + liveState.torqueNm;
    return {
      crankDeg: pt.crankAngleDeg,
      instantaneousTorqueNm: parseFloat(Math.max(0, multiCylTorque).toFixed(1)),
      meanTorqueNm: liveState.torqueNm,
    };
  });

  return (
    <div className="flex flex-col gap-5 p-4 bg-[#0d1117] text-neutral-200">
      {/* Top Engineering KPIs Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-3.5 bg-neutral-900/90 rounded-xl border border-neutral-800">
          <div className="text-[11px] font-mono text-neutral-400 flex items-center justify-between">
            <span>IMEP (Indicated)</span>
            <Gauge className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-xl font-bold text-cyan-400 font-mono mt-1">
            {liveState.imepBar.toFixed(2)}{' '}
            <span className="text-xs text-neutral-400 font-normal">bar</span>
          </div>
          <div className="text-[10px] font-mono text-neutral-500 mt-1">
            BMEP: {liveState.bmepBar.toFixed(2)} | FMEP: {liveState.fmepBar.toFixed(2)}
          </div>
        </div>

        <div className="p-3.5 bg-neutral-900/90 rounded-xl border border-neutral-800">
          <div className="text-[11px] font-mono text-neutral-400 flex items-center justify-between">
            <span>BRAKE EFFICIENCY</span>
            <Activity className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-xl font-bold text-emerald-400 font-mono mt-1">
            {liveState.thermalEfficiency.toFixed(1)}{' '}
            <span className="text-xs text-neutral-400 font-normal">% BTE</span>
          </div>
          <div className="text-[10px] font-mono text-neutral-500 mt-1">
            BSFC: {( (liveState.hydrogenFlowKgH * 1000) / (liveState.powerW / 1000) ).toFixed(1)} g/kWh H₂
          </div>
        </div>

        <div className="p-3.5 bg-neutral-900/90 rounded-xl border border-neutral-800">
          <div className="text-[11px] font-mono text-neutral-400 flex items-center justify-between">
            <span>PEAK CYL PRESSURE</span>
            <Flame className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-xl font-bold text-amber-400 font-mono mt-1">
            {combustionResult.peakPressureBar.toFixed(1)}{' '}
            <span className="text-xs text-neutral-400 font-normal">bar</span>
          </div>
          <div className="text-[10px] font-mono text-neutral-500 mt-1">
            Location: {combustionResult.peakPressureAngleDeg}° ATDC
          </div>
        </div>

        <div className="p-3.5 bg-neutral-900/90 rounded-xl border border-neutral-800">
          <div className="text-[11px] font-mono text-neutral-400 flex items-center justify-between">
            <span>THERMAL NOx</span>
            <Zap className="w-3.5 h-3.5 text-purple-400" />
          </div>
          <div className="text-xl font-bold text-purple-400 font-mono mt-1">
            {emissions.totalNoxGPerKwh.toFixed(3)}{' '}
            <span className="text-xs text-neutral-400 font-normal">g/kWh</span>
          </div>
          <div className="text-[10px] font-mono text-neutral-500 mt-1">
            Euro VII limit: 0.20 | NO: {emissions.noPpm} ppm
          </div>
        </div>

        <div className="p-3.5 bg-neutral-900/90 rounded-xl border border-neutral-800">
          <div className="text-[11px] font-mono text-neutral-400 flex items-center justify-between">
            <span>BEARING OIL FILM</span>
            <Compass className="w-3.5 h-3.5 text-blue-400" />
          </div>
          <div className="text-xl font-bold text-blue-400 font-mono mt-1">
            {crankDynamics.bearingMinimumOilFilmUm.toFixed(2)}{' '}
            <span className="text-xs text-neutral-400 font-normal">µm</span>
          </div>
          <div className="text-[10px] font-mono text-neutral-500 mt-1">
            Buckling Margin: {crankDynamics.connectingRodBucklingMargin.toFixed(1)}x
          </div>
        </div>

        <div className="p-3.5 bg-neutral-900/90 rounded-xl border border-neutral-800">
          <div className="text-[11px] font-mono text-neutral-400 flex items-center justify-between">
            <span>BACKFIRE RISK</span>
            <ShieldAlert className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-xl font-bold text-emerald-400 font-mono mt-1">
            {emissions.backfireRisk}
          </div>
          <div className="text-[10px] font-mono text-neutral-500 mt-1">
            Pre-ignition Index: {emissions.preIgnitionRiskIndex.toFixed(2)}
          </div>
        </div>
      </div>

      {/* Plot Selector Tabs */}
      <div className="flex items-center gap-2 border-b border-neutral-800 pb-2 overflow-x-auto text-xs font-mono">
        <button
          onClick={() => setActivePlot('PV')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            activePlot === 'PV'
              ? 'bg-cyan-950 text-cyan-400 border border-cyan-500/40 font-bold'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
          }`}
        >
          P-V Thermodynamic Indicator Diagram
        </button>
        <button
          onClick={() => setActivePlot('PTHETA')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            activePlot === 'PTHETA'
              ? 'bg-cyan-950 text-cyan-400 border border-cyan-500/40 font-bold'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
          }`}
        >
          P(θ) Pressure & Wiebe Heat Release Rate
        </button>
        <button
          onClick={() => setActivePlot('TORQUE')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            activePlot === 'TORQUE'
              ? 'bg-cyan-950 text-cyan-400 border border-cyan-500/40 font-bold'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
          }`}
        >
          Instantaneous Crank Torque & Ripple
        </button>
        <button
          onClick={() => setActivePlot('TURBO')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            activePlot === 'TURBO'
              ? 'bg-cyan-950 text-cyan-400 border border-cyan-500/40 font-bold'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
          }`}
        >
          Compressor Map & Operating Point
        </button>
      </div>

      {/* Dynamic Graph Container */}
      <div className="h-80 w-full bg-neutral-900/60 p-4 rounded-xl border border-neutral-800 flex flex-col justify-between">
        {activePlot === 'PV' && (
          <>
            <div className="flex justify-between items-center text-xs font-mono text-neutral-400 mb-2">
              <span className="font-semibold text-neutral-200">
                P-V INDICATOR DIAGRAM [W_net = {combustionResult.indicatedWorkPerCylinderJ.toFixed(1)} J / cyl]
              </span>
              <span>X: Cylinder Volume (cm³) | Y: Absolute Pressure (bar)</span>
            </div>
            <ResponsiveContainer width="100%" height="90%">
              <AreaChart data={pvData}>
                <defs>
                  <linearGradient id="pvFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00e5ff" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#00e5ff" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" />
                <XAxis dataKey="volumeCm3" stroke="#737373" tick={{ fontSize: 11 }} />
                <YAxis stroke="#737373" tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#171717', borderColor: '#404040', fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="pressureBar" stroke="#00e5ff" fill="url(#pvFill)" strokeWidth={2} name="Pressure (bar)" />
              </AreaChart>
            </ResponsiveContainer>
          </>
        )}

        {activePlot === 'PTHETA' && (
          <>
            <div className="flex justify-between items-center text-xs font-mono text-neutral-400 mb-2">
              <span className="font-semibold text-neutral-200">
                CRANK-ANGLE RESOLVED COMBUSTION [0° = TDC Expansion | 180° = BDC | 360° = TDC Exhaust | 540° = BDC Intake]
              </span>
              <span>Ignition: {state.ignitionAdvanceDegBtdc}° BTDC | Peak: {combustionResult.peakPressureBar.toFixed(1)} bar</span>
            </div>
            <ResponsiveContainer width="100%" height="90%">
              <LineChart data={pThetaData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" />
                <XAxis dataKey="crankDeg" stroke="#737373" tick={{ fontSize: 11 }} />
                <YAxis yAxisId="left" stroke="#00e5ff" tick={{ fontSize: 11 }} />
                <YAxis yAxisId="right" orientation="right" stroke="#f59e0b" tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#171717', borderColor: '#404040', fontSize: '12px' }}
                />
                <ReferenceLine yAxisId="left" x={720 - state.ignitionAdvanceDegBtdc} stroke="#a855f7" strokeDasharray="3 3" label="Spark" />
                <Line yAxisId="left" type="monotone" dataKey="pressureBar" stroke="#00e5ff" strokeWidth={2} dot={false} name="Pressure (bar)" />
                <Line yAxisId="right" type="monotone" dataKey="heatReleaseRate" stroke="#f59e0b" strokeWidth={1.5} dot={false} name="Heat Release dQ/dθ (J/deg)" />
              </LineChart>
            </ResponsiveContainer>
          </>
        )}

        {activePlot === 'TORQUE' && (
          <>
            <div className="flex justify-between items-center text-xs font-mono text-neutral-400 mb-2">
              <span className="font-semibold text-neutral-200">
                INSTANTANEOUS CRANKSHAFT TORQUE RIPPLE [Mean Torque: {liveState.torqueNm} Nm]
              </span>
              <span>Primary Firing Order: 1 - 3 - 4 - 2</span>
            </div>
            <ResponsiveContainer width="100%" height="90%">
              <LineChart data={torqueData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" />
                <XAxis dataKey="crankDeg" stroke="#737373" tick={{ fontSize: 11 }} />
                <YAxis stroke="#10b981" tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#171717', borderColor: '#404040', fontSize: '12px' }}
                />
                <ReferenceLine y={liveState.torqueNm} stroke="#00e5ff" strokeDasharray="4 4" label="Mean Torque" />
                <Line type="monotone" dataKey="instantaneousTorqueNm" stroke="#10b981" strokeWidth={2} dot={false} name="Instantaneous Torque (Nm)" />
              </LineChart>
            </ResponsiveContainer>
          </>
        )}

        {activePlot === 'TURBO' && (
          <div className="flex flex-col h-full justify-between font-mono text-xs">
            <div className="flex justify-between items-center text-neutral-400">
              <span className="font-semibold text-neutral-200">TURBOCHARGER COMPRESSOR OPERATING ENVELOPE</span>
              <span>Shaft Speed: {Math.round(turboOperating.shaftSpeedRpm)} RPM</span>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 my-auto">
              <div className="p-3 bg-neutral-900 rounded-lg border border-neutral-800">
                <span className="text-neutral-500 block text-[10px]">PRESSURE RATIO (PR)</span>
                <span className="text-lg font-bold text-cyan-400">{turboOperating.pressureRatio.toFixed(2)}:1</span>
              </div>
              <div className="p-3 bg-neutral-900 rounded-lg border border-neutral-800">
                <span className="text-neutral-500 block text-[10px]">CORRECTED MASS FLOW</span>
                <span className="text-lg font-bold text-amber-400">{turboOperating.correctedMassFlowKgS.toFixed(3)} kg/s</span>
              </div>
              <div className="p-3 bg-neutral-900 rounded-lg border border-neutral-800">
                <span className="text-neutral-500 block text-[10px]">ISENTROPIC EFFICIENCY</span>
                <span className="text-lg font-bold text-emerald-400">{(turboOperating.efficiency * 100).toFixed(1)}%</span>
              </div>
              <div className="p-3 bg-neutral-900 rounded-lg border border-neutral-800">
                <span className="text-neutral-500 block text-[10px]">AERODYNAMIC MARGIN</span>
                <span className={`text-lg font-bold ${turboOperating.isSurge ? 'text-red-400' : 'text-emerald-400'}`}>
                  {turboOperating.isSurge ? 'SURGE LIMIT DETECTED' : 'OPTIMAL CORE ISLAND'}
                </span>
              </div>
            </div>

            <div className="p-2.5 bg-neutral-950/60 rounded border border-neutral-800 text-[11px] text-neutral-400">
              Charge Air Cooler (Intercooler): Inlet Temp: 142°C | Outlet Temp: 38°C | Core Effectiveness: 85.0% | Heat Rejection: 22.4 kW
            </div>
          </div>
        )}
      </div>

      {/* Vibration FFT Order Spectrum */}
      <div className="p-4 bg-neutral-900/60 rounded-xl border border-neutral-800">
        <div className="flex items-center justify-between text-xs font-mono mb-3">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-cyan-400" />
            <span className="font-bold text-neutral-200">VIBRATION ORDER SPECTRUM & HARMONICS ANALYSIS</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-neutral-400">Overall RMS:</span>
            <span className="text-emerald-400 font-bold">{vibration.overallRmsMmS} mm/s</span>
            <span className="px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 font-bold">
              {vibration.severityRating}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-6 gap-2">
          {vibration.orders.map((o) => (
            <div key={o.order} className="p-2.5 bg-neutral-900 rounded-lg border border-neutral-800 font-mono text-xs">
              <div className="text-neutral-400 text-[10px] truncate">{o.order}</div>
              <div className="text-sm font-bold text-cyan-400 mt-1">{o.amplitudeMmS} mm/s</div>
              <div className="text-[10px] text-neutral-500">{o.frequencyHz} Hz</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
