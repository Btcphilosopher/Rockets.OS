'use client';

import React, { useMemo } from 'react';
import { EngineStoreState } from '@/lib/engineStore';
import { DynoTestCell } from '@/lib/testcell/dynoSimulator';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import { Activity, CheckCircle2, ShieldCheck, Zap, Gauge, Flame, AlertCircle } from 'lucide-react';

interface TestCellConsoleProps {
  state: EngineStoreState;
}

export function TestCellConsole({ state }: TestCellConsoleProps) {
  const dynoReport = useMemo(() => {
    return DynoTestCell.generateDynoComparison(
      state.config.boreM,
      state.config.strokeM,
      state.boostBarGauge,
      state.lambda
    );
  }, [state.config.boreM, state.config.strokeM, state.boostBarGauge, state.lambda]);

  return (
    <div className="flex flex-col gap-5 p-4 bg-[#0d1117] text-neutral-200">
      {/* Test Cell Header Banner */}
      <div className="p-4 bg-neutral-900/90 rounded-xl border border-neutral-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 font-bold">
              AVL PUMA 2 HYDROGEN AUTOMATED TEST RIG
            </span>
          </div>
          <h3 className="text-base font-bold text-neutral-100 mt-1">
            Engine Test Run: {dynoReport.testRunId}
          </h3>
          <p className="text-xs font-mono text-neutral-400 mt-0.5">
            11-Point Full Load WOT Power & Emissions Verification | Unit Serial: {state.config.engineId}
          </p>
        </div>

        {/* Validation Badges */}
        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="p-2.5 bg-neutral-950/80 rounded-lg border border-neutral-800 text-center">
            <span className="text-neutral-500 block text-[10px]">CORRELATION</span>
            <span className="text-emerald-400 font-bold text-base">{dynoReport.overallCorrelationPercent}%</span>
          </div>
          <div className="p-2.5 bg-neutral-950/80 rounded-lg border border-neutral-800 text-center">
            <span className="text-neutral-500 block text-[10px]">RMSE POWER</span>
            <span className="text-cyan-400 font-bold text-base">{dynoReport.rmsePowerKw} kW</span>
          </div>
          <div className="p-2.5 bg-neutral-950/80 rounded-lg border border-neutral-800 text-center">
            <span className="text-neutral-500 block text-[10px]">MAE TORQUE</span>
            <span className="text-amber-400 font-bold text-base">{dynoReport.maeTorqueNm} Nm</span>
          </div>
          <div className="px-3 py-2 rounded-lg bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 font-bold flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4" />
            CERTIFIED
          </div>
        </div>
      </div>

      {/* Dyno Comparison Chart */}
      <div className="p-5 bg-neutral-900/80 rounded-xl border border-neutral-800">
        <div className="flex justify-between items-center text-xs font-mono text-neutral-400 mb-3">
          <span className="font-bold text-neutral-100">
            SIMULATION VS MEASURED DYNO CURVES [Power & Torque vs RPM]
          </span>
          <span className="text-neutral-400">Solid lines: Measured Dyno | Dashed: Simulation Model</span>
        </div>

        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={dynoReport.points}>
              <CartesianGrid strokeDasharray="3 3" stroke="#262626" />
              <XAxis dataKey="rpm" stroke="#737373" tick={{ fontSize: 11 }} />
              <YAxis yAxisId="power" stroke="#f59e0b" tick={{ fontSize: 11 }} label={{ value: 'Power (kW)', angle: -90, position: 'insideLeft', fill: '#f59e0b', fontSize: 10 }} />
              <YAxis yAxisId="torque" orientation="right" stroke="#00e5ff" tick={{ fontSize: 11 }} label={{ value: 'Torque (Nm)', angle: 90, position: 'insideRight', fill: '#00e5ff', fontSize: 10 }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#171717', borderColor: '#404040', fontSize: '12px' }}
              />
              <Legend wrapperStyle={{ fontSize: '11px', fontFamily: 'monospace' }} />
              
              {/* Power curves */}
              <Line yAxisId="power" type="monotone" dataKey="measuredPowerKw" stroke="#f59e0b" strokeWidth={2.5} name="Measured Dyno Power (kW)" dot={{ r: 3 }} />
              <Line yAxisId="power" type="monotone" dataKey="simPowerKw" stroke="#d97706" strokeWidth={1.8} strokeDasharray="4 4" name="Sim Model Power (kW)" dot={false} />

              {/* Torque curves */}
              <Line yAxisId="torque" type="monotone" dataKey="measuredTorqueNm" stroke="#00e5ff" strokeWidth={2.5} name="Measured Dyno Torque (Nm)" dot={{ r: 3 }} />
              <Line yAxisId="torque" type="monotone" dataKey="simTorqueNm" stroke="#0284c7" strokeWidth={1.8} strokeDasharray="4 4" name="Sim Model Torque (Nm)" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Sweep Data Table */}
      <div className="bg-neutral-900/80 rounded-xl border border-neutral-800 overflow-hidden">
        <div className="p-3.5 border-b border-neutral-800 flex justify-between items-center text-xs font-mono">
          <span className="font-bold text-neutral-200">
            11-POINT CERTIFICATION HARNESS DATA ACQUISITION LOG
          </span>
          <span className="text-neutral-400">Peak Brake Power: {dynoReport.peakPowerKw} kW @ 6000 RPM</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-neutral-950 text-neutral-400 uppercase text-[10px]">
              <tr>
                <th className="p-3">RPM</th>
                <th className="p-3">Sim Pwr (kW)</th>
                <th className="p-3">Dyno Pwr (kW)</th>
                <th className="p-3">Pwr Err (%)</th>
                <th className="p-3">Sim Trq (Nm)</th>
                <th className="p-3">Dyno Trq (Nm)</th>
                <th className="p-3">H₂ Flow (kg/h)</th>
                <th className="p-3">NOx (g/kWh)</th>
                <th className="p-3">Exhaust (°C)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800">
              {dynoReport.points.map((pt) => (
                <tr key={pt.rpm} className="hover:bg-neutral-800/40 transition-colors">
                  <td className="p-3 text-cyan-400 font-bold">{pt.rpm}</td>
                  <td className="p-3 text-neutral-300">{pt.simPowerKw}</td>
                  <td className="p-3 text-amber-400 font-bold">{pt.measuredPowerKw}</td>
                  <td className="p-3 text-emerald-400">{pt.powerErrorPercent}%</td>
                  <td className="p-3 text-neutral-300">{pt.simTorqueNm}</td>
                  <td className="p-3 text-cyan-400 font-bold">{pt.measuredTorqueNm}</td>
                  <td className="p-3 text-neutral-300">{pt.measuredHydrogenKgH}</td>
                  <td className="p-3 text-purple-400">{pt.measuredNoxGPerKwh}</td>
                  <td className="p-3 text-neutral-400">{pt.measuredExhaustTempC} °C</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
