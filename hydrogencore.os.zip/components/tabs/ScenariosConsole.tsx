'use client';

import React from 'react';
import { EngineStoreState, ActiveFaults } from '@/lib/engineStore';
import {
  AlertTriangle,
  RotateCcw,
  ShieldAlert,
  Flame,
  Droplets,
  Activity,
  Gauge,
  CheckCircle2,
  Zap,
} from 'lucide-react';

interface ScenariosConsoleProps {
  state: EngineStoreState;
  onToggleFault: (faultKey: keyof ActiveFaults) => void;
  onResetAllFaults: () => void;
}

export function ScenariosConsole({ state, onToggleFault, onResetAllFaults }: ScenariosConsoleProps) {
  const { activeFaults, liveState, thermalNodes, emissions, vibration, safetyStatus } = state;

  const anyFaultActive = Object.values(activeFaults).some((v) => v);

  return (
    <div className="flex flex-col gap-5 p-4 bg-[#0d1117] text-neutral-200">
      {/* Top Banner */}
      <div className="p-4 bg-neutral-900/90 rounded-xl border border-neutral-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${anyFaultActive ? 'bg-amber-400 animate-ping' : 'bg-emerald-400'}`} />
            <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 font-bold">
              FAULT INJECTION & PROPAGATION CAUSALITY ENGINE
            </span>
          </div>
          <h3 className="text-base font-bold text-neutral-100 mt-1">
            Operational Health & Diagnostic Scenarios
          </h3>
          <p className="text-xs font-mono text-neutral-400 mt-0.5">
            Inject deterministic hardware failures to observe multi-physics causal propagation across the digital twin.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-neutral-950/80 rounded-lg border border-neutral-800 text-right font-mono text-xs">
            <span className="text-neutral-500 block text-[10px]">HEALTH SCORE</span>
            <span className={`text-xl font-bold ${
              liveState.overallHealthScore > 85
                ? 'text-emerald-400'
                : liveState.overallHealthScore > 60
                ? 'text-amber-400'
                : 'text-red-400'
            }`}>
              {liveState.overallHealthScore}%
            </span>
          </div>

          <button
            onClick={onResetAllFaults}
            disabled={!anyFaultActive}
            className={`px-4 py-2 rounded-lg text-xs font-mono font-bold flex items-center gap-2 border transition-all ${
              anyFaultActive
                ? 'bg-cyan-950/60 hover:bg-cyan-900/80 text-cyan-300 border-cyan-700 cursor-pointer'
                : 'bg-neutral-900 text-neutral-600 border-neutral-800 cursor-not-allowed'
            }`}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset All Baseline</span>
          </button>
        </div>
      </div>

      {/* Fault Injection Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Fault 1: Injector Restriction */}
        <div className={`p-4 rounded-xl border transition-all font-mono text-xs flex flex-col justify-between ${
          activeFaults.injectorRestriction
            ? 'bg-amber-950/30 border-amber-500/60 shadow-lg'
            : 'bg-neutral-900/70 border-neutral-800 hover:border-neutral-700'
        }`}>
          <div>
            <div className="flex justify-between items-start">
              <span className="font-bold text-neutral-100 flex items-center gap-2">
                <Zap className="w-4 h-4 text-cyan-400" />
                H₂ Injector Orifice Restriction
              </span>
              <button
                onClick={() => onToggleFault('injectorRestriction')}
                className={`px-3 py-1 rounded text-[11px] font-bold transition-colors ${
                  activeFaults.injectorRestriction
                    ? 'bg-amber-500 text-black'
                    : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'
                }`}
              >
                {activeFaults.injectorRestriction ? 'ACTIVE' : 'INJECT'}
              </button>
            </div>
            <p className="text-[11px] text-neutral-400 mt-2 leading-relaxed">
              Partially clogged nozzle in Cylinder #1. Creates localized lean-out, torque imbalance, and generates a 0.5X / 1.0X rotational vibration spike.
            </p>
          </div>

          <div className="mt-3 pt-3 border-t border-neutral-800/80 text-[10px] text-neutral-500">
            <span className="text-amber-400 font-semibold">Causal Chain: </span>
            Aperture restriction → Flow drop → Localized λ lean spike → Torque ripple ↑ → Vibration 1X: {vibration.orders[1].amplitudeMmS} mm/s
          </div>
        </div>

        {/* Fault 2: Coolant Pump Failure */}
        <div className={`p-4 rounded-xl border transition-all font-mono text-xs flex flex-col justify-between ${
          activeFaults.coolantPumpDegradation
            ? 'bg-red-950/30 border-red-500/60 shadow-lg'
            : 'bg-neutral-900/70 border-neutral-800 hover:border-neutral-700'
        }`}>
          <div>
            <div className="flex justify-between items-start">
              <span className="font-bold text-neutral-100 flex items-center gap-2">
                <Droplets className="w-4 h-4 text-blue-400" />
                Cooling Pump Impeller Degradation
              </span>
              <button
                onClick={() => onToggleFault('coolantPumpDegradation')}
                className={`px-3 py-1 rounded text-[11px] font-bold transition-colors ${
                  activeFaults.coolantPumpDegradation
                    ? 'bg-red-500 text-white'
                    : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'
                }`}
              >
                {activeFaults.coolantPumpDegradation ? 'ACTIVE' : 'INJECT'}
              </button>
            </div>
            <p className="text-[11px] text-neutral-400 mt-2 leading-relaxed">
              Coolant flow drops from 75 to 18 L/min. Head and liner temperatures surge, raising combustion chamber wall temperatures and triggering exponential NOx generation.
            </p>
          </div>

          <div className="mt-3 pt-3 border-t border-neutral-800/80 text-[10px] text-neutral-500">
            <span className="text-red-400 font-semibold">Causal Chain: </span>
            Coolant flow loss → Head Temp: {thermalNodes.cylinderHeadDeckC}°C → T_flame ↑ → Zeldovich NOx Surge: {emissions.totalNoxGPerKwh} g/kWh
          </div>
        </div>

        {/* Fault 3: Hydrogen Supply Pressure Loss */}
        <div className={`p-4 rounded-xl border transition-all font-mono text-xs flex flex-col justify-between ${
          activeFaults.hydrogenPressureLoss
            ? 'bg-purple-950/30 border-purple-500/60 shadow-lg'
            : 'bg-neutral-900/70 border-neutral-800 hover:border-neutral-700'
        }`}>
          <div>
            <div className="flex justify-between items-start">
              <span className="font-bold text-neutral-100 flex items-center gap-2">
                <Gauge className="w-4 h-4 text-purple-400" />
                Hydrogen Rail Pressure Collapse
              </span>
              <button
                onClick={() => onToggleFault('hydrogenPressureLoss')}
                className={`px-3 py-1 rounded text-[11px] font-bold transition-colors ${
                  activeFaults.hydrogenPressureLoss
                    ? 'bg-purple-500 text-white'
                    : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'
                }`}
              >
                {activeFaults.hydrogenPressureLoss ? 'ACTIVE' : 'INJECT'}
              </button>
            </div>
            <p className="text-[11px] text-neutral-400 mt-2 leading-relaxed">
              Pressure drops from 350 to 180 bar. Injector reaches maximum 100% duty cycle window. ECU enters limp mode, curtailing turbo boost and load.
            </p>
          </div>

          <div className="mt-3 pt-3 border-t border-neutral-800/80 text-[10px] text-neutral-500">
            <span className="text-purple-400 font-semibold">Causal Chain: </span>
            Supply pressure loss → Choked mass flow → Duty saturation → Power derated to {(liveState.powerW / 1000).toFixed(0)} kW
          </div>
        </div>

        {/* Fault 4: Hydrogen Leak in Enclosure */}
        <div className={`p-4 rounded-xl border transition-all font-mono text-xs flex flex-col justify-between ${
          activeFaults.hydrogenLeak
            ? 'bg-red-950/40 border-red-500/80 shadow-lg animate-pulse'
            : 'bg-neutral-900/70 border-neutral-800 hover:border-neutral-700'
        }`}>
          <div>
            <div className="flex justify-between items-start">
              <span className="font-bold text-neutral-100 flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-red-400" />
                H₂ Enclosure Gas Leak (&gt;10% LFL)
              </span>
              <button
                onClick={() => onToggleFault('hydrogenLeak')}
                className={`px-3 py-1 rounded text-[11px] font-bold transition-colors ${
                  activeFaults.hydrogenLeak
                    ? 'bg-red-600 text-white'
                    : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'
                }`}
              >
                {activeFaults.hydrogenLeak ? 'ACTIVE' : 'INJECT'}
              </button>
            </div>
            <p className="text-[11px] text-neutral-400 mt-2 leading-relaxed">
              Leak detection in test bay reaches 6,200 ppm (15.5% LFL). Safety state elevates to WARNING, initiating forced boost ventilation and arming ESD isolation valve.
            </p>
          </div>

          <div className="mt-3 pt-3 border-t border-neutral-800/80 text-[10px] text-neutral-500">
            <span className="text-red-400 font-semibold">Causal Chain: </span>
            Fittings micro-leak → Concentration {safetyStatus.enclosureH2Ppm} PPM ({safetyStatus.percentLfl}% LFL) → Boost Ventilation Active
          </div>
        </div>

        {/* Fault 5: Hydrodynamic Bearing Wear */}
        <div className={`p-4 rounded-xl border transition-all font-mono text-xs flex flex-col justify-between ${
          activeFaults.bearingWear
            ? 'bg-amber-950/30 border-amber-500/60 shadow-lg'
            : 'bg-neutral-900/70 border-neutral-800 hover:border-neutral-700'
        }`}>
          <div>
            <div className="flex justify-between items-start">
              <span className="font-bold text-neutral-100 flex items-center gap-2">
                <Activity className="w-4 h-4 text-amber-400" />
                Main Bearing Hydrodynamic Wear
              </span>
              <button
                onClick={() => onToggleFault('bearingWear')}
                className={`px-3 py-1 rounded text-[11px] font-bold transition-colors ${
                  activeFaults.bearingWear
                    ? 'bg-amber-500 text-black'
                    : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'
                }`}
              >
                {activeFaults.bearingWear ? 'ACTIVE' : 'INJECT'}
              </button>
            </div>
            <p className="text-[11px] text-neutral-400 mt-2 leading-relaxed">
              Radial bearing clearance increases to 45 µm. Minimum oil film thickness collapses below 1.0 µm, causing oil pressure drop and high 1X rotational vibration.
            </p>
          </div>

          <div className="mt-3 pt-3 border-t border-neutral-800/80 text-[10px] text-neutral-500">
            <span className="text-amber-400 font-semibold">Causal Chain: </span>
            Clearance growth → Sommerfeld S ↓ → Oil Film: {state.crankDynamics.bearingMinimumOilFilmUm.toFixed(2)} µm → Oil Press: {liveState.oilPressureBar} bar
          </div>
        </div>

        {/* Fault 6: Combustion Misfire */}
        <div className={`p-4 rounded-xl border transition-all font-mono text-xs flex flex-col justify-between ${
          activeFaults.misfire
            ? 'bg-red-950/30 border-red-500/60 shadow-lg'
            : 'bg-neutral-900/70 border-neutral-800 hover:border-neutral-700'
        }`}>
          <div>
            <div className="flex justify-between items-start">
              <span className="font-bold text-neutral-100 flex items-center gap-2">
                <Flame className="w-4 h-4 text-red-400" />
                Cylinder Spark Misfire
              </span>
              <button
                onClick={() => onToggleFault('misfire')}
                className={`px-3 py-1 rounded text-[11px] font-bold transition-colors ${
                  activeFaults.misfire
                    ? 'bg-red-500 text-white'
                    : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'
                }`}
              >
                {activeFaults.misfire ? 'ACTIVE' : 'INJECT'}
              </button>
            </div>
            <p className="text-[11px] text-neutral-400 mt-2 leading-relaxed">
              Spark coil failure in Cylinder #4. Unburned hydrogen vents into exhaust, triggering extreme sub-synchronous vibration order 0.5X and severe power loss.
            </p>
          </div>

          <div className="mt-3 pt-3 border-t border-neutral-800/80 text-[10px] text-neutral-500">
            <span className="text-red-400 font-semibold">Causal Chain: </span>
            Ignition failure → Power drops → 0.5X vibration jumps to {vibration.orders[0].amplitudeMmS} mm/s → H2 slip surge
          </div>
        </div>
      </div>
    </div>
  );
}
