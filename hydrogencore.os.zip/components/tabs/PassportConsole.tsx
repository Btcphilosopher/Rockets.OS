'use client';

import React, { useState } from 'react';
import { REFERENCE_PASSPORT } from '@/lib/quality/passport';
import { TraceabilityEngine, RecallSearchResult } from '@/lib/quality/recall';
import {
  FileBadge,
  ShieldCheck,
  CheckCircle2,
  Lock,
  Search,
  AlertTriangle,
  Layers,
  Cpu,
  Barcode,
} from 'lucide-react';

export function PassportConsole() {
  const passport = REFERENCE_PASSPORT;
  const [batchQuery, setBatchQuery] = useState<string>('BAT-H2INJ-350-09');
  const [recallResult, setRecallResult] = useState<RecallSearchResult | null>(null);

  const handleTraceBatch = (e: React.FormEvent) => {
    e.preventDefault();
    const result = TraceabilityEngine.traceComponentBatch(batchQuery);
    setRecallResult(result);
  };

  return (
    <div className="flex flex-col gap-5 p-4 bg-[#0d1117] text-neutral-200">
      {/* Passport Header Certificate Card */}
      <div className="p-5 bg-gradient-to-r from-neutral-900 via-neutral-900/90 to-neutral-950 rounded-xl border border-neutral-800 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6 opacity-10 pointer-events-none">
          <FileBadge className="w-48 h-48 text-cyan-400" />
        </div>

        <div className="relative z-10 flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
              <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 font-bold">
                ENGINE DIGITAL PASSPORT & CERTIFICATE OF CONFORMANCE
              </span>
            </div>
            <h2 className="text-xl font-bold text-neutral-100 mt-1 font-mono">
              SERIAL NO: {passport.engineSerialNumber}
            </h2>
            <p className="text-xs font-mono text-neutral-400 mt-0.5">
              Engine Family: {passport.engineFamily} | Released: {passport.releasedDate}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-3 bg-neutral-950/80 rounded-lg border border-neutral-800 text-right font-mono">
              <span className="text-neutral-500 block text-[10px]">CONFORMANCE SCORE</span>
              <span className="text-xl font-bold text-emerald-400">{passport.overallScore}%</span>
            </div>
            <div className="p-3 bg-emerald-950/70 border border-emerald-500/40 rounded-lg flex items-center gap-2 text-emerald-400 text-xs font-mono font-bold">
              <ShieldCheck className="w-5 h-5" />
              <span>PASSPORT SEALED & VALIDATED</span>
            </div>
          </div>
        </div>

        {/* Cryptographic SHA-256 Signature */}
        <div className="mt-4 p-3 bg-neutral-950/80 rounded border border-neutral-800 flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-2">
            <Lock className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-neutral-400">CRYPTOGRAPHIC HASH:</span>
            <span className="text-neutral-300 truncate max-w-md">{passport.hashSignature}</span>
          </div>
          <span className="text-[10px] text-neutral-500">IMMUTABLE LEDGER RECORD</span>
        </div>
      </div>

      {/* Quality Gates QG-01 through QG-07 */}
      <div className="p-4 bg-neutral-900/80 rounded-xl border border-neutral-800">
        <h3 className="text-xs font-mono font-bold text-neutral-200 uppercase tracking-wider mb-3 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          MANDATORY PRODUCTION QUALITY GATES (100% PASS)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 font-mono text-xs">
          {passport.qualityGates.map((qg) => (
            <div key={qg.gateId} className="p-3 bg-neutral-950/70 rounded-lg border border-neutral-800 flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start">
                  <span className="text-cyan-400 font-bold text-[11px]">{qg.gateId}</span>
                  <span className="text-emerald-400 font-bold text-[11px]">{qg.scorePercent}%</span>
                </div>
                <h4 className="font-bold text-neutral-100 mt-1">{qg.name}</h4>
                <p className="text-[11px] text-neutral-400 mt-1">{qg.details}</p>
              </div>
              <div className="text-[10px] text-neutral-500 mt-3 pt-2 border-t border-neutral-900">
                Sign-off: {qg.inspectedBy}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bill of Materials & Subcomponent Serialization */}
      <div className="bg-neutral-900/80 rounded-xl border border-neutral-800 overflow-hidden">
        <div className="p-3.5 border-b border-neutral-800 flex justify-between items-center text-xs font-mono">
          <span className="font-bold text-neutral-200 flex items-center gap-2">
            <Cpu className="w-4 h-4 text-cyan-400" />
            CRITICAL COMPONENT DIGITAL THREAD SERIALIZATION
          </span>
          <span className="text-neutral-400">8 of 8 Primary Assemblies Traced</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-neutral-950 text-neutral-400 uppercase text-[10px]">
              <tr>
                <th className="p-3">Component</th>
                <th className="p-3">Part Number</th>
                <th className="p-3">Serial Number</th>
                <th className="p-3">Material Specification</th>
                <th className="p-3">Batch ID</th>
                <th className="p-3">Tier-1 Supplier</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800">
              {passport.criticalComponents.map((c) => (
                <tr key={c.serialNumber} className="hover:bg-neutral-800/40 transition-colors">
                  <td className="p-3 text-neutral-100 font-bold">{c.partName}</td>
                  <td className="p-3 text-cyan-400">{c.partNumber}</td>
                  <td className="p-3 text-neutral-200">{c.serialNumber}</td>
                  <td className="p-3 text-neutral-400">{c.material}</td>
                  <td className="p-3 text-amber-400">{c.batchNumber}</td>
                  <td className="p-3 text-neutral-300">{c.supplier}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Traceability & Recall Simulation Engine */}
      <div className="p-5 bg-neutral-900/80 rounded-xl border border-neutral-800">
        <div className="flex justify-between items-center text-xs font-mono mb-3">
          <div className="flex items-center gap-2">
            <Barcode className="w-4 h-4 text-cyan-400" />
            <span className="font-bold text-neutral-100 uppercase">
              Reverse Component Batch Traceability & Recall Simulation
            </span>
          </div>
          <span className="text-neutral-400">Global Fleet Integrity Tool</span>
        </div>

        <form onSubmit={handleTraceBatch} className="flex gap-2 mb-4">
          <div className="relative flex-1">
            <input
              type="text"
              value={batchQuery}
              onChange={(e) => setBatchQuery(e.target.value)}
              placeholder="Enter part batch number (e.g. BAT-H2INJ-350-09 or BAT-STEEL-4340-98)..."
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-xs font-mono text-neutral-100 focus:outline-none focus:border-cyan-500"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-mono font-bold flex items-center gap-1.5 transition-colors"
          >
            <Search className="w-3.5 h-3.5" />
            <span>Trace Affected Engines</span>
          </button>
        </form>

        {recallResult && (
          <div className="p-4 bg-neutral-950 rounded-lg border border-neutral-800 text-xs font-mono">
            <div className="flex justify-between items-center pb-2 border-b border-neutral-800 mb-3">
              <div>
                <span className="text-neutral-400">Batch: </span>
                <span className="text-amber-400 font-bold">{recallResult.batchNumber}</span>
                <span className="text-neutral-500 mx-2">|</span>
                <span className="text-neutral-300">{recallResult.componentType}</span>
              </div>
              <span className="px-2.5 py-0.5 rounded bg-red-950/70 border border-red-500/40 text-red-400 font-bold">
                {recallResult.affectedEnginesCount} Engines Affected
              </span>
            </div>

            <div className="space-y-2">
              {recallResult.engines.map((eng) => (
                <div key={eng.engineSerial} className="p-3 bg-neutral-900/60 rounded border border-neutral-800/80 flex flex-col sm:flex-row justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-cyan-400 font-bold">{eng.engineSerial}</span>
                      <span className="text-neutral-400">({eng.engineModel})</span>
                      <span className="text-neutral-500 text-[10px]">Hours: {eng.operatingHours}h</span>
                    </div>
                    <div className="text-[11px] text-neutral-400 mt-1">{eng.actionRequired}</div>
                  </div>
                  <div className="flex items-center gap-2 self-end sm:self-center">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-neutral-800 text-neutral-300">
                      {eng.status}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      eng.riskSeverity === 'CRITICAL' ? 'bg-red-950 text-red-400 border border-red-800' : 'bg-amber-950 text-amber-400'
                    }`}>
                      {eng.riskSeverity}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
