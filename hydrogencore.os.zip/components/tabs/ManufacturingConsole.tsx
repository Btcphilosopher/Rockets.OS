'use client';

import React, { useState } from 'react';
import { FACTORY_STAGES, INITIAL_MACHINES, MachineTwin } from '@/lib/manufacturing/factory';
import { SAMPLE_METROLOGY_INSPECTIONS } from '@/lib/manufacturing/metrology';
import { SAMPLE_FASTENER_RECORDS, ASSEMBLY_SEQUENCE } from '@/lib/manufacturing/assembly';
import {
  Factory,
  Cpu,
  Ruler,
  CheckCircle2,
  Wrench,
  Activity,
  Layers,
  Sparkles,
  Search,
} from 'lucide-react';

export function ManufacturingConsole() {
  const [selectedMachine, setSelectedMachine] = useState<MachineTwin>(INITIAL_MACHINES[0]);
  const [activeSubTab, setActiveSubTab] = useState<'MACHINES' | 'METROLOGY' | 'ASSEMBLY'>('MACHINES');

  return (
    <div className="flex flex-col gap-5 p-4 bg-[#0d1117] text-neutral-200">
      {/* Factory Line Progress Ribbon */}
      <div className="p-4 bg-neutral-900/80 rounded-xl border border-neutral-800">
        <div className="flex items-center justify-between text-xs font-mono mb-3">
          <span className="font-bold text-neutral-200 flex items-center gap-2">
            <Factory className="w-4 h-4 text-cyan-400" />
            PLANT 04 - HYDROGEN POWERTRAIN PRODUCTION LINE ARCHITECTURE
          </span>
          <span className="text-neutral-400">Tact Time: 42 min | Line Yield: 99.1%</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 lg:grid-cols-10 gap-1.5 overflow-x-auto text-[11px] font-mono">
          {FACTORY_STAGES.map((stg) => (
            <div
              key={stg.id}
              className="p-2 bg-neutral-950/80 rounded border border-neutral-800 flex flex-col justify-between hover:border-cyan-500/50 transition-colors"
            >
              <div className="text-cyan-400 font-bold">0{stg.stageNumber}</div>
              <div className="text-neutral-300 font-medium truncate mt-1">{stg.title.split(' ')[0]}</div>
              <div className="text-[9px] text-neutral-500 mt-2">WIP: {stg.wipCount}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Subtabs Selector */}
      <div className="flex items-center gap-2 border-b border-neutral-800 pb-2 text-xs font-mono">
        <button
          onClick={() => setActiveSubTab('MACHINES')}
          className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${
            activeSubTab === 'MACHINES'
              ? 'bg-cyan-950 text-cyan-400 border border-cyan-500/40 font-bold'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
          }`}
        >
          <Cpu className="w-3.5 h-3.5" />
          <span>CNC Machines & Honing Stations</span>
        </button>

        <button
          onClick={() => setActiveSubTab('METROLOGY')}
          className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${
            activeSubTab === 'METROLOGY'
              ? 'bg-cyan-950 text-cyan-400 border border-cyan-500/40 font-bold'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
          }`}
        >
          <Ruler className="w-3.5 h-3.5" />
          <span>Zeiss CMM Inspection Logs</span>
        </button>

        <button
          onClick={() => setActiveSubTab('ASSEMBLY')}
          className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${
            activeSubTab === 'ASSEMBLY'
              ? 'bg-cyan-950 text-cyan-400 border border-cyan-500/40 font-bold'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
          }`}
        >
          <Wrench className="w-3.5 h-3.5" />
          <span>Assembly Torque-Angle Fastening</span>
        </button>
      </div>

      {/* Subtab 1: Machine Telemetry */}
      {activeSubTab === 'MACHINES' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Machine List */}
          <div className="flex flex-col gap-2">
            <h4 className="text-xs font-mono font-bold text-neutral-400 uppercase tracking-wider">
              Connected CNC Twins
            </h4>
            {INITIAL_MACHINES.map((m) => (
              <div
                key={m.machineId}
                onClick={() => setSelectedMachine(m)}
                className={`p-3 rounded-lg border cursor-pointer transition-all ${
                  selectedMachine.machineId === m.machineId
                    ? 'bg-neutral-900 border-cyan-500/50 shadow-md'
                    : 'bg-neutral-950/60 border-neutral-800 hover:border-neutral-700'
                }`}
              >
                <div className="flex justify-between items-start text-xs font-mono">
                  <span className="font-bold text-neutral-100">{m.name}</span>
                  <span className="px-2 py-0.5 rounded bg-emerald-950/70 border border-emerald-500/40 text-emerald-400 text-[10px] font-bold">
                    {m.status}
                  </span>
                </div>
                <div className="text-[11px] font-mono text-neutral-400 mt-1">{m.stationName}</div>
                <div className="flex justify-between text-[10px] font-mono text-neutral-500 mt-2">
                  <span>Part: {m.currentPartId}</span>
                  <span>Wear: {m.toolWearPercent}%</span>
                </div>
              </div>
            ))}
          </div>

          {/* Machine Live Detail Telemetry */}
          <div className="lg:col-span-2 p-5 bg-neutral-900/90 rounded-xl border border-neutral-800 flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start border-b border-neutral-800 pb-3">
                <div>
                  <div className="text-xs font-mono text-cyan-400 font-semibold">{selectedMachine.machineId}</div>
                  <h3 className="text-lg font-bold text-neutral-100 mt-0.5">{selectedMachine.name}</h3>
                  <p className="text-xs font-mono text-neutral-400 mt-1">{selectedMachine.currentOperation}</p>
                </div>
                <div className="text-right font-mono">
                  <span className="text-xs text-neutral-500 block">AVAILABILITY</span>
                  <span className="text-lg font-bold text-emerald-400">{selectedMachine.uptimePercent}%</span>
                </div>
              </div>

              {/* Machine Parameters Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-4 text-xs font-mono">
                <div className="p-3 bg-neutral-950/60 rounded-lg border border-neutral-800">
                  <span className="text-neutral-500 block text-[10px]">SPINDLE SPEED</span>
                  <span className="text-base font-bold text-cyan-400">{selectedMachine.spindleSpeedRpm} RPM</span>
                </div>
                <div className="p-3 bg-neutral-950/60 rounded-lg border border-neutral-800">
                  <span className="text-neutral-500 block text-[10px]">FEED RATE</span>
                  <span className="text-base font-bold text-amber-400">{selectedMachine.feedRateMmMin} mm/min</span>
                </div>
                <div className="p-3 bg-neutral-950/60 rounded-lg border border-neutral-800">
                  <span className="text-neutral-500 block text-[10px]">CUTTING SPEED</span>
                  <span className="text-base font-bold text-emerald-400">{selectedMachine.cuttingSpeedMMin} m/min</span>
                </div>
                <div className="p-3 bg-neutral-950/60 rounded-lg border border-neutral-800">
                  <span className="text-neutral-500 block text-[10px]">POWER DRAW</span>
                  <span className="text-base font-bold text-purple-400">{selectedMachine.powerConsumptionKw} kW</span>
                </div>
                <div className="p-3 bg-neutral-950/60 rounded-lg border border-neutral-800">
                  <span className="text-neutral-500 block text-[10px]">SPINDLE VIBRATION</span>
                  <span className="text-base font-bold text-blue-400">{selectedMachine.vibrationRmsMmS} mm/s</span>
                </div>
                <div className="p-3 bg-neutral-950/60 rounded-lg border border-neutral-800">
                  <span className="text-neutral-500 block text-[10px]">TOOL INSERTS WEAR</span>
                  <span className="text-base font-bold text-neutral-200">{selectedMachine.toolWearPercent}%</span>
                </div>
              </div>
            </div>

            {/* Plateau Honing Microstructure Analysis Notice */}
            <div className="mt-4 p-3.5 bg-neutral-950/80 rounded-lg border border-neutral-800 text-xs font-mono">
              <div className="text-cyan-400 font-bold flex items-center gap-2 mb-1">
                <Sparkles className="w-3.5 h-3.5" />
                Cylinder Liner Surface Metrology (DIN EN ISO 13565-2)
              </div>
              <div className="text-neutral-400 text-[11px] leading-relaxed">
                Nagel plateau honing achieves 45° cross-hatch angle with core roughness depth Rk = 0.38 µm, reduced peak height Rpk = 0.12 µm, and valley retention depth Rvk = 1.15 µm. This micro-texture guarantees optimum hydrodynamic oil wedge retention and low friction with DLC-coated piston rings.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Subtab 2: CMM Metrology */}
      {activeSubTab === 'METROLOGY' && (
        <div className="bg-neutral-900/80 rounded-xl border border-neutral-800 overflow-hidden">
          <div className="p-4 border-b border-neutral-800 flex justify-between items-center text-xs font-mono">
            <span className="font-bold text-neutral-100 flex items-center gap-2">
              <Ruler className="w-4 h-4 text-cyan-400" />
              ZEISS PRISMO CMM INSPECTION PROTOCOL [PRECISION CLASS 0.9 + L/350 µm]
            </span>
            <span className="text-emerald-400 font-bold">ALL 7 FEATURES COMPLIANT</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-neutral-950 text-neutral-400 uppercase text-[10px]">
                <tr>
                  <th className="p-3">ID</th>
                  <th className="p-3">Component / Feature</th>
                  <th className="p-3">Nominal (mm)</th>
                  <th className="p-3">Actual (mm)</th>
                  <th className="p-3">Tol (+)</th>
                  <th className="p-3">Tol (-)</th>
                  <th className="p-3">Deviation</th>
                  <th className="p-3">Instrument</th>
                  <th className="p-3">Result</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800">
                {SAMPLE_METROLOGY_INSPECTIONS.map((m) => (
                  <tr key={m.measurementId} className="hover:bg-neutral-800/40 transition-colors">
                    <td className="p-3 text-cyan-400 font-bold">{m.measurementId}</td>
                    <td className="p-3 text-neutral-200">
                      <div>{m.parameterName}</div>
                      <div className="text-[10px] text-neutral-500">{m.feature}</div>
                    </td>
                    <td className="p-3 text-neutral-300">{m.nominalMm.toFixed(3)}</td>
                    <td className="p-3 text-neutral-100 font-bold">{m.actualMm.toFixed(4)}</td>
                    <td className="p-3 text-neutral-400">+{m.upperTolMm.toFixed(3)}</td>
                    <td className="p-3 text-neutral-400">{m.lowerTolMm.toFixed(3)}</td>
                    <td className="p-3 text-amber-400 font-semibold">{m.deviationUm > 0 ? `+${m.deviationUm}` : m.deviationUm} µm</td>
                    <td className="p-3 text-neutral-400 text-[11px]">{m.instrument}</td>
                    <td className="p-3">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-950/70 border border-emerald-500/40 text-emerald-400 text-[10px] font-bold">
                        <CheckCircle2 className="w-3 h-3" /> PASS
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Subtab 3: Assembly Torque-Angle Records */}
      {activeSubTab === 'ASSEMBLY' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Fastening Records Table */}
          <div className="bg-neutral-900/80 rounded-xl border border-neutral-800 p-4">
            <h4 className="text-xs font-mono font-bold text-neutral-200 mb-3 flex items-center gap-2">
              <Wrench className="w-4 h-4 text-cyan-400" />
              DIGITAL FASTENER TORQUE-ANGLE SIGNATURES
            </h4>

            <div className="space-y-2.5">
              {SAMPLE_FASTENER_RECORDS.map((f) => (
                <div key={f.fastenerId} className="p-3 bg-neutral-950/70 rounded-lg border border-neutral-800 font-mono text-xs">
                  <div className="flex justify-between items-start">
                    <span className="font-bold text-neutral-100">{f.location}</span>
                    <span className="px-2 py-0.5 rounded bg-emerald-950/70 border border-emerald-500/40 text-emerald-400 text-[10px] font-bold">
                      {f.status}
                    </span>
                  </div>
                  <div className="text-[11px] text-neutral-400 mt-1">{f.specification}</div>
                  <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-neutral-900 text-[11px]">
                    <div>
                      <span className="text-neutral-500 block text-[10px]">TORQUE (TARGET / ACTUAL)</span>
                      <span className="text-neutral-200">{f.targetTorqueNm} Nm / </span>
                      <span className="text-emerald-400 font-bold">{f.actualTorqueNm} Nm</span>
                    </div>
                    <div>
                      <span className="text-neutral-500 block text-[10px]">ANGLE (TARGET / ACTUAL)</span>
                      <span className="text-neutral-200">{f.targetAngleDeg}° / </span>
                      <span className="text-cyan-400 font-bold">{f.actualAngleDeg}°</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Assembly Flow Sequence */}
          <div className="bg-neutral-900/80 rounded-xl border border-neutral-800 p-4">
            <h4 className="text-xs font-mono font-bold text-neutral-200 mb-3 flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              ISO CLASS 7 CLEANROOM ASSEMBLY SEQUENCE
            </h4>

            <div className="space-y-2">
              {ASSEMBLY_SEQUENCE.slice(0, 7).map((step) => (
                <div key={step.stepNumber} className="p-2.5 bg-neutral-950/70 rounded border border-neutral-800 font-mono text-xs flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="w-5 h-5 rounded-full bg-cyan-950 border border-cyan-500/40 text-cyan-400 flex items-center justify-center text-[10px] font-bold">
                      {step.stepNumber}
                    </span>
                    <div>
                      <span className="text-neutral-200 font-semibold">{step.subsystem}: </span>
                      <span className="text-neutral-400 text-[11px]">{step.operation}</span>
                    </div>
                  </div>
                  <span className="text-emerald-400 font-bold text-[10px] px-2 py-0.5 rounded bg-emerald-950/50">
                    VERIFIED
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
