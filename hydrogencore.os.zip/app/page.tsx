'use client';

import React, { useState, useCallback, useEffect } from 'react';
import {
  createInitialEngineState,
  recomputeEnginePhysics,
  EngineStoreState,
  ViewMode,
  ActiveConsoleTab,
  ActiveFaults,
} from '@/lib/engineStore';
import { REFERENCE_CONFIG_I4, REFERENCE_CONFIG_I6, REFERENCE_CONFIG_V8 } from '@/lib/syntheticData';
import dynamic from 'next/dynamic';

const Engine3DViewer = dynamic(
  () => import('@/components/Engine3DViewer').then((mod) => mod.Engine3DViewer),
  {
    ssr: false,
    loading: () => (
      <div className="w-full h-full flex flex-col items-center justify-center bg-[#07090e] text-neutral-400 font-mono text-xs gap-3">
        <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
        <span>Initializing WebGL 3D Kinematics Engine...</span>
      </div>
    ),
  }
);
import { SimulationCockpit } from '@/components/SimulationCockpit';
import { ComponentInspector } from '@/components/ComponentInspector';
import { EngineeringConsole } from '@/components/tabs/EngineeringConsole';
import { ManufacturingConsole } from '@/components/tabs/ManufacturingConsole';
import { TestCellConsole } from '@/components/tabs/TestCellConsole';
import { PassportConsole } from '@/components/tabs/PassportConsole';
import { ScenariosConsole } from '@/components/tabs/ScenariosConsole';
import {
  Layers,
  Activity,
  Factory,
  CheckCircle2,
  FileBadge,
  AlertTriangle,
  Flame,
  ShieldCheck,
  ShieldAlert,
  ChevronDown,
  Compass,
  Cpu,
  Zap,
} from 'lucide-react';

export default function HydrogenCoreOSPage() {
  const [engineState, setEngineState] = useState<EngineStoreState>(() => createInitialEngineState());
  const [selectedEngineModel, setSelectedEngineModel] = useState<'I4' | 'I6' | 'V8'>('I4');

  // Switch engine architecture
  const handleModelSelect = (model: 'I4' | 'I6' | 'V8') => {
    setSelectedEngineModel(model);
    let cfg = REFERENCE_CONFIG_I4;
    if (model === 'I6') cfg = REFERENCE_CONFIG_I6;
    if (model === 'V8') cfg = REFERENCE_CONFIG_V8;

    setEngineState((prev) => {
      const updated = { ...prev, config: cfg };
      return recomputeEnginePhysics(updated);
    });
  };

  // Update simulation parameters
  const handleUpdateParam = useCallback((key: string, value: number | boolean) => {
    setEngineState((prev) => {
      const updated = { ...prev, [key]: value };
      return recomputeEnginePhysics(updated);
    });
  }, []);

  // Presets
  const handleApplyPreset = useCallback((preset: 'IDLE' | 'CRUISE' | 'RATED' | 'TRANSIENT') => {
    setEngineState((prev) => {
      let nextState = { ...prev };
      switch (preset) {
        case 'IDLE':
          nextState.rpm = 850;
          nextState.loadFactor = 0.15;
          nextState.lambda = 2.2;
          nextState.boostBarGauge = 0.2;
          nextState.ignitionAdvanceDegBtdc = 12;
          break;
        case 'CRUISE':
          nextState.rpm = 2400;
          nextState.loadFactor = 0.45;
          nextState.lambda = 2.3;
          nextState.boostBarGauge = 0.4;
          nextState.ignitionAdvanceDegBtdc = 22;
          break;
        case 'RATED':
          nextState.rpm = 6000;
          nextState.loadFactor = 1.0;
          nextState.lambda = 1.8;
          nextState.boostBarGauge = 1.4;
          nextState.ignitionAdvanceDegBtdc = 18;
          break;
        case 'TRANSIENT':
          nextState.rpm = 6500;
          nextState.loadFactor = 1.0;
          nextState.lambda = 1.6;
          nextState.boostBarGauge = 1.8;
          nextState.ignitionAdvanceDegBtdc = 16;
          break;
      }
      return recomputeEnginePhysics(nextState);
    });
  }, []);

  // Emergency Shutdown (ESD)
  const handleTriggerEsd = useCallback(() => {
    setEngineState((prev) => {
      const isAlreadyEsd = prev.safetyStatus.esdTriggered;
      if (isAlreadyEsd) {
        // Reset ESD
        return recomputeEnginePhysics({
          ...prev,
          safetyStatus: {
            ...prev.safetyStatus,
            state: 'SAFE',
            esdTriggered: false,
            esdReason: undefined,
            tankIsolationValveOpen: true,
            railPurgeValveOpen: false,
          },
        });
      } else {
        // Engage ESD
        return {
          ...prev,
          simulationRunning: false,
          rpm: 0,
          loadFactor: 0,
          safetyStatus: {
            ...prev.safetyStatus,
            state: 'EMERGENCY',
            esdTriggered: true,
            esdReason: 'MANUAL EMERGENCY SHUTDOWN ENGAGED - HIGH PRESSURE SUPPLY ISOLATED',
            tankIsolationValveOpen: false,
            railPurgeValveOpen: true,
            ventilationFanStatus: 'BOOST_100_PERCENT',
          },
          liveState: {
            ...prev.liveState,
            rpm: 0,
            powerW: 0,
            torqueNm: 0,
            hydrogenFlowKgH: 0,
            safetyState: 'EMERGENCY',
          },
        };
      }
    });
  }, []);

  // Fault toggling
  const handleToggleFault = useCallback((faultKey: keyof ActiveFaults) => {
    setEngineState((prev) => {
      const updatedFaults = {
        ...prev.activeFaults,
        [faultKey]: !prev.activeFaults[faultKey],
      };
      return recomputeEnginePhysics({
        ...prev,
        activeFaults: updatedFaults,
      });
    });
  }, []);

  const handleResetAllFaults = useCallback(() => {
    setEngineState((prev) => {
      const clearedFaults: ActiveFaults = {
        injectorRestriction: false,
        coolantPumpDegradation: false,
        hydrogenPressureLoss: false,
        hydrogenLeak: false,
        bearingWear: false,
        misfire: false,
      };
      return recomputeEnginePhysics({
        ...prev,
        activeFaults: clearedFaults,
      });
    });
  }, []);

  const handleSelectComponent = (compName: string) => {
    setEngineState((prev) => ({
      ...prev,
      selectedComponentId: prev.selectedComponentId === compName ? null : compName,
    }));
  };

  const handleViewModeChange = (mode: ViewMode) => {
    setEngineState((prev) => ({ ...prev, viewMode: mode }));
  };

  const activeTab = engineState.activeTab;
  const isEsdActive = engineState.safetyStatus.esdTriggered;

  return (
    <main className="min-h-screen bg-[#07090e] text-neutral-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-black">
      {/* ========================================================================= */}
      {/* 1. INDUSTRIAL TOP COMMAND BAR                                             */}
      {/* ========================================================================= */}
      <header className="h-16 border-b border-neutral-800 bg-[#0a0d14]/95 backdrop-blur-md px-4 flex items-center justify-between z-30 sticky top-0">
        {/* Brand & Engine Model Switcher */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-700 flex items-center justify-center font-mono font-black text-black text-sm shadow-[0_0_15px_rgba(0,229,255,0.35)]">
              H₂
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold tracking-tight text-neutral-100 text-sm">
                  HYDROGENCORE<span className="text-cyan-400">.OS</span>
                </span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-400 border border-neutral-700">
                  v2.4.1
                </span>
              </div>
              <p className="text-[10px] font-mono text-neutral-500 hidden sm:block">
                Hydrogen Combustion Engine Digital Twin & Production Platform
              </p>
            </div>
          </div>

          <div className="hidden md:block w-[1px] h-6 bg-neutral-800 mx-1" />

          {/* Engine Model Selector */}
          <div className="hidden lg:flex items-center gap-1 bg-neutral-900 border border-neutral-800 p-1 rounded-lg text-xs font-mono">
            <button
              onClick={() => handleModelSelect('I4')}
              className={`px-2.5 py-1 rounded transition-colors ${
                selectedEngineModel === 'I4'
                  ? 'bg-neutral-800 text-cyan-400 font-bold border border-cyan-500/30'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              H2-I4 2.0L (185 kW)
            </button>
            <button
              onClick={() => handleModelSelect('I6')}
              className={`px-2.5 py-1 rounded transition-colors ${
                selectedEngineModel === 'I6'
                  ? 'bg-neutral-800 text-cyan-400 font-bold border border-cyan-500/30'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              H2-I6 3.0L (280 kW)
            </button>
            <button
              onClick={() => handleModelSelect('V8')}
              className={`px-2.5 py-1 rounded transition-colors ${
                selectedEngineModel === 'V8'
                  ? 'bg-neutral-800 text-cyan-400 font-bold border border-cyan-500/30'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              H2-V8 4.5L (420 kW)
            </button>
          </div>
        </div>

        {/* Global Safety & Quick Health Pills */}
        <div className="flex items-center gap-3">
          {/* Safety State */}
          <div
            className={`px-3 py-1.5 rounded-lg border text-xs font-mono font-bold flex items-center gap-2 ${
              isEsdActive
                ? 'bg-red-950/80 border-red-500 text-red-400 animate-pulse'
                : engineState.safetyStatus.state === 'WARNING'
                ? 'bg-amber-950/80 border-amber-500 text-amber-400'
                : 'bg-emerald-950/70 border-emerald-500/50 text-emerald-400'
            }`}
          >
            {isEsdActive ? (
              <ShieldAlert className="w-3.5 h-3.5" />
            ) : engineState.safetyStatus.state === 'WARNING' ? (
              <AlertTriangle className="w-3.5 h-3.5" />
            ) : (
              <ShieldCheck className="w-3.5 h-3.5" />
            )}
            <span>
              {isEsdActive
                ? 'ESD TRIP ACTIVE'
                : engineState.safetyStatus.state === 'WARNING'
                ? 'H₂ SAFETY WARNING'
                : 'SAFETY ENCLOSURE: NOMINAL'}
            </span>
          </div>

          {/* Health Score Pill */}
          <div className="hidden sm:flex items-center gap-2 bg-neutral-900 border border-neutral-800 px-3 py-1.5 rounded-lg font-mono text-xs">
            <span className="text-neutral-400">HEALTH:</span>
            <span
              className={`font-bold ${
                engineState.liveState.overallHealthScore > 85
                  ? 'text-emerald-400'
                  : engineState.liveState.overallHealthScore > 60
                  ? 'text-amber-400'
                  : 'text-red-400'
              }`}
            >
              {engineState.liveState.overallHealthScore}%
            </span>
          </div>
        </div>
      </header>

      {/* ========================================================================= */}
      {/* 2. INDUSTRIAL NAVIGATION TABS BAR                                         */}
      {/* ========================================================================= */}
      <nav className="border-b border-neutral-800 bg-[#0a0d14] px-4 flex items-center gap-1 overflow-x-auto text-xs font-mono">
        <button
          onClick={() => setEngineState((prev) => ({ ...prev, activeTab: 'TWIN_3D' }))}
          className={`py-3 px-4 border-b-2 font-bold flex items-center gap-2 transition-colors whitespace-nowrap ${
            activeTab === 'TWIN_3D'
              ? 'border-cyan-400 text-cyan-400 bg-neutral-900/60'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>3D Digital Twin Engine</span>
        </button>

        <button
          onClick={() => setEngineState((prev) => ({ ...prev, activeTab: 'ENGINEERING' }))}
          className={`py-3 px-4 border-b-2 font-bold flex items-center gap-2 transition-colors whitespace-nowrap ${
            activeTab === 'ENGINEERING'
              ? 'border-cyan-400 text-cyan-400 bg-neutral-900/60'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Thermodynamics & Engineering</span>
        </button>

        <button
          onClick={() => setEngineState((prev) => ({ ...prev, activeTab: 'MANUFACTURING' }))}
          className={`py-3 px-4 border-b-2 font-bold flex items-center gap-2 transition-colors whitespace-nowrap ${
            activeTab === 'MANUFACTURING'
              ? 'border-cyan-400 text-cyan-400 bg-neutral-900/60'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Factory className="w-4 h-4" />
          <span>Manufacturing & Metrology</span>
        </button>

        <button
          onClick={() => setEngineState((prev) => ({ ...prev, activeTab: 'TEST_CELL' }))}
          className={`py-3 px-4 border-b-2 font-bold flex items-center gap-2 transition-colors whitespace-nowrap ${
            activeTab === 'TEST_CELL'
              ? 'border-cyan-400 text-cyan-400 bg-neutral-900/60'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>Test Cell & Dyno Simulator</span>
        </button>

        <button
          onClick={() => setEngineState((prev) => ({ ...prev, activeTab: 'PASSPORT' }))}
          className={`py-3 px-4 border-b-2 font-bold flex items-center gap-2 transition-colors whitespace-nowrap ${
            activeTab === 'PASSPORT'
              ? 'border-cyan-400 text-cyan-400 bg-neutral-900/60'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <FileBadge className="w-4 h-4" />
          <span>Digital Passport & Traceability</span>
        </button>

        <button
          onClick={() => setEngineState((prev) => ({ ...prev, activeTab: 'SCENARIOS' }))}
          className={`py-3 px-4 border-b-2 font-bold flex items-center gap-2 transition-colors whitespace-nowrap ${
            activeTab === 'SCENARIOS'
              ? 'border-cyan-400 text-cyan-400 bg-neutral-900/60'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <AlertTriangle className="w-4 h-4" />
          <span>Fault Injection & Diagnostics</span>
          {Object.values(engineState.activeFaults).some((v) => v) && (
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          )}
        </button>
      </nav>

      {/* ========================================================================= */}
      {/* 3. MAIN WORKSPACE / ACTIVE TAB VIEW                                       */}
      {/* ========================================================================= */}
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Tab 1: 3D Twin View + Cockpit */}
        {activeTab === 'TWIN_3D' && (
          <div className="flex-1 flex flex-col p-4 gap-4 overflow-y-auto">
            <div className="flex-1 min-h-[520px] flex rounded-xl overflow-hidden relative border border-neutral-800">
              <Engine3DViewer
                state={engineState}
                onSelectComponent={handleSelectComponent}
                selectedComponentId={engineState.selectedComponentId}
                onViewModeChange={handleViewModeChange}
              />

              {/* Slide-out Component Inspector */}
              {engineState.selectedComponentId && (
                <ComponentInspector
                  componentId={engineState.selectedComponentId}
                  onClose={() => setEngineState((prev) => ({ ...prev, selectedComponentId: null }))}
                  state={engineState}
                />
              )}
            </div>

            {/* Simulation Cockpit Controls */}
            <SimulationCockpit
              state={engineState}
              onUpdateParam={handleUpdateParam}
              onTriggerEsd={handleTriggerEsd}
              onApplyPreset={handleApplyPreset}
            />
          </div>
        )}

        {/* Tab 2: Engineering & Thermodynamics */}
        {activeTab === 'ENGINEERING' && (
          <div className="flex-1 overflow-y-auto">
            <EngineeringConsole state={engineState} />
          </div>
        )}

        {/* Tab 3: Manufacturing & Metrology */}
        {activeTab === 'MANUFACTURING' && (
          <div className="flex-1 overflow-y-auto">
            <ManufacturingConsole />
          </div>
        )}

        {/* Tab 4: Test Cell & Dyno Simulator */}
        {activeTab === 'TEST_CELL' && (
          <div className="flex-1 overflow-y-auto">
            <TestCellConsole state={engineState} />
          </div>
        )}

        {/* Tab 5: Digital Passport & Traceability */}
        {activeTab === 'PASSPORT' && (
          <div className="flex-1 overflow-y-auto">
            <PassportConsole />
          </div>
        )}

        {/* Tab 6: Fault Injection & Scenarios */}
        {activeTab === 'SCENARIOS' && (
          <div className="flex-1 overflow-y-auto">
            <ScenariosConsole
              state={engineState}
              onToggleFault={handleToggleFault}
              onResetAllFaults={handleResetAllFaults}
            />
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 4. INDUSTRIAL STATUS FOOTER                                               */}
      {/* ========================================================================= */}
      <footer className="h-9 border-t border-neutral-800 bg-[#0a0d14] px-4 flex items-center justify-between text-[11px] font-mono text-neutral-400 z-20">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>SOLVER: 4-Stroke SI Real Gas Kinetics</span>
          </div>
          <span className="text-neutral-700">|</span>
          <div>
            UNITS: <span className="text-neutral-200">Strict SI (Pa, K, kg, m, s, rad/s)</span>
          </div>
          <span className="text-neutral-700 hidden sm:inline">|</span>
          <div className="hidden sm:block">
            ACTIVE THREAD: <span className="text-cyan-400">{engineState.config.engineId}</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <span>H₂ LFL: 4.0% vol (40,000 ppm)</span>
          <span className="text-neutral-700">|</span>
          <span className="text-neutral-300">HYDROGENCORE.OS © 2026</span>
        </div>
      </footer>
    </main>
  );
}
