import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'HYDROGENCORE.OS | Hydrogen Engine Digital Twin & Production Platform',
  description: 'Enterprise-grade industrial digital twin, engineering simulator, manufacturing system and production-management platform for hydrogen-fuelled internal combustion engines.',
  openGraph: {
    title: 'HYDROGENCORE.OS | Hydrogen Engine Digital Twin & Production Platform',
    description: 'Enterprise-grade industrial digital twin, engineering simulator, manufacturing system and production-management platform for hydrogen-fuelled internal combustion engines.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'HYDROGENCORE.OS | Hydrogen Engine Digital Twin & Production Platform',
    description: 'Enterprise-grade industrial digital twin, engineering simulator, manufacturing system and production-management platform for hydrogen-fuelled internal combustion engines.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
