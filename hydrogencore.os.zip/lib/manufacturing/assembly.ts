/**
 * Engine Assembly Digital Twin & Torque-Controlled Fastening Records
 * Ensures complete traceability of every bolt, nut, bearing, and seal.
 */

import { FastenerRecord } from '../domain/types';

export interface AssemblyStep {
  stepNumber: number;
  subsystem: string;
  operation: string;
  toolModel: string;
  componentPartNumber: string;
  status: 'COMPLETED' | 'IN_PROGRESS' | 'PENDING' | 'FAULT';
  notes: string;
}

export const SAMPLE_FASTENER_RECORDS: FastenerRecord[] = [
  {
    fastenerId: 'FAST-HB-01',
    location: 'Cylinder Head Bolt #1 (M11x1.5 Grade 12.9)',
    specification: 'Stage 1: 35 Nm -> Stage 2: 60 Nm -> Stage 3: +90° Angle',
    targetTorqueNm: 60,
    actualTorqueNm: 60.4,
    targetAngleDeg: 90,
    actualAngleDeg: 90.5,
    tolerancePercent: 3.0,
    operatorId: 'TECH-742',
    toolId: 'TOOL-TENS-01',
    timestamp: '2026-08-28 09:14:22 UTC',
    status: 'PASS',
  },
  {
    fastenerId: 'FAST-HB-02',
    location: 'Cylinder Head Bolt #2 (M11x1.5 Grade 12.9)',
    specification: 'Stage 1: 35 Nm -> Stage 2: 60 Nm -> Stage 3: +90° Angle',
    targetTorqueNm: 60,
    actualTorqueNm: 60.1,
    targetAngleDeg: 90,
    actualAngleDeg: 90.2,
    tolerancePercent: 3.0,
    operatorId: 'TECH-742',
    toolId: 'TOOL-TENS-01',
    timestamp: '2026-08-28 09:14:38 UTC',
    status: 'PASS',
  },
  {
    fastenerId: 'FAST-CRB-01',
    location: 'Connecting Rod Cap Bolt #1A (ARP 2000 M9)',
    specification: '55 Nm with ARP assembly lubricant',
    targetTorqueNm: 55,
    actualTorqueNm: 55.2,
    targetAngleDeg: 0,
    actualAngleDeg: 0,
    tolerancePercent: 2.5,
    operatorId: 'TECH-608',
    toolId: 'TOOL-TORQ-03',
    timestamp: '2026-08-28 08:35:10 UTC',
    status: 'PASS',
  },
  {
    fastenerId: 'FAST-MCB-01',
    location: 'Main Bearing Saddle Bolt #1 (M12x1.5)',
    specification: '95 Nm cross-pattern sequence',
    targetTorqueNm: 95,
    actualTorqueNm: 95.3,
    targetAngleDeg: 0,
    actualAngleDeg: 0,
    tolerancePercent: 2.0,
    operatorId: 'TECH-608',
    toolId: 'TOOL-TORQ-03',
    timestamp: '2026-08-28 08:12:05 UTC',
    status: 'PASS',
  },
  {
    fastenerId: 'FAST-INJ-01',
    location: 'Hydrogen Direct Injector Clamp #1',
    specification: '22 Nm precision seating clamp',
    targetTorqueNm: 22,
    actualTorqueNm: 22.1,
    targetAngleDeg: 0,
    actualAngleDeg: 0,
    tolerancePercent: 4.0,
    operatorId: 'TECH-819',
    toolId: 'TOOL-PNEUM-02',
    timestamp: '2026-08-28 10:04:15 UTC',
    status: 'PASS',
  },
];

export const ASSEMBLY_SEQUENCE: AssemblyStep[] = [
  { stepNumber: 1, subsystem: 'Cylinder Block', operation: 'Mount block on rotating engine rollover stand; verify oil gallery plugs', toolModel: 'STAND-ROLL-01', componentPartNumber: 'BLK-H2-2000-01', status: 'COMPLETED', notes: 'Ultrasonic cleanliness verified' },
  { stepNumber: 2, subsystem: 'Main Bearings', operation: 'Install tri-metal coated upper main bearings & lube with Break-In Oil', toolModel: 'MANUAL-PRECISION', componentPartNumber: 'BRG-MAIN-001', status: 'COMPLETED', notes: 'Oil film clearance measured: 38 um' },
  { stepNumber: 3, subsystem: 'Crankshaft', operation: 'Lower forged 4340 crankshaft into saddles; check axial end play (0.12 mm)', toolModel: 'HOIST-CRANE-01', componentPartNumber: 'CRK-H2-2000-01', status: 'COMPLETED', notes: 'Free rotation verified: < 0.4 Nm drag' },
  { stepNumber: 4, subsystem: 'Main Caps & Girdle', operation: 'Torque main bearing bolts in spiral pattern to 95 Nm', toolModel: 'TOOL-TORQ-03', componentPartNumber: 'GIRDLE-LOWER-01', status: 'COMPLETED', notes: 'All 10 bolts verified PASS' },
  { stepNumber: 5, subsystem: 'Pistons & Rods', operation: 'Insert piston ring packs using tapered guide sleeve; torque rod bolts to 55 Nm', toolModel: 'RING-COMPRESS-01', componentPartNumber: 'PST-H2-2000-01', status: 'COMPLETED', notes: 'Deck protrusion measured: +0.10 mm' },
  { stepNumber: 6, subsystem: 'Multi-Layer Steel Gasket', operation: 'Position 4-layer stainless steel MLS head gasket (H2 sealing coating)', toolModel: 'ALIGN-PINS-01', componentPartNumber: 'GSK-MLS-H2-01', status: 'COMPLETED', notes: 'Combustion fire-ring alignment verified' },
  { stepNumber: 7, subsystem: 'Cylinder Head', operation: 'Seat cylinder head and execute torque-to-yield sequence (60 Nm + 90 deg)', toolModel: 'TOOL-TENS-01', componentPartNumber: 'HED-H2-2000-01', status: 'COMPLETED', notes: 'All 10 head bolts recorded to digital log' },
  { stepNumber: 8, subsystem: 'Valvetrain & Timing', operation: 'Install dual overhead camshafts, timing chain, hydraulic tensioner', toolModel: 'TIMING-LOCK-01', componentPartNumber: 'CAM-DOHC-01', status: 'COMPLETED', notes: 'Timing marks zeroed at TDC Cyl #1' },
  { stepNumber: 9, subsystem: 'Hydrogen Direct Rail', operation: 'Seat 350-bar H2 injectors with Viton/PTFE seals, torque clamps to 22 Nm', toolModel: 'TOOL-PNEUM-02', componentPartNumber: 'RAIL-H2-350-01', status: 'COMPLETED', notes: 'Helium micro-leak sniff test passed' },
  { stepNumber: 10, subsystem: 'Turbo & Manifolds', operation: 'Mount twin-scroll turbocharger, water-cooled stainless exhaust manifold', toolModel: 'TOOL-TORQ-02', componentPartNumber: 'TRB-TWIN-SCROLL-01', status: 'COMPLETED', notes: 'Wastegate pre-tension calibrated' },
];
