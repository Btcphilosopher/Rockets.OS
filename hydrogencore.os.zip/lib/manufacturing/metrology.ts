/**
 * Coordinate Metrology & GD&T Inspection Digital Twin
 * Grounded in precision CMM, air-gage bore scanners, and optical profilometers.
 */

import { MetrologyInspection } from '../domain/types';

export interface GdtFeatureTolerance {
  featureName: string;
  symbol: 'FLATNESS' | 'CYLINDRICITY' | 'CIRCULARITY' | 'RUNOUT' | 'POSITION' | 'PERPENDICULARITY';
  nominalValue: number;
  toleranceZoneUm: number;
  measuredDeviationUm: number;
  datumReference: string;
  result: 'PASS' | 'FAIL';
}

export const SAMPLE_METROLOGY_INSPECTIONS: MetrologyInspection[] = [
  {
    measurementId: 'MET-BORE-01',
    componentSerial: 'BLK-H2-2000-01',
    parameterName: 'Cylinder #1 Bore Diameter (Top)',
    feature: 'Bore #1 at depth 20mm',
    nominalMm: 86.000,
    actualMm: 86.004,
    upperTolMm: 0.010,
    lowerTolMm: -0.005,
    deviationUm: 4.0,
    instrument: 'Zeiss PRISMO CMM + 2mm Ruby Probe',
    status: 'PASS',
  },
  {
    measurementId: 'MET-BORE-02',
    componentSerial: 'BLK-H2-2000-01',
    parameterName: 'Cylinder #1 Roundness / Circularity',
    feature: 'Bore #1 360° circle profile',
    nominalMm: 0.000,
    actualMm: 0.0028,
    upperTolMm: 0.005,
    lowerTolMm: 0.000,
    deviationUm: 2.8,
    instrument: 'Taylor Hobson Talyrond 585',
    status: 'PASS',
  },
  {
    measurementId: 'MET-BORE-03',
    componentSerial: 'BLK-H2-2000-01',
    parameterName: 'Cylinder #1 Taper / Cylindricity',
    feature: 'Top-to-bottom bore profile (140mm depth)',
    nominalMm: 0.000,
    actualMm: 0.0035,
    upperTolMm: 0.006,
    lowerTolMm: 0.000,
    deviationUm: 3.5,
    instrument: 'Zeiss PRISMO CMM Continuous Scanning',
    status: 'PASS',
  },
  {
    measurementId: 'MET-DECK-01',
    componentSerial: 'BLK-H2-2000-01',
    parameterName: 'Cylinder Block Deck Flatness',
    feature: 'Top deck fire-face surface',
    nominalMm: 0.000,
    actualMm: 0.012,
    upperTolMm: 0.025,
    lowerTolMm: 0.000,
    deviationUm: 12.0,
    instrument: 'Laser Surface Scanner + CMM Grid',
    status: 'PASS',
  },
  {
    measurementId: 'MET-CRK-01',
    componentSerial: 'CRK-H2-2000-01',
    parameterName: 'Main Journal #1 Diameter',
    feature: 'Main Journal #1 cylindrical face',
    nominalMm: 52.000,
    actualMm: 49.998,
    upperTolMm: 0.000,
    lowerTolMm: -0.010,
    deviationUm: -2.0,
    instrument: 'Mahr Federal Air Gage System',
    status: 'PASS',
  },
  {
    measurementId: 'MET-CRK-02',
    componentSerial: 'CRK-H2-2000-01',
    parameterName: 'Crankshaft Total Radial Runout',
    feature: 'Center main journal relative to datums A-B',
    nominalMm: 0.000,
    actualMm: 0.006,
    upperTolMm: 0.012,
    lowerTolMm: 0.000,
    deviationUm: 6.0,
    instrument: 'Zeiss Optical Runout Bench',
    status: 'PASS',
  },
  {
    measurementId: 'MET-HED-01',
    componentSerial: 'HED-H2-2000-01',
    parameterName: 'Intake Valve Seat Concentricity',
    feature: 'Combustion chamber #1 intake valve guide-to-seat',
    nominalMm: 0.000,
    actualMm: 0.008,
    upperTolMm: 0.015,
    lowerTolMm: 0.000,
    deviationUm: 8.0,
    instrument: 'Newen CNC Contour Vision Probe',
    status: 'PASS',
  },
];

export const SAMPLE_GDT_FEATURES: GdtFeatureTolerance[] = [
  { featureName: 'Block Deck Surface', symbol: 'FLATNESS', nominalValue: 0, toleranceZoneUm: 25, measuredDeviationUm: 12, datumReference: '-', result: 'PASS' },
  { featureName: 'Cylinder #1-4 Bores', symbol: 'CYLINDRICITY', nominalValue: 0, toleranceZoneUm: 8, measuredDeviationUm: 3.5, datumReference: 'Datum A (Deck)', result: 'PASS' },
  { featureName: 'Crankshaft Main Journals', symbol: 'CIRCULARITY', nominalValue: 0, toleranceZoneUm: 4, measuredDeviationUm: 1.8, datumReference: '-', result: 'PASS' },
  { featureName: 'Crank Center Journal', symbol: 'RUNOUT', nominalValue: 0, toleranceZoneUm: 12, measuredDeviationUm: 6.0, datumReference: 'Datums A-B (Ends)', result: 'PASS' },
  { featureName: 'Head Bolt Bosses', symbol: 'POSITION', nominalValue: 0, toleranceZoneUm: 50, measuredDeviationUm: 18, datumReference: 'Datums A|B|C', result: 'PASS' },
];
