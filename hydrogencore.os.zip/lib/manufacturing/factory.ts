/**
 * Manufacturing Digital Twin & Factory Layout Model
 * Real industrial stations, CNC machines, honing, metrology, and assembly lines.
 */

export interface MachineTwin {
  machineId: string;
  name: string;
  type: 'CNC_5AXIS_MILL' | 'CNC_LATHE' | 'PLATEAU_HONING' | 'HEAT_TREATMENT' | 'CMM_METROLOGY' | 'TORQUE_ASSEMBLY' | 'TEST_CELL_DYNO';
  stationName: string;
  status: 'RUNNING' | 'IDLE' | 'TOOL_CHANGE' | 'MAINTENANCE' | 'BLOCKED';
  cycleTimeSec: number;
  spindleSpeedRpm: number;
  feedRateMmMin: number;
  cuttingSpeedMMin: number;
  powerConsumptionKw: number;
  toolWearPercent: number;
  vibrationRmsMmS: number;
  uptimePercent: number;
  currentPartId: string;
  currentOperation: string;
}

export interface WorkstationStage {
  id: string;
  stageNumber: number;
  title: string;
  description: string;
  machineIds: string[];
  wipCount: number;
  standardCycleTimeMin: number;
  qualityGateName: string;
}

export const FACTORY_STAGES: WorkstationStage[] = [
  {
    id: 'STG-01-RAW',
    stageNumber: 1,
    title: 'Raw Stock & Metallurgical Testing',
    description: 'Billet forging stock (AISI 4340 alloy steel) and AlSi7Mg block ingots with spectroscopic certification.',
    machineIds: ['INSP-RAW-01'],
    wipCount: 18,
    standardCycleTimeMin: 12,
    qualityGateName: 'Material Chemistry & Ultrasonic Flaw Check',
  },
  {
    id: 'STG-02-FORGE',
    stageNumber: 2,
    title: 'Forging & Near-Net Casting',
    description: '12,000-tonne hydraulic closed-die forging of crankshaft blanks and high-pressure die casting of engine block.',
    machineIds: ['FORGE-PRESS-01', 'CAST-CELL-02'],
    wipCount: 12,
    standardCycleTimeMin: 25,
    qualityGateName: 'Grain Flow & Void Ultrasonic Gate',
  },
  {
    id: 'STG-03-HEAT',
    stageNumber: 3,
    title: 'Vacuum Heat Treatment & Gas Nitriding',
    description: 'Quench & temper to 34-38 HRC followed by plasma gas nitriding of journal surfaces to 62 HRC (depth 0.4mm).',
    machineIds: ['FURNACE-VAC-01', 'NITRIDE-PLAS-01'],
    wipCount: 14,
    standardCycleTimeMin: 180,
    qualityGateName: 'Surface Microhardness & Case Depth',
  },
  {
    id: 'STG-04-CNC',
    stageNumber: 4,
    title: '5-Axis Precision CNC Machining',
    description: 'Hermle C52 and DMG MORI CTX gamma 2000 rough and finish machining of journals, deck, and main bearing saddles.',
    machineIds: ['CNC-MILL-5AX-01', 'CNC-LATHE-02'],
    wipCount: 8,
    standardCycleTimeMin: 45,
    qualityGateName: 'Dimensional Rough Machining Gate',
  },
  {
    id: 'STG-05-HONE',
    stageNumber: 5,
    title: 'Plateau Honing & Micro-Finishing',
    description: 'Nagel multi-stage plateau honing of cylinder bores for precise cross-hatch angle (45 deg) and Rk/Rpk surface parameters.',
    machineIds: ['HONE-NAGEL-01', 'FINISH-SUPER-01'],
    wipCount: 6,
    standardCycleTimeMin: 18,
    qualityGateName: 'Liner Surface Roughness (Ra <= 0.12 um)',
  },
  {
    id: 'STG-06-SUBASM',
    stageNumber: 6,
    title: 'Subassembly & Valvetrain Pairing',
    description: 'Precision weight-matching of pistons and rods (within 0.5g tolerance) and robotic valve-spring seat pressing.',
    machineIds: ['SUB-ROBOT-01', 'BAL-DYNAMIC-01'],
    wipCount: 9,
    standardCycleTimeMin: 22,
    qualityGateName: 'Reciprocating Mass Balance Check',
  },
  {
    id: 'STG-07-ASM',
    stageNumber: 7,
    title: 'Final Engine Cleanroom Assembly',
    description: 'ISO Class 7 cleanroom assembly of crankshaft, bearings, head, hydrogen rail, direct injectors, and turbocharger.',
    machineIds: ['ASM-TORQUE-CELL-01'],
    wipCount: 5,
    standardCycleTimeMin: 55,
    qualityGateName: 'Digital Fastener Torque-Angle Log',
  },
  {
    id: 'STG-08-CMM',
    stageNumber: 8,
    title: 'Zeiss Coordinate Measuring Machine (CMM)',
    description: 'Full 3D geometric verification of bore roundness, crankshaft runout, deck flatness, and port alignment.',
    machineIds: ['CMM-ZEISS-PRISMO-01'],
    wipCount: 4,
    standardCycleTimeMin: 35,
    qualityGateName: 'GD&T Profile & Runout Verification',
  },
  {
    id: 'STG-09-DYNO',
    stageNumber: 9,
    title: 'Automated Hydrogen Test Cell (Hot/Cold Dyno)',
    description: 'Cold leak-down test, automated break-in, and full dynamometer power/torque/NOx certification run.',
    machineIds: ['TEST-CELL-AVL-01'],
    wipCount: 3,
    standardCycleTimeMin: 40,
    qualityGateName: 'Power & Zero-H2-Leak Certification',
  },
  {
    id: 'STG-10-PASSPORT',
    stageNumber: 10,
    title: 'Digital Passport Generation & Dispatch',
    description: 'Cryptographic binding of all manufacturing threads, torque records, CMM scans, and dyno data to engine serial.',
    machineIds: ['DISPATCH-STG-01'],
    wipCount: 2,
    standardCycleTimeMin: 10,
    qualityGateName: 'Digital Quality Passport Release Gate',
  },
];

export const INITIAL_MACHINES: MachineTwin[] = [
  {
    machineId: 'CNC-MILL-5AX-01',
    name: 'Hermle C52 5-Axis Machining Center',
    type: 'CNC_5AXIS_MILL',
    stationName: 'Station 04 - Block & Head Machining',
    status: 'RUNNING',
    cycleTimeSec: 2450,
    spindleSpeedRpm: 12500,
    feedRateMmMin: 4200,
    cuttingSpeedMMin: 220,
    powerConsumptionKw: 38.5,
    toolWearPercent: 24.5,
    vibrationRmsMmS: 0.85,
    uptimePercent: 96.8,
    currentPartId: 'BLK-H2-2000-01',
    currentOperation: 'Deck face milling and combustion chamber semi-finish',
  },
  {
    machineId: 'CNC-LATHE-02',
    name: 'DMG MORI CTX gamma 2000 TC Lathe',
    type: 'CNC_LATHE',
    stationName: 'Station 04 - Crankshaft Turning',
    status: 'RUNNING',
    cycleTimeSec: 1820,
    spindleSpeedRpm: 2800,
    feedRateMmMin: 850,
    cuttingSpeedMMin: 185,
    powerConsumptionKw: 29.2,
    toolWearPercent: 38.0,
    vibrationRmsMmS: 0.62,
    uptimePercent: 94.2,
    currentPartId: 'CRK-H2-2000-01',
    currentOperation: 'Crankshaft main and rod journal finish turning',
  },
  {
    machineId: 'HONE-NAGEL-01',
    name: 'Nagel EcoHone Precision Cylinder Honer',
    type: 'PLATEAU_HONING',
    stationName: 'Station 05 - Cylinder Honing',
    status: 'RUNNING',
    cycleTimeSec: 840,
    spindleSpeedRpm: 450,
    feedRateMmMin: 1200,
    cuttingSpeedMMin: 65,
    powerConsumptionKw: 14.8,
    toolWearPercent: 12.0,
    vibrationRmsMmS: 0.42,
    uptimePercent: 98.1,
    currentPartId: 'BLK-H2-2000-01',
    currentOperation: 'Plateau diamond honing 45 deg crosshatch finish',
  },
  {
    machineId: 'CMM-ZEISS-PRISMO-01',
    name: 'Zeiss PRISMO Ultra CMM with VAST Gold Probe',
    type: 'CMM_METROLOGY',
    stationName: 'Station 08 - Quality Metrology Lab',
    status: 'RUNNING',
    cycleTimeSec: 1420,
    spindleSpeedRpm: 0,
    feedRateMmMin: 350,
    cuttingSpeedMMin: 0,
    powerConsumptionKw: 4.2,
    toolWearPercent: 1.5,
    vibrationRmsMmS: 0.08,
    uptimePercent: 99.4,
    currentPartId: 'BLK-H2-2000-01',
    currentOperation: 'Scanning bore cylindricity, roundness & deck flatness',
  },
  {
    machineId: 'ASM-TORQUE-CELL-01',
    name: 'Atlas Copco Tensor Multi-Spindle Torque System',
    type: 'TORQUE_ASSEMBLY',
    stationName: 'Station 07 - Final Assembly',
    status: 'RUNNING',
    cycleTimeSec: 1100,
    spindleSpeedRpm: 120,
    feedRateMmMin: 0,
    cuttingSpeedMMin: 0,
    powerConsumptionKw: 6.5,
    toolWearPercent: 5.0,
    vibrationRmsMmS: 0.15,
    uptimePercent: 98.9,
    currentPartId: 'ENG-H2-000127',
    currentOperation: 'Torque-to-yield head bolt fastening (60 Nm + 90 deg)',
  },
  {
    machineId: 'TEST-CELL-AVL-01',
    name: 'AVL PUMA 2 Hydro-Dyno Test Cell',
    type: 'TEST_CELL_DYNO',
    stationName: 'Station 09 - Engine Hot Dyno',
    status: 'RUNNING',
    cycleTimeSec: 2400,
    spindleSpeedRpm: 6500,
    feedRateMmMin: 0,
    cuttingSpeedMMin: 0,
    powerConsumptionKw: 85.0,
    toolWearPercent: 2.0,
    vibrationRmsMmS: 2.1,
    uptimePercent: 95.5,
    currentPartId: 'ENG-H2-000127',
    currentOperation: 'Automated 12-point power sweep and NOx verification',
  },
];
