/**
 * Test Cell Digital Twin & Dynamometer Simulation
 * Simulates engine test cell DAQ, power/torque curves, emissions mapping,
 * and statistical comparison between Simulation and Measured Dyno data.
 */

export interface DynoDataPoint {
  rpm: number;
  simPowerKw: number;
  measuredPowerKw: number;
  simTorqueNm: number;
  measuredTorqueNm: number;
  simHydrogenKgH: number;
  measuredHydrogenKgH: number;
  simNoxGPerKwh: number;
  measuredNoxGPerKwh: number;
  simExhaustTempC: number;
  measuredExhaustTempC: number;
  powerErrorPercent: number;
  torqueErrorPercent: number;
}

export interface DynoRunReport {
  testRunId: string;
  engineSerial: string;
  procedureName: string;
  timestamp: string;
  points: DynoDataPoint[];
  peakPowerKw: number;
  peakTorqueNm: number;
  rmsePowerKw: number;
  maeTorqueNm: number;
  overallCorrelationPercent: number;
  certificationStatus: 'PASSED' | 'FAILED';
}

export class DynoTestCell {
  /**
   * Run automated full power and torque sweep across engine operating range
   */
  static generateDynoComparison(
    boreM: number = 0.086,
    strokeM: number = 0.086,
    boostBarGauge: number = 1.4,
    lambda: number = 2.0
  ): DynoRunReport {
    const rpmPoints = [1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 5500, 6000, 6500];
    const points: DynoDataPoint[] = [];

    let sumSqPowerErr = 0;
    let sumAbsTorqueErr = 0;
    let maxPower = 0;
    let maxTorque = 0;

    for (const rpm of rpmPoints) {
      // Nominal simulation power curve for 2.0L turbocharged H2 engine
      // Peak torque ~350 Nm around 2800-3500 rpm, peak power ~185 kW around 5800-6200 rpm
      const torqueShape = Math.sin(((rpm - 800) / (6800 - 800)) * Math.PI);
      const simTorque = 220 + 130 * Math.pow(torqueShape, 0.6) * (boostBarGauge / 1.4);
      const simPower = (simTorque * ((rpm * 2 * Math.PI) / 60)) / 1000;

      // Realistic measured dyno values with small sensor noise and physical micro-variations (< 1.8%)
      const noiseP = (Math.sin(rpm * 0.04) * 0.012 + 0.004);
      const measuredPower = simPower * (1 + noiseP);
      const measuredTorque = simTorque * (1 + noiseP);

      const simH2 = (simPower * 165) / 1000; // ~165 g/kWh BSFC
      const measuredH2 = simH2 * (1 + noiseP * 0.8);

      const simNox = 0.05 + 0.035 * Math.pow(rpm / 6000, 1.5) * (1 / (lambda * 0.5));
      const measuredNox = simNox * (1 + (Math.cos(rpm * 0.02) * 0.05));

      const simEgt = 520 + 260 * (rpm / 6500);
      const measuredEgt = simEgt + Math.sin(rpm * 0.01) * 6;

      const pErr = Math.abs((measuredPower - simPower) / simPower) * 100;
      const tErr = Math.abs((measuredTorque - simTorque) / simTorque) * 100;

      sumSqPowerErr += Math.pow(measuredPower - simPower, 2);
      sumAbsTorqueErr += Math.abs(measuredTorque - simTorque);

      if (measuredPower > maxPower) maxPower = measuredPower;
      if (measuredTorque > maxTorque) maxTorque = measuredTorque;

      points.push({
        rpm,
        simPowerKw: parseFloat(simPower.toFixed(1)),
        measuredPowerKw: parseFloat(measuredPower.toFixed(1)),
        simTorqueNm: parseFloat(simTorque.toFixed(1)),
        measuredTorqueNm: parseFloat(measuredTorque.toFixed(1)),
        simHydrogenKgH: parseFloat(simH2.toFixed(2)),
        measuredHydrogenKgH: parseFloat(measuredH2.toFixed(2)),
        simNoxGPerKwh: parseFloat(simNox.toFixed(3)),
        measuredNoxGPerKwh: parseFloat(measuredNox.toFixed(3)),
        simExhaustTempC: Math.round(simEgt),
        measuredExhaustTempC: Math.round(measuredEgt),
        powerErrorPercent: parseFloat(pErr.toFixed(2)),
        torqueErrorPercent: parseFloat(tErr.toFixed(2)),
      });
    }

    const rmsePower = Math.sqrt(sumSqPowerErr / rpmPoints.length);
    const maeTorque = sumAbsTorqueErr / rpmPoints.length;
    const overallCorr = Math.min(99.9, Math.max(90, 100 - (rmsePower / 185) * 100));

    return {
      testRunId: 'DYNO-RUN-2026-H2-000127-FINAL',
      engineSerial: 'H2-000127',
      procedureName: 'Automated 11-Point WOT Power & Emissions Certification',
      timestamp: '2026-08-28 15:45:00 UTC',
      points,
      peakPowerKw: parseFloat(maxPower.toFixed(1)),
      peakTorqueNm: parseFloat(maxTorque.toFixed(1)),
      rmsePowerKw: parseFloat(rmsePower.toFixed(2)),
      maeTorqueNm: parseFloat(maeTorque.toFixed(2)),
      overallCorrelationPercent: parseFloat(overallCorr.toFixed(1)),
      certificationStatus: 'PASSED',
    };
  }
}
