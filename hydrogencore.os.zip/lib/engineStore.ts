/**
 * Master State Engine & Simulation Loop for HYDROGENCORE.OS
 * Single source of truth embodying the Digital Thread:
 * Design -> Physics -> Component -> Material -> Manufacturing -> Metrology -> Assembly -> Test -> Operation -> Lifecycle.
 */

import {
  HydrogenEngineTwin,
  EngineConfiguration,
  EngineLiveState,
  DigitalThread,
  SafetyState,
} from './domain/types';
import { REFERENCE_CONFIG_I4, MATERIAL_DATABASE } from './syntheticData';
import { HydrogenCombustionSolver, CombustionSimulationResult } from './physics/combustion';
import { EmissionsModel, EmissionsBreakdown } from './physics/emissions';
import { ThermalNetworkModel, EngineThermalNodes } from './physics/thermal';
import { CranktrainMechanics, CrankDynamics } from './physics/mechanics';
import { VibrationModel, VibrationAnalysis } from './physics/vibration';
import { TurbochargerPhysics, CompressorOperatingPoint } from './physics/turbocharger';
import { HydrogenSafetySystem, HydrogenSafetyStatus } from './safety/safetySystem';

export type ViewMode = 'NORMAL' | 'CUTAWAY' | 'EXPLODED' | 'FLOW' | 'THERMAL' | 'COMBUSTION';
export type ActiveConsoleTab = 'TWIN_3D' | 'ENGINEERING' | 'MANUFACTURING' | 'TEST_CELL' | 'PASSPORT' | 'SCENARIOS';

export interface ActiveFaults {
  injectorRestriction: boolean;
  coolantPumpDegradation: boolean;
  hydrogenPressureLoss: boolean;
  hydrogenLeak: boolean;
  bearingWear: boolean;
  misfire: boolean;
}

export interface EngineStoreState {
  config: EngineConfiguration;
  liveState: EngineLiveState;
  combustionResult: CombustionSimulationResult;
  emissions: EmissionsBreakdown;
  thermalNodes: EngineThermalNodes;
  crankDynamics: CrankDynamics;
  vibration: VibrationAnalysis;
  turboOperating: CompressorOperatingPoint;
  safetyStatus: HydrogenSafetyStatus;
  
  // Controls
  rpm: number;
  loadFactor: number; // 0.1 to 1.0
  lambda: number; // 1.2 to 2.5
  boostBarGauge: number; // 0.2 to 2.2 bar
  ignitionAdvanceDegBtdc: number; // 10 to 30 deg
  egrPercent: number; // 0 to 25%

  // Faults
  activeFaults: ActiveFaults;

  // UI state
  activeTab: ActiveConsoleTab;
  viewMode: ViewMode;
  selectedComponentId: string | null;
  simulationRunning: boolean;
  clockSpeedMultiplier: number; // 1, 5, 10
  crankAngleDeg: number;
}

export function createInitialEngineState(): EngineStoreState {
  const config = REFERENCE_CONFIG_I4;
  const rpm = 3000;
  const loadFactor = 0.75;
  const lambda = 2.0; // Clean lean-burn operation
  const boostBarGauge = 1.4; // 1.4 bar boost
  const ignitionAdvanceDegBtdc = 18;
  const egrPercent = 5;

  const combustionResult = HydrogenCombustionSolver.solveCycle(
    config.boreM,
    config.strokeM,
    config.rodLengthM,
    config.compressionRatio,
    config.cylinderCount,
    rpm,
    loadFactor,
    lambda,
    boostBarGauge,
    ignitionAdvanceDegBtdc
  );

  const emissions = EmissionsModel.calculateEmissions(
    combustionResult.peakTemperatureK,
    combustionResult.peakPressureBar,
    lambda,
    egrPercent,
    ignitionAdvanceDegBtdc,
    combustionResult.brakePowerW / 1000
  );

  const thermalNodes = ThermalNetworkModel.calculateTemperatures(
    combustionResult.brakePowerW / 1000,
    rpm,
    combustionResult.peakTemperatureK,
    75,
    0.85,
    false
  );

  const crankDynamics = CranktrainMechanics.calculateCrankForces(
    config.boreM,
    config.strokeM,
    config.rodLengthM,
    0.340, // 340g piston mass
    0.160, // 160g rod recip mass
    combustionResult.peakPressureBar * 1e5,
    20, // 20 deg ATDC peak force
    rpm
  );

  const vibration = VibrationModel.analyzeVibration(
    rpm,
    config.cylinderCount,
    combustionResult.peakPressureBar,
    false,
    false
  );

  const turboOperating = TurbochargerPhysics.evaluateCompressor(
    combustionResult.airFlowKgH / 3600,
    boostBarGauge
  );

  const safetyStatus = HydrogenSafetySystem.evaluateSafety(12, 350, thermalNodes.engineCoolantC, false);

  const liveState: EngineLiveState = {
    timestampMs: Date.now(),
    crankAngleDeg: 0,
    rpm,
    torqueNm: parseFloat(combustionResult.brakeTorqueNm.toFixed(1)),
    powerW: parseFloat(combustionResult.brakePowerW.toFixed(0)),
    imepBar: parseFloat(combustionResult.imepBar.toFixed(2)),
    bmepBar: parseFloat(combustionResult.bmepBar.toFixed(2)),
    fmepBar: parseFloat(combustionResult.fmepBar.toFixed(2)),
    thermalEfficiency: parseFloat((combustionResult.thermalEfficiency * 100).toFixed(1)),
    hydrogenFlowKgH: parseFloat(combustionResult.fuelFlowKgH.toFixed(2)),
    airFlowKgH: parseFloat(combustionResult.airFlowKgH.toFixed(1)),
    lambda,
    boostPressureBar: boostBarGauge,
    oilPressureBar: 4.5,
    oilTemperatureC: thermalNodes.engineOilC,
    coolantTemperatureC: thermalNodes.engineCoolantC,
    exhaustTemperatureC: thermalNodes.exhaustManifoldC,
    peakCylinderPressureBar: parseFloat(combustionResult.peakPressureBar.toFixed(1)),
    vibrationRmsMmS: vibration.overallRmsMmS,
    noxGPerKwh: emissions.totalNoxGPerKwh,
    h2SlipPpm: emissions.unburnedH2SlipPpm,
    overallHealthScore: 98.4,
    fidelity: 'ENGINEERING',
    safetyState: 'SAFE',
  };

  return {
    config,
    liveState,
    combustionResult,
    emissions,
    thermalNodes,
    crankDynamics,
    vibration,
    turboOperating,
    safetyStatus,
    rpm,
    loadFactor,
    lambda,
    boostBarGauge,
    ignitionAdvanceDegBtdc,
    egrPercent,
    activeFaults: {
      injectorRestriction: false,
      coolantPumpDegradation: false,
      hydrogenPressureLoss: false,
      hydrogenLeak: false,
      bearingWear: false,
      misfire: false,
    },
    activeTab: 'TWIN_3D',
    viewMode: 'NORMAL',
    selectedComponentId: null,
    simulationRunning: true,
    clockSpeedMultiplier: 1,
    crankAngleDeg: 0,
  };
}

/**
 * Re-evaluates entire causal physics loop with current control parameters and active faults
 */
export function recomputeEnginePhysics(prev: EngineStoreState): EngineStoreState {
  const { config, activeFaults } = prev;
  let { rpm, loadFactor, lambda, boostBarGauge, ignitionAdvanceDegBtdc, egrPercent } = prev;

  // Causal impact of active faults:
  let effectiveLambda = lambda;
  let effectiveCoolantLoss = activeFaults.coolantPumpDegradation;
  let simulatedH2Ppm = 12;
  let effectiveRailPressure = 350;

  if (activeFaults.injectorRestriction) {
    // Injector restriction causes localized lean-out and torque drop
    effectiveLambda *= 1.25; // leaner
  }

  if (activeFaults.hydrogenPressureLoss) {
    effectiveRailPressure = 180; // drops below rating
    boostBarGauge *= 0.6; // boost curtailed
    loadFactor *= 0.65; // ECU torque limit
  }

  if (activeFaults.hydrogenLeak) {
    simulatedH2Ppm = 6200; // >10% LFL triggers warning!
  }

  // 1. Solve thermodynamics
  const combustionResult = HydrogenCombustionSolver.solveCycle(
    config.boreM,
    config.strokeM,
    config.rodLengthM,
    config.compressionRatio,
    config.cylinderCount,
    rpm,
    loadFactor,
    effectiveLambda,
    boostBarGauge,
    ignitionAdvanceDegBtdc
  );

  // 2. Solve thermal network
  const thermalNodes = ThermalNetworkModel.calculateTemperatures(
    combustionResult.brakePowerW / 1000,
    rpm,
    combustionResult.peakTemperatureK,
    effectiveCoolantLoss ? 18 : 75,
    0.85,
    effectiveCoolantLoss
  );

  // 3. Solve emissions (Zeldovich thermal NOx)
  const emissions = EmissionsModel.calculateEmissions(
    combustionResult.peakTemperatureK,
    combustionResult.peakPressureBar,
    effectiveLambda,
    egrPercent,
    ignitionAdvanceDegBtdc,
    combustionResult.brakePowerW / 1000
  );

  // 4. Solve cranktrain mechanics & hydrodynamic bearing film
  const crankDynamics = CranktrainMechanics.calculateCrankForces(
    config.boreM,
    config.strokeM,
    config.rodLengthM,
    0.340,
    0.160,
    combustionResult.peakPressureBar * 1e5,
    20,
    rpm
  );

  // 5. Solve vibration & harmonics
  const vibration = VibrationModel.analyzeVibration(
    rpm,
    config.cylinderCount,
    combustionResult.peakPressureBar,
    activeFaults.bearingWear,
    activeFaults.misfire || activeFaults.injectorRestriction
  );

  // 6. Turbocharger compressor map
  const turboOperating = TurbochargerPhysics.evaluateCompressor(
    combustionResult.airFlowKgH / 3600,
    boostBarGauge
  );

  // 7. Safety interlocks & ESD evaluation
  const safetyStatus = HydrogenSafetySystem.evaluateSafety(
    simulatedH2Ppm,
    effectiveRailPressure,
    thermalNodes.engineCoolantC,
    false
  );

  // Compute decomposable health score
  let healthScore = 98.4;
  if (activeFaults.coolantPumpDegradation) healthScore -= 18.0;
  if (activeFaults.injectorRestriction) healthScore -= 14.5;
  if (activeFaults.bearingWear) healthScore -= 22.0;
  if (activeFaults.hydrogenLeak) healthScore -= 30.0;
  if (activeFaults.hydrogenPressureLoss) healthScore -= 15.0;
  if (activeFaults.misfire) healthScore -= 20.0;
  healthScore = Math.max(15, parseFloat(healthScore.toFixed(1)));

  const liveState: EngineLiveState = {
    timestampMs: Date.now(),
    crankAngleDeg: prev.crankAngleDeg,
    rpm,
    torqueNm: parseFloat(combustionResult.brakeTorqueNm.toFixed(1)),
    powerW: parseFloat(combustionResult.brakePowerW.toFixed(0)),
    imepBar: parseFloat(combustionResult.imepBar.toFixed(2)),
    bmepBar: parseFloat(combustionResult.bmepBar.toFixed(2)),
    fmepBar: parseFloat(combustionResult.fmepBar.toFixed(2)),
    thermalEfficiency: parseFloat((combustionResult.thermalEfficiency * 100).toFixed(1)),
    hydrogenFlowKgH: parseFloat(combustionResult.fuelFlowKgH.toFixed(2)),
    airFlowKgH: parseFloat(combustionResult.airFlowKgH.toFixed(1)),
    lambda: effectiveLambda,
    boostPressureBar: boostBarGauge,
    oilPressureBar: activeFaults.bearingWear ? 2.8 : 4.5,
    oilTemperatureC: thermalNodes.engineOilC,
    coolantTemperatureC: thermalNodes.engineCoolantC,
    exhaustTemperatureC: thermalNodes.exhaustManifoldC,
    peakCylinderPressureBar: parseFloat(combustionResult.peakPressureBar.toFixed(1)),
    vibrationRmsMmS: vibration.overallRmsMmS,
    noxGPerKwh: emissions.totalNoxGPerKwh,
    h2SlipPpm: emissions.unburnedH2SlipPpm,
    overallHealthScore: healthScore,
    fidelity: 'ENGINEERING',
    safetyState: safetyStatus.state,
  };

  return {
    ...prev,
    liveState,
    combustionResult,
    emissions,
    thermalNodes,
    crankDynamics,
    vibration,
    turboOperating,
    safetyStatus,
  };
}
