/**
 * Turbocharger & Intercooler Digital Twin Physics
 * Real compressor performance maps, turbine power balance, and heat exchanger effectiveness.
 */

export interface CompressorOperatingPoint {
  correctedMassFlowKgS: number;
  pressureRatio: number;
  shaftSpeedRpm: number;
  efficiency: number;
  isSurge: boolean;
  isChoke: boolean;
}

export interface IntercoolerState {
  tInK: number;
  tOutK: number;
  pressureDropPa: number;
  heatRejectionRateW: number;
  effectiveness: number;
}

export class TurbochargerPhysics {
  /**
   * Evaluate compressor operating point on the compressor map
   */
  static evaluateCompressor(
    airMassFlowKgS: number,
    targetBoostBarGauge: number,
    ambientPressurePa: number = 101325
  ): CompressorOperatingPoint {
    const pOutPa = ambientPressurePa + targetBoostBarGauge * 1e5;
    const pr = Math.max(1.05, pOutPa / ambientPressurePa);
    
    // Corrected mass flow: m_dot_corr = m_dot * sqrt(T/T_ref) / (P/P_ref)
    const correctedFlow = Math.max(0.02, airMassFlowKgS);

    // Speed estimation from PR: N_shaft ~ k * sqrt(PR - 1)
    const shaftSpeedRpm = Math.min(185000, 65000 + (pr - 1.0) * 55000);

    // Surge line boundary: PR_surge = 1.0 + 8.5 * correctedFlow
    const surgePrLimit = 1.0 + 9.5 * correctedFlow;
    const isSurge = pr > surgePrLimit;

    // Choke line boundary: correctedFlow_max = 0.08 + 0.12 * PR
    const chokeFlowLimit = 0.08 + 0.14 * pr;
    const isChoke = correctedFlow > chokeFlowLimit;

    // Peak efficiency island around PR 1.8 - 2.4 and flow 0.15 - 0.28 kg/s
    let efficiency = 0.74;
    if (isSurge || isChoke) {
      efficiency = 0.55;
    } else {
      const flowDev = Math.abs(correctedFlow - 0.20);
      const prDev = Math.abs(pr - 2.1);
      efficiency = Math.max(0.60, 0.78 - 0.8 * Math.pow(flowDev, 1.5) - 0.06 * Math.pow(prDev, 2));
    }

    return {
      correctedMassFlowKgS: correctedFlow,
      pressureRatio: pr,
      shaftSpeedRpm,
      efficiency,
      isSurge,
      isChoke,
    };
  }

  /**
   * Intercooler charge air cooler (CAC) thermal calculation
   */
  static calculateIntercooler(
    tCompressorOutK: number,
    ambientTempK: number,
    airMassFlowKgS: number
  ): IntercoolerState {
    const effectiveness = 0.85; // High-efficiency air-to-air core
    const tOutK = tCompressorOutK - effectiveness * (tCompressorOutK - ambientTempK);
    const cpAir = 1005; // J/(kg*K)
    const heatRejectionRateW = airMassFlowKgS * cpAir * (tCompressorOutK - tOutK);
    const pressureDropPa = 7000 + 15000 * Math.pow(airMassFlowKgS / 0.25, 2);

    return {
      tInK: tCompressorOutK,
      tOutK: Math.max(ambientTempK + 5, tOutK),
      pressureDropPa,
      heatRejectionRateW,
      effectiveness,
    };
  }
}
