/**
 * Hydrogen Gas Property Model for HYDROGENCORE.OS
 * Real-gas thermodynamics, compressibility, heating value, flammability limits and transport properties.
 * Strict SI calculations.
 */

export const H2_PROPERTIES = {
  molecularWeightKgMol: 0.00201588, // 2.016 g/mol
  specificGasConstantR: 4124.2, // J/(kg·K) = R_universal / M
  lowerHeatingValueLhvJPerKg: 119.96e6, // 119.96 MJ/kg (highest energy density by mass)
  higherHeatingValueHhvJPerKg: 141.80e6, // 141.80 MJ/kg
  stoichiometricAfr: 34.3, // 34.3 kg air per 1 kg H2 (vs 14.7 for gasoline)
  flammabilityLimitLowerPercent: 4.0, // 4% in air
  flammabilityLimitUpperPercent: 75.0, // 75% in air (extremely wide flammability)
  minimumIgnitionEnergyMilliJoules: 0.02, // 0.02 mJ (vs 0.24 mJ for methane/gasoline)
  laminarFlameSpeedMaxMS: 2.5, // 2.5 m/s at phi=1.8 (approx 5x faster than hydrocarbons)
  autoIgnitionTempK: 858.15, // 585 °C
  criticalPressurePa: 1.293e6, // 12.93 bar
  criticalTemperatureK: 33.145, // -240 °C
  gammaCpCv: 1.405, // Specific heat ratio at standard temp
};

export class HydrogenPropertyModel {
  /**
   * Compressibility factor Z for gaseous hydrogen as function of P (Pa) and T (K)
   * Derived from Abel-Noble equation of state for high-pressure H2 gas (up to 700 bar).
   */
  static getCompressibilityFactor(pressurePa: number, tempK: number): number {
    const b = 0.00769e-3; // co-volume constant m3/kg
    const R = H2_PROPERTIES.specificGasConstantR;
    // Z = 1 + (b * P) / (R * T)
    const z = 1 + (b * pressurePa) / (R * tempK);
    return Math.max(1.0, z);
  }

  /**
   * Gas-phase density kg/m3 using real gas law: rho = P / (Z * R * T)
   */
  static getDensityKgM3(pressurePa: number, tempK: number): number {
    const Z = this.getCompressibilityFactor(pressurePa, tempK);
    const density = pressurePa / (Z * H2_PROPERTIES.specificGasConstantR * tempK);
    return Math.max(0.01, density);
  }

  /**
   * Speed of sound in hydrogen (m/s): a = sqrt(gamma * Z * R * T)
   */
  static getSpeedOfSoundMS(pressurePa: number, tempK: number): number {
    const Z = this.getCompressibilityFactor(pressurePa, tempK);
    return Math.sqrt(H2_PROPERTIES.gammaCpCv * Z * H2_PROPERTIES.specificGasConstantR * tempK);
  }

  /**
   * Dynamic viscosity (Pa·s) via Sutherland correlation for H2
   */
  static getDynamicViscosityPaS(tempK: number): number {
    const mu0 = 8.76e-6; // Pa·s at T0 = 273.15 K
    const T0 = 273.15;
    const S = 72; // Sutherland constant for H2
    return mu0 * Math.pow(tempK / T0, 1.5) * ((T0 + S) / (tempK + S));
  }

  /**
   * Specific heat Cp (J/(kg·K)) as function of temperature
   */
  static getCpJKgK(tempK: number): number {
    // Polynomial fit around 300K - 1200K
    return 14300 + 0.5 * (tempK - 300);
  }
}
