/**
 * Hydrogen Combustion & Thermodynamic Cycle Engine for HYDROGENCORE.OS
 * 4-stroke SI cycle, Wiebe heat release formulation, hydrogen flame kinetics,
 * and crank-angle resolved P(theta), T(theta), V(theta) computation.
 */

import { H2_PROPERTIES } from './hydrogen';
import { EngineKinematics } from './kinematics';

export interface CyclePoint {
  crankAngleDeg: number;
  volumeM3: number;
  pressurePa: number;
  pressureBar: number;
  temperatureK: number;
  heatReleaseRateJDeg: number;
  massKg: number;
}

export interface CombustionSimulationResult {
  indicatedWorkPerCylinderJ: number;
  imepPa: number;
  imepBar: number;
  bmepBar: number;
  fmepBar: number;
  indicatedPowerW: number;
  brakePowerW: number;
  brakeTorqueNm: number;
  thermalEfficiency: number; // BTE
  fuelFlowKgH: number;
  airFlowKgH: number;
  peakPressureBar: number;
  peakPressureAngleDeg: number;
  peakTemperatureK: number;
  cycleData: CyclePoint[]; // 72 points across 0° - 720°
}

export class HydrogenCombustionSolver {
  /**
   * Run 4-stroke thermodynamic cycle simulation for hydrogen combustion
   */
  static solveCycle(
    boreM: number,
    strokeM: number,
    rodLengthM: number,
    compressionRatio: number,
    cylinderCount: number,
    rpm: number,
    loadFactor: number, // 0.1 to 1.0
    lambda: number, // e.g. 1.2 to 2.5 (lean burn)
    boostPressureBar: number, // gauge boost e.g. 0.8 to 2.2 bar
    ignitionAdvanceDegBtdc: number // e.g. 15 to 25 deg before TDC
  ): CombustionSimulationResult {
    const sweptVolPerCyl = EngineKinematics.getSweptVolume(boreM, strokeM);
    const totalDisplacementM3 = sweptVolPerCyl * cylinderCount;
    const vClearance = sweptVolPerCyl / (compressionRatio - 1);
    
    // Intake conditions
    const pAtm = 101325; // Pa
    const boostPa = Math.max(0, boostPressureBar) * 1e5;
    const pIntake = (pAtm + boostPa) * (0.2 + 0.8 * loadFactor); // throttle & boost
    const tIntake = 315; // K (after intercooler)

    // Air & Fuel calculation
    // Air density at intake: rho_air = P / (R_air * T)
    const R_air = 287.058; // J/(kg*K)
    const volumetricEfficiency = Math.min(1.05, 0.85 + 0.12 * (loadFactor) - 0.05 * Math.pow((rpm - 3500) / 3500, 2));
    const airMassPerCylinder = (pIntake / (R_air * tIntake)) * sweptVolPerCyl * volumetricEfficiency;

    // Stoichiometric AFR for H2 is 34.3
    const h2MassPerCylinder = airMassPerCylinder / (34.3 * lambda);
    const totalChargeMass = airMassPerCylinder + h2MassPerCylinder;

    // Hydrogen chemical energy released (LHV = 119.96 MJ/kg)
    const totalCombustionEnergyJ = h2MassPerCylinder * H2_PROPERTIES.lowerHeatingValueLhvJPerKg * 0.98; // 98% combustion efficiency

    // Wiebe parameters for Hydrogen:
    // Hydrogen burns significantly faster than hydrocarbons.
    // Wiebe form: xb(theta) = 1 - exp( -a * ((theta - theta_start) / delta_theta)^m )
    // H2 typical burn duration delta_theta is around 25 - 35 deg CA (vs 50-60 for gasoline)
    const thetaStart = 720 - ignitionAdvanceDegBtdc; // e.g. 705 deg (15 BTDC)
    const burnDurationDeg = Math.max(18, 30 / Math.sqrt(Math.max(0.5, 2.0 / lambda))); // faster at rich/stoich
    const wiebeA = 5.0; // standard Wiebe parameter
    const wiebeM = 2.0; // form factor for rapid H2 turbulent flame

    const cyclePoints: CyclePoint[] = [];
    const gammaAir = 1.36; // effective polytropic exponent for compression
    const gammaExhaust = 1.30; // effective polytropic exponent for expansion

    let pCurrent = pIntake;
    let tCurrent = tIntake;
    let workAccumulatedJ = 0;
    let peakPressure = 0;
    let peakPressureAngle = 0;
    let peakTemp = 0;

    const stepDeg = 10;
    let prevVol = EngineKinematics.calculateKinematics(boreM, strokeM, rodLengthM, compressionRatio, 0, rpm).cylinderVolumeM3;

    for (let deg = 0; deg <= 720; deg += stepDeg) {
      const kin = EngineKinematics.calculateKinematics(boreM, strokeM, rodLengthM, compressionRatio, deg, rpm);
      const vCyl = kin.cylinderVolumeM3;
      let dQ_dTheta = 0;

      // 4-Stroke Phases:
      if (deg >= 0 && deg < 180) {
        // Combustion / Expansion stroke (Power)
        // From TDC (0) to BDC (180)
        const effectiveTheta = 720 + deg;
        if (effectiveTheta >= thetaStart && effectiveTheta <= thetaStart + burnDurationDeg) {
          const progress = (effectiveTheta - thetaStart) / burnDurationDeg;
          const xb = 1 - Math.exp(-wiebeA * Math.pow(progress, wiebeM));
          const xbPrev = 1 - Math.exp(-wiebeA * Math.pow(Math.max(0, progress - stepDeg / burnDurationDeg), wiebeM));
          const dXb = Math.max(0, xb - xbPrev);
          dQ_dTheta = (dXb * totalCombustionEnergyJ) / stepDeg;
        }

        // Pressure calculation from polytropic expansion + heat release
        const vRatio = prevVol / vCyl;
        const pAdiabatic = pCurrent * Math.pow(vRatio, gammaExhaust);
        // Energy addition dT = (dQ - P*dV) / (m * Cv)
        const Cv = 720; // J/(kg*K) average mixture Cv
        const heatAdditionPa = (dQ_dTheta * stepDeg * (gammaExhaust - 1)) / vCyl;
        pCurrent = Math.max(pAtm * 0.9, pAdiabatic + heatAdditionPa);
        tCurrent = Math.min(2800, (pCurrent * vCyl) / (totalChargeMass * R_air));

      } else if (deg >= 180 && deg < 360) {
        // Exhaust stroke (BDC to TDC)
        // Blowdown to exhaust manifold pressure ~1.2-1.5 bar abs
        const pExhaust = pAtm + 0.25e5 * (loadFactor);
        pCurrent = pExhaust + 0.1e5 * Math.sin(((deg - 180) * Math.PI) / 180);
        tCurrent = 750 + 200 * loadFactor;

      } else if (deg >= 360 && deg < 540) {
        // Intake stroke (TDC to BDC)
        pCurrent = pIntake - 0.05e5 * Math.sin(((deg - 360) * Math.PI) / 180);
        tCurrent = tIntake;

      } else {
        // Compression stroke (540 to 720)
        const vRatio = prevVol / vCyl;
        pCurrent = pCurrent * Math.pow(vRatio, gammaAir);
        tCurrent = tIntake * Math.pow(vRatio, gammaAir - 1);

        // Pre-TDC spark & early heat release
        if (deg >= thetaStart && deg <= 720) {
          const progress = (deg - thetaStart) / burnDurationDeg;
          const xb = 1 - Math.exp(-wiebeA * Math.pow(progress, wiebeM));
          const xbPrev = 1 - Math.exp(-wiebeA * Math.pow(Math.max(0, progress - stepDeg / burnDurationDeg), wiebeM));
          const dXb = Math.max(0, xb - xbPrev);
          dQ_dTheta = (dXb * totalCombustionEnergyJ) / stepDeg;
          const heatAdditionPa = (dQ_dTheta * stepDeg * (gammaAir - 1)) / vCyl;
          pCurrent += heatAdditionPa;
          tCurrent += (dQ_dTheta * stepDeg) / (totalChargeMass * 720);
        }
      }

      // Work PdV
      if (deg > 0) {
        const dV = vCyl - prevVol;
        workAccumulatedJ += pCurrent * dV;
      }
      prevVol = vCyl;

      if (pCurrent > peakPressure) {
        peakPressure = pCurrent;
        peakPressureAngle = deg;
      }
      if (tCurrent > peakTemp) {
        peakTemp = tCurrent;
      }

      cyclePoints.push({
        crankAngleDeg: deg,
        volumeM3: vCyl,
        pressurePa: pCurrent,
        pressureBar: pCurrent / 1e5,
        temperatureK: tCurrent,
        heatReleaseRateJDeg: dQ_dTheta,
        massKg: totalChargeMass,
      });
    }

    // IMEP (Indicated Mean Effective Pressure): W_net / V_d
    const imepPa = Math.max(1e5, workAccumulatedJ / sweptVolPerCyl);
    const imepBar = imepPa / 1e5;

    // FMEP (Friction Mean Effective Pressure via Chen-Flynn model)
    // FMEP = a + b*P_max + c*meanPistonSpeed + d*meanPistonSpeed^2
    const meanPistonSpeed = (2 * strokeM * rpm) / 60;
    const fmepBar = 0.4 + 0.005 * (peakPressure / 1e5) + 0.08 * meanPistonSpeed + 0.001 * Math.pow(meanPistonSpeed, 2);

    // BMEP = IMEP - FMEP
    const bmepBar = Math.max(0.2, imepBar - fmepBar);

    // Indicated and Brake Power
    // Power = (BMEP * V_d * N) / (2 * 60) for 4-stroke
    const indicatedPowerW = (imepPa * totalDisplacementM3 * rpm) / 120;
    const brakePowerW = Math.max(1000, (bmepBar * 1e5 * totalDisplacementM3 * rpm) / 120);

    // Brake Torque: T = P / omega
    const omega = (rpm * 2 * Math.PI) / 60;
    const brakeTorqueNm = brakePowerW / omega;

    // Fuel Consumption & Efficiency
    // H2 mass flow per second = h2MassPerCylinder * cylinderCount * (rpm / 120)
    const fuelFlowKgS = h2MassPerCylinder * cylinderCount * (rpm / 120);
    const fuelFlowKgH = fuelFlowKgS * 3600;
    const airFlowKgH = airMassPerCylinder * cylinderCount * (rpm / 120) * 3600;

    const fuelInputPowerW = fuelFlowKgS * H2_PROPERTIES.lowerHeatingValueLhvJPerKg;
    const thermalEfficiency = Math.min(0.48, Math.max(0.20, brakePowerW / fuelInputPowerW));

    return {
      indicatedWorkPerCylinderJ: workAccumulatedJ,
      imepPa,
      imepBar,
      bmepBar,
      fmepBar,
      indicatedPowerW,
      brakePowerW,
      brakeTorqueNm,
      thermalEfficiency,
      fuelFlowKgH,
      airFlowKgH,
      peakPressureBar: peakPressure / 1e5,
      peakPressureAngleDeg: peakPressureAngle,
      peakTemperatureK: peakTemp,
      cycleData: cyclePoints,
    };
  }
}
