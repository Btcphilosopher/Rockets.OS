/**
 * Hydrogen Engine Emissions & Thermal NOx Model
 * Grounded in Extended Zeldovich Thermal NOx Mechanism:
 *   N2 + O <-> NO + N
 *   N + O2 <-> NO + O
 *   N + OH <-> NO + H
 * Zero fuel-derived CO2. Explicit tracking of H2 slip, lubricant-derived carbon trace, and backfire risk.
 */

export interface EmissionsBreakdown {
  totalNoxGPerKwh: number;
  noPpm: number;
  no2Ppm: number;
  fuelCo2GPerKwh: number; // Strictly 0.0 for pure hydrogen
  lubeDerivedCo2GPerKwh: number; // ~0.5 - 2.0 g/kWh from lubricating oil consumption
  lubeDerivedHcGPerKwh: number;
  particulateMatterMgPerKwh: number;
  unburnedH2SlipPpm: number;
  preIgnitionRiskIndex: number; // 0.0 (safe) to 1.0 (dangerous)
  backfireRisk: 'NEGLIGIBLE' | 'LOW' | 'ELEVATED' | 'CRITICAL';
}

export class EmissionsModel {
  /**
   * Calculate NOx and emissions based on combustion state
   */
  static calculateEmissions(
    peakFlameTempK: number,
    cylinderPressureBar: number,
    lambda: number,
    egrPercent: number,
    sparkAdvanceDegBtdc: number,
    powerKw: number
  ): EmissionsBreakdown {
    // Extended Zeldovich thermal NOx mechanism is strongly exponential with flame temperature:
    // Rate ~ exp(-38000 / T_flame)
    // For Hydrogen, at stoichiometric (lambda = 1.0) flame temperatures exceed 2400K -> very high NOx.
    // At lean operation (lambda > 2.0), peak flame temp drops below 1800K -> near-zero NOx (<0.1 g/kWh).
    // EGR further dilutes the charge and reduces peak temperature.

    const tEffective = peakFlameTempK * (1 - 0.0035 * egrPercent);
    
    // Zeldovich temperature sensitivity factor
    let rawNoxFactor = 0;
    if (tEffective > 1700) {
      // Exponential growth above 1700K
      rawNoxFactor = Math.exp((tEffective - 1700) / 120);
    } else {
      rawNoxFactor = Math.max(0.01, (tEffective - 1200) / 5000);
    }

    // Oxygen availability peaking around lambda = 1.1 - 1.2
    let o2Factor = 1.0;
    if (lambda < 1.0) {
      o2Factor = lambda; // fuel rich
    } else if (lambda <= 1.3) {
      o2Factor = 1.0 + (lambda - 1.0) * 1.5; // peak excess O2 + high temp
    } else {
      o2Factor = Math.max(0.02, Math.exp(-2.2 * (lambda - 1.3))); // lean quenching
    }

    // Baseline NOx in g/kWh
    let noxGPerKwh = 0.05 * rawNoxFactor * o2Factor * Math.sqrt(cylinderPressureBar / 60);
    // Timing advance impact
    if (sparkAdvanceDegBtdc > 18) {
      noxGPerKwh *= (1 + 0.04 * (sparkAdvanceDegBtdc - 18));
    }

    noxGPerKwh = Math.min(25.0, Math.max(0.01, noxGPerKwh));

    const totalNoPpm = Math.round(noxGPerKwh * 120);
    const noPpm = Math.round(totalNoPpm * 0.92);
    const no2Ppm = Math.round(totalNoPpm * 0.08);

    // H2 slip (unburned hydrogen remaining due to wall quenching and injector crevices)
    // Typically higher at ultra-lean (lambda > 2.5) or with late injection
    const h2SlipPpm = Math.round(Math.max(15, 25 * Math.pow(lambda / 1.5, 1.8)));

    // Lubricant oil consumption emissions (~0.1 g/kWh oil burned in cylinder)
    const lubeDerivedCo2GPerKwh = 1.2;
    const lubeDerivedHcGPerKwh = 0.08;
    const particulateMatterMgPerKwh = 1.5;

    // Hydrogen-specific backfire / pre-ignition risk assessment:
    // Hydrogen's minimum ignition energy is only 0.02 mJ (10x lower than gasoline).
    // Risk factors: high spark advance, stoichiometric mixture (lambda ~ 1.0-1.2), high cylinder wall temp
    let preIgnitionRisk = 0.05;
    if (lambda < 1.4) preIgnitionRisk += (1.4 - lambda) * 0.5;
    if (sparkAdvanceDegBtdc > 22) preIgnitionRisk += (sparkAdvanceDegBtdc - 22) * 0.04;
    if (peakFlameTempK > 2400) preIgnitionRisk += 0.25;

    preIgnitionRisk = Math.min(1.0, Math.max(0.01, preIgnitionRisk));

    let backfireRisk: 'NEGLIGIBLE' | 'LOW' | 'ELEVATED' | 'CRITICAL' = 'NEGLIGIBLE';
    if (preIgnitionRisk > 0.7) {
      backfireRisk = 'CRITICAL';
    } else if (preIgnitionRisk > 0.45) {
      backfireRisk = 'ELEVATED';
    } else if (preIgnitionRisk > 0.2) {
      backfireRisk = 'LOW';
    }

    return {
      totalNoxGPerKwh: parseFloat(noxGPerKwh.toFixed(3)),
      noPpm,
      no2Ppm,
      fuelCo2GPerKwh: 0.0, // Fundamental physics: H2 + O2 -> H2O
      lubeDerivedCo2GPerKwh,
      lubeDerivedHcGPerKwh,
      particulateMatterMgPerKwh,
      unburnedH2SlipPpm: h2SlipPpm,
      preIgnitionRiskIndex: parseFloat(preIgnitionRisk.toFixed(2)),
      backfireRisk,
    };
  }
}
