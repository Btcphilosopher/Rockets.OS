/**
 * Structural Mechanics, Cranktrain Dynamics & Hydrodynamic Lubrication
 * Calculates forces, crank torque curve, connecting rod buckling, and bearing film thickness.
 */

import { EngineKinematics } from './kinematics';

export interface CrankDynamics {
  gasForceN: number;
  inertialForceN: number;
  resultantPistonForceN: number;
  instantaneousTorqueNm: number;
  connectingRodBucklingMargin: number;
  bearingMinimumOilFilmUm: number;
  bearingPeakLoadN: number;
}

export class CranktrainMechanics {
  /**
   * Calculate dynamic forces and instantaneous crank torque at crank angle theta
   */
  static calculateCrankForces(
    boreM: number,
    strokeM: number,
    rodLengthM: number,
    pistonMassKg: number,
    rodRecipMassKg: number,
    cylinderPressurePa: number,
    crankAngleDeg: number,
    rpm: number
  ): CrankDynamics {
    const kin = EngineKinematics.calculateKinematics(boreM, strokeM, rodLengthM, 12.5, crankAngleDeg, rpm);
    const r = strokeM / 2;
    const l = rodLengthM;
    const lambda = r / l;
    const theta = kin.crankAngleRad;

    const pistonArea = (Math.PI * Math.pow(boreM, 2)) / 4;
    // Gas force: F_gas = (P_cyl - P_crankcase) * A_piston
    const pCrankcase = 101325; // ambient atmospheric
    const gasForceN = (cylinderPressurePa - pCrankcase) * pistonArea;

    // Reciprocating inertia force: F_inertia = -m_recip * a_piston
    const totalRecipMass = pistonMassKg + rodRecipMassKg;
    const inertialForceN = -totalRecipMass * kin.pistonAccelerationMS2;

    // Resultant force along cylinder axis
    const resultantPistonForceN = gasForceN + inertialForceN;

    // Crankshaft torque:
    // T = F_res * r * ( sin(theta) + (lambda * sin(2*theta)) / (2 * sqrt(1 - lambda^2 * sin^2(theta))) )
    const sinTheta = Math.sin(theta);
    const sqrtTerm = Math.sqrt(Math.max(0.001, 1 - Math.pow(lambda * sinTheta, 2)));
    const leverArm = r * (sinTheta + (lambda * Math.sin(2 * theta)) / (2 * sqrtTerm));
    const instantaneousTorqueNm = resultantPistonForceN * leverArm;

    // Connecting rod buckling safety factor (Rankine-Gordon / Euler formula)
    // Critical buckling load P_cr = (pi^2 * E * I) / L_eff^2
    const E = 205e9; // Pa for forged steel 4340
    // Approximate I for typical H-beam connecting rod (I_yy)
    const I = 4.2e-9; // m4
    const pCritEuler = (Math.pow(Math.PI, 2) * E * I) / Math.pow(rodLengthM, 2);
    const maxCompForce = Math.max(1000, resultantPistonForceN);
    const connectingRodBucklingMargin = pCritEuler / maxCompForce;

    // Hydrodynamic bearing minimum oil film thickness (Raimondi & Boyd / Sommerfeld number)
    // h_min approx = c * (1 - epsilon)
    // Typically ~1.5 - 4.5 micrometers under operating load and viscosity
    const journalDia = 0.052; // 52 mm
    const radialClearanceUm = 28; // 28 um clearance
    const omega = (rpm * 2 * Math.PI) / 60;
    const oilViscosityPaS = 0.012; // 5W-30 at 95°C
    const bearingWidth = 0.022; // 22 mm

    // Sommerfeld S = (mu * N / P) * (R/c)^2
    const projectedArea = journalDia * bearingWidth;
    const bearingUnitPressure = maxCompForce / projectedArea;
    const sommerfeld = ((oilViscosityPaS * (rpm / 60)) / Math.max(1e5, bearingUnitPressure)) * Math.pow(journalDia / 2 / (radialClearanceUm * 1e-6), 2);
    
    // Empirical eccentricity ratio epsilon = f(S)
    const epsilon = Math.min(0.96, Math.max(0.2, 1 / (1 + 0.8 * Math.sqrt(sommerfeld))));
    const bearingMinimumOilFilmUm = radialClearanceUm * (1 - epsilon);

    return {
      gasForceN,
      inertialForceN,
      resultantPistonForceN,
      instantaneousTorqueNm,
      connectingRodBucklingMargin: Math.min(15.0, Math.max(1.1, connectingRodBucklingMargin)),
      bearingMinimumOilFilmUm: Math.max(0.5, bearingMinimumOilFilmUm),
      bearingPeakLoadN: maxCompForce,
    };
  }
}
