/**
 * Engine Vibration & Order Analysis Model
 * Covers 1X (unbalance/misalignment), 2X (secondary reciprocating inertia),
 * firing order excitation (2X for 4-cylinder 4-stroke), and torsional harmonics.
 */

export interface VibrationSpectrumPoint {
  order: string;
  orderNum: number;
  frequencyHz: number;
  amplitudeMmS: number;
}

export interface VibrationAnalysis {
  overallRmsMmS: number;
  peakVelocityMmS: number;
  severityRating: 'EXCELLENT' | 'GOOD' | 'ACCEPTABLE' | 'ROUGH' | 'CRITICAL';
  orders: VibrationSpectrumPoint[];
}

export class VibrationModel {
  /**
   * Calculate vibration spectrum and RMS velocity as function of RPM, cylinder pressure, and mechanical faults
   */
  static analyzeVibration(
    rpm: number,
    cylinderCount: number,
    peakCylinderPressureBar: number,
    bearingWearFault: boolean = false,
    misfireFault: boolean = false
  ): VibrationAnalysis {
    const f0 = rpm / 60; // 1X fundamental rotational frequency in Hz

    // In an Inline-4 engine:
    // 1X primary inertial forces balance out, but small residual unbalance exists (~0.5 - 1.2 mm/s).
    // 2X secondary inertial forces are naturally UNBALANCED due to finite connecting rod angularity!
    // Firing frequency = (cylinderCount / 2) * 1X = 2.0X for I4.

    let amp05X = 0.3; // Half-order (camshaft, sub-synchronous oil whirl)
    let amp1X = 0.8; // 1X rotational unbalance
    let amp2X = 2.2 * (rpm / 3000) * (peakCylinderPressureBar / 70); // 2X secondary reciprocating + firing order
    let amp3X = 0.5;
    let amp4X = 0.9 * (rpm / 3000); // 4X secondary firing harmonic
    let amp6X = 0.4;
    let ampTurbo = 1.1; // ~1200 - 2500 Hz turbo rotation

    if (bearingWearFault) {
      amp1X *= 2.8;
      amp05X *= 3.5;
    }

    if (misfireFault) {
      // Half-order and 1X spikes tremendously when one cylinder fails to fire
      amp05X += 4.2;
      amp1X += 3.8;
    }

    const orders: VibrationSpectrumPoint[] = [
      { order: '0.5X (Cam/Sub-synch)', orderNum: 0.5, frequencyHz: Math.round(0.5 * f0 * 10) / 10, amplitudeMmS: parseFloat(amp05X.toFixed(2)) },
      { order: '1.0X (Shaft Unbalance)', orderNum: 1.0, frequencyHz: Math.round(1.0 * f0 * 10) / 10, amplitudeMmS: parseFloat(amp1X.toFixed(2)) },
      { order: '2.0X (Firing / Secondary)', orderNum: 2.0, frequencyHz: Math.round(2.0 * f0 * 10) / 10, amplitudeMmS: parseFloat(amp2X.toFixed(2)) },
      { order: '3.0X (Harmonic)', orderNum: 3.0, frequencyHz: Math.round(3.0 * f0 * 10) / 10, amplitudeMmS: parseFloat(amp3X.toFixed(2)) },
      { order: '4.0X (Double Firing)', orderNum: 4.0, frequencyHz: Math.round(4.0 * f0 * 10) / 10, amplitudeMmS: parseFloat(amp4X.toFixed(2)) },
      { order: '6.0X (Acoustic Order)', orderNum: 6.0, frequencyHz: Math.round(6.0 * f0 * 10) / 10, amplitudeMmS: parseFloat(amp6X.toFixed(2)) },
    ];

    // RMS velocity: sqrt(sum(v_i^2) / 2)
    const sumSquares = orders.reduce((sum, item) => sum + Math.pow(item.amplitudeMmS, 2), 0);
    const overallRmsMmS = Math.sqrt(sumSquares / 2);
    const peakVelocityMmS = Math.max(...orders.map(o => o.amplitudeMmS));

    let severityRating: 'EXCELLENT' | 'GOOD' | 'ACCEPTABLE' | 'ROUGH' | 'CRITICAL' = 'GOOD';
    if (overallRmsMmS > 8.0) severityRating = 'CRITICAL';
    else if (overallRmsMmS > 5.0) severityRating = 'ROUGH';
    else if (overallRmsMmS > 3.0) severityRating = 'ACCEPTABLE';
    else if (overallRmsMmS > 1.5) severityRating = 'GOOD';
    else severityRating = 'EXCELLENT';

    return {
      overallRmsMmS: parseFloat(overallRmsMmS.toFixed(2)),
      peakVelocityMmS: parseFloat(peakVelocityMmS.toFixed(2)),
      severityRating,
      orders,
    };
  }
}
