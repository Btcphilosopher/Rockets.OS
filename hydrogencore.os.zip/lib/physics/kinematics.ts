/**
 * Slider-Crank Kinematics & Geometric Calculations
 * SI units: meters, radians, seconds.
 */

export interface KinematicState {
  crankAngleRad: number;
  crankAngleDeg: number;
  pistonDisplacementM: number; // distance from TDC (0 at TDC, stroke at BDC)
  pistonVelocityMS: number;
  pistonAccelerationMS2: number;
  cylinderVolumeM3: number;
  meanPistonSpeedMS: number;
}

export class EngineKinematics {
  /**
   * Calculate kinematics for a given cylinder at crank angle theta
   * @param boreM Cylinder bore in meters
   * @param strokeM Stroke in meters
   * @param rodLengthM Connecting rod center-to-center length in meters
   * @param compressionRatio Compression ratio (e.g. 12.5)
   * @param crankAngleDeg Crank angle in degrees (0 = TDC firing, 180 = BDC, 360 = TDC exhaust, 540 = BDC intake, 720 = TDC)
   * @param rpm Engine rotational speed
   */
  static calculateKinematics(
    boreM: number,
    strokeM: number,
    rodLengthM: number,
    compressionRatio: number,
    crankAngleDeg: number,
    rpm: number
  ): KinematicState {
    const theta = ((crankAngleDeg % 720) * Math.PI) / 180;
    const r = strokeM / 2; // crank radius
    const l = rodLengthM;
    const lambda = r / l; // rod-to-crank ratio (typically ~0.3)
    const omega = (rpm * 2 * Math.PI) / 60; // rad/s

    // Piston position from TDC:
    // s(theta) = r * ( (1 - cos(theta)) + (1 / lambda) * (1 - sqrt(1 - lambda^2 * sin^2(theta))) )
    const sinTheta = Math.sin(theta);
    const cosTheta = Math.cos(theta);
    const sqrtTerm = Math.sqrt(Math.max(0.0001, 1 - Math.pow(lambda * sinTheta, 2)));
    
    const s = r * ((1 - cosTheta) + (1 / lambda) * (1 - sqrtTerm));

    // Velocity:
    // v(theta) = r * omega * ( sin(theta) + (lambda * sin(2*theta)) / (2 * sqrt(1 - lambda^2 * sin^2(theta))) )
    const v = r * omega * (sinTheta + (lambda * Math.sin(2 * theta)) / (2 * sqrtTerm));

    // Acceleration:
    // a(theta) approx = r * omega^2 * ( cos(theta) + lambda * cos(2*theta) )
    const a = r * Math.pow(omega, 2) * (cosTheta + lambda * Math.cos(2 * theta));

    // Cylinder Volumes
    const pistonArea = (Math.PI * Math.pow(boreM, 2)) / 4;
    const sweptVolumeM3 = pistonArea * strokeM;
    const clearanceVolumeM3 = sweptVolumeM3 / (compressionRatio - 1);
    const cylinderVolumeM3 = clearanceVolumeM3 + pistonArea * s;

    const meanPistonSpeedMS = (2 * strokeM * rpm) / 60;

    return {
      crankAngleRad: theta,
      crankAngleDeg: crankAngleDeg % 720,
      pistonDisplacementM: s,
      pistonVelocityMS: v,
      pistonAccelerationMS2: a,
      cylinderVolumeM3,
      meanPistonSpeedMS,
    };
  }

  /**
   * Swept volume per cylinder
   */
  static getSweptVolume(boreM: number, strokeM: number): number {
    return ((Math.PI * Math.pow(boreM, 2)) / 4) * strokeM;
  }

  /**
   * Total engine displacement
   */
  static getTotalDisplacement(boreM: number, strokeM: number, cylinderCount: number): number {
    return this.getSweptVolume(boreM, strokeM) * cylinderCount;
  }
}
