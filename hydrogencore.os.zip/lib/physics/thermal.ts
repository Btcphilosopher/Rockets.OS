/**
 * Lumped-Parameter Thermal Network Model for Hydrogen Internal Combustion Engine
 * Hydrogen flame temperatures can reach ~2400-2800K, necessitating accurate component thermal tracking.
 */

export interface EngineThermalNodes {
  pistonCrownC: number;
  cylinderLinerC: number;
  cylinderHeadDeckC: number;
  exhaustValveHeadC: number;
  exhaustManifoldC: number;
  engineCoolantC: number;
  engineOilC: number;
  turboTurbineHousingC: number;
}

export class ThermalNetworkModel {
  /**
   * Calculate steady-state component temperatures based on engine operating load, rpm, and cooling state
   */
  static calculateTemperatures(
    powerKw: number,
    rpm: number,
    peakCombustionTempK: number,
    coolantFlowRateLpm: number = 75,
    oilCoolerEffectiveness: number = 0.85,
    coolantLossFault: boolean = false
  ): EngineThermalNodes {
    const loadFactor = Math.min(1.0, powerKw / 185); // normalized to 185kW rated
    const rpmFactor = rpm / 6000;

    // Base heat flux scaling factor
    const heatFluxFactor = 0.35 * loadFactor + 0.65 * Math.pow(peakCombustionTempK / 2200, 1.8);

    // Coolant penalty if fault active
    const coolantMultiplier = coolantLossFault ? 2.2 : (75 / Math.max(15, coolantFlowRateLpm));

    // Coolant temperature
    const engineCoolantC = Math.min(130, 85 + 12 * loadFactor * coolantMultiplier);

    // Engine Oil temperature (influenced by piston cooling jets and bearings)
    const engineOilC = Math.min(145, 90 + 18 * loadFactor + 8 * rpmFactor * (coolantLossFault ? 1.8 : 1.0));

    // Piston crown (aluminum/forged alloy with ceramic thermal barrier coating)
    const pistonCrownC = Math.min(380, 210 + 110 * heatFluxFactor + (coolantLossFault ? 60 : 0));

    // Cylinder liner / wall
    const cylinderLinerC = Math.min(220, 120 + 50 * heatFluxFactor * (coolantMultiplier * 0.7));

    // Cylinder head deck
    const cylinderHeadDeckC = Math.min(260, 140 + 70 * heatFluxFactor * (coolantMultiplier * 0.8));

    // Exhaust valve head (sodium-cooled Inconel 718 / Nimonic alloy)
    const exhaustValveHeadC = Math.min(880, 520 + 260 * heatFluxFactor);

    // Exhaust manifold & turbine
    const exhaustManifoldC = Math.min(950, 480 + 380 * loadFactor);
    const turboTurbineHousingC = Math.min(920, 450 + 360 * loadFactor);

    return {
      pistonCrownC: Math.round(pistonCrownC),
      cylinderLinerC: Math.round(cylinderLinerC),
      cylinderHeadDeckC: Math.round(cylinderHeadDeckC),
      exhaustValveHeadC: Math.round(exhaustValveHeadC),
      exhaustManifoldC: Math.round(exhaustManifoldC),
      engineCoolantC: Math.round(engineCoolantC),
      engineOilC: Math.round(engineOilC),
      turboTurbineHousingC: Math.round(turboTurbineHousingC),
    };
  }
}
