/**
 * Hydrogen Safety Architecture & Emergency Shutdown (ESD) Model
 * Manages leak detection, ventilation, isolation valves, nitrogen purge, and interlocks.
 */

import { SafetyState } from '../domain/types';

export interface HydrogenSafetyStatus {
  state: SafetyState;
  enclosureH2Ppm: number;
  percentLfl: number; // % of Lower Flammability Limit (40,000 ppm = 100% LFL)
  tankIsolationValveOpen: boolean;
  railPurgeValveOpen: boolean;
  ventilationFanStatus: 'OFF' | 'NORMAL' | 'BOOST_100_PERCENT';
  esdTriggered: boolean;
  esdReason?: string;
  activeInterlocks: string[];
}

export class HydrogenSafetySystem {
  static evaluateSafety(
    measuredH2Ppm: number,
    railPressureBar: number,
    coolantTempC: number,
    manualEsdEngaged: boolean = false
  ): HydrogenSafetyStatus {
    const LFL_PPM = 40000; // 4.0% vol in air
    const percentLfl = (measuredH2Ppm / LFL_PPM) * 100;
    const interlocks: string[] = [];

    let state: SafetyState = 'SAFE';
    let tankIsolationValveOpen = true;
    let railPurgeValveOpen = false;
    let ventilationFanStatus: 'OFF' | 'NORMAL' | 'BOOST_100_PERCENT' = 'NORMAL';
    let esdTriggered = false;
    let esdReason: string | undefined = undefined;

    if (manualEsdEngaged) {
      state = 'EMERGENCY';
      esdTriggered = true;
      esdReason = 'MANUAL EMERGENCY SHUTDOWN PUSHBUTTON ACTIVATED';
      tankIsolationValveOpen = false;
      railPurgeValveOpen = true;
      ventilationFanStatus = 'BOOST_100_PERCENT';
      interlocks.push('MANUAL_ESD_LOCKOUT');
    } else if (percentLfl >= 25.0) {
      // >25% LFL is immediate emergency trip
      state = 'EMERGENCY';
      esdTriggered = true;
      esdReason = `CRITICAL H2 LEAK: ${measuredH2Ppm} PPM (${percentLfl.toFixed(1)}% LFL) DETECTED`;
      tankIsolationValveOpen = false;
      railPurgeValveOpen = true;
      ventilationFanStatus = 'BOOST_100_PERCENT';
      interlocks.push('HIGH_H2_CONCENTRATION_TRIP');
    } else if (percentLfl >= 10.0) {
      // >10% LFL warning
      state = 'WARNING';
      ventilationFanStatus = 'BOOST_100_PERCENT';
      interlocks.push('H2_LEAK_EARLY_WARNING');
    } else if (railPressureBar > 380) {
      state = 'TRIP';
      esdTriggered = true;
      esdReason = `FUEL RAIL OVERPRESSURE: ${railPressureBar.toFixed(1)} BAR EXCEEDS RATING (350 BAR)`;
      tankIsolationValveOpen = false;
      interlocks.push('RAIL_OVERPRESSURE_TRIP');
    } else if (coolantTempC > 125) {
      state = 'WARNING';
      interlocks.push('COOLANT_OVERTEMP_WARNING');
    }

    return {
      state,
      enclosureH2Ppm: measuredH2Ppm,
      percentLfl: parseFloat(percentLfl.toFixed(2)),
      tankIsolationValveOpen,
      railPurgeValveOpen,
      ventilationFanStatus,
      esdTriggered,
      esdReason,
      activeInterlocks: interlocks,
    };
  }
}
