/**
 * Engine Digital Passport & Immutable Build Record
 * Cryptographic certificate binding all design, material, manufacturing, assembly, and test results.
 */

import { EngineDigitalPassport, QualityGateResult } from '../domain/types';
import { SAMPLE_FASTENER_RECORDS } from '../manufacturing/assembly';
import { SAMPLE_METROLOGY_INSPECTIONS } from '../manufacturing/metrology';

export const INITIAL_QUALITY_GATES: QualityGateResult[] = [
  {
    gateId: 'QG-01-DIM',
    name: 'Critical Dimensional & GD&T Gate',
    category: 'DIMENSIONAL',
    passed: true,
    scorePercent: 99.4,
    details: 'All bore cylindricities, journal runouts, and deck flatness within spec (< 12 um max deviation).',
    inspectedBy: 'Chief Metrology Inspector M. Dubois (Zeiss Lab)',
    timestamp: '2026-08-28 11:20:00 UTC',
  },
  {
    gateId: 'QG-02-ASM',
    name: 'Assembly Torque-Angle Fastener Gate',
    category: 'ASSEMBLY',
    passed: true,
    scorePercent: 100.0,
    details: '100% of critical fasteners (head bolts, rod bolts, main caps) torqued and logged with zero failures.',
    inspectedBy: 'Automated Atlas Copco Q-System',
    timestamp: '2026-08-28 10:45:12 UTC',
  },
  {
    gateId: 'QG-03-LEAK',
    name: 'Hydrogen High-Pressure Helium Leak Test',
    category: 'LEAK_TEST',
    passed: true,
    scorePercent: 100.0,
    details: 'Pressurized to 450 bar with 95% N2 / 5% H2 tracer gas. Mass spectrometer leak rate < 1.2e-6 mbar·L/s (Safe).',
    inspectedBy: 'Pfeiffer Vacuum Sniffer Cell',
    timestamp: '2026-08-28 13:10:45 UTC',
  },
  {
    gateId: 'QG-04-SNS',
    name: 'ECU & Sensor Harness Continuity Validation',
    category: 'SENSOR_TEST',
    passed: true,
    scorePercent: 100.0,
    details: 'All 16 sensor channels (MAP, MAF, Lambda, Rail Pressure, Knock, Vibration, Temps) calibrated & verified.',
    inspectedBy: 'Automated End-Of-Line DAQ Test Rig',
    timestamp: '2026-08-28 14:02:18 UTC',
  },
  {
    gateId: 'QG-05-DYNO',
    name: 'Hot Dyno Performance & Torque Verification',
    category: 'DYNO_TEST',
    passed: true,
    scorePercent: 98.6,
    details: 'Full power sweep delivered 186.2 kW @ 6000 RPM (Target 185 kW) and 352.4 Nm @ 2800 RPM.',
    inspectedBy: 'AVL Dyno Engineer K. Vance',
    timestamp: '2026-08-28 15:45:00 UTC',
  },
  {
    gateId: 'QG-06-EMIS',
    name: 'Ultra-Low NOx Emissions Compliance',
    category: 'EMISSIONS',
    passed: true,
    scorePercent: 97.8,
    details: 'Peak cycle NOx 0.082 g/kWh (Euro VII limit 0.20 g/kWh). Zero fuel-derived CO2. H2 slip < 35 ppm.',
    inspectedBy: 'Horiba MEXA-ONE Exhaust Gas Analyzer',
    timestamp: '2026-08-28 16:15:30 UTC',
  },
  {
    gateId: 'QG-07-FINAL',
    name: 'Final Quality Release & Digital Sign-Off',
    category: 'FINAL_INSPECTION',
    passed: true,
    scorePercent: 100.0,
    details: 'Cosmetic inspection, fluid drain, nitrogen charge sealing, and packaging clearance approved.',
    inspectedBy: 'VP of Quality & Certification Dr. A. Sterling',
    timestamp: '2026-08-28 17:00:00 UTC',
  },
];

export const REFERENCE_PASSPORT: EngineDigitalPassport = {
  engineSerialNumber: 'H2-000127',
  engineFamily: 'HYDROGENCORE H2-I4-2000',
  manufacturingDate: '2026-08-28',
  releasedDate: '2026-08-28 17:05:00 UTC',
  status: 'RELEASED',
  overallScore: 99.2,
  qualityGates: INITIAL_QUALITY_GATES,
  criticalComponents: [
    { partName: 'Engine Cylinder Block', partNumber: 'BLK-H2-2000-01', serialNumber: 'BLK-SN-84920', material: 'AlSi7Mg-T6 + Cast Iron Liners', batchNumber: 'BAT-AL-2026-44', supplier: 'HydroCores In-House Foundry' },
    { partName: 'Forged Crankshaft', partNumber: 'CRK-H2-2000-01', serialNumber: 'CRK-SN-10492', material: 'AISI 4340 Ni-Cr-Mo Steel (Gas Nitrided)', batchNumber: 'BAT-STEEL-4340-98', supplier: 'ThyssenKrupp Precision Forgings' },
    { partName: 'Cylinder Head Assembly', partNumber: 'HED-H2-2000-01', serialNumber: 'HED-SN-30219', material: 'A356-T6 Aluminum (High Thermal Cond)', batchNumber: 'BAT-AL-HEAD-12', supplier: 'Nemak Precision Components' },
    { partName: 'Pistons (Set of 4)', partNumber: 'PST-H2-2000-01', serialNumber: 'PST-SN-44101..04', material: 'Mahle 124 Forged Alloy + TBC Ceramic', batchNumber: 'BAT-PST-6601', supplier: 'Mahle Powertrain Motorsport' },
    { partName: 'Connecting Rods (Set of 4)', partNumber: 'ROD-H2-2000-01', serialNumber: 'ROD-SN-58190..93', material: '4340 Forged Steel H-Beam', batchNumber: 'BAT-ROD-8821', supplier: 'Pankl Racing Systems' },
    { partName: 'Hydrogen Direct Injectors (x4)', partNumber: 'INJ-H2-DI-350', serialNumber: 'INJ-SN-99411..14', material: 'Austenitic 316L + DLC Needle', batchNumber: 'BAT-H2INJ-350-09', supplier: 'Bosch Hydrogen Mobility' },
    { partName: 'Twin-Scroll Turbocharger', partNumber: 'TRB-TWIN-SCROLL-01', serialNumber: 'TRB-SN-77291', material: 'Titanium-Aluminide Wheel + Inconel 713C', batchNumber: 'BAT-TURBO-3310', supplier: 'BorgWarner Engineered Systems' },
    { partName: 'Hydrogen Powertrain ECU', partNumber: 'ECU-H2-F1-01', serialNumber: 'ECU-SN-12004', material: 'IP67 Aluminum Enclosure + Dual TriCore MCU', batchNumber: 'BAT-ECU-0091', supplier: 'Continental Hydrogen Controls' },
  ],
  fastenerRecords: SAMPLE_FASTENER_RECORDS,
  metrologyResults: SAMPLE_METROLOGY_INSPECTIONS,
  dynoVerification: {
    peakPowerKw: 186.2,
    peakTorqueNm: 352.4,
    bsfcGPerKwh: 162.8,
    peakNoxGPerKwh: 0.082,
    testRunId: 'DYNO-RUN-2026-H2-000127-FINAL',
  },
  hashSignature: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855a82e9',
};
