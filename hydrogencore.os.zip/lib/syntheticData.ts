/**
 * Synthetic Engineering Demonstration Data for HYDROGENCORE.OS
 * Notice: All values are calibrated synthetic engineering demonstration models.
 */

import { EngineConfiguration, MaterialProperties, DigitalThread } from './domain/types';

export const MATERIAL_DATABASE: Record<string, MaterialProperties> = {
  STEEL_4340: {
    materialId: 'MAT-STEEL-4340',
    name: 'AISI 4340 Ni-Cr-Mo Forged Alloy Steel',
    densityKgM3: 7850,
    youngsModulusPa: 205e9,
    poissonsRatio: 0.29,
    yieldStrengthPa: 860e6,
    ultimateStrengthPa: 1080e6,
    thermalConductivityWMK: 44.5,
    specificHeatJKgK: 475,
    thermalExpansionK: 12.3e-6,
    hydrogenCompatibilityScore: 82,
    embrittlementRisk: 'LOW',
  },
  ALSI7MG_T6: {
    materialId: 'MAT-ALSI7MG-T6',
    name: 'AlSi7Mg0.3 (A356) T6 Heat-Treated Cast Aluminum',
    densityKgM3: 2680,
    youngsModulusPa: 72e9,
    poissonsRatio: 0.33,
    yieldStrengthPa: 220e6,
    ultimateStrengthPa: 290e6,
    thermalConductivityWMK: 160,
    specificHeatJKgK: 920,
    thermalExpansionK: 21.4e-6,
    hydrogenCompatibilityScore: 95,
    embrittlementRisk: 'NEGLIGIBLE',
  },
  INCONEL_718: {
    materialId: 'MAT-INCONEL-718',
    name: 'Inconel 718 Nickel-Chromium Superalloy',
    densityKgM3: 8190,
    youngsModulusPa: 211e9,
    poissonsRatio: 0.28,
    yieldStrengthPa: 1100e6,
    ultimateStrengthPa: 1375e6,
    thermalConductivityWMK: 11.4,
    specificHeatJKgK: 435,
    thermalExpansionK: 13.0e-6,
    hydrogenCompatibilityScore: 90,
    embrittlementRisk: 'LOW',
  },
  SS316L: {
    materialId: 'MAT-SS316L',
    name: 'Austenitic Stainless Steel 316L (Vacuum Arc Remelt)',
    densityKgM3: 8000,
    youngsModulusPa: 193e9,
    poissonsRatio: 0.30,
    yieldStrengthPa: 290e6,
    ultimateStrengthPa: 580e6,
    thermalConductivityWMK: 16.3,
    specificHeatJKgK: 500,
    thermalExpansionK: 16.0e-6,
    hydrogenCompatibilityScore: 98,
    embrittlementRisk: 'NEGLIGIBLE',
  },
};

export const REFERENCE_CONFIG_I4: EngineConfiguration = {
  engineId: 'ENG-H2-000127',
  engineFamily: 'HYDROGENCORE H2-I4-2000',
  version: '2.4.1-PROD',
  cylinderCount: 4,
  architecture: 'INLINE',
  boreM: 0.086, // 86.0 mm
  strokeM: 0.086, // 86.0 mm (Square bore/stroke)
  displacementM3: 0.001998, // 1.998 Liters (2.0L)
  compressionRatio: 12.5,
  rodLengthM: 0.1435, // 143.5 mm (rod/stroke ratio 1.668)
  bankAngleDeg: 0,
  firingOrder: [1, 3, 4, 2],
  rpmLimit: 7200,
  idleRPM: 850,
  targetPowerW: 185000, // 185 kW (248 hp)
  targetTorqueNm: 350,
  targetEfficiency: 0.42,
  fuelSystem: 'High-Pressure Direct Hydrogen Rail (350 bar)',
  injectionType: 'DIRECT_INJECTION',
  aspiration: 'TURBOCHARGED',
  coolingSystem: 'LIQUID_COOLED',
  lubricationSystem: 'WET_SUMP',
  ignitionSystem: 'HIGH_ENERGY_SPARK',
};

export const REFERENCE_CONFIG_I6: EngineConfiguration = {
  engineId: 'ENG-H2-000201',
  engineFamily: 'HYDROGENCORE H2-I6-3000',
  version: '1.2.0-PROD',
  cylinderCount: 6,
  architecture: 'INLINE',
  boreM: 0.086,
  strokeM: 0.086,
  displacementM3: 0.002997, // 3.0 Liters
  compressionRatio: 12.5,
  rodLengthM: 0.1435,
  bankAngleDeg: 0,
  firingOrder: [1, 5, 3, 6, 2, 4],
  rpmLimit: 7200,
  idleRPM: 800,
  targetPowerW: 280000, // 280 kW (375 hp)
  targetTorqueNm: 520,
  targetEfficiency: 0.43,
  fuelSystem: 'High-Pressure Direct Hydrogen Rail (350 bar)',
  injectionType: 'DIRECT_INJECTION',
  aspiration: 'TURBOCHARGED',
  coolingSystem: 'LIQUID_COOLED',
  lubricationSystem: 'DRY_SUMP',
  ignitionSystem: 'HIGH_ENERGY_SPARK',
};

export const REFERENCE_CONFIG_V8: EngineConfiguration = {
  engineId: 'ENG-H2-000305',
  engineFamily: 'HYDROGENCORE H2-V8-4500',
  version: '1.0.0-PROD',
  cylinderCount: 8,
  architecture: 'VEE',
  boreM: 0.090,
  strokeM: 0.088,
  displacementM3: 0.004478, // 4.5 Liters
  compressionRatio: 12.0,
  rodLengthM: 0.150,
  bankAngleDeg: 90,
  firingOrder: [1, 8, 4, 3, 6, 5, 7, 2],
  rpmLimit: 7500,
  idleRPM: 750,
  targetPowerW: 420000, // 420 kW (563 hp)
  targetTorqueNm: 780,
  targetEfficiency: 0.44,
  fuelSystem: 'Twin High-Pressure Direct Hydrogen Rails (350 bar)',
  injectionType: 'DIRECT_INJECTION',
  aspiration: 'TURBOCHARGED',
  coolingSystem: 'LIQUID_COOLED',
  lubricationSystem: 'DRY_SUMP',
  ignitionSystem: 'HIGH_ENERGY_SPARK',
};
