/**
 * Canonical Types & Data Models for HYDROGENCORE.OS
 * The master computational representation of the Hydrogen Engine.
 */

export type EngineArchitecture = 'INLINE' | 'VEE' | 'BOXER';
export type FuelInjectionType = 'DIRECT_INJECTION' | 'PORT_INJECTION' | 'DUAL';
export type AspirationType = 'TURBOCHARGED' | 'NATURALLY_ASPIRATED' | 'SUPERCHARGED';
export type ModelFidelity = 'CONCEPTUAL' | 'REDUCED_ORDER' | 'ENGINEERING' | 'CALIBRATED' | 'EXPERIMENTALLY_VALIDATED';
export type SafetyState = 'SAFE' | 'WARNING' | 'TRIP' | 'EMERGENCY';

export interface EngineConfiguration {
  engineId: string;
  engineFamily: string; // e.g. 'HYDROGENCORE H2-I4'
  version: string;
  cylinderCount: number;
  architecture: EngineArchitecture;
  boreM: number; // e.g. 0.086 m (86 mm)
  strokeM: number; // e.g. 0.086 m (86 mm)
  displacementM3: number; // calculated e.g. 0.001998 m3 (2.0L)
  compressionRatio: number; // e.g. 12.5:1 (high compression for H2 lean combustion)
  rodLengthM: number; // e.g. 0.1435 m (143.5 mm)
  bankAngleDeg: number; // 0 for inline, 60 or 90 for V
  firingOrder: number[]; // e.g. [1, 3, 4, 2]
  rpmLimit: number; // e.g. 7000 rpm
  idleRPM: number; // e.g. 850 rpm
  targetPowerW: number; // e.g. 185,000 W (185 kW / 248 hp)
  targetTorqueNm: number; // e.g. 350 Nm
  targetEfficiency: number; // e.g. 0.42 (42% BTE)
  fuelSystem: string;
  injectionType: FuelInjectionType;
  aspiration: AspirationType;
  coolingSystem: 'LIQUID_COOLED' | 'AIR_COOLED';
  lubricationSystem: 'WET_SUMP' | 'DRY_SUMP';
  ignitionSystem: 'HIGH_ENERGY_SPARK' | 'CORONA_IGNITION';
}

export interface MaterialProperties {
  materialId: string;
  name: string;
  densityKgM3: number;
  youngsModulusPa: number;
  poissonsRatio: number;
  yieldStrengthPa: number;
  ultimateStrengthPa: number;
  thermalConductivityWMK: number;
  specificHeatJKgK: number;
  thermalExpansionK: number;
  hydrogenCompatibilityScore: number; // 0-100 (resistance to H2 embrittlement)
  embrittlementRisk: 'NEGLIGIBLE' | 'LOW' | 'MODERATE' | 'CRITICAL_VALIDATION_REQUIRED';
}

export interface DigitalThread {
  partNumber: string;
  revision: string;
  serialNumber: string;
  bomCategory: string;
  material: MaterialProperties;
  supplier: string;
  manufacturingRouteId: string;
  machineId: string;
  operatorId: string;
  manufacturedTimestamp: string;
  nominalDimensionsMm: Record<string, number>;
  measuredDimensionsMm: Record<string, number>;
  tolerancesMm: Record<string, number>;
  passFailStatus: 'PASS' | 'FAIL' | 'REVIEW';
  operatingHours: number;
  healthPercent: number;
}

export interface CrankshaftTwin {
  id: string;
  partNumber: string;
  serialNumber: string;
  material: MaterialProperties;
  massKg: number;
  momentOfInertiaKgM2: number;
  mainJournalDiameterM: number;
  rodJournalDiameterM: number;
  strokeRadiusM: number;
  counterweightCount: number;
  oilPassageDiameterM: number;
  maxTorsionalDeflectionDeg: number;
  peakBendingStressMpa: number;
  bearingOilFilmThicknessUm: number;
  fatigueLifeSafetyFactor: number;
}

export interface PistonTwin {
  cylinderIndex: number;
  partNumber: string;
  serialNumber: string;
  massKg: number;
  crownDiameterM: number;
  compressionHeightM: number;
  pinDiameterM: number;
  skirtClearanceUm: number;
  coating: string;
  crownTempK: number;
  gasForceN: number;
  inertialForceN: number;
  resultantSideThrustN: number;
}

export interface ConnectingRodTwin {
  cylinderIndex: number;
  partNumber: string;
  serialNumber: string;
  massKg: number;
  centerToCenterLengthM: number;
  bigEndDiameterM: number;
  smallEndDiameterM: number;
  bearingClearanceUm: number;
  bucklingSafetyFactor: number;
  axialStressMpa: number;
}

export interface CylinderBlockTwin {
  partNumber: string;
  serialNumber: string;
  material: MaterialProperties;
  massKg: number;
  deckHeightM: number;
  cylinderBoreM: number;
  boreRoundnessToleranceUm: number;
  deckFlatnessUm: number;
  coolantJacketVolumeM3: number;
  mainSaddleTorqueSpecNm: number;
}

export interface CylinderHeadTwin {
  partNumber: string;
  serialNumber: string;
  material: MaterialProperties;
  valvesPerCylinder: number;
  intakeValveDiameterM: number;
  exhaustValveDiameterM: number;
  combustionChamberVolumeM3: number;
  headGasketThicknessM: number;
  headBoltTorqueSpecNm: number;
}

export interface ValvetrainTwin {
  camshaftCount: number; // e.g. 2 for DOHC
  camPhasingVvt: boolean;
  maxIntakeLiftM: number; // e.g. 0.010 m (10 mm)
  maxExhaustLiftM: number;
  intakeDurationDeg: number; // e.g. 240 deg
  exhaustDurationDeg: number; // e.g. 236 deg
  valveOverlapDeg: number;
  currentAdvanceDeg: number;
}

export interface HydrogenInjectorTwin {
  injectorId: string;
  cylinderIndex: number;
  serialNumber: string;
  nozzleHoles: number;
  holeDiameterM: number;
  flowCoefficientCd: number;
  maxPressurePa: number; // e.g. 350 bar (3.5e7 Pa)
  currentRailPressurePa: number;
  openingDelayMs: number;
  injectionTimingDegBtdc: number; // degrees before top dead center
  injectionDurationDeg: number;
  massFlowKgPerSec: number;
  status: 'NORMAL' | 'RESTRICTED' | 'LEAKING' | 'OFFLINE';
}

export interface HydrogenFuelSystemTwin {
  tankStoragePressurePa: number; // e.g. 700 bar (7.0e7 Pa)
  regulatorStage1PressurePa: number; // e.g. 25 bar
  railPressurePa: number; // e.g. 150-350 bar
  fuelTemperatureK: number;
  massFlowKgPerSec: number;
  h2LeakPpm: number;
  isolationValveState: 'OPEN' | 'CLOSED';
  purgeActive: boolean;
  sensors: {
    tankPressure: number;
    railPressure: number;
    fuelTemp: number;
    ambientLeakPpm: number;
  };
}

export interface TurbochargerTwin {
  partNumber: string;
  compressorWheelDiameterM: number;
  turbineWheelDiameterM: number;
  currentRpm: number;
  pressureRatio: number;
  compressorEfficiency: number;
  turbineEfficiency: number;
  boostPressurePa: number;
  wastegatePositionPercent: number; // 0 (closed) to 100 (open)
  surgeMarginPercent: number;
}

export interface CombustionChamberTwin {
  cylinderIndex: number;
  volumeM3: number;
  pressurePa: number;
  temperatureK: number;
  gamma: number;
  equivalenceRatioPhi: number;
  lambda: number;
  flameSpeedMS: number;
  wiebeBurnFraction: number;
  heatReleaseRateJDeg: number;
  accumulatedWorkJ: number;
  preIgnitionRiskIndex: number; // 0.0 - 1.0 (hydrogen requires tight pre-ignition control)
  backfireRisk: 'NEGLIGIBLE' | 'LOW' | 'ELEVATED' | 'CRITICAL';
}

export interface ECUTwin {
  rpmTarget: number;
  currentRpm: number;
  throttlePercent: number;
  lambdaTarget: number;
  lambdaActual: number;
  ignitionTimingDegBtdc: number;
  boostTargetBar: number;
  boostActualBar: number;
  egrPercent: number;
  knockDetectionCount: number;
  misfireCount: number;
  controlMode: 'CLOSED_LOOP' | 'WARMUP' | 'TORQUE_MANAGEMENT' | 'LIMP_HOME' | 'EMERGENCY_SHUTDOWN';
}

export interface EngineLiveState {
  timestampMs: number;
  crankAngleDeg: number; // 0 to 720 (4-stroke)
  rpm: number;
  torqueNm: number;
  powerW: number;
  imepBar: number;
  bmepBar: number;
  fmepBar: number;
  thermalEfficiency: number; // BTE
  hydrogenFlowKgH: number;
  airFlowKgH: number;
  lambda: number;
  boostPressureBar: number;
  oilPressureBar: number;
  oilTemperatureC: number;
  coolantTemperatureC: number;
  exhaustTemperatureC: number;
  peakCylinderPressureBar: number;
  vibrationRmsMmS: number;
  noxGPerKwh: number;
  h2SlipPpm: number;
  overallHealthScore: number;
  fidelity: ModelFidelity;
  safetyState: SafetyState;
}

export interface HydrogenEngineTwin {
  config: EngineConfiguration;
  liveState: EngineLiveState;
  crankshaft: CrankshaftTwin;
  pistons: PistonTwin[];
  connectingRods: ConnectingRodTwin[];
  block: CylinderBlockTwin;
  head: CylinderHeadTwin;
  valvetrain: ValvetrainTwin;
  injectors: HydrogenInjectorTwin[];
  fuelSystem: HydrogenFuelSystemTwin;
  turbocharger: TurbochargerTwin;
  chambers: CombustionChamberTwin[];
  ecu: ECUTwin;
  digitalThreads: Record<string, DigitalThread>;
}

export interface FastenerRecord {
  fastenerId: string;
  location: string;
  specification: string;
  targetTorqueNm: number;
  actualTorqueNm: number;
  targetAngleDeg: number;
  actualAngleDeg: number;
  tolerancePercent: number;
  operatorId: string;
  toolId: string;
  timestamp: string;
  status: 'PASS' | 'FAIL';
}

export interface MetrologyInspection {
  measurementId: string;
  componentSerial: string;
  parameterName: string;
  feature: string;
  nominalMm: number;
  actualMm: number;
  upperTolMm: number;
  lowerTolMm: number;
  deviationUm: number;
  instrument: string;
  status: 'PASS' | 'FAIL';
}

export interface QualityGateResult {
  gateId: string;
  name: string;
  category: 'DIMENSIONAL' | 'ASSEMBLY' | 'LEAK_TEST' | 'SENSOR_TEST' | 'DYNO_TEST' | 'EMISSIONS' | 'FINAL_INSPECTION';
  passed: boolean;
  scorePercent: number;
  details: string;
  inspectedBy: string;
  timestamp: string;
}

export interface EngineDigitalPassport {
  engineSerialNumber: string;
  engineFamily: string;
  manufacturingDate: string;
  releasedDate?: string;
  status: 'RELEASED' | 'IN_PRODUCTION' | 'QUALITY_HOLD' | 'REJECTED';
  overallScore: number;
  qualityGates: QualityGateResult[];
  criticalComponents: {
    partName: string;
    partNumber: string;
    serialNumber: string;
    material: string;
    batchNumber: string;
    supplier: string;
  }[];
  fastenerRecords: FastenerRecord[];
  metrologyResults: MetrologyInspection[];
  dynoVerification: {
    peakPowerKw: number;
    peakTorqueNm: number;
    bsfcGPerKwh: number;
    peakNoxGPerKwh: number;
    testRunId: string;
  };
  hashSignature: string;
}
