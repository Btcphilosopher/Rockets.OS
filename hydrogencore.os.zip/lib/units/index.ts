/**
 * Strict SI Units & Conversion Architecture for HYDROGENCORE.OS
 * All internal physics state is strictly SI: Pa, K, kg, m, s, N, N*m, W, J, rad/s.
 * User-facing display units (bar, deg C, mm, L, kW, hp, Nm, rpm, kg/h) are converted explicitly.
 */

export interface StrictQuantity {
  value: number;
  unit: string;
  source: 'CALCULATED' | 'MEASURED' | 'CALIBRATED' | 'SYNTHETIC_SPEC';
  confidence: number; // 0.0 to 1.0
}

export interface PressureQuantity {
  valuePa: number; // Absolute SI pressure
  isGauge: boolean;
  referenceAtmPa: number; // Standard ambient 101325 Pa
}

export const ATMOSPHERIC_PRESSURE_PA = 101325; // 1.01325 bar absolute
export const STANDARD_TEMP_K = 298.15; // 25°C

export const Units = {
  // Pressure
  barToPa: (bar: number): number => bar * 1e5,
  paToBar: (pa: number): number => pa / 1e5,
  paToBarGauge: (pa: number, atm: number = ATMOSPHERIC_PRESSURE_PA): number => (pa - atm) / 1e5,
  barGaugeToPaAbs: (barGauge: number, atm: number = ATMOSPHERIC_PRESSURE_PA): number => (barGauge * 1e5) + atm,
  paToKpa: (pa: number): number => pa / 1000,
  kpaToPa: (kpa: number): number => kpa * 1000,
  
  // Temperature
  celsiusToKelvin: (c: number): number => c + 273.15,
  kelvinToCelsius: (k: number): number => k - 273.15,
  
  // Speed / Angular Velocity
  rpmToRadS: (rpm: number): number => (rpm * 2 * Math.PI) / 60,
  radSToRpm: (rads: number): number => (rads * 60) / (2 * Math.PI),
  
  // Length & Volume
  mmToM: (mm: number): number => mm * 1e-3,
  mToMm: (m: number): number => m * 1e3,
  m3ToL: (m3: number): number => m3 * 1e3,
  lToM3: (l: number): number => l * 1e-3,
  m3ToCc: (m3: number): number => m3 * 1e6,
  ccToM3: (cc: number): number => cc * 1e-6,

  // Power & Energy
  wToKw: (w: number): number => w / 1e3,
  kwToW: (kw: number): number => kw * 1e3,
  wToHp: (w: number): number => w / 745.699872,
  hpToW: (hp: number): number => hp * 745.699872,
  kwToHp: (kw: number): number => kw * 1.34102,
  
  // Mass flow
  kgSToKgH: (kgs: number): number => kgs * 3600,
  kgHToKgS: (kgh: number): number => kgh / 3600,
  gSToKgH: (gs: number): number => (gs / 1000) * 3600,
  
  // Density
  kgM3ToGL: (kgm3: number): number => kgm3,
};
