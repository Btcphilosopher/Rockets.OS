"""
AUREOM — Test Suite
Validates core subsystems with deterministic assertions.
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pytest
import math


# ── Storage tests ─────────────────────────────────────────────────────────────
class TestHydrogenStorage:
    def _make_tank(self, kg=100.0):
        from hydrogen.storage import HydrogenTank, TankConfig, StorageMode
        return HydrogenTank(TankConfig(capacity_kg=kg, mode=StorageMode.COMPRESSED))

    def test_initial_fill(self):
        t = self._make_tank(100.0)
        assert abs(t.mass_kg - 100.0) < 1e-6

    def test_depletion(self):
        t = self._make_tank(100.0)
        result = t.step(dt=1.0, extracted_kgs=5.0)
        assert t.mass_kg < 100.0
        assert result["actual_flow_kgs"] > 0

    def test_no_negative_mass(self):
        t = self._make_tank(1.0)
        t.step(dt=10.0, extracted_kgs=100.0)
        assert t.mass_kg >= 0.0

    def test_pressure_positive(self):
        t = self._make_tank(50.0)
        assert t.pressure_Pa > 0

    def test_refill(self):
        t = self._make_tank(100.0)
        t.step(dt=1.0, extracted_kgs=50.0)
        t.refill()
        assert abs(t.mass_kg - 100.0) < 1e-3


# ── Nozzle tests ──────────────────────────────────────────────────────────────
class TestNozzleModel:
    def _make_nozzle(self):
        from propulsion.nozzle import NozzleModel, NozzleConfig
        return NozzleModel(NozzleConfig(expansion_ratio=8.0))

    def test_thrust_positive(self):
        n = self._make_nozzle()
        r = n.compute(6e6, 2800, 0.5)
        assert r["thrust_N"] > 0

    def test_zero_flow_no_thrust(self):
        n = self._make_nozzle()
        r = n.compute(6e6, 2800, 0.0)
        assert r["thrust_N"] == 0.0

    def test_isp_reasonable(self):
        n = self._make_nozzle()
        r = n.compute(6e6, 2800, 0.5)
        # H₂-only propellant gives high specific impulse (no oxidiser mass counted)
        # typical range 350–800 s for H₂ thruster with high R gas
        assert 300 < r["isp_s"] < 900

    def test_exit_mach_supersonic(self):
        n = self._make_nozzle()
        r = n.compute(6e6, 2800, 0.5)
        assert r["exit_mach"] > 1.0

    def test_higher_expansion_higher_isp(self):
        from propulsion.nozzle import NozzleModel, NozzleConfig
        n_low = NozzleModel(NozzleConfig(expansion_ratio=4.0))
        n_high = NozzleModel(NozzleConfig(expansion_ratio=15.0))
        r_low  = n_low.compute(6e6, 2800, 0.5)
        r_high = n_high.compute(6e6, 2800, 0.5)
        assert r_high["isp_s"] > r_low["isp_s"]


# ── Combustion tests ──────────────────────────────────────────────────────────
class TestCombustionChamber:
    def _make_chamber(self):
        from propulsion.combustion import CombustionChamber, CombustionConfig
        return CombustionChamber(CombustionConfig())

    def test_initial_state_idle(self):
        from propulsion.combustion import EngineState
        c = self._make_chamber()
        assert c.state == EngineState.IDLE

    def test_ignition_transitions(self):
        from propulsion.combustion import EngineState
        c = self._make_chamber()
        c.command_ignition()
        assert c.state == EngineState.IGNITION

    def test_pressure_builds_with_flow(self):
        c = self._make_chamber()
        c.command_ignition()
        c.set_throttle(1.0)
        p_initial = c.chamber_pressure_Pa
        for _ in range(100):
            c.step(dt=0.05, delivered_flow_kgs=0.5, nozzle_discharge_kgs=0.4)
        assert c.chamber_pressure_Pa >= p_initial

    def test_shutdown_reduces_throttle(self):
        from propulsion.combustion import EngineState
        c = self._make_chamber()
        c.command_ignition()
        c.set_throttle(0.8)
        # Ramp up
        for _ in range(40):
            c.step(0.05, 0.5, 0.4)
        c.command_shutdown()
        assert c.state in (EngineState.RAMP_DOWN, EngineState.SHUTDOWN, EngineState.IDLE)


# ── Vehicle dynamics tests ────────────────────────────────────────────────────
class TestVehicleDynamics:
    def _make_car(self):
        from vehicles.car_dynamics import VehicleDynamics, VehicleSpec
        return VehicleDynamics(VehicleSpec.car())

    def test_thrust_accelerates(self):
        v = self._make_car()
        result = v.step(dt=1.0, thrust_N=10000.0)
        assert result["velocity_ms"] > 0

    def test_no_negative_velocity(self):
        v = self._make_car()
        for _ in range(10):
            result = v.step(dt=0.1, thrust_N=0.0)
        assert result["velocity_ms"] >= 0

    def test_drag_at_speed(self):
        v = self._make_car()
        v.state.velocity_ms = 50.0
        result = v.step(dt=0.1, thrust_N=0.0)
        assert result["drag_force_N"] > 0

    def test_speed_limit(self):
        v = self._make_car()
        for _ in range(200):
            result = v.step(dt=0.1, thrust_N=500_000.0)
        assert result["velocity_ms"] <= v.spec.max_speed_ms + 0.1


# ── Thermal tests ─────────────────────────────────────────────────────────────
class TestThermalModel:
    def _make_thermal(self):
        from thermal.heat_model import ThermalModel, ThermalConfig
        return ThermalModel(ThermalConfig())

    def test_temp_rises_with_combustion(self):
        t = self._make_thermal()
        r = t.step(
            dt=1.0,
            hot_gas_temp_K=2800,
            mass_flow_kgs=0.5,
            chamber_pressure_Pa=6e6,
            is_burning=True,
        )
        assert r["chamber_wall_temp_K"] > 293.15

    def test_fatigue_accumulates_on_ignition(self):
        t = self._make_thermal()
        t.step(1.0, 2800, 0.5, 6e6, True, ignition_event=True)
        assert t.fatigue_pct > 0

    def test_cools_when_not_burning(self):
        t = self._make_thermal()
        t.chamber_wall_temp_K = 800.0
        r = t.step(1.0, 293.15, 0, 1e5, False)
        # should cool slightly
        assert r["chamber_wall_temp_K"] <= 800.0


# ── Cost model tests ──────────────────────────────────────────────────────────
class TestCostModel:
    def _make_cost(self):
        from financials.cost_model import CostModel, FinancialConfig
        return CostModel(FinancialConfig(n_thruster_units=48, h2_price_per_kg=6.0))

    def test_cost_increases(self):
        c = self._make_cost()
        r1 = c.step(1.0, 1.0, 100.0, 48)
        r2 = c.step(1.0, 1.0, 100.0, 48)
        assert r2["total_opex_usd"] > r1["total_opex_usd"]

    def test_h2_consumed_accumulates(self):
        c = self._make_cost()
        for _ in range(10):
            c.step(1.0, 2.0, 50.0, 48)
        assert c._h2_consumed_kg > 0

    def test_npv_structure(self):
        c = self._make_cost()
        for _ in range(100):
            c.step(36.0, 2.0, 1000.0, 48)
        npv = c.npv_analysis()
        assert "npv_usd" in npv
        assert "payback_years" in npv
        assert "roi_pct" in npv


# ── Integration test ──────────────────────────────────────────────────────────
class TestFullSimulation:
    def test_short_run_completes(self):
        from core.simulation import SimulationEngine, SimulationConfig
        cfg = SimulationConfig(
            vehicle_type="car",
            thruster_units=2,
            hydrogen_storage_kg=50.0,
            thrust_per_unit_N=5000.0,
            route_length_km=5.0,
            simulation_time_hours=0.05,
            dt=0.1,
        )
        engine = SimulationEngine(cfg)
        summary = engine.run()
        assert "duration_s" in summary
        assert summary["duration_s"] > 0

    def test_train_simulation(self):
        from core.simulation import SimulationEngine, SimulationConfig
        cfg = SimulationConfig(
            vehicle_type="train",
            thruster_units=6,
            hydrogen_storage_kg=200.0,
            thrust_per_unit_N=8000.0,
            route_length_km=20.0,
            payload_tons=100.0,
            simulation_time_hours=0.1,
            dt=0.1,
        )
        engine = SimulationEngine(cfg)
        summary = engine.run()
        assert summary.get("distance_km", 0) >= 0

    def test_telemetry_logged(self):
        from core.simulation import SimulationEngine, SimulationConfig
        cfg = SimulationConfig(
            vehicle_type="car",
            thruster_units=1,
            hydrogen_storage_kg=20.0,
            thrust_per_unit_N=3000.0,
            route_length_km=1.0,
            simulation_time_hours=0.01,
            dt=0.1,
        )
        engine = SimulationEngine(cfg)
        engine.run()
        df = engine.telemetry.to_dataframe()
        assert len(df) > 0
        assert "thrust_total_N" in df.columns
        assert "velocity_kmh" in df.columns


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])


# ── Engine Loop tests ─────────────────────────────────────────────────────────
class TestEngineLoop:
    def test_ticks_advance_sim_time(self):
        from core.engine_loop import EngineLoop
        counter = [0]
        def fake_step():
            counter[0] += 1
            return counter[0]
        loop = EngineLoop(dt=0.1, step_fn=fake_step, max_sim_time_s=1.0)
        results = list(loop.run())
        assert 10 <= len(results) <= 11   # floating-point boundary tolerance
        assert results[-1].sim_time_s >= 1.0

    def test_stop_fn_halts_loop(self):
        from core.engine_loop import EngineLoop
        vals = [0]
        def step():
            vals[0] += 1
            return vals[0]
        loop = EngineLoop(dt=0.1, step_fn=step,
                          stop_fn=lambda r: r.payload >= 5)
        results = list(loop.run())
        assert results[-1].payload == 5
        assert results[-1].stop_reason == "stop_fn"

    def test_stats_populated(self):
        from core.engine_loop import EngineLoop
        loop = EngineLoop(dt=0.05, step_fn=lambda: 1, max_sim_time_s=0.5)
        list(loop.run())
        s = loop.summary()
        assert 10 <= s["total_ticks"] <= 11
        assert s["avg_tick_ms"] >= 0


# ── Physics motion tests ──────────────────────────────────────────────────────
class TestMotionIntegrator:
    def test_euler_accelerates(self):
        from physics.motion import MotionIntegrator1D
        m = MotionIntegrator1D("forward_euler")
        s = m.step(dt=1.0, net_force_N=1000.0, mass_kg=100.0)
        assert s.velocity_ms > 0
        assert s.position_m > 0

    def test_no_negative_velocity(self):
        from physics.motion import MotionIntegrator1D
        m = MotionIntegrator1D()
        for _ in range(20):
            s = m.step(dt=0.1, net_force_N=-5000.0, mass_kg=100.0)
        assert s.velocity_ms >= 0

    def test_3d_motion_lateral(self):
        from physics.motion import MotionIntegrator3D, ThrustVector
        m = MotionIntegrator3D()
        tv = ThrustVector(axial_N=1000.0, lateral_N=500.0, normal_N=0.0)
        s = m.step(dt=1.0, thrust=tv, drag_x_N=0.0, drag_y_N=0.0, mass_kg=100.0)
        assert s.vx_ms > 0
        assert abs(s.vy_ms) > 0


# ── Friction model tests ──────────────────────────────────────────────────────
class TestFrictionModels:
    def test_rolling_resistance_positive(self):
        from physics.friction import rolling_resistance_N, RollingConfig
        cfg = RollingConfig(mass_kg=100_000, crr_static=0.002, crr_speed_coeff=3e-6)
        assert rolling_resistance_N(30.0, cfg) > 0

    def test_tyre_force_zero_at_zero_slip(self):
        from physics.friction import tyre_force_N, TyreConfig
        cfg = TyreConfig(mass_on_axle_kg=5000)
        assert tyre_force_N(0.0, cfg) == 0.0

    def test_brake_model_regen(self):
        from physics.friction import BrakeModel, BrakeConfig
        cfg = BrakeConfig(mass_kg=50000, regen_fraction=0.35)
        m = BrakeModel(cfg)
        r = m.apply(velocity_ms=30.0, dt=1.0, target_decel_ms2=0.8)
        assert r["regen_force_N"] > 0
        assert r["regen_force_N"] < r["total_brake_force_N"]

    def test_grade_resistance(self):
        from physics.friction import grade_resistance_N
        assert grade_resistance_N(10000, 2.0) > grade_resistance_N(10000, 0.0)


# ── Cooling system tests ──────────────────────────────────────────────────────
class TestCoolingSystem:
    def test_regen_removes_heat(self):
        from thermal.cooling import RegenerativeCoolingLoop, RegenerativeCoolingConfig
        cfg = RegenerativeCoolingConfig()
        loop = RegenerativeCoolingLoop(cfg)
        r = loop.step(dt=1.0, wall_temp_K=1200.0, mass_flow_kgs=0.5)
        assert r["Q_removed_W"] > 0
        assert r["outlet_temp_K"] >= cfg.inlet_temp_K

    def test_radiation_scales_with_temp(self):
        from thermal.cooling import RadiationCooling, RadiationConfig
        rc = RadiationCooling(RadiationConfig())
        r_cold = rc.step(500.0)
        r_hot  = rc.step(1500.0)
        assert r_hot["Q_radiation_W"] > r_cold["Q_radiation_W"]

    def test_combined_cooling_system(self):
        from thermal.cooling import CoolingSystem
        cs = CoolingSystem()
        r = cs.step(dt=1.0, chamber_wall_temp_K=1200.0,
                    nozzle_temp_K=1100.0, mass_flow_kgs=0.4)
        assert r["Q_total_removed_W"] > 0
        assert "mode" in r


# ── Pod system tests ──────────────────────────────────────────────────────────
class TestPodSystem:
    def test_pod_departs_and_accelerates(self):
        from vehicles.pod_system import TransportPod, PodConfig
        pod = TransportPod(PodConfig())
        pod.depart()
        for _ in range(100):
            r = pod.step(dt=0.1, h2_available=100.0, h2_rate_at_full=0.05)
        assert r["speed_kmh"] > 0

    def test_formation_convoy(self):
        from vehicles.pod_system import PodFormation
        convoy = PodFormation.create_convoy(n_pods=3)
        convoy.depart_all()
        h2 = [100.0] * 3
        rates = [0.05] * 3
        for _ in range(50):
            r = convoy.step(dt=0.1, h2_available_per_pod=h2, h2_rate_per_pod=rates)
        assert r["n_pods"] == 3
        assert r["avg_speed_kmh"] >= 0


# ── AI optimizer tests ────────────────────────────────────────────────────────
class TestAIOptimizer:
    def test_hill_climb_improves(self):
        from ai.optimizer import HillClimbOptimizer, HillClimbConfig
        opt = HillClimbOptimizer()
        scores = []
        for _ in range(200):
            params = opt.step(current_score=sum(opt._params))
            scores.append(sum(params))
        assert opt.best["score"] >= 0

    def test_bayesian_suggests_within_bounds(self):
        from ai.optimizer import BayesianOptimizer
        bounds = [(3.0, 20.0), (0.5, 1.0)]
        opt = BayesianOptimizer(bounds)
        opt.observe([8.0, 0.9], 0.85)
        opt.observe([12.0, 0.8], 0.88)
        x = opt.suggest()
        assert len(x) == 2
        for val, (lo, hi) in zip(x, bounds):
            assert lo <= val <= hi

    def test_pareto_front(self):
        from ai.optimizer import MultiObjectiveOptimizer
        opt = MultiObjectiveOptimizer(n_objectives=2)
        opt.add([1.0], [0.5, 0.8])
        opt.add([2.0], [0.3, 0.9])
        opt.add([3.0], [0.6, 0.7])
        assert len(opt.pareto_front) >= 1

    def test_predictive_scheduler(self):
        from ai.optimizer import PredictiveThrustScheduler, RouteSegment
        segs = [RouteSegment(5000), RouteSegment(5000, grade_pct=1.5),
                RouteSegment(1000, is_station=True), RouteSegment(5000)]
        sched = PredictiveThrustScheduler(segs, 500_000, 576_000, 5000)
        profile = sched.optimise(target_speed_ms=80.0)
        assert len(profile) == 4
        assert profile[2] == 0.0   # station = zero throttle
        assert all(0.0 <= t <= 1.0 for t in profile)
