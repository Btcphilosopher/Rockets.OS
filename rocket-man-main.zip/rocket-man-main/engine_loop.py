"""
AUREOM — Engine Loop
Low-level deterministic tick manager. Decoupled from SimulationEngine so
it can be driven by GUI timers, external event loops, or headless runners.

Provides:
    EngineLoop        — fixed-timestep accumulator with wall-clock pacing
    StepResult        — lightweight result envelope per tick
    LoopStats         — performance counters (sim-time / wall-time ratio)
"""
from __future__ import annotations
import time
from dataclasses import dataclass, field
from typing import Callable, Any
from utils.constants import DEFAULT_DT


@dataclass
class StepResult:
    """Lightweight per-tick envelope returned by EngineLoop.tick()."""
    sim_time_s:   float = 0.0
    wall_time_s:  float = 0.0
    dt:           float = DEFAULT_DT
    payload:      Any   = None          # TelemetryFrame or custom data
    stop_reason:  str   = ""            # "" = still running


@dataclass
class LoopStats:
    """Running performance metrics for the simulation loop."""
    ticks:           int   = 0
    sim_time_s:      float = 0.0
    wall_elapsed_s:  float = 0.0
    realtime_ratio:  float = 0.0        # sim_time / wall_time  (>1 = faster than real)
    avg_tick_ms:     float = 0.0
    max_tick_ms:     float = 0.0
    overruns:        int   = 0          # ticks that took longer than dt


class EngineLoop:
    """
    Fixed-timestep deterministic engine loop.

    Usage (headless):
        loop = EngineLoop(dt=0.05, step_fn=sim.step, stop_fn=lambda r: r.payload.t > 100)
        for result in loop.run():
            process(result)

    Usage (GUI / external drive):
        loop = EngineLoop(dt=0.05, step_fn=sim.step)
        # Called by QTimer or similar every frame:
        result = loop.tick()
        if result.stop_reason:
            loop.stop()
    """

    def __init__(
        self,
        dt: float,
        step_fn: Callable[[], Any],
        stop_fn: Callable[[StepResult], bool] | None = None,
        max_sim_time_s: float | None = None,
        realtime: bool = False,         # pace to wall clock (GUI mode)
    ) -> None:
        self.dt            = dt
        self._step_fn      = step_fn
        self._stop_fn      = stop_fn
        self._max_sim_time = max_sim_time_s
        self._realtime     = realtime

        self._sim_time:  float = 0.0
        self._running:   bool  = False
        self._stats      = LoopStats()
        self._wall_start: float = 0.0

    # ── Properties ────────────────────────────────────────────────────────────
    @property
    def sim_time(self) -> float:
        return self._sim_time

    @property
    def stats(self) -> LoopStats:
        return self._stats

    @property
    def is_running(self) -> bool:
        return self._running

    # ── Control ───────────────────────────────────────────────────────────────
    def start(self) -> None:
        self._running    = True
        self._wall_start = time.perf_counter()
        self._stats      = LoopStats()

    def stop(self) -> None:
        self._running = False

    def reset(self) -> None:
        self._sim_time = 0.0
        self._running  = False
        self._stats    = LoopStats()

    # ── Single tick ───────────────────────────────────────────────────────────
    def tick(self) -> StepResult:
        """
        Execute one simulation step. Call this from an external drive loop
        (e.g. QTimer). Returns StepResult with stop_reason set when finished.
        """
        if not self._running:
            return StepResult(stop_reason="not_started")

        tick_wall_start = time.perf_counter()

        # ── Optional real-time pacing ──
        if self._realtime:
            expected_wall = self._wall_start + self._sim_time
            now = time.perf_counter()
            sleep_s = expected_wall - now
            if sleep_s > 1e-4:
                time.sleep(sleep_s)

        # ── Execute simulation step ──
        payload = self._step_fn()

        tick_wall_end = time.perf_counter()
        tick_ms = (tick_wall_end - tick_wall_start) * 1000.0

        # ── Advance sim clock ──
        self._sim_time += self.dt

        # ── Update stats ──
        s = self._stats
        s.ticks         += 1
        s.sim_time_s     = self._sim_time
        s.wall_elapsed_s = tick_wall_end - self._wall_start
        s.avg_tick_ms    = (s.avg_tick_ms * (s.ticks - 1) + tick_ms) / s.ticks
        s.max_tick_ms    = max(s.max_tick_ms, tick_ms)
        s.realtime_ratio = s.sim_time_s / max(1e-9, s.wall_elapsed_s)
        if tick_ms > self.dt * 1000.0:
            s.overruns += 1

        result = StepResult(
            sim_time_s  = self._sim_time,
            wall_time_s = s.wall_elapsed_s,
            dt          = self.dt,
            payload     = payload,
        )

        # ── Stop conditions ──
        if self._max_sim_time is not None and self._sim_time >= self._max_sim_time:
            result.stop_reason = "time_limit"
            self._running      = False
        elif self._stop_fn is not None and self._stop_fn(result):
            result.stop_reason = "stop_fn"
            self._running      = False

        return result

    # ── Headless generator ────────────────────────────────────────────────────
    def run(self):
        """
        Generator: yields StepResult for every tick until stopped.

        Example:
            for result in loop.run():
                if result.payload.h2_stored_kg < 10:
                    break
        """
        self.start()
        while self._running:
            result = self.tick()
            yield result
            if result.stop_reason:
                break

    # ── Summary ───────────────────────────────────────────────────────────────
    def summary(self) -> dict:
        s = self._stats
        return {
            "total_ticks":      s.ticks,
            "sim_time_s":       s.sim_time_s,
            "wall_elapsed_s":   s.wall_elapsed_s,
            "realtime_ratio":   s.realtime_ratio,
            "avg_tick_ms":      s.avg_tick_ms,
            "max_tick_ms":      s.max_tick_ms,
            "overruns":         s.overruns,
            "overrun_pct":      100.0 * s.overruns / max(1, s.ticks),
        }
