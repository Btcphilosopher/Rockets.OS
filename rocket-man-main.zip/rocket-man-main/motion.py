"""
AUREOM — Motion Integrator
Standalone 1-D and 3-D rigid-body motion models.

Separates kinematics from the vehicle-specific drag/friction logic so
either can be unit-tested or swapped independently.

Provides:
    MotionState1D       — position, velocity, acceleration (longitudinal)
    MotionIntegrator1D  — forward-Euler + RK4 integrators
    MotionState3D       — 3-axis state for pod / gimbal thrust
    ThrustVector        — force decomposition (axial + lateral + normal)
"""
from __future__ import annotations
import math
from dataclasses import dataclass, field


# ══════════════════════════════════════════════════════════════════════════════
#  1-D LONGITUDINAL
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class MotionState1D:
    position_m:     float = 0.0
    velocity_ms:    float = 0.0
    acceleration_ms2: float = 0.0
    jerk_ms3:       float = 0.0      # rate of change of acceleration
    distance_total_m: float = 0.0


class MotionIntegrator1D:
    """
    Fixed-timestep longitudinal integrator.

    Supports:
        forward_euler  — first-order (fast, sufficient for small dt)
        rk4            — fourth-order Runge-Kutta (more accurate, 4× cost)
    """

    def __init__(self, method: str = "forward_euler") -> None:
        assert method in ("forward_euler", "rk4"), "method must be 'forward_euler' or 'rk4'"
        self.method = method
        self.state  = MotionState1D()

    def reset(self, position_m: float = 0.0, velocity_ms: float = 0.0) -> None:
        self.state = MotionState1D(position_m=position_m, velocity_ms=velocity_ms)

    # ── Forward Euler ─────────────────────────────────────────────────────────
    def _euler_step(self, dt: float, net_force_N: float, mass_kg: float) -> None:
        s = self.state
        prev_acc = s.acceleration_ms2
        s.acceleration_ms2 = net_force_N / max(1e-9, mass_kg)
        s.jerk_ms3         = (s.acceleration_ms2 - prev_acc) / max(dt, 1e-9)
        s.velocity_ms      = max(0.0, s.velocity_ms + s.acceleration_ms2 * dt)
        dx                 = s.velocity_ms * dt
        s.position_m      += dx
        s.distance_total_m += abs(dx)

    # ── RK4 ──────────────────────────────────────────────────────────────────
    def _rk4_step(
        self,
        dt: float,
        force_fn: "Callable[[float, float], float]",   # force_fn(pos, vel) → N
        mass_kg: float,
    ) -> None:
        """
        Fourth-order Runge-Kutta for dx/dt = v, dv/dt = F(x,v)/m
        """
        s    = self.state
        x0   = s.position_m
        v0   = s.velocity_ms

        def acc(x, v):
            return force_fn(x, v) / max(1e-9, mass_kg)

        k1x = v0;             k1v = acc(x0, v0)
        k2x = v0 + dt/2*k1v; k2v = acc(x0 + dt/2*k1x, v0 + dt/2*k1v)
        k3x = v0 + dt/2*k2v; k3v = acc(x0 + dt/2*k2x, v0 + dt/2*k2v)
        k4x = v0 + dt*k3v;   k4v = acc(x0 + dt*k3x,   v0 + dt*k3v)

        dx = dt / 6 * (k1x + 2*k2x + 2*k3x + k4x)
        dv = dt / 6 * (k1v + 2*k2v + 2*k3v + k4v)

        prev_acc           = s.acceleration_ms2
        s.position_m      += dx
        s.velocity_ms      = max(0.0, v0 + dv)
        s.acceleration_ms2 = dv / max(dt, 1e-9)
        s.jerk_ms3         = (s.acceleration_ms2 - prev_acc) / max(dt, 1e-9)
        s.distance_total_m += abs(dx)

    # ── Public step ───────────────────────────────────────────────────────────
    def step(
        self,
        dt: float,
        net_force_N: float,
        mass_kg: float,
        v_max_ms: float = 1e9,
        force_fn=None,
    ) -> MotionState1D:
        """
        Advance motion by dt seconds.

        Args:
            dt:           timestep (s)
            net_force_N:  sum of all forces on vehicle (N). Positive = forward.
            mass_kg:      vehicle mass (kg)
            v_max_ms:     hard speed ceiling (m/s)
            force_fn:     optional callable(pos, vel) → N for RK4 mode

        Returns updated MotionState1D.
        """
        if self.method == "rk4" and force_fn is not None:
            self._rk4_step(dt, force_fn, mass_kg)
        else:
            self._euler_step(dt, net_force_N, mass_kg)

        # Enforce speed cap
        if self.state.velocity_ms > v_max_ms:
            self.state.velocity_ms = v_max_ms
            self.state.acceleration_ms2 = 0.0

        return self.state


# ══════════════════════════════════════════════════════════════════════════════
#  3-D MOTION (for pod / gimbal thrust)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class ThrustVector:
    """Force decomposition for 3-axis thrust."""
    axial_N:   float = 0.0    # forward / longitudinal
    lateral_N: float = 0.0   # left / right
    normal_N:  float = 0.0   # up / down

    @property
    def magnitude_N(self) -> float:
        return math.sqrt(self.axial_N**2 + self.lateral_N**2 + self.normal_N**2)

    def from_magnitude_and_angles(
        magnitude_N: float,
        yaw_deg: float   = 0.0,
        pitch_deg: float = 0.0,
    ) -> "ThrustVector":
        yaw_rad   = math.radians(yaw_deg)
        pitch_rad = math.radians(pitch_deg)
        axial   = magnitude_N * math.cos(pitch_rad) * math.cos(yaw_rad)
        lateral = magnitude_N * math.cos(pitch_rad) * math.sin(yaw_rad)
        normal  = magnitude_N * math.sin(pitch_rad)
        return ThrustVector(axial_N=axial, lateral_N=lateral, normal_N=normal)


@dataclass
class MotionState3D:
    x_m:   float = 0.0   # forward
    y_m:   float = 0.0   # lateral
    z_m:   float = 0.0   # vertical
    vx_ms: float = 0.0
    vy_ms: float = 0.0
    vz_ms: float = 0.0
    ax_ms2: float = 0.0
    ay_ms2: float = 0.0
    az_ms2: float = 0.0
    heading_deg: float = 0.0
    distance_total_m: float = 0.0


class MotionIntegrator3D:
    """
    3-axis forward-Euler integrator for pod / gimbal-capable vehicles.
    """

    def __init__(self) -> None:
        self.state = MotionState3D()

    def reset(self) -> None:
        self.state = MotionState3D()

    def step(
        self,
        dt: float,
        thrust: ThrustVector,
        drag_x_N: float,
        drag_y_N: float,
        mass_kg:  float,
        gravity_ms2: float = 9.80665,
    ) -> MotionState3D:
        """
        Advance 3D motion by dt.
        drag_x_N / drag_y_N are resistance magnitudes (always opposing motion).
        """
        s = self.state

        # Net forces per axis
        sign_vx = 1.0 if s.vx_ms >= 0 else -1.0
        sign_vy = 1.0 if s.vy_ms >= 0 else -1.0

        Fx = thrust.axial_N   - sign_vx * abs(drag_x_N)
        Fy = thrust.lateral_N - sign_vy * abs(drag_y_N)
        Fz = thrust.normal_N  - mass_kg * gravity_ms2    # net vertical

        s.ax_ms2 = Fx / max(1e-9, mass_kg)
        s.ay_ms2 = Fy / max(1e-9, mass_kg)
        s.az_ms2 = Fz / max(1e-9, mass_kg)

        s.vx_ms = max(0.0, s.vx_ms + s.ax_ms2 * dt)  # no reverse on x
        s.vy_ms = s.vy_ms + s.ay_ms2 * dt
        s.vz_ms = s.vz_ms + s.az_ms2 * dt

        dx = s.vx_ms * dt
        dy = s.vy_ms * dt
        dz = s.vz_ms * dt

        s.x_m += dx
        s.y_m += dy
        s.z_m += dz
        s.distance_total_m += math.sqrt(dx**2 + dy**2 + dz**2)

        if abs(s.vx_ms) > 0.01 or abs(s.vy_ms) > 0.01:
            s.heading_deg = math.degrees(math.atan2(s.vy_ms, s.vx_ms))

        return s
