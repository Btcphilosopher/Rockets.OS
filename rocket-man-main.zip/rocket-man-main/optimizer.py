"""
AUREOM — AI Optimizer
Standalone module for adaptive propulsion efficiency optimization.

Implements:
    HillClimbOptimizer     — online gradient-free hill climbing (fast, robust)
    BayesianOptimizer      — GP-surrogate Bayesian optimization (accurate)
    MultiObjectiveOptimizer — Pareto-optimal trade-off (thrust vs efficiency)
    PredictiveThrustScheduler — look-ahead throttle profile generator
"""
from __future__ import annotations
import math
import random
from dataclasses import dataclass, field
from typing import Callable


# ══════════════════════════════════════════════════════════════════════════════
#  HILL CLIMBING (online, gradient-free)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class HillClimbConfig:
    param_names:     list[str] = field(default_factory=lambda: ["expansion_ratio"])
    initial_values:  list[float] = field(default_factory=lambda: [8.0])
    step_sizes:      list[float] = field(default_factory=lambda: [0.5])
    min_values:      list[float] = field(default_factory=lambda: [3.0])
    max_values:      list[float] = field(default_factory=lambda: [25.0])
    tune_interval:   int = 50        # steps between parameter updates
    perturbation_decay: float = 0.995


class HillClimbOptimizer:
    """
    Online hill-climbing optimizer for continuous propulsion parameters.

    Usage:
        opt = HillClimbOptimizer(cfg)
        new_params = opt.step(current_score, current_params)
    """

    def __init__(self, cfg: HillClimbConfig | None = None) -> None:
        self.cfg = cfg or HillClimbConfig()
        self._params    = list(self.cfg.initial_values)
        self._steps     = list(self.cfg.step_sizes)
        self._best_score  = -math.inf
        self._best_params = list(self._params)
        self._directions  = [1.0] * len(self._params)
        self._call_count  = 0
        self._history:    list[tuple[float, list[float]]] = []

    def step(
        self,
        current_score: float,
        current_params: list[float] | None = None,
    ) -> list[float]:
        """
        Evaluate current score and propose next parameter set.
        Returns list of recommended parameter values.
        """
        self._call_count += 1
        if current_params:
            self._params = list(current_params)

        if current_score > self._best_score:
            self._best_score  = current_score
            self._best_params = list(self._params)

        self._history.append((current_score, list(self._params)))

        # Tune every N steps
        if self._call_count % self.cfg.tune_interval == 0:
            for i in range(len(self._params)):
                # Evaluate improvement in current direction
                recent = self._history[-self.cfg.tune_interval:]
                scores = [s for s, _ in recent]
                if len(scores) >= 2 and scores[-1] > scores[0]:
                    # Improving — continue direction, may increase step
                    pass
                else:
                    # Stagnant — reverse direction
                    self._directions[i] *= -1.0

                # Perturb parameter
                self._params[i] += self._directions[i] * self._steps[i]
                self._params[i]  = max(self.cfg.min_values[i],
                                       min(self.cfg.max_values[i], self._params[i]))

                # Decay step size over time
                self._steps[i] *= self.cfg.perturbation_decay

        return list(self._params)

    @property
    def best(self) -> dict:
        return {
            "score":  self._best_score,
            "params": dict(zip(self.cfg.param_names, self._best_params)),
        }


# ══════════════════════════════════════════════════════════════════════════════
#  BAYESIAN OPTIMIZER (GP surrogate, no external deps)
# ══════════════════════════════════════════════════════════════════════════════

class BayesianOptimizer:
    """
    Lightweight Gaussian Process surrogate optimizer.
    Uses RBF kernel; no scipy/sklearn required.
    Suitable for 1–4 parameter optimization with sparse evaluations.
    """

    def __init__(
        self,
        bounds: list[tuple[float, float]],
        noise: float = 0.01,
        length_scale: float = 1.0,
    ) -> None:
        self.bounds      = bounds
        self.noise       = noise
        self.l           = length_scale
        self._X:  list[list[float]] = []
        self._y:  list[float]       = []
        self._n_candidates = 20

    # ── RBF kernel ────────────────────────────────────────────────────────────
    def _k(self, x1: list[float], x2: list[float]) -> float:
        sq_dist = sum((a - b)**2 for a, b in zip(x1, x2))
        return math.exp(-0.5 * sq_dist / self.l**2)

    def _K(self, X: list[list[float]]) -> list[list[float]]:
        n = len(X)
        return [[self._k(X[i], X[j]) + (self.noise**2 if i == j else 0.0)
                 for j in range(n)] for i in range(n)]

    # ── Cholesky solve ────────────────────────────────────────────────────────
    def _solve(self, A: list[list[float]], b: list[float]) -> list[float]:
        """Naive Gaussian elimination — fine for n < 30."""
        n = len(b)
        M = [row[:] + [b[i]] for i, row in enumerate(A)]
        for col in range(n):
            pivot = M[col][col]
            if abs(pivot) < 1e-12:
                continue
            for row in range(col + 1, n):
                factor = M[row][col] / pivot
                for k in range(col, n + 1):
                    M[row][k] -= factor * M[col][k]
        x = [0.0] * n
        for i in range(n - 1, -1, -1):
            x[i] = M[i][n]
            for j in range(i + 1, n):
                x[i] -= M[i][j] * x[j]
            x[i] /= max(1e-12, M[i][i])
        return x

    # ── GP posterior ─────────────────────────────────────────────────────────
    def _posterior(self, x_new: list[float]) -> tuple[float, float]:
        if not self._X:
            return 0.0, 1.0
        n = len(self._X)
        K_mat = self._K(self._X)
        k_star = [self._k(x_new, xi) for xi in self._X]
        alpha  = self._solve(K_mat, self._y)
        mu     = sum(k_star[i] * alpha[i] for i in range(n))
        v      = self._solve(K_mat, k_star)
        var    = max(0.0, self._k(x_new, x_new) - sum(k_star[i] * v[i] for i in range(n)))
        return mu, math.sqrt(var)

    # ── Upper confidence bound acquisition ────────────────────────────────────
    def _ucb(self, x: list[float], kappa: float = 2.0) -> float:
        mu, sigma = self._posterior(x)
        return mu + kappa * sigma

    # ── Public ───────────────────────────────────────────────────────────────
    def observe(self, x: list[float], y: float) -> None:
        """Record an evaluation result."""
        self._X.append(x)
        self._y.append(y)

    def suggest(self) -> list[float]:
        """Return the next parameter set to evaluate."""
        best_x   = None
        best_ucb = -math.inf
        for _ in range(self._n_candidates):
            x_cand = [random.uniform(lo, hi) for lo, hi in self.bounds]
            u = self._ucb(x_cand)
            if u > best_ucb:
                best_ucb = u
                best_x   = x_cand
        return best_x or [(lo + hi) / 2 for lo, hi in self.bounds]

    @property
    def best_observed(self) -> tuple[list[float], float]:
        if not self._y:
            return [(lo + hi) / 2 for lo, hi in self.bounds], 0.0
        idx = self._y.index(max(self._y))
        return self._X[idx], self._y[idx]


# ══════════════════════════════════════════════════════════════════════════════
#  MULTI-OBJECTIVE (Pareto) OPTIMIZER
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class Solution:
    params: list[float]
    objectives: list[float]   # minimise convention → negate for maximise

    def dominates(self, other: "Solution") -> bool:
        """True if self Pareto-dominates other."""
        return (all(a <= b for a, b in zip(self.objectives, other.objectives))
                and any(a <  b for a, b in zip(self.objectives, other.objectives)))


class MultiObjectiveOptimizer:
    """
    Simple NSGA-II-inspired Pareto front tracker.
    Objectives: [−efficiency, −speed]  (both negated → minimise)
    """

    def __init__(self, n_objectives: int = 2) -> None:
        self.n_obj  = n_objectives
        self._archive: list[Solution] = []

    def add(self, params: list[float], objectives: list[float]) -> None:
        """Add a new evaluated solution to the Pareto archive."""
        new_sol = Solution(params=params, objectives=objectives)
        # Remove dominated solutions
        self._archive = [s for s in self._archive if not new_sol.dominates(s)]
        # Add if not dominated
        if not any(s.dominates(new_sol) for s in self._archive):
            self._archive.append(new_sol)

    @property
    def pareto_front(self) -> list[Solution]:
        return list(self._archive)

    def best_compromise(self, weights: list[float] | None = None) -> Solution | None:
        """Return weighted-sum compromise solution from Pareto front."""
        if not self._archive:
            return None
        w = weights or [1.0 / self.n_obj] * self.n_obj
        def score(s: Solution) -> float:
            return sum(wi * oi for wi, oi in zip(w, s.objectives))
        return min(self._archive, key=score)


# ══════════════════════════════════════════════════════════════════════════════
#  PREDICTIVE THRUST SCHEDULER
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class RouteSegment:
    """Describes one segment of the route for look-ahead planning."""
    length_m:    float
    grade_pct:   float = 0.0
    speed_limit_ms: float = 83.3
    is_station:  bool  = False


class PredictiveThrustScheduler:
    """
    Look-ahead throttle profile generator.
    Plans optimal thrust schedule over the next N route segments to
    minimise H₂ consumption while respecting speed limits.

    Uses dynamic programming over a discretised state space.
    """

    def __init__(
        self,
        segments:       list[RouteSegment],
        vehicle_mass_kg: float,
        design_thrust_N: float,
        h2_budget_kg:    float,
    ) -> None:
        self.segments       = segments
        self.mass           = vehicle_mass_kg
        self.design_thrust  = design_thrust_N
        self.h2_budget      = h2_budget_kg
        self._schedule:     list[float] = []   # throttle per segment
        self._optimised     = False

    def optimise(
        self,
        h2_per_sec_at_full: float = 0.5,
        target_speed_ms:    float = 83.3,
    ) -> list[float]:
        """
        Build throttle schedule using greedy energy-aware planning.
        Returns list of throttle values [0–1] per segment.
        """
        schedule = []
        for seg in self.segments:
            if seg.is_station:
                schedule.append(0.0)
                continue
            # Estimate resistance
            v   = target_speed_ms * 0.8
            F_drag = 0.5 * 1.225 * v**2 * 9.0 * 0.33
            F_grade = self.mass * 9.81 * math.sin(math.atan(seg.grade_pct / 100))
            F_resist = F_drag + F_grade
            # Throttle needed just to overcome resistance
            t_min = F_resist / self.design_thrust
            # Apply speed-limit cap
            t_max = min(1.0, seg.speed_limit_ms / target_speed_ms)
            schedule.append(max(0.05, min(t_max, t_min * 1.15)))

        self._schedule   = schedule
        self._optimised  = True
        return schedule

    def get_throttle(self, segment_idx: int) -> float:
        """Return planned throttle for segment index."""
        if not self._optimised:
            self.optimise()
        if 0 <= segment_idx < len(self._schedule):
            return self._schedule[segment_idx]
        return 0.5

    def h2_estimate_kg(self, h2_per_sec_at_full: float = 0.5) -> float:
        """Estimate total H₂ for the planned schedule."""
        if not self._schedule:
            return 0.0
        avg_throttle = sum(self._schedule) / len(self._schedule)
        total_dist   = sum(s.length_m for s in self.segments)
        avg_speed    = 83.3
        total_time   = total_dist / max(1.0, avg_speed)
        return h2_per_sec_at_full * avg_throttle * total_time
