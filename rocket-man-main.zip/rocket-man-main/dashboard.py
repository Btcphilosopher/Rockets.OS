"""
AUREOM HYDRO-THRUSTER PLATFORM
PyQt6 Real-Time Simulation Dashboard
Anglo-Futurist dark aesthetic — charcoal / gold / cyan
"""
from __future__ import annotations
import sys
import math
import time
from collections import deque

import numpy as np
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QGridLayout, QLabel, QPushButton, QSlider, QComboBox,
    QGroupBox, QProgressBar, QSpinBox, QDoubleSpinBox,
    QFrame, QSizePolicy, QTabWidget, QTextEdit, QSplitter,
)
from PyQt6.QtCore import (
    Qt, QTimer, QThread, pyqtSignal, QObject, pyqtSlot,
)
from PyQt6.QtGui import (
    QFont, QColor, QPalette, QPainter, QPen, QBrush,
    QLinearGradient, QFontDatabase,
)

# ── Import simulation ─────────────────────────────────────────────────────────
sys.path.insert(0, "/home/claude/aureom_hydro_thruster")
from core.simulation import SimulationEngine, SimulationConfig
from utils.logger import TelemetryFrame


# ══════════════════════════════════════════════════════════════════════════════
#  COLOUR PALETTE
# ══════════════════════════════════════════════════════════════════════════════
BG_DEEP    = "#0c0e11"
BG_PANEL   = "#111418"
BG_CARD    = "#161b21"
BG_BORDER  = "#1e2530"
GOLD       = "#c9a84c"
GOLD_LIGHT = "#e8c86a"
CYAN       = "#00d4e0"
CYAN_DIM   = "#007a82"
RED        = "#e05555"
RED_DIM    = "#7a2222"
GREEN      = "#55cc88"
GREEN_DIM  = "#1a5535"
WHITE      = "#d8dde8"
GREY       = "#5a6478"
GREY_LIGHT = "#8a95a8"


# ══════════════════════════════════════════════════════════════════════════════
#  SIMULATION THREAD
# ══════════════════════════════════════════════════════════════════════════════
class SimulationWorker(QObject):
    frame_ready  = pyqtSignal(object)
    sim_complete = pyqtSignal(dict)
    error_signal = pyqtSignal(str)

    def __init__(self) -> None:
        super().__init__()
        self._engine: SimulationEngine | None = None
        self._running = False

    def configure(self, cfg: SimulationConfig) -> None:
        self._cfg = cfg

    @pyqtSlot()
    def run(self) -> None:
        try:
            self._engine = SimulationEngine(self._cfg)
            self._running = True
            max_t = self._cfg.simulation_time_hours * 3600.0

            while self._running and self._engine._t < max_t:
                frame = self._engine.step()
                self.frame_ready.emit(frame)

                if self._engine.storage.total_mass_kg < 0.5:
                    break
                pos = frame.position_m
                if pos >= self._cfg.route_length_km * 1000.0:
                    break

            summary = self._engine.telemetry.summary()
            self.sim_complete.emit(summary)
        except Exception as exc:
            self.error_signal.emit(str(exc))

    def stop(self) -> None:
        self._running = False
        if self._engine:
            self._engine.stop()


# ══════════════════════════════════════════════════════════════════════════════
#  CUSTOM WIDGETS
# ══════════════════════════════════════════════════════════════════════════════

class GaugeWidget(QWidget):
    """Analogue arc gauge with value + label."""

    def __init__(
        self,
        label: str,
        unit: str,
        min_val: float,
        max_val: float,
        warn_pct: float = 0.75,
        crit_pct: float = 0.90,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.label = label
        self.unit = unit
        self.min_val = min_val
        self.max_val = max_val
        self.warn_pct = warn_pct
        self.crit_pct = crit_pct
        self._value = 0.0
        self.setMinimumSize(130, 130)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

    def set_value(self, v: float) -> None:
        self._value = max(self.min_val, min(self.max_val, v))
        self.update()

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        w, h = self.width(), self.height()
        cx, cy = w / 2, h / 2
        r = min(w, h) / 2 - 8

        # background arc
        start = 225
        span = 270
        p.setPen(QPen(QColor(BG_BORDER), 6, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.drawArc(int(cx - r), int(cy - r), int(2 * r), int(2 * r),
                  int(start * 16), int(-span * 16))

        # value fraction
        frac = (self._value - self.min_val) / max(1e-9, self.max_val - self.min_val)
        frac = max(0.0, min(1.0, frac))

        # colour based on threshold
        if frac >= self.crit_pct:
            arc_colour = QColor(RED)
        elif frac >= self.warn_pct:
            arc_colour = QColor(GOLD)
        else:
            arc_colour = QColor(CYAN)

        p.setPen(QPen(arc_colour, 6, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.drawArc(int(cx - r), int(cy - r), int(2 * r), int(2 * r),
                  int(start * 16), int(-frac * span * 16))

        # value text
        p.setPen(QColor(WHITE))
        p.setFont(QFont("Courier New", 14, QFont.Weight.Bold))
        val_str = f"{self._value:.1f}"
        p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, val_str)

        # unit text
        p.setPen(QColor(GREY_LIGHT))
        p.setFont(QFont("Courier New", 8))
        p.drawText(int(cx - 30), int(cy + r * 0.55), 60, 16,
                   Qt.AlignmentFlag.AlignCenter, self.unit)

        # label
        p.setPen(QColor(GOLD))
        p.setFont(QFont("Courier New", 7, QFont.Weight.Bold))
        p.drawText(int(cx - 40), int(cy + r * 0.75), 80, 16,
                   Qt.AlignmentFlag.AlignCenter, self.label)


class SparklineWidget(QWidget):
    """Rolling sparkline chart."""

    def __init__(self, label: str, colour: str, max_points: int = 300, parent=None) -> None:
        super().__init__(parent)
        self.label = label
        self.colour = QColor(colour)
        self._data: deque[float] = deque(maxlen=max_points)
        self.setMinimumHeight(80)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

    def push(self, v: float) -> None:
        self._data.append(v)
        self.update()

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        w, h = self.width(), self.height()
        p.fillRect(0, 0, w, h, QColor(BG_CARD))

        if len(self._data) < 2:
            return

        data = list(self._data)
        mn, mx = min(data), max(data)
        rng = max(1e-9, mx - mn)

        # grid line
        p.setPen(QPen(QColor(BG_BORDER), 1))
        p.drawLine(0, h // 2, w, h // 2)

        # sparkline
        pen = QPen(self.colour, 1.5)
        p.setPen(pen)
        n = len(data)
        pts = [
            (int(i * w / (n - 1)), int(h - 4 - (data[i] - mn) / rng * (h - 8)))
            for i in range(n)
        ]
        for i in range(len(pts) - 1):
            p.drawLine(pts[i][0], pts[i][1], pts[i+1][0], pts[i+1][1])

        # label
        p.setPen(QColor(GREY_LIGHT))
        p.setFont(QFont("Courier New", 8))
        p.drawText(4, 12, self.label)

        # current value
        p.setPen(self.colour)
        p.setFont(QFont("Courier New", 9, QFont.Weight.Bold))
        p.drawText(w - 80, 12, f"{data[-1]:.1f}")


class MetricCard(QFrame):
    """Small KPI card: label + value + unit."""

    def __init__(self, label: str, unit: str = "", colour: str = CYAN, parent=None) -> None:
        super().__init__(parent)
        self.setFrameShape(QFrame.Shape.Box)
        self.setStyleSheet(f"""
            QFrame {{
                background: {BG_CARD};
                border: 1px solid {BG_BORDER};
                border-radius: 4px;
            }}
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(2)

        self._lbl = QLabel(label.upper())
        self._lbl.setStyleSheet(f"color: {GREY_LIGHT}; font: 7pt 'Courier New'; border:none;")

        self._val = QLabel("—")
        self._val.setStyleSheet(f"color: {colour}; font: bold 16pt 'Courier New'; border:none;")

        self._unit = QLabel(unit)
        self._unit.setStyleSheet(f"color: {GREY}; font: 8pt 'Courier New'; border:none;")

        layout.addWidget(self._lbl)
        layout.addWidget(self._val)
        layout.addWidget(self._unit)

    def set_value(self, v: float, fmt: str = ".1f") -> None:
        self._val.setText(f"{v:{fmt}}")

    def set_text(self, s: str) -> None:
        self._val.setText(s)


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN WINDOW
# ══════════════════════════════════════════════════════════════════════════════

STYLE = f"""
QMainWindow, QWidget {{
    background-color: {BG_DEEP};
    color: {WHITE};
    font-family: 'Courier New';
}}
QGroupBox {{
    border: 1px solid {BG_BORDER};
    border-radius: 4px;
    margin-top: 14px;
    font: bold 8pt 'Courier New';
    color: {GOLD};
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 4px;
    color: {GOLD};
}}
QPushButton {{
    background: {BG_CARD};
    border: 1px solid {GOLD};
    border-radius: 3px;
    color: {GOLD};
    font: bold 9pt 'Courier New';
    padding: 6px 16px;
}}
QPushButton:hover {{
    background: {GOLD};
    color: {BG_DEEP};
}}
QPushButton:disabled {{
    border-color: {GREY};
    color: {GREY};
}}
QSlider::groove:horizontal {{
    background: {BG_BORDER};
    height: 4px;
    border-radius: 2px;
}}
QSlider::handle:horizontal {{
    background: {CYAN};
    width: 14px;
    height: 14px;
    margin: -5px 0;
    border-radius: 7px;
}}
QComboBox {{
    background: {BG_CARD};
    border: 1px solid {BG_BORDER};
    color: {WHITE};
    padding: 4px;
}}
QProgressBar {{
    background: {BG_BORDER};
    border: none;
    border-radius: 2px;
    height: 8px;
    text-align: right;
}}
QProgressBar::chunk {{
    background: {CYAN};
    border-radius: 2px;
}}
QLabel {{ border: none; }}
QTabWidget::pane {{
    border: 1px solid {BG_BORDER};
    background: {BG_PANEL};
}}
QTabBar::tab {{
    background: {BG_CARD};
    color: {GREY_LIGHT};
    border: 1px solid {BG_BORDER};
    padding: 6px 16px;
    font: 8pt 'Courier New';
}}
QTabBar::tab:selected {{
    background: {BG_PANEL};
    color: {GOLD};
    border-bottom: 2px solid {GOLD};
}}
QTextEdit {{
    background: {BG_CARD};
    color: {GREEN};
    border: 1px solid {BG_BORDER};
    font: 8pt 'Courier New';
}}
QSpinBox, QDoubleSpinBox {{
    background: {BG_CARD};
    border: 1px solid {BG_BORDER};
    color: {WHITE};
    padding: 3px;
    font: 9pt 'Courier New';
}}
"""


class AureomDashboard(QMainWindow):

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("AUREOM HYDRO-THRUSTER PLATFORM  //  v1.0")
        self.resize(1400, 900)
        self.setStyleSheet(STYLE)

        self._worker: SimulationWorker | None = None
        self._thread: QThread | None = None
        self._running = False
        self._step_count = 0
        self._last_frame: TelemetryFrame | None = None

        self._build_ui()

    # ── UI construction ───────────────────────────────────────────────────────
    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(10, 8, 10, 8)
        root.setSpacing(6)

        # ── Header bar ──
        root.addLayout(self._build_header())

        # ── Main content tabs ──
        tabs = QTabWidget()
        tabs.addTab(self._build_operations_tab(), "⚡  OPERATIONS")
        tabs.addTab(self._build_propulsion_tab(), "🔥  PROPULSION")
        tabs.addTab(self._build_thermal_tab(), "🌡  THERMAL")
        tabs.addTab(self._build_economics_tab(), "📊  ECONOMICS")
        tabs.addTab(self._build_config_tab(), "⚙  CONFIGURATION")
        root.addWidget(tabs)

        # ── Status bar ──
        root.addLayout(self._build_statusbar())

    # ── Header ────────────────────────────────────────────────────────────────
    def _build_header(self) -> QHBoxLayout:
        hdr = QHBoxLayout()

        title_lbl = QLabel("AUREOM  //  HYDRO-THRUSTER PLATFORM")
        title_lbl.setStyleSheet(
            f"color: {GOLD}; font: bold 14pt 'Courier New'; letter-spacing: 2px;"
        )
        hdr.addWidget(title_lbl)
        hdr.addStretch()

        self._sim_time_lbl = QLabel("T+ 0:00:00")
        self._sim_time_lbl.setStyleSheet(
            f"color: {CYAN}; font: bold 12pt 'Courier New';"
        )
        hdr.addWidget(self._sim_time_lbl)
        hdr.addSpacing(20)

        self._status_lbl = QLabel("● STANDBY")
        self._status_lbl.setStyleSheet(f"color: {GREY}; font: bold 9pt 'Courier New';")
        hdr.addWidget(self._status_lbl)
        hdr.addSpacing(20)

        self._btn_start = QPushButton("▶  IGNITE")
        self._btn_start.clicked.connect(self._on_start)
        hdr.addWidget(self._btn_start)

        self._btn_stop = QPushButton("■  ABORT")
        self._btn_stop.setEnabled(False)
        self._btn_stop.clicked.connect(self._on_stop)
        self._btn_stop.setStyleSheet(self._btn_stop.styleSheet() +
                                      f"border-color: {RED}; color: {RED};")
        hdr.addWidget(self._btn_stop)

        return hdr

    # ── Operations tab ────────────────────────────────────────────────────────
    def _build_operations_tab(self) -> QWidget:
        w = QWidget()
        layout = QHBoxLayout(w)
        layout.setSpacing(10)

        # ── Left: gauges ──
        gauge_col = QVBoxLayout()
        gauge_row1 = QHBoxLayout()

        self._g_thrust    = GaugeWidget("THRUST",   "kN",  0, 1000, 0.7, 0.90)
        self._g_velocity  = GaugeWidget("VELOCITY", "km/h", 0, 400, 0.6, 0.85)
        self._g_isp       = GaugeWidget("Isp",      "s",   0, 450, 0.7, 0.95)
        self._g_fuel      = GaugeWidget("FUEL",     "%",   0, 100, 0.25, 0.1)

        for g in (self._g_thrust, self._g_velocity, self._g_isp, self._g_fuel):
            gauge_row1.addWidget(g)
        gauge_col.addLayout(gauge_row1)

        # KPI row
        kpi_row = QHBoxLayout()
        self._kpi_pos   = MetricCard("DISTANCE", "km",   CYAN)
        self._kpi_acc   = MetricCard("ACCEL",   "m/s²", GOLD)
        self._kpi_flow  = MetricCard("H₂ FLOW", "kg/s", CYAN)
        self._kpi_throttle = MetricCard("THROTTLE", "%", GOLD)
        self._kpi_state = MetricCard("STATE",    "",    GREEN)
        for c in (self._kpi_pos, self._kpi_acc, self._kpi_flow, self._kpi_throttle, self._kpi_state):
            kpi_row.addWidget(c)
        gauge_col.addLayout(kpi_row)
        layout.addLayout(gauge_col, 3)

        # ── Right: sparklines ──
        spark_col = QVBoxLayout()
        self._sp_thrust   = SparklineWidget("THRUST (N)",    CYAN)
        self._sp_velocity = SparklineWidget("VELOCITY (km/h)", GOLD)
        self._sp_h2       = SparklineWidget("H₂ STORED (kg)", GREEN)
        self._sp_isp      = SparklineWidget("Isp (s)",       GOLD_LIGHT)
        for sp in (self._sp_thrust, self._sp_velocity, self._sp_h2, self._sp_isp):
            spark_col.addWidget(sp)
        layout.addLayout(spark_col, 2)

        return w

    # ── Propulsion tab ────────────────────────────────────────────────────────
    def _build_propulsion_tab(self) -> QWidget:
        w = QWidget()
        layout = QGridLayout(w)
        layout.setSpacing(10)

        # Chamber pressure gauge
        self._g_chamber_p = GaugeWidget("CHAMBER P", "MPa", 0, 12, 0.7, 0.90)
        self._g_chamber_t = GaugeWidget("CHAMBER T", "K",   200, 3200, 0.75, 0.90)
        self._g_nozzle_er = GaugeWidget("EXP RATIO", "",    1, 25,   0.7, 0.95)
        self._g_eta_c     = GaugeWidget("η COMB",    "",    0, 1.0,  0.5, 0.3)
        layout.addWidget(self._g_chamber_p, 0, 0)
        layout.addWidget(self._g_chamber_t, 0, 1)
        layout.addWidget(self._g_nozzle_er, 0, 2)
        layout.addWidget(self._g_eta_c,     0, 3)

        # Sparklines
        self._sp_chamber_p = SparklineWidget("CHAMBER PRESSURE (Pa)", CYAN)
        self._sp_exhaust_v = SparklineWidget("EXHAUST VELOCITY (m/s)", GOLD)
        self._sp_mass_flow = SparklineWidget("MASS FLOW (kg/s)", GREEN)
        layout.addWidget(self._sp_chamber_p, 1, 0, 1, 2)
        layout.addWidget(self._sp_exhaust_v, 1, 2, 1, 2)
        layout.addWidget(self._sp_mass_flow, 2, 0, 1, 4)

        # KPIs
        kpi_row = QHBoxLayout()
        self._kpi_exhaust = MetricCard("EXHAUST Vₑ", "m/s", CYAN)
        self._kpi_cf      = MetricCard("Cf",         "",    GOLD)
        self._kpi_nozzle  = MetricCard("NOZZLE",     "",    GREEN)
        self._kpi_units   = MetricCard("ACTIVE THR", "",    CYAN)
        for c in (self._kpi_exhaust, self._kpi_cf, self._kpi_nozzle, self._kpi_units):
            kpi_row.addWidget(c)
        layout.addLayout(kpi_row, 3, 0, 1, 4)

        return w

    # ── Thermal tab ───────────────────────────────────────────────────────────
    def _build_thermal_tab(self) -> QWidget:
        w = QWidget()
        layout = QGridLayout(w)
        layout.setSpacing(10)

        self._g_wall_t    = GaugeWidget("WALL TEMP",    "K",  200, 1700, 0.75, 0.90)
        self._g_nozzle_t  = GaugeWidget("NOZZLE TEMP",  "K",  200, 1900, 0.75, 0.90)
        self._g_coolant_t = GaugeWidget("COOLANT OUT",  "K",  280, 500,  0.70, 0.85)
        self._g_fatigue   = GaugeWidget("FATIGUE",      "%",  0, 100,   0.50, 0.75)
        layout.addWidget(self._g_wall_t,   0, 0)
        layout.addWidget(self._g_nozzle_t, 0, 1)
        layout.addWidget(self._g_coolant_t,0, 2)
        layout.addWidget(self._g_fatigue,  0, 3)

        self._sp_wall_t   = SparklineWidget("WALL TEMP (K)",    RED)
        self._sp_fatigue  = SparklineWidget("STRUCTURAL FATIGUE (%)", GOLD)
        layout.addWidget(self._sp_wall_t,  1, 0, 1, 2)
        layout.addWidget(self._sp_fatigue, 1, 2, 1, 2)

        # Overtemp warnings
        self._warn_overtemp = QLabel("")
        self._warn_overtemp.setStyleSheet(f"color: {RED}; font: bold 10pt 'Courier New';")
        layout.addWidget(self._warn_overtemp, 2, 0, 1, 4)

        return w

    # ── Economics tab ─────────────────────────────────────────────────────────
    def _build_economics_tab(self) -> QWidget:
        w = QWidget()
        layout = QGridLayout(w)
        layout.setSpacing(10)

        # KPI cards
        kpi = QHBoxLayout()
        self._kpi_cost_km    = MetricCard("COST / km",     "USD",  GOLD)
        self._kpi_h2_burnt   = MetricCard("H₂ CONSUMED",  "kg",   CYAN)
        self._kpi_fuel_cost  = MetricCard("FUEL SPEND",   "USD",  GOLD)
        self._kpi_opex       = MetricCard("TOTAL OPEX",   "USD",  RED)
        for c in (self._kpi_cost_km, self._kpi_h2_burnt, self._kpi_fuel_cost, self._kpi_opex):
            kpi.addWidget(c)
        layout.addLayout(kpi, 0, 0, 1, 4)

        self._sp_cost_km   = SparklineWidget("COST / km (USD)", GOLD)
        self._sp_h2_rate   = SparklineWidget("H₂ CONSUMPTION RATE (kg/s)", CYAN)
        self._sp_h2_stored = SparklineWidget("H₂ REMAINING (%)", GREEN)
        layout.addWidget(self._sp_cost_km,   1, 0, 1, 2)
        layout.addWidget(self._sp_h2_rate,   1, 2, 1, 2)
        layout.addWidget(self._sp_h2_stored, 2, 0, 1, 4)

        return w

    # ── Configuration tab ─────────────────────────────────────────────────────
    def _build_config_tab(self) -> QWidget:
        w = QWidget()
        layout = QHBoxLayout(w)

        # ── Left panel: parameters ──
        left = QGroupBox("SIMULATION PARAMETERS")
        form = QGridLayout(left)
        form.setSpacing(8)

        def row(r, label, widget):
            form.addWidget(QLabel(label), r, 0)
            form.addWidget(widget, r, 1)

        self._cfg_vehicle = QComboBox()
        self._cfg_vehicle.addItems(["train", "car", "pod"])
        row(0, "Vehicle Type", self._cfg_vehicle)

        self._cfg_units = QSpinBox()
        self._cfg_units.setRange(1, 256)
        self._cfg_units.setValue(48)
        row(1, "Thruster Units", self._cfg_units)

        self._cfg_h2 = QDoubleSpinBox()
        self._cfg_h2.setRange(100, 50000)
        self._cfg_h2.setValue(5000)
        self._cfg_h2.setSuffix(" kg")
        row(2, "H₂ Storage", self._cfg_h2)

        self._cfg_thrust = QDoubleSpinBox()
        self._cfg_thrust.setRange(1000, 100000)
        self._cfg_thrust.setValue(12000)
        self._cfg_thrust.setSuffix(" N")
        row(3, "Thrust/Unit", self._cfg_thrust)

        self._cfg_route = QDoubleSpinBox()
        self._cfg_route.setRange(1, 5000)
        self._cfg_route.setValue(200)
        self._cfg_route.setSuffix(" km")
        row(4, "Route Length", self._cfg_route)

        self._cfg_payload = QDoubleSpinBox()
        self._cfg_payload.setRange(0, 50000)
        self._cfg_payload.setValue(800)
        self._cfg_payload.setSuffix(" t")
        row(5, "Payload", self._cfg_payload)

        self._cfg_speed = QDoubleSpinBox()
        self._cfg_speed.setRange(10, 600)
        self._cfg_speed.setValue(300)
        self._cfg_speed.setSuffix(" km/h")
        row(6, "Target Speed", self._cfg_speed)

        self._cfg_hours = QDoubleSpinBox()
        self._cfg_hours.setRange(0.1, 24)
        self._cfg_hours.setValue(3)
        self._cfg_hours.setSuffix(" h")
        row(7, "Sim Duration", self._cfg_hours)

        self._cfg_mode = QComboBox()
        self._cfg_mode.addItems(["cruise", "performance", "efficiency"])
        row(8, "Control Mode", self._cfg_mode)

        self._cfg_storage = QComboBox()
        self._cfg_storage.addItems(["compressed", "cryogenic"])
        row(9, "Storage Mode", self._cfg_storage)

        self._cfg_h2price = QDoubleSpinBox()
        self._cfg_h2price.setRange(0.5, 30)
        self._cfg_h2price.setValue(6.0)
        self._cfg_h2price.setSuffix(" USD/kg")
        row(10, "H₂ Price", self._cfg_h2price)

        layout.addWidget(left, 1)

        # ── Right panel: event log ──
        right = QGroupBox("MISSION LOG")
        rlay = QVBoxLayout(right)
        self._log_view = QTextEdit()
        self._log_view.setReadOnly(True)
        rlay.addWidget(self._log_view)
        layout.addWidget(right, 2)

        return w

    # ── Status bar ────────────────────────────────────────────────────────────
    def _build_statusbar(self) -> QHBoxLayout:
        bar = QHBoxLayout()

        # Fuel bar
        bar.addWidget(QLabel("H₂ FUEL"))
        self._fuel_bar = QProgressBar()
        self._fuel_bar.setRange(0, 100)
        self._fuel_bar.setValue(100)
        self._fuel_bar.setFixedHeight(8)
        self._fuel_bar.setFixedWidth(200)
        bar.addWidget(self._fuel_bar)

        bar.addSpacing(20)

        # Route bar
        bar.addWidget(QLabel("ROUTE"))
        self._route_bar = QProgressBar()
        self._route_bar.setRange(0, 1000)
        self._route_bar.setValue(0)
        self._route_bar.setFixedHeight(8)
        self._route_bar.setFixedWidth(200)
        self._route_bar.setStyleSheet(
            self._route_bar.styleSheet() +
            "QProgressBar::chunk { background: " + GOLD + "; }"
        )
        bar.addWidget(self._route_bar)

        bar.addSpacing(20)
        self._ctrl_mode_lbl = QLabel("MODE: CRUISE")
        self._ctrl_mode_lbl.setStyleSheet(f"color: {CYAN}; font: 8pt 'Courier New';")
        bar.addWidget(self._ctrl_mode_lbl)

        bar.addStretch()

        self._fps_lbl = QLabel("SIM: 0 fps")
        self._fps_lbl.setStyleSheet(f"color: {GREY}; font: 8pt 'Courier New';")
        bar.addWidget(self._fps_lbl)

        return bar

    # ── Simulation control ────────────────────────────────────────────────────
    def _build_sim_config(self) -> SimulationConfig:
        return SimulationConfig(
            vehicle_type=self._cfg_vehicle.currentText(),
            thruster_units=self._cfg_units.value(),
            hydrogen_storage_kg=self._cfg_h2.value(),
            thrust_per_unit_N=self._cfg_thrust.value(),
            route_length_km=self._cfg_route.value(),
            payload_tons=self._cfg_payload.value(),
            simulation_time_hours=self._cfg_hours.value(),
            target_speed_kmh=self._cfg_speed.value(),
            control_mode=self._cfg_mode.currentText(),
            storage_mode=self._cfg_storage.currentText(),
            h2_price_per_kg=self._cfg_h2price.value(),
            dt=0.1,  # 10 Hz for responsive GUI
        )

    def _on_start(self) -> None:
        self._btn_start.setEnabled(False)
        self._btn_stop.setEnabled(True)
        self._status_lbl.setText("● RUNNING")
        self._status_lbl.setStyleSheet(f"color: {GREEN}; font: bold 9pt 'Courier New';")
        self._running = True
        self._step_count = 0
        self._fps_t0 = time.time()

        cfg = self._build_sim_config()

        self._worker = SimulationWorker()
        self._worker.configure(cfg)
        self._thread = QThread()
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.frame_ready.connect(self._on_frame)
        self._worker.sim_complete.connect(self._on_complete)
        self._worker.error_signal.connect(self._on_error)
        self._thread.start()
        self._log("IGNITION SEQUENCE INITIATED")
        self._log(f"Vehicle: {cfg.vehicle_type.upper()}  |  Units: {cfg.thruster_units}")
        self._log(f"H₂ Storage: {cfg.hydrogen_storage_kg:.0f} kg  |  Route: {cfg.route_length_km:.0f} km")

    def _on_stop(self) -> None:
        if self._worker:
            self._worker.stop()
        self._running = False
        self._btn_start.setEnabled(True)
        self._btn_stop.setEnabled(False)
        self._status_lbl.setText("● ABORTED")
        self._status_lbl.setStyleSheet(f"color: {RED}; font: bold 9pt 'Courier New';")
        self._log("ABORT COMMAND — THRUSTERS SHUTDOWN")

    @pyqtSlot(object)
    def _on_frame(self, frame: TelemetryFrame) -> None:
        self._last_frame = frame
        self._step_count += 1

        # ── Throttle UI update rate (every 5 frames) ──
        if self._step_count % 5 != 0:
            return

        f = frame
        route_len = self._cfg_route.value() * 1000.0

        # ── Operations tab ──
        self._g_thrust.set_value(f.thrust_total_N / 1000)
        self._g_velocity.set_value(f.velocity_kmh)
        self._g_isp.set_value(f.isp_s)
        self._g_fuel.set_value(f.fuel_remaining_pct)

        self._kpi_pos.set_value(f.position_m / 1000)
        self._kpi_acc.set_value(f.acceleration_ms2, ".3f")
        self._kpi_flow.set_value(f.mass_flow_total_kgs, ".3f")
        self._kpi_throttle.set_value(f.throttle * 100, ".0f")
        self._kpi_state.set_text(f.engine_state[:6])

        self._sp_thrust.push(f.thrust_total_N)
        self._sp_velocity.push(f.velocity_kmh)
        self._sp_h2.push(f.h2_stored_kg)
        self._sp_isp.push(f.isp_s)

        # ── Propulsion tab ──
        self._g_chamber_p.set_value(f.chamber_pressure_Pa / 1e6)
        self._g_chamber_t.set_value(f.chamber_temp_K)
        self._g_nozzle_er.set_value(f.nozzle_expansion_ratio)
        self._g_eta_c.set_value(f.combustion_efficiency)

        self._sp_chamber_p.push(f.chamber_pressure_Pa)
        self._sp_exhaust_v.push(f.exhaust_velocity_ms)
        self._sp_mass_flow.push(f.mass_flow_total_kgs)

        self._kpi_exhaust.set_value(f.exhaust_velocity_ms)
        self._kpi_nozzle.set_text(f.engine_state[:8])

        # ── Thermal tab ──
        self._g_wall_t.set_value(f.chamber_temp_K)
        self._g_nozzle_t.set_value(f.nozzle_temp_K)
        self._g_coolant_t.set_value(f.coolant_temp_K)
        self._g_fatigue.set_value(f.structural_fatigue_pct)

        self._sp_wall_t.push(f.chamber_temp_K)
        self._sp_fatigue.push(f.structural_fatigue_pct)

        warn = []
        if f.chamber_temp_K > 1500:
            warn.append("⚠ CHAMBER OVERTEMP")
        if f.nozzle_temp_K > 1750:
            warn.append("⚠ NOZZLE OVERTEMP")
        if f.structural_fatigue_pct > 75:
            warn.append("⚠ STRUCTURAL FATIGUE CRITICAL")
        self._warn_overtemp.setText("   ".join(warn))

        # ── Economics tab ──
        self._kpi_cost_km.set_value(f.cost_per_km_usd, ".2f")
        self._kpi_h2_burnt.set_value(f.h2_consumed_kg, ".1f")
        self._kpi_fuel_cost.set_value(f.h2_consumed_kg * self._cfg_h2price.value(), ".0f")
        self._kpi_opex.set_value(f.cost_so_far_usd, ".0f")

        self._sp_cost_km.push(f.cost_per_km_usd)
        self._sp_h2_rate.push(f.mass_flow_total_kgs)
        self._sp_h2_stored.push(f.fuel_remaining_pct)

        # ── Status bar ──
        self._fuel_bar.setValue(int(f.fuel_remaining_pct))
        route_pct = min(1000, int(f.position_m / route_len * 1000))
        self._route_bar.setValue(route_pct)
        self._ctrl_mode_lbl.setText(f"MODE: {f.control_mode}")

        # ── Sim time ──
        h = int(f.t // 3600)
        m = int((f.t % 3600) // 60)
        s = int(f.t % 60)
        self._sim_time_lbl.setText(f"T+ {h}:{m:02d}:{s:02d}")

        # ── FPS ──
        elapsed = time.time() - self._fps_t0
        fps = self._step_count / max(0.001, elapsed)
        self._fps_lbl.setText(f"SIM: {fps:.0f} steps/s")

    @pyqtSlot(dict)
    def _on_complete(self, summary: dict) -> None:
        self._btn_start.setEnabled(True)
        self._btn_stop.setEnabled(False)
        self._status_lbl.setText("● COMPLETE")
        self._status_lbl.setStyleSheet(f"color: {GOLD}; font: bold 9pt 'Courier New';")
        self._log("══ MISSION COMPLETE ══")
        for k, v in summary.items():
            if isinstance(v, float):
                self._log(f"  {k:<35} {v:.3f}")
            else:
                self._log(f"  {k:<35} {v}")

    @pyqtSlot(str)
    def _on_error(self, msg: str) -> None:
        self._log(f"[ERROR] {msg}")
        self._status_lbl.setText("● ERROR")
        self._status_lbl.setStyleSheet(f"color: {RED}; font: bold 9pt 'Courier New';")

    def _log(self, msg: str) -> None:
        self._log_view.append(f"  {msg}")

    def closeEvent(self, event) -> None:
        if self._worker:
            self._worker.stop()
        if self._thread:
            self._thread.quit()
            self._thread.wait(2000)
        super().closeEvent(event)


# ══════════════════════════════════════════════════════════════════════════════
#  LAUNCH
# ══════════════════════════════════════════════════════════════════════════════

def launch_dashboard() -> None:
    app = QApplication.instance() or QApplication(sys.argv)
    win = AureomDashboard()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    launch_dashboard()
