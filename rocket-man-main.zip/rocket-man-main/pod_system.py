"""
AUREOM — Modular Transport Pod System
Autonomous thrust-controlled pod units supporting:
    - Formation flight / convoy mode
    - Independent 3-axis thrust vectoring
    - Inter-pod communication and synchronisation
    - Platoon gap-keeping using PID control
    - Docking / undocking lifecycle
"""
from __future__ import annotations
import math
from dataclasses import dataclass, field
from enum import Enum, auto
from physics.motion import MotionIntegrator3D, MotionState3D, ThrustVector
from physics.drag import DragConfig, aerodynamic_drag
from utils.constants import GRAVITY


class PodState(Enum):
    DOCKED     = auto()
    DEPARTING  = auto()
    CRUISING   = auto()
    FORMATION  = auto()
    BRAKING    = auto()
    ARRIVED    = auto()
    FAULT      = auto()


@dataclass
class PodConfig:
    pod_id: str = "POD-01"
    mass_kg: float = 8_000.0
    payload_kg: float = 2_000.0
    n_thrusters: int = 4
    thrust_per_unit_N: float = 5_000.0
    max_speed_ms: float = 120.0
    drag_cd: float = 0.22
    frontal_area_m2: float = 3.8
    # Formation
    target_gap_m: float = 50.0       # distance to vehicle ahead in platoon
    gap_tolerance_m: float = 5.0
    # Gimbal limits
    max_yaw_deg: float = 8.0
    max_pitch_deg: float = 5.0


class PodController:
    """
    PID gap-keeping controller for formation mode.
    Controls throttle to maintain target separation.
    """

    def __init__(self, target_gap_m: float, tolerance_m: float = 5.0) -> None:
        self.target_gap = target_gap_m
        self.tolerance  = tolerance_m
        self._kp = 0.015
        self._ki = 0.002
        self._kd = 0.008
        self._integral = 0.0
        self._prev_error = 0.0

    def update(self, current_gap_m: float, dt: float) -> float:
        """Returns throttle command [0, 1]."""
        error = current_gap_m - self.target_gap
        if abs(error) < self.tolerance:
            error = 0.0
        self._integral  = max(-2.0, min(2.0, self._integral + error * dt))
        derivative = (error - self._prev_error) / max(dt, 1e-6)
        self._prev_error = error
        cmd = 0.5 + self._kp * error + self._ki * self._integral + self._kd * derivative
        return max(0.0, min(1.0, cmd))


class TransportPod:
    """
    Single autonomous transport pod.

    Features:
        - 3D motion with thrust vectoring
        - Formation gap-keeping PID
        - Docking state machine
        - Per-pod telemetry
    """

    def __init__(self, cfg: PodConfig) -> None:
        self.cfg    = cfg
        self.state  = PodState.DOCKED
        self.motion = MotionIntegrator3D()
        self._controller    = PodController(cfg.target_gap_m, cfg.gap_tolerance_m)
        self._drag_cfg      = DragConfig(cd=cfg.drag_cd, frontal_area_m2=cfg.frontal_area_m2)
        self._throttle      = 0.0
        self._yaw_deg       = 0.0
        self._pitch_deg     = 0.0
        self._h2_consumed_kg = 0.0
        self._burn_time_s   = 0.0

        # Total mass
        self._total_mass = cfg.mass_kg + cfg.payload_kg

    # ── Commands ──────────────────────────────────────────────────────────────
    def depart(self) -> None:
        if self.state == PodState.DOCKED:
            self.state = PodState.DEPARTING

    def dock(self) -> None:
        self.state = PodState.DOCKED
        self._throttle = 0.0

    def set_throttle(self, throttle: float) -> None:
        self._throttle = max(0.0, min(1.0, throttle))

    def set_vector(self, yaw_deg: float, pitch_deg: float) -> None:
        self._yaw_deg   = max(-self.cfg.max_yaw_deg,   min(self.cfg.max_yaw_deg,   yaw_deg))
        self._pitch_deg = max(-self.cfg.max_pitch_deg, min(self.cfg.max_pitch_deg, pitch_deg))

    def enter_formation(self) -> None:
        if self.state in (PodState.CRUISING, PodState.DEPARTING):
            self.state = PodState.FORMATION

    # ── Step ──────────────────────────────────────────────────────────────────
    def step(
        self,
        dt: float,
        h2_available: float,        # kg available from tank
        h2_rate_at_full: float,     # kg/s at full throttle
        leader_position_m: float | None = None,
        target_speed_ms: float = 80.0,
        ambient_pressure_Pa: float = 101_325.0,
    ) -> dict:
        """
        Advance pod by dt.

        Args:
            dt:               timestep (s)
            h2_available:     remaining H₂ (kg)
            h2_rate_at_full:  max H₂ consumption rate (kg/s)
            leader_position_m: longitudinal position of pod ahead (for formation)
            target_speed_ms:  cruise speed target
            ambient_pressure_Pa: ambient back-pressure

        Returns full pod telemetry dict.
        """
        ms = self.motion.state

        # ── State machine ──
        if self.state == PodState.DOCKED:
            self._throttle = 0.0

        elif self.state == PodState.DEPARTING:
            self._throttle = min(1.0, self._throttle + 0.3 * dt)
            if ms.vx_ms > target_speed_ms * 0.5:
                self.state = PodState.CRUISING

        elif self.state == PodState.CRUISING:
            # Simple P-controller for speed
            error = target_speed_ms - ms.vx_ms
            self._throttle = max(0.05, min(1.0, 0.5 + 0.04 * error))
            if h2_available < 1.0:
                self.state = PodState.BRAKING

        elif self.state == PodState.FORMATION:
            if leader_position_m is not None:
                gap = leader_position_m - ms.x_m
                self._throttle = self._controller.update(gap, dt)
            else:
                self.state = PodState.CRUISING

        elif self.state == PodState.BRAKING:
            self._throttle = max(0.0, self._throttle - 0.5 * dt)
            if ms.vx_ms < 0.5:
                self.state = PodState.ARRIVED

        elif self.state == PodState.ARRIVED:
            self._throttle = 0.0

        # ── Thrust vector ──
        design_thrust = self.cfg.n_thrusters * self.cfg.thrust_per_unit_N
        magnitude     = design_thrust * self._throttle

        thrust = ThrustVector(
            axial_N  =magnitude * math.cos(math.radians(self._pitch_deg))
                                 * math.cos(math.radians(self._yaw_deg)),
            lateral_N=magnitude * math.cos(math.radians(self._pitch_deg))
                                 * math.sin(math.radians(self._yaw_deg)),
            normal_N =magnitude * math.sin(math.radians(self._pitch_deg)),
        )

        # ── Drag ──
        drag_x = aerodynamic_drag(ms.vx_ms, self._drag_cfg)
        drag_y = aerodynamic_drag(abs(ms.vy_ms), self._drag_cfg) * 0.3

        # ── H₂ consumption ──
        h2_demand = h2_rate_at_full * self._throttle
        h2_actual = min(h2_demand, h2_available / dt)
        if h2_demand > 1e-9:
            supply_frac = h2_actual / h2_demand
            thrust.axial_N   *= supply_frac
            thrust.lateral_N *= supply_frac
            thrust.normal_N  *= supply_frac
        self._h2_consumed_kg += h2_actual * dt

        # ── Motion integration ──
        motion_state = self.motion.step(
            dt=dt,
            thrust=thrust,
            drag_x_N=drag_x,
            drag_y_N=drag_y,
            mass_kg=self._total_mass,
        )

        # ── Burn tracking ──
        if self._throttle > 0.01:
            self._burn_time_s += dt

        return {
            "pod_id":           self.cfg.pod_id,
            "state":            self.state.name,
            "throttle":         self._throttle,
            "thrust_N":         thrust.magnitude_N,
            "vx_ms":            motion_state.vx_ms,
            "vy_ms":            motion_state.vy_ms,
            "speed_kmh":        motion_state.vx_ms * 3.6,
            "x_m":              motion_state.x_m,
            "y_m":              motion_state.y_m,
            "distance_km":      motion_state.distance_total_m / 1000.0,
            "h2_consumed_kg":   self._h2_consumed_kg,
            "h2_flow_kgs":      h2_actual,
            "burn_time_s":      self._burn_time_s,
            "yaw_deg":          self._yaw_deg,
            "pitch_deg":        self._pitch_deg,
            "drag_N":           drag_x,
        }


class PodFormation:
    """
    Manages a convoy of TransportPods.
    Leader-follower formation with gap control.
    """

    def __init__(self, pods: list[TransportPod]) -> None:
        self.pods = pods
        self._formation_active = False

    @classmethod
    def create_convoy(
        cls,
        n_pods: int,
        gap_m: float = 50.0,
        mass_kg: float = 8_000.0,
        payload_kg: float = 2_000.0,
        n_thrusters: int = 4,
        thrust_N: float = 5_000.0,
    ) -> "PodFormation":
        pods = [
            TransportPod(PodConfig(
                pod_id=f"POD-{i+1:02d}",
                mass_kg=mass_kg,
                payload_kg=payload_kg,
                n_thrusters=n_thrusters,
                thrust_per_unit_N=thrust_N,
                target_gap_m=gap_m,
            ))
            for i in range(n_pods)
        ]
        return cls(pods)

    def depart_all(self) -> None:
        for p in self.pods:
            p.depart()

    def enter_formation_all(self) -> None:
        self._formation_active = True
        for p in self.pods[1:]:   # leader stays in CRUISING
            p.enter_formation()

    def step(
        self,
        dt: float,
        h2_available_per_pod: list[float],
        h2_rate_per_pod: list[float],
        target_speed_ms: float = 80.0,
    ) -> dict:
        """
        Advance all pods. Leader is index 0; followers track leader.
        """
        results = []
        for i, pod in enumerate(self.pods):
            leader_pos = (self.pods[i-1].motion.state.x_m
                          if i > 0 and self._formation_active else None)
            r = pod.step(
                dt=dt,
                h2_available=h2_available_per_pod[i],
                h2_rate_at_full=h2_rate_per_pod[i],
                leader_position_m=leader_pos,
                target_speed_ms=target_speed_ms,
            )
            results.append(r)

        total_thrust   = sum(r["thrust_N"]        for r in results)
        total_h2       = sum(r["h2_flow_kgs"]     for r in results)
        avg_speed      = sum(r["speed_kmh"]        for r in results) / len(results)
        lead_x         = results[0]["x_m"]
        tail_x         = results[-1]["x_m"]
        convoy_length  = abs(lead_x - tail_x)

        # Gap quality (mean absolute gap error)
        gap_errors = []
        for i in range(1, len(self.pods)):
            actual_gap = self.pods[i-1].motion.state.x_m - self.pods[i].motion.state.x_m
            gap_errors.append(abs(actual_gap - self.pods[i].cfg.target_gap_m))
        mean_gap_err = sum(gap_errors) / max(1, len(gap_errors))

        return {
            "total_thrust_N":        total_thrust,
            "total_h2_flow_kgs":     total_h2,
            "avg_speed_kmh":         avg_speed,
            "convoy_length_m":       convoy_length,
            "mean_gap_error_m":      mean_gap_err,
            "formation_active":      self._formation_active,
            "n_pods":                len(self.pods),
            "pod_results":           results,
        }
