"""
AUREOM — Core Simulation Engine
Deterministic timestep loop integrating all subsystems.
"""
from __future__ import annotations
import time
from dataclasses import dataclass, field
from typing import Callable

from hydrogen.storage import HydrogenStorageArray, HydrogenTank, TankConfig, StorageMode
from hydrogen.flow_control import FlowController, FlowLineConfig
from propulsion.thruster_model import ThrusterArray, ThrusterConfig
from propulsion.combustion import CombustionConfig
from propulsion.nozzle import NozzleModel, NozzleConfig
from thermal.heat_model import ThermalModel, ThermalConfig
from vehicles.car_dynamics import VehicleSpec, VehicleDynamics
from vehicles.train_dynamics import TrainDynamics, TrainConfig
from control.thrust_controller import ThrustController, ControllerConfig, ControlMode, AdaptiveOptimizer
from financials.cost_model import CostModel, FinancialConfig
from utils.logger import TelemetryLog, TelemetryFrame, get_logger
from utils.constants import DEFAULT_DT, P_ATM, GRAVITY

logger = get_logger("SimEngine")


@dataclass
class SimulationConfig:
    vehicle_type: str = "train"          # "car" | "train" | "pod"
    thruster_units: int = 48
    hydrogen_storage_kg: float = 5000.0
    thrust_per_unit_N: float = 12_000.0
    route_length_km: float = 200.0
    payload_tons: float = 800.0
    simulation_time_hours: float = 3.0
    dt: float = DEFAULT_DT
    # storage
    storage_mode: str = "compressed"     # "compressed" | "cryogenic"
    n_tanks: int = 4
    # control
    target_speed_kmh: float = 300.0
    control_mode: str = "cruise"
    # financial
    h2_price_per_kg: float = 6.0
    # AI optimizer
    use_optimizer: bool = True
    # callbacks
    on_step: Callable | None = None


class SimulationEngine:
    """
    Top-level orchestrator.
    Architecture:
        - Vehicle thrust uses design-spec values (scaled by throttle + flow availability)
          so the vehicle moves correctly regardless of nozzle warm-up state.
        - Nozzle/combustion physics runs in parallel to provide realistic
          display metrics (Isp, chamber temp, exhaust velocity, etc.)
        - H₂ consumption is mission-budgeted so the tank endures the full route.
    """

    def __init__(self, cfg: SimulationConfig) -> None:
        self.cfg = cfg
        self.telemetry = TelemetryLog()
        self._t: float = 0.0
        self._running: bool = False
        self._build_subsystems()

    # ── Build ─────────────────────────────────────────────────────────────────
    def _build_subsystems(self) -> None:
        cfg = self.cfg

        # ── H₂ storage array ──
        tank_capacity = cfg.hydrogen_storage_kg / cfg.n_tanks
        mode = StorageMode.CRYOGENIC if cfg.storage_mode == "cryogenic" else StorageMode.COMPRESSED
        self.storage = HydrogenStorageArray([
            HydrogenTank(TankConfig(capacity_kg=tank_capacity, mode=mode))
            for _ in range(cfg.n_tanks)
        ])

        # ── Flow controller ──
        self.flow_ctrl = FlowController(FlowLineConfig(
            max_flow_kgs=cfg.thruster_units * 2.0,
            regulator_setpoint_Pa=6.0e6,
        ))

        # ── Thruster array (physics display) ──
        self.thrusters = ThrusterArray.create(
            n_units=cfg.thruster_units,
            design_thrust_N=cfg.thrust_per_unit_N,
        )
        self.thrusters.ignite_all()
        self.thrusters.set_throttle_all(0.8)

        # ── Standalone nozzle for display metrics ──
        self._nozzle = NozzleModel(NozzleConfig(expansion_ratio=8.0))

        # ── Thermal ──
        self.thermal = ThermalModel(ThermalConfig(
            wall_mass_kg=4.5 * cfg.thruster_units,
            nozzle_mass_kg=2.2 * cfg.thruster_units,
        ))

        # ── Vehicle ──
        if cfg.vehicle_type == "car":
            spec = VehicleSpec.car(mass_kg=1800, payload_kg=cfg.payload_tons * 1000)
            self.vehicle = VehicleDynamics(spec)
            self._is_train = False
        elif cfg.vehicle_type == "train":
            n_car = max(1, cfg.thruster_units // 6)
            train_cfg = TrainConfig(
                n_carriages=n_car,
                carriage_mass_kg=60_000,
                payload_tons=cfg.payload_tons,
                thrusters_per_carriage=6,
                route_length_km=cfg.route_length_km,
                max_speed_kmh=cfg.target_speed_kmh,
                station_spacing_km=min(50.0, cfg.route_length_km / 4),
            )
            self.vehicle = TrainDynamics(train_cfg)
            self._is_train = True
        else:
            self.vehicle = VehicleDynamics(VehicleSpec.pod())
            self._is_train = False

        # ── Vehicle mass for dynamics ──
        self._veh_mass = (
            self.vehicle.dynamics.spec.total_mass_kg if self._is_train
            else self.vehicle.spec.total_mass_kg
        )

        # ── H₂ budget per step ──
        # Total H₂ spread evenly over sim duration at 65% mean throttle.
        sim_s = cfg.simulation_time_hours * 3600.0
        self._h2_rate_at_full: float = cfg.hydrogen_storage_kg / (sim_s * 0.65)
        # Cap: no more than 2 kg/s total regardless of config
        self._h2_rate_at_full = min(self._h2_rate_at_full, 2.0)

        # ── PID controller ──
        ctrl_mode_map = {
            "cruise": ControlMode.CRUISE,
            "performance": ControlMode.PERFORMANCE,
            "efficiency": ControlMode.EFFICIENCY,
        }
        self.controller = ThrustController(ControllerConfig(
            mode=ctrl_mode_map.get(cfg.control_mode, ControlMode.CRUISE),
            target_velocity_ms=cfg.target_speed_kmh / 3.6,
            target_throttle=0.75,
            kp=0.04, ki=0.006, kd=0.012,
            max_throttle_rate=0.25,
        ))

        # ── Optimizer & Financials ──
        self.optimizer = AdaptiveOptimizer() if cfg.use_optimizer else None
        self.financials = CostModel(FinancialConfig(
            n_thruster_units=cfg.thruster_units,
            h2_price_per_kg=cfg.h2_price_per_kg,
        ))

        # ── Running nozzle display metrics ──
        self._display_chamber_P: float = 101_325.0
        self._display_chamber_T: float = 293.15
        self._display_Ve:        float = 0.0
        self._display_isp:       float = 0.0
        self._display_eta_c:     float = 0.0

    # ── Single timestep ───────────────────────────────────────────────────────
    def step(self) -> TelemetryFrame:
        dt  = self.cfg.dt
        t   = self._t

        # ── 1. Vehicle state ──
        if self._is_train:
            v   = self.vehicle.dynamics.state.velocity_ms
            pos = self.vehicle.dynamics.state.position_m
            at_station = self.vehicle._phase in ("dwell", "pre_departure")
        else:
            v   = self.vehicle.state.velocity_ms
            pos = self.vehicle.state.position_m
            at_station = False

        # ── 2. Fuel remaining ──
        total_cap = sum(tk.cfg.capacity_kg for tk in self.storage.tanks)
        fill_pct  = self.storage.total_mass_kg / max(1e-9, total_cap) * 100.0

        # ── 3. Controller → throttle ──
        if at_station:
            throttle = 0.0
            ctrl     = {"throttle": 0.0, "mode": "DWELL"}
        else:
            ctrl = self.controller.update(
                dt=dt,
                current_velocity_ms=v,
                current_isp_s=max(1.0, self._display_isp),
                fuel_remaining_pct=fill_pct,
                thermal_fault=(self.thermal.chamber_wall_temp_K > 1550),
                pressure_fault=False,
            )
            throttle = ctrl["throttle"]

        # ── 4. Design-spec thrust (drives vehicle motion) ──
        # Thrust scales with throttle and tank pressure availability.
        pressure_fraction = min(1.0, self.storage.mean_pressure_Pa / 5e6) if \
                            self.storage.mean_pressure_Pa > 1e5 else 0.0
        design_thrust_total = (
            self.cfg.thrust_per_unit_N * self.cfg.thruster_units
            * throttle
            * pressure_fraction
        )

        # ── 5. H₂ demand & storage ──
        # Consumption is proportional to thrust (energy budget)
        h2_demanded = self._h2_rate_at_full * throttle
        stor_result = self.storage.step(dt, h2_demanded)
        actual_h2   = stor_result["actual_flow_kgs"]

        # If storage is starving, derate thrust proportionally
        if h2_demanded > 1e-9:
            supply_fraction = min(1.0, actual_h2 / h2_demanded)
        else:
            supply_fraction = 0.0
        design_thrust_total *= supply_fraction

        # ── 6. Flow controller (feed line simulation) ──
        flow_result    = self.flow_ctrl.step(
            dt,
            upstream_pressure_Pa=stor_result["pressure_Pa"],
            upstream_temp_K=280.0,
            demanded_flow_kgs=actual_h2,
        )
        delivered_flow = flow_result["delivered_flow_kgs"]

        # ── 7. Nozzle / combustion display physics ──
        # Run at representative operating point (not used for motion)
        if throttle > 0.02:
            chamber_P = max(5e5, min(8e6,
                throttle * pressure_fraction * 6e6))
            chamber_T = 293.15 + throttle * 2500.0
            nz = self._nozzle.compute(
                chamber_pressure_Pa=chamber_P,
                chamber_temp_K=chamber_T,
                mass_flow_kgs=actual_h2,
                ambient_pressure_Pa=P_ATM,
            )
            self._display_chamber_P = chamber_P
            self._display_chamber_T = chamber_T
            self._display_Ve        = nz["exhaust_velocity_ms"]
            self._display_isp       = nz["isp_s"]
            self._display_eta_c     = min(0.98, 0.60 + throttle * 0.38)
        else:
            # Cool-down when not burning
            self._display_chamber_P = max(1e5, self._display_chamber_P * 0.92)
            self._display_chamber_T = max(293.15,
                self._display_chamber_T * 0.97 + 293.15 * 0.03)
            self._display_Ve   = 0.0
            self._display_isp  = 0.0
            self._display_eta_c = 0.0

        # ── 8. Thermal model ──
        therm = self.thermal.step(
            dt=dt,
            hot_gas_temp_K=self._display_chamber_T,
            mass_flow_kgs=actual_h2,
            chamber_pressure_Pa=self._display_chamber_P,
            is_burning=(throttle > 0.02),
        )
        # Efficiency penalty from overtemp
        thermal_penalty = therm["efficiency_penalty"]

        # ── 9. Net thrust to vehicle ──
        net_thrust = design_thrust_total * (1.0 - thermal_penalty)

        # ── 10. Vehicle dynamics ──
        if self._is_train:
            dyn = self.vehicle.step(dt, net_thrust)
            route_complete = dyn.get("route_complete", False)
        else:
            dyn = self.vehicle.step(dt, net_thrust)
            route_complete = pos >= self.cfg.route_length_km * 1000.0

        # ── 11. Optimizer ──
        if self.optimizer and pos > 100:
            consumed = max(0.001, self.cfg.hydrogen_storage_kg - self.storage.total_mass_kg)
            score = (pos / 1000.0) / consumed
            self.optimizer.step(score, 8.0)

        # ── 12. Financials ──
        dx  = abs(dyn["velocity_ms"] * dt)
        fin = self.financials.step(dt, actual_h2, dx, self.cfg.thruster_units)

        # ── 13. Assemble telemetry frame ──
        frame = TelemetryFrame(
            t=t,
            thrust_total_N=net_thrust,
            thrust_per_unit_N=net_thrust / max(1, self.cfg.thruster_units),
            mass_flow_total_kgs=actual_h2,
            exhaust_velocity_ms=self._display_Ve,
            chamber_pressure_Pa=self._display_chamber_P,
            nozzle_expansion_ratio=8.0,
            combustion_efficiency=self._display_eta_c,
            nozzle_efficiency=0.94,
            isp_s=self._display_isp,
            engine_state=("STEADY" if throttle > 0.05 else "IDLE"),
            throttle=throttle,
            h2_stored_kg=self.storage.total_mass_kg,
            h2_pressure_Pa=stor_result["pressure_Pa"],
            h2_flow_rate_kgs=actual_h2,
            h2_leakage_kgs=stor_result.get("leaked_kg", 0.0),
            fuel_remaining_pct=fill_pct,
            velocity_ms=dyn["velocity_ms"],
            velocity_kmh=dyn["velocity_kmh"],
            position_m=dyn["position_m"],
            acceleration_ms2=dyn["acceleration_ms2"],
            drag_force_N=dyn["drag_force_N"],
            friction_force_N=dyn["rolling_resistance_N"],
            chamber_temp_K=self._display_chamber_T,
            nozzle_temp_K=therm["nozzle_temp_K"],
            coolant_temp_K=therm["coolant_outlet_temp_K"],
            structural_fatigue_pct=therm["fatigue_pct"],
            h2_consumed_kg=fin["h2_consumed_kg"],
            cost_so_far_usd=fin["total_opex_usd"],
            cost_per_km_usd=fin["cost_per_km_usd"],
            control_mode=ctrl["mode"],
            efficiency_score=(pos / 1000.0) / max(0.001, fin["h2_consumed_kg"]),
        )

        self.telemetry.record(frame)
        self._t += dt

        if self.cfg.on_step:
            self.cfg.on_step(frame)

        return frame

    # ── Full autonomous run ───────────────────────────────────────────────────
    def run(self) -> dict:
        max_t = self.cfg.simulation_time_hours * 3600.0
        self._running = True
        t_wall_start = time.time()

        logger.info(
            "AUREOM START — vehicle=%s  units=%d  H₂=%.0f kg  route=%.0f km",
            self.cfg.vehicle_type, self.cfg.thruster_units,
            self.cfg.hydrogen_storage_kg, self.cfg.route_length_km,
        )

        while self._running and self._t < max_t:
            frame = self.step()

            if self.storage.total_mass_kg < 0.5:
                logger.warning("Fuel exhausted at t=%.1f s", self._t)
                break

            if self._is_train and self.vehicle._route_complete:
                logger.info("Route complete (flag) at t=%.1f s  dist=%.1f km",
                            self._t, frame.position_m / 1000)
                break

            if not self._is_train and frame.position_m >= self.cfg.route_length_km * 1000.0:
                logger.info("Route complete (pos) at t=%.1f s  dist=%.1f km",
                            self._t, frame.position_m / 1000)
                break

        elapsed_wall = time.time() - t_wall_start
        summary = self.telemetry.summary()
        summary["wall_time_s"] = elapsed_wall
        summary["sim_time_s"]  = self._t

        logger.info(
            "AUREOM END — %.1f km  avg_isp=%.0f s  cost=%.2f USD/km",
            summary.get("distance_km", 0),
            summary.get("avg_isp_s", 0),
            (summary.get("total_cost_usd", 0) /
             max(1.0, summary.get("distance_km", 1))),
        )
        return summary

    def stop(self) -> None:
        self._running = False
        self.thrusters.shutdown_all()
