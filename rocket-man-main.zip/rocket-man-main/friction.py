"""
AUREOM — Friction Models
Standalone module for wheel-rail, tyre-road, and bearing friction.
Separated from drag.py so each can be composed independently.

Models:
    RollingFriction     — Davis / AREMA rail rolling resistance
    TyreFriction        — Pacejka magic-formula approximation (road)
    BearingFriction     — axle bearing losses
    WheelSlip           — creep-force / slip curve (Kalker linearised)
    BrakeModel          — disc / regenerative braking
"""
from __future__ import annotations
import math
from dataclasses import dataclass
from utils.constants import GRAVITY


# ══════════════════════════════════════════════════════════════════════════════
#  ROLLING FRICTION (rail / road)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class RollingConfig:
    mass_kg: float
    crr_static: float         # coefficient of rolling resistance at v=0
    crr_speed_coeff: float    # speed-dependent term  (Crr = crr_static + k·v)
    crr_temp_coeff: float = 0.0  # temperature dependence (cold = higher Crr)
    reference_temp_K: float = 293.15


def rolling_resistance_N(
    velocity_ms: float,
    cfg: RollingConfig,
    temperature_K: float = 293.15,
) -> float:
    """
    Davis-modified rolling resistance.
        F_rr = m·g·(Crr + k·v)·temp_factor
    """
    crr = cfg.crr_static + cfg.crr_speed_coeff * velocity_ms
    temp_factor = 1.0 + cfg.crr_temp_coeff * max(0.0, cfg.reference_temp_K - temperature_K)
    return cfg.mass_kg * GRAVITY * crr * temp_factor


# ══════════════════════════════════════════════════════════════════════════════
#  TYRE FRICTION (Pacejka approximation)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class TyreConfig:
    mass_on_axle_kg: float
    peak_mu: float = 0.85          # peak friction coefficient
    slip_at_peak: float = 0.12     # longitudinal slip ratio at peak
    shape_factor: float = 1.65     # Pacejka B parameter proxy
    stiffness_factor: float = 10.0 # Pacejka C×B


def tyre_force_N(slip_ratio: float, cfg: TyreConfig) -> float:
    """
    Simplified Pacejka 'Magic Formula' longitudinal force.
        F = Fz · D · sin(C · arctan(B·κ − E·(B·κ − arctan(B·κ))))
    Approximated as:  F = Fz · μ_peak · tanh(κ / κ_peak · shape)
    """
    if abs(slip_ratio) < 1e-6:
        return 0.0
    Fz     = cfg.mass_on_axle_kg * GRAVITY
    x      = slip_ratio / cfg.slip_at_peak * cfg.shape_factor
    F      = Fz * cfg.peak_mu * math.tanh(x)
    return F


def tyre_mu_at_slip(slip_ratio: float, cfg: TyreConfig) -> float:
    Fz = cfg.mass_on_axle_kg * GRAVITY
    return tyre_force_N(slip_ratio, cfg) / max(1.0, Fz)


def max_traction_N(cfg: TyreConfig) -> float:
    """Maximum tractive force at optimal slip."""
    return cfg.mass_on_axle_kg * GRAVITY * cfg.peak_mu


# ══════════════════════════════════════════════════════════════════════════════
#  BEARING FRICTION
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class BearingConfig:
    n_axles: int = 4
    bearing_mu: float = 0.001      # sealed roller bearing
    axle_radius_m: float = 0.08
    mass_kg: float = 60_000.0


def bearing_friction_N(velocity_ms: float, cfg: BearingConfig) -> float:
    """
    Bearing drag: F = μ_b · N_axles · m·g·(r_axle / r_wheel)
    """
    wheel_radius = 0.46  # m — standard rail wheel
    return (cfg.bearing_mu * cfg.n_axles * cfg.mass_kg * GRAVITY
            * cfg.axle_radius_m / wheel_radius)


# ══════════════════════════════════════════════════════════════════════════════
#  WHEEL-RAIL CREEP (Kalker linear theory)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class CreepConfig:
    wheel_radius_m:   float = 0.46
    contact_patch_a:  float = 0.007   # semi-axis of contact ellipse (m)
    contact_patch_b:  float = 0.005
    shear_modulus_Pa: float = 80e9    # steel
    kalker_C11:       float = 3.40    # Kalker coefficient for longitudinal creep
    normal_force_N:   float = 80_000.0


def creep_force_N(
    velocity_slip_ms: float,   # relative velocity at contact patch
    forward_velocity_ms: float,
    cfg: CreepConfig,
) -> float:
    """
    Kalker linear creep force for wheel-rail contact.
    Valid for small creep ratios (< ~0.02).
    """
    if forward_velocity_ms < 0.01:
        return 0.0
    creep_ratio = velocity_slip_ms / forward_velocity_ms
    ab = cfg.contact_patch_a * cfg.contact_patch_b
    G  = cfg.shear_modulus_Pa
    F  = -G * ab * cfg.kalker_C11 * creep_ratio
    # Saturate at friction limit
    F_limit = cfg.normal_force_N * 0.30   # μ_rail ≈ 0.30
    return max(-F_limit, min(F_limit, F))


# ══════════════════════════════════════════════════════════════════════════════
#  BRAKE MODEL
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class BrakeConfig:
    mass_kg:           float = 500_000.0
    max_decel_ms2:     float = 1.2         # maximum service deceleration
    emergency_decel:   float = 2.5         # emergency braking
    regen_fraction:    float = 0.35        # fraction of KE recovered
    disc_brake_force_N: float = 600_000.0


class BrakeModel:
    """
    Combined disc + regenerative braking model.
    Tracks energy recovered by regeneration.
    """

    def __init__(self, cfg: BrakeConfig) -> None:
        self.cfg = cfg
        self.energy_recovered_J: float = 0.0

    def apply(
        self,
        velocity_ms: float,
        dt: float,
        target_decel_ms2: float,
        emergency: bool = False,
    ) -> dict:
        """
        Returns:
            brake_force_N, regen_power_W, energy_recovered_J
        """
        max_decel = self.cfg.emergency_decel if emergency else self.cfg.max_decel_ms2
        decel = min(abs(target_decel_ms2), max_decel)
        total_force = self.cfg.mass_kg * decel

        # Regen portion (limited at low speeds)
        regen_eff = min(1.0, velocity_ms / 10.0)  # regen less effective below 10 m/s
        regen_force = total_force * self.cfg.regen_fraction * regen_eff
        disc_force  = total_force - regen_force

        regen_power = regen_force * velocity_ms
        self.energy_recovered_J += regen_power * dt

        return {
            "total_brake_force_N": total_force,
            "disc_brake_force_N":  disc_force,
            "regen_force_N":       regen_force,
            "regen_power_W":       regen_power,
            "energy_recovered_J":  self.energy_recovered_J,
            "decel_ms2":           decel,
        }


# ══════════════════════════════════════════════════════════════════════════════
#  GRADE RESISTANCE
# ══════════════════════════════════════════════════════════════════════════════

def grade_resistance_N(mass_kg: float, grade_pct: float) -> float:
    """
    Resistance force from track grade.
        F = m·g·sin(θ),  θ = atan(grade/100)
    """
    theta = math.atan(grade_pct / 100.0)
    return mass_kg * GRAVITY * math.sin(theta)


def curve_resistance_N(
    mass_kg: float,
    radius_m: float,
    velocity_ms: float,
    wheel_base_m: float = 2.5,
) -> float:
    """
    Curve (centrifugal) resistance: simplified Röckl formula.
    """
    if radius_m <= 0:
        return 0.0
    # Simplified: F ≈ m·g·k/R  where k ≈ 0.65 for rail
    return mass_kg * GRAVITY * 0.65 / max(radius_m, 1.0)


# ══════════════════════════════════════════════════════════════════════════════
#  CONVENIENCE: combined rail resistance
# ══════════════════════════════════════════════════════════════════════════════

def total_rail_resistance_N(
    velocity_ms: float,
    mass_kg: float,
    grade_pct: float = 0.0,
    curve_radius_m: float = 0.0,
    temperature_K: float = 293.15,
) -> dict:
    """
    One-call aggregate for all rail resistance terms.
    Returns dict with individual components + total.
    """
    roll_cfg = RollingConfig(
        mass_kg=mass_kg, crr_static=0.0015, crr_speed_coeff=3e-6)
    bear_cfg = BearingConfig(mass_kg=mass_kg)

    F_roll  = rolling_resistance_N(velocity_ms, roll_cfg, temperature_K)
    F_bear  = bearing_friction_N(velocity_ms, bear_cfg)
    F_grade = grade_resistance_N(mass_kg, grade_pct)
    F_curve = curve_resistance_N(mass_kg, curve_radius_m, velocity_ms) if curve_radius_m > 0 else 0.0

    total = F_roll + F_bear + F_grade + F_curve
    return {
        "rolling_N":  F_roll,
        "bearing_N":  F_bear,
        "grade_N":    F_grade,
        "curve_N":    F_curve,
        "total_N":    total,
    }
