"""
AUREOM HYDRO-THRUSTER PLATFORM
Entry point — run_simulation() API + CLI launcher.
"""
from __future__ import annotations
import argparse
import json
from core.simulation import SimulationEngine, SimulationConfig


def run_simulation(
    vehicle_type: str = "train",
    thruster_units: int = 48,
    hydrogen_storage: float = 5000.0,
    thrust_per_unit: float = 12_000.0,
    route_length_km: float = 200.0,
    payload_tons: float = 800.0,
    simulation_time_hours: float = 3.0,
    target_speed_kmh: float = 300.0,
    control_mode: str = "cruise",
    storage_mode: str = "compressed",
    n_tanks: int = 4,
    h2_price_per_kg: float = 6.0,
    use_optimizer: bool = True,
    save_csv: str | None = None,
) -> dict:
    """
    Public API for AUREOM hydrogen propulsion simulation.

    Example:
        run_simulation(
            vehicle_type="train",
            thruster_units=48,
            hydrogen_storage=5000,
            thrust_per_unit=12000,
            route_length_km=200,
            payload_tons=800,
            simulation_time_hours=3
        )
    """
    cfg = SimulationConfig(
        vehicle_type=vehicle_type,
        thruster_units=thruster_units,
        hydrogen_storage_kg=hydrogen_storage,
        thrust_per_unit_N=thrust_per_unit,
        route_length_km=route_length_km,
        payload_tons=payload_tons,
        simulation_time_hours=simulation_time_hours,
        target_speed_kmh=target_speed_kmh,
        control_mode=control_mode,
        storage_mode=storage_mode,
        n_tanks=n_tanks,
        h2_price_per_kg=h2_price_per_kg,
        use_optimizer=use_optimizer,
    )

    engine = SimulationEngine(cfg)
    summary = engine.run()

    if save_csv:
        engine.telemetry.save_csv(save_csv)
        print(f"Telemetry saved → {save_csv}")

    return summary


def _cli() -> None:
    parser = argparse.ArgumentParser(
        description="AUREOM Hydro-Thruster Platform",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--vehicle", default="train",
                        choices=["car", "train", "pod"])
    parser.add_argument("--units", type=int, default=48)
    parser.add_argument("--h2", type=float, default=5000.0,
                        help="Hydrogen storage (kg)")
    parser.add_argument("--thrust", type=float, default=12000.0,
                        help="Thrust per unit (N)")
    parser.add_argument("--route", type=float, default=200.0,
                        help="Route length (km)")
    parser.add_argument("--payload", type=float, default=800.0,
                        help="Payload (tons)")
    parser.add_argument("--hours", type=float, default=3.0,
                        help="Simulation time (hours)")
    parser.add_argument("--speed", type=float, default=300.0,
                        help="Target speed (km/h)")
    parser.add_argument("--mode", default="cruise",
                        choices=["cruise", "performance", "efficiency"])
    parser.add_argument("--csv", default=None,
                        help="Save telemetry to CSV path")
    parser.add_argument("--gui", action="store_true",
                        help="Launch PyQt6 dashboard")

    args = parser.parse_args()

    if args.gui:
        from gui.dashboard import launch_dashboard
        launch_dashboard()
        return

    summary = run_simulation(
        vehicle_type=args.vehicle,
        thruster_units=args.units,
        hydrogen_storage=args.h2,
        thrust_per_unit=args.thrust,
        route_length_km=args.route,
        payload_tons=args.payload,
        simulation_time_hours=args.hours,
        target_speed_kmh=args.speed,
        control_mode=args.mode,
        save_csv=args.csv,
    )

    print("\n" + "═" * 60)
    print("  AUREOM SIMULATION SUMMARY")
    print("═" * 60)
    for k, v in summary.items():
        if isinstance(v, float):
            print(f"  {k:<35} {v:>12.3f}")
        else:
            print(f"  {k:<35} {v!r}")
    print("═" * 60)


if __name__ == "__main__":
    _cli()
