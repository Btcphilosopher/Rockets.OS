"""
AUREOM — Cooling System
Dedicated module for regenerative, film, and radiation cooling of
thruster components. Designed to be composed with heat_model.py.

Models:
    RegenerativeCoolingLoop  — hydrogen pre-heat cycle (classic regen cooling)
    FilmCoolingLayer         — boundary layer enrichment
    RadiationCooling         — Stefan-Boltzmann outer surface radiation
    CoolingSystem            — aggregate controller managing all modes
"""
from __future__ import annotations
import math
from dataclasses import dataclass
from enum import Enum, auto
from utils.constants import (
    AMBIENT_TEMP, CP_H2, STEFAN_BOLTZMANN, CP_COOLANT,
    COOLANT_FLOW_DEFAULT, CHAMBER_WALL_MAX_TEMP, NOZZLE_THROAT_MAX_TEMP,
)


class CoolingMode(Enum):
    OFF           = auto()
    PASSIVE       = auto()    # radiation only
    REGENERATIVE  = auto()    # H₂ pre-heat loop
    FILM          = auto()    # boundary layer film injection
    COMBINED      = auto()    # regen + film


@dataclass
class RegenerativeCoolingConfig:
    """Regenerative H₂ coolant loop configuration."""
    coolant_flow_kgs:   float = 0.08    # H₂ flow through cooling channels
    inlet_temp_K:       float = 100.0   # cryogenic H₂ inlet (pre-warmed)
    channel_area_m2:    float = 4e-4    # total channel cross-section area
    channel_length_m:   float = 0.35    # channel path length
    n_channels:         int   = 64      # number of parallel channels
    pressure_Pa:        float = 8e6     # coolant channel pressure
    max_outlet_temp_K:  float = 800.0   # max H₂ temperature before cracking


@dataclass
class FilmCoolingConfig:
    """Film cooling injection parameters."""
    injection_fraction: float = 0.05   # fraction of propellant used for film
    injection_area_m2:  float = 2e-5   # total injection port area
    coverage_fraction:  float = 0.70   # fraction of wall covered by film
    film_temp_K:        float = 250.0  # film injection temperature


@dataclass
class RadiationConfig:
    outer_surface_area_m2: float = 0.12
    emissivity:            float = 0.85
    view_factor:           float = 0.90   # fraction of surface radiating to environment


class RegenerativeCoolingLoop:
    """
    Models the regenerative H₂ cooling loop where cryogenic propellant
    absorbs combustion heat before entering the injector.

    Physics:
        Q_absorbed = ṁ_c · Cp_H₂ · (T_outlet − T_inlet)
        T_outlet   = T_inlet + Q_convective / (ṁ_c · Cp_H₂)
    """

    def __init__(self, cfg: RegenerativeCoolingConfig) -> None:
        self.cfg = cfg
        self.outlet_temp_K: float = cfg.inlet_temp_K
        self._total_heat_absorbed_J: float = 0.0
        self._cracking_events: int = 0

    def step(
        self,
        dt: float,
        wall_temp_K: float,
        mass_flow_kgs: float,  # total propellant flow (cooling share derived internally)
    ) -> dict:
        """
        Advance cooling loop by dt.

        Returns:
            Q_removed_W, outlet_temp_K, coolant_flow_kgs, cracking_risk
        """
        mdot_c = min(self.cfg.coolant_flow_kgs, mass_flow_kgs * 0.15)

        # Convective heat transfer: h_eff for channel flow
        velocity = mdot_c / max(1e-9, 0.7 * self.cfg.channel_area_m2)  # 0.7 = density H₂ at 8 MPa ~200 K
        Re = 0.7 * velocity * 0.003 / 8.9e-6   # Re with ~3mm hydraulic diameter
        Re = max(Re, 1.0)
        Nu = 0.023 * Re**0.8 * 0.8**0.4         # Dittus-Boelter (Pr ≈ 0.8 for H₂)
        h  = Nu * 0.18 / 0.003                  # h = Nu · k / D_h, k_H₂ ≈ 0.18 W/m·K

        contact_area = self.cfg.n_channels * self.cfg.channel_length_m * math.pi * 0.003
        Q_max = h * contact_area * (wall_temp_K - self.cfg.inlet_temp_K)
        Q_max = max(0.0, Q_max)

        # Actual heat absorbed limited by coolant capacity
        Q_capacity = mdot_c * CP_H2 * (self.cfg.max_outlet_temp_K - self.cfg.inlet_temp_K)
        Q_removed  = min(Q_max, Q_capacity)

        # Outlet temperature
        if mdot_c > 1e-9:
            self.outlet_temp_K = (self.cfg.inlet_temp_K
                                  + Q_removed / (mdot_c * CP_H2))
        else:
            self.outlet_temp_K = self.cfg.inlet_temp_K

        self._total_heat_absorbed_J += Q_removed * dt

        cracking_risk = self.outlet_temp_K > self.cfg.max_outlet_temp_K
        if cracking_risk:
            self._cracking_events += 1

        return {
            "Q_removed_W":       Q_removed,
            "outlet_temp_K":     self.outlet_temp_K,
            "coolant_flow_kgs":  mdot_c,
            "cracking_risk":     cracking_risk,
            "cracking_events":   self._cracking_events,
            "total_heat_J":      self._total_heat_absorbed_J,
        }


class FilmCoolingLayer:
    """
    Film cooling boundary layer model.
    Reduces effective gas temperature at wall via coolant injection.

    Effectiveness:
        η_film = (T_gas − T_wall) / (T_gas − T_film)
    """

    def __init__(self, cfg: FilmCoolingConfig) -> None:
        self.cfg = cfg
        self._coverage_decay: float = 1.0   # degrades over time

    def effectiveness(self, flow_ratio: float) -> float:
        """
        Film cooling effectiveness as a function of blowing ratio M = ṁ_film/(ρ_gas·v_gas·A).
        Simplified correlation: η = 0.85 · exp(-0.3·M^{-0.8}) for M in [0.5, 3]
        """
        M = max(0.01, flow_ratio)
        eta = 0.85 * math.exp(-0.3 * M ** -0.8)
        return min(0.90, max(0.0, eta)) * self._coverage_decay

    def step(
        self,
        dt: float,
        hot_gas_temp_K: float,
        wall_temp_K: float,
        mass_flow_kgs: float,
    ) -> dict:
        """
        Returns:
            effective_wall_temp_K, Q_reduction_W, coverage, film_flow_kgs
        """
        film_flow = mass_flow_kgs * self.cfg.injection_fraction
        blowing_ratio = film_flow / max(1e-9, mass_flow_kgs)
        eta = self.effectiveness(blowing_ratio)

        # Effective temperature seen by wall surface
        T_eff = hot_gas_temp_K - eta * (hot_gas_temp_K - self.cfg.film_temp_K)
        T_eff = max(self.cfg.film_temp_K, T_eff)

        # Heat reduction vs un-cooled case
        h_ref = 5000.0  # reference h W/m²K
        Q_without = h_ref * 0.05 * (hot_gas_temp_K - wall_temp_K)
        Q_with    = h_ref * 0.05 * (T_eff - wall_temp_K)
        Q_reduction = max(0.0, Q_without - Q_with)

        # Coverage slowly decays with time (deposit / erosion)
        self._coverage_decay = max(0.5, self._coverage_decay - 2e-6 * dt)

        return {
            "effective_wall_temp_K": T_eff,
            "Q_reduction_W":         Q_reduction,
            "eta_film":              eta,
            "film_flow_kgs":         film_flow,
            "coverage_fraction":     self._coverage_decay * self.cfg.coverage_fraction,
        }


class RadiationCooling:
    """Stefan-Boltzmann radiation from outer nozzle and chamber surfaces."""

    def __init__(self, cfg: RadiationConfig) -> None:
        self.cfg = cfg

    def step(self, surface_temp_K: float) -> dict:
        eps  = self.cfg.emissivity
        vf   = self.cfg.view_factor
        area = self.cfg.outer_surface_area_m2
        Q_rad = eps * vf * STEFAN_BOLTZMANN * area * (surface_temp_K**4 - AMBIENT_TEMP**4)
        Q_rad = max(0.0, Q_rad)
        return {
            "Q_radiation_W":   Q_rad,
            "surface_temp_K":  surface_temp_K,
            "emission_density": Q_rad / max(1e-9, area),
        }


class CoolingSystem:
    """
    Aggregate cooling controller.
    Selects and manages regen + film + radiation based on thermal state.
    Auto-switches mode based on wall temperature vs limits.
    """

    def __init__(
        self,
        regen_cfg:  RegenerativeCoolingConfig | None = None,
        film_cfg:   FilmCoolingConfig | None = None,
        rad_cfg:    RadiationConfig | None = None,
    ) -> None:
        self.regen  = RegenerativeCoolingLoop(regen_cfg or RegenerativeCoolingConfig())
        self.film   = FilmCoolingLayer(film_cfg or FilmCoolingConfig())
        self.rad    = RadiationCooling(rad_cfg or RadiationConfig())
        self._mode  = CoolingMode.COMBINED
        self._total_removed_J: float = 0.0

    def set_mode(self, mode: CoolingMode) -> None:
        self._mode = mode

    def step(
        self,
        dt: float,
        chamber_wall_temp_K: float,
        nozzle_temp_K: float,
        mass_flow_kgs: float,
    ) -> dict:
        """
        Compute total heat removal across all active cooling systems.

        Returns:
            Q_total_removed_W, Q_regen_W, Q_film_W, Q_radiation_W,
            regen_outlet_temp_K, film_eta, mode, total_removed_J
        """
        Q_regen = Q_film = Q_rad = 0.0
        regen_outlet = AMBIENT_TEMP
        film_eta     = 0.0
        eff_wall_T   = chamber_wall_temp_K

        # Auto mode escalation
        if chamber_wall_temp_K > CHAMBER_WALL_MAX_TEMP * 0.85:
            self._mode = CoolingMode.COMBINED

        if self._mode in (CoolingMode.REGENERATIVE, CoolingMode.COMBINED):
            r = self.regen.step(dt, chamber_wall_temp_K, mass_flow_kgs)
            Q_regen      = r["Q_removed_W"]
            regen_outlet = r["outlet_temp_K"]

        if self._mode in (CoolingMode.FILM, CoolingMode.COMBINED) and mass_flow_kgs > 0.001:
            f = self.film.step(dt, chamber_wall_temp_K, chamber_wall_temp_K * 0.85, mass_flow_kgs)
            Q_film   = f["Q_reduction_W"]
            film_eta = f["eta_film"]
            eff_wall_T = f["effective_wall_temp_K"]

        if self._mode != CoolingMode.OFF:
            r2 = self.rad.step(nozzle_temp_K)
            Q_rad = r2["Q_radiation_W"]

        Q_total = Q_regen + Q_film + Q_rad
        self._total_removed_J += Q_total * dt

        return {
            "Q_total_removed_W":      Q_total,
            "Q_regen_W":              Q_regen,
            "Q_film_W":               Q_film,
            "Q_radiation_W":          Q_rad,
            "regen_outlet_temp_K":    regen_outlet,
            "film_effectiveness":     film_eta,
            "effective_wall_temp_K":  eff_wall_T,
            "mode":                   self._mode.name,
            "total_removed_J":        self._total_removed_J,
        }
