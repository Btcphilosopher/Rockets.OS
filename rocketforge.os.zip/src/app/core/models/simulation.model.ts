
export type SimulationStage = 
  | 'PAD_COUNTDOWN'
  | 'LIFTOFF'
  | 'MAX_Q'
  | 'MECO'
  | 'STAGE_SEPARATION'
  | 'STAGE2_IGNITION'
  | 'FAIRING_JETTISON'
  | 'BOOSTBACK_BURN'
  | 'ENTRY_BURN'
  | 'SECO_ORBIT_INSERTION'
  | 'LANDING_BURN'
  | 'TOUCHDOWN'
  | 'MISSION_COMPLETE'
  | 'MISSION_ABORT';

export interface TelemetryFrame {
  timeS: number;
  stage: SimulationStage;
  altitudeM: number;
  downrangeKm: number;
  velocityMs: number;
  accelerationG: number;
  dynamicPressureKPa: number;
  machNumber: number;
  pitchAngleDeg: number;
  flightPathAngleDeg: number;
  totalMassKg: number;
  stage1PropellantRemainingKg: number;
  stage2PropellantRemainingKg: number;
  stage1ThrustKn: number;
  stage2ThrustKn: number;
  chamberPressureBar: number;
  turbopumpRpm: number;
  engineTemperatureK: number;
  skinTemperatureK: number;
  structuralStressMpa: number;
  safetyFactor: number;
  vibrationGrms: number;
  batteryVoltageV: number;
  telemetryLinkDbm: number;
  gimbalPitchDeg: number;
  gimbalYawDeg: number;
}

export interface TrajectorySummary {
  maxAltitudeM: number;
  maxVelocityMs: number;
  maxAccelerationG: number;
  maxDynamicPressureKPa: number;
  maxQTimeS: number;
  mecoTimeS: number;
  secoTimeS: number;
  finalOrbitPerigeeKm: number;
  finalOrbitApogeeKm: number;
  finalOrbitInclinationDeg: number;
  insertionVelocityMs: number;
  missionSuccess: boolean;
  totalBurnTimeS: number;
  frames: TelemetryFrame[];
}

export type ManufacturingStepId = 
  | 'RAW_MATERIAL_INTAKE'
  | 'MATERIAL_SPEC_SPECTROMETRY'
  | 'CNC_CYLINDER_FORMING'
  | 'FRICTION_STIR_WELDING'
  | 'HEAT_TREATMENT_AGING'
  | 'SURFACE_ANODIZATION'
  | 'NDT_PHASED_ARRAY_SCAN'
  | 'TANK_HYDROSTATIC_PROOF'
  | 'OCTAWEB_POWERPACK_MOUNT'
  | 'AVIONICS_HARNESS_DOCKING'
  | 'STAGE_INTEGRATION_STACKING'
  | 'FINAL_SYSTEM_CHECKOUT';

export interface ManufacturingProcessStep {
  id: ManufacturingStepId;
  name: string;
  stationName: string;
  department: 'MATERIALS' | 'MACHINING' | 'WELDING' | 'INSPECTION' | 'INTEGRATION' | 'TEST';
  order: number;
  estimatedDurationHours: number;
  standardCostUsd: number;
  equipmentRequired: string;
  operatorRole: string;
  defectProbability: number;
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'HOLD' | 'REWORK_REQUIRED';
  progressPercent: number;
  qualityGatePassed: boolean;
  activeCycleTimeMinutes: number;
  kpiMetrics: {
    energyKwh: number;
    weldPorosityPct?: number;
    dimensionalDeviationMm?: number;
    operatorCertLevel: string;
  };
}

export interface FactoryWorkstation {
  id: string;
  name: string;
  zone: string;
  type: 'FSW_GANTRY' | 'CNC_MILL' | 'NDT_ROBOT' | 'HYDRO_CELL' | 'CLEANROOM_BAY' | 'AUTONOMOUS_AGV' | 'OVERHEAD_CRANE';
  status: 'OPERATING' | 'IDLE' | 'CALIBRATING' | 'MAINTENANCE' | 'BLOCKED';
  efficiencyPercent: number;
  temperatureC: number;
  vibrationMmS: number;
  powerDrawKw: number;
  currentPartId: string | null;
  position: { x: number; y: number; z: number };
}

export interface FactoryKpis {
  stage1CycleTimeDays: number;
  annualThroughputUnits: number;
  overallEquipmentEffectivenessPct: number;
  averageQueueTimeHours: number;
  machineAvailabilityPct: number;
  firstPassYieldPct: number;
  scrapAndReworkRatePct: number;
  materialEfficiencyPct: number;
  totalEnergyConsumptionMwh: number;
  estimatedStageManufacturingCostUsd: number;
}

export type FaultId = 
  | 'NONE'
  | 'LOX_TURBOPUMP_SEAL_LEAK'
  | 'INJECTOR_EROSION_HOTSPOT'
  | 'GIMBAL_ACTUATOR_HYDRAULIC_STALL'
  | 'AVIONICS_BUS_BROWNOUT'
  | 'TANK_DOME_MICRO_CRACK'
  | 'HIGH_ALTITUDE_WIND_SHEAR'
  | 'SENSOR_DRIFT_IMU_YAW'
  | 'INTERSTAGE_SEP_LATCH_DELAY';

export interface InjectedFault {
  id: FaultId;
  name: string;
  category: 'PROPULSION' | 'STRUCTURES' | 'AVIONICS' | 'MANUFACTURING' | 'ENVIRONMENT';
  severity: 'MODERATE' | 'SEVERE' | 'CATASTROPHIC';
  triggerTimeS: number;
  description: string;
  telemetrySignature: string;
  downstreamEffects: string[];
  investigationGuidance: string[];
  active: boolean;
}

export interface MonteCarloParameterVariations {
  dryMassStdDevPercent: number; // e.g. 2.0%
  propellantMassStdDevPercent: number; // e.g. 0.5%
  engineThrustStdDevPercent: number; // e.g. 1.5%
  engineIspStdDevPercent: number; // e.g. 1.0%
  aerodynamicDragStdDevPercent: number; // e.g. 4.0%
  tankThicknessStdDevMm: number; // e.g. 0.05 mm
  highAltitudeWindGustMs: number; // e.g. 12 m/s
  sensorNoiseG: number;
}

export interface MonteCarloScenarioResult {
  runIndex: number;
  seed: number;
  liftoffMassKg: number;
  maxQ_kPa: number;
  maxStressMpa: number;
  minSafetyFactor: number;
  insertionApogeeKm: number;
  insertionPerigeeKm: number;
  finalDeltaVRemainingMs: number;
  missionSuccess: boolean;
  failureReason?: string;
}

export interface MonteCarloAnalysisResult {
  totalRuns: number;
  successProbabilityPercent: number;
  meanApogeeKm: number;
  stdDevApogeeKm: number;
  meanMaxQ_kPa: number;
  p99MaxQ_kPa: number;
  meanSafetyFactor: number;
  p01MinSafetyFactor: number;
  meanDryMassKg: number;
  runs: MonteCarloScenarioResult[];
}

export interface OptimizationWeights {
  minimizeMassWeight: number; // 0-100
  minimizeCostWeight: number; // 0-100
  minimizeCycleTimeWeight: number; // 0-100
  maximizePayloadWeight: number; // 0-100
  maximizeSafetyMarginWeight: number; // 0-100
  maximizeThroughputWeight: number; // 0-100
}

export interface CandidateDesign {
  id: string;
  designName: string;
  archetype: 'MINIMAL_MASS' | 'BALANCED_PRODUCTION' | 'HIGH_SAFETY_MARGIN' | 'LOW_COST_EXPENDABLE';
  score: number;
  rank: number;
  massSavingsKg: number;
  costDeltaUsd: number;
  manufacturingDays: number;
  payloadCapacityKg: number;
  safetyFactor: number;
  keyChanges: string[];
  tradeOffRationale: string;
  configSnapshot: {
    material: string;
    skinThicknessMm: number;
    engineCount: number;
    propellantMassKg: number;
    diameterM: number;
  };
}
