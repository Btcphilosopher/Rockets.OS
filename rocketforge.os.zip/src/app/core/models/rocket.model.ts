export type DataSource = 'SIMULATED' | 'ESTIMATED' | 'ASSUMED' | 'USER-SUPPLIED' | 'VALIDATED';
export type ModelFidelity = 'LOW' | 'MEDIUM' | 'HIGH';
export type UnitSystem = 'SI' | 'IMPERIAL';

export interface TraceableParameter<T = number> {
  value: T;
  unit: string;
  source: DataSource;
  fidelity: ModelFidelity;
  uncertaintyPercent: number;
  lastUpdated?: string;
  description?: string;
  min?: number;
  max?: number;
}

export type StructuralMaterialId = 'AL_LI_2195' | 'CARBON_COMPOSITE' | 'STAINLESS_301' | 'INCONEL_718' | 'TITANIUM_6AL4V';

export interface MaterialProperties {
  id: StructuralMaterialId;
  name: string;
  density: number; // kg/m3
  yieldStrength: number; // MPa
  ultimateStrength: number; // MPa
  youngsModulus: number; // GPa
  thermalConductivity: number; // W/(m*K)
  maxServiceTemp: number; // K
  costPerKg: number; // USD/kg
  weldability: 'EXCELLENT' | 'GOOD' | 'FAIR' | 'SPECIALIZED';
  machinabilityIndex: number; // 0-1
}

export type PropellantType = 'LOX_RP1' | 'LOX_METHANE' | 'LOX_LH2' | 'N2O4_UDMH';

export interface PropellantProperties {
  type: PropellantType;
  name: string;
  oxidizerName: string;
  fuelName: string;
  oxidizerDensity: number; // kg/m3
  fuelDensity: number; // kg/m3
  nominalMixtureRatio: number; // O/F by mass
  nominalSeaLevelIsp: number; // s
  nominalVacuumIsp: number; // s
  flameTemperature: number; // K
  molecularWeight: number; // g/mol
  gamma: number; // specific heat ratio
}

export interface ComponentInspectionRecord {
  id: string;
  partId: string;
  componentName: string;
  process: string;
  technicianId: string;
  timestamp: string;
  status: 'PASS' | 'FAIL' | 'REWORK' | 'QUARANTINE' | 'PENDING';
  ndtMethod: 'ULTRASONIC' | 'XRAY_RADIOGRAPHY' | 'EDDY_CURRENT' | 'DYE_PENETRANT' | 'CMM_DIMENSIONAL' | 'MASS_SPECTROMETER_LEAK';
  measuredDimensionMm: number;
  nominalDimensionMm: number;
  tolerancePlusMm: number;
  toleranceMinusMm: number;
  flawSeverityScore: number; // 0 = flawless, 100 = critical
  notes: string;
}

export interface RocketSubsystemConfig {
  geometry: {
    totalHeight: TraceableParameter<number>;
    coreDiameter: TraceableParameter<number>;
    fairingDiameter: TraceableParameter<number>;
    fairingHeight: TraceableParameter<number>;
    stage1Height: TraceableParameter<number>;
    interstageHeight: TraceableParameter<number>;
    stage2Height: TraceableParameter<number>;
    finCount: TraceableParameter<number>;
    finSpan: TraceableParameter<number>;
    finRootChord: TraceableParameter<number>;
    finTipChord: TraceableParameter<number>;
    finSweepAngleDeg: TraceableParameter<number>;
    noseConeType: TraceableParameter<'VON_KARMAN' | 'CONICAL' | 'OGIVE' | 'PARABOLIC'>;
    noseConeFineness: TraceableParameter<number>;
  };
  propulsion: {
    propellantType: TraceableParameter<PropellantType>;
    stage1EngineCount: TraceableParameter<number>;
    stage1EngineName: TraceableParameter<string>;
    stage1ThrustSeaLevelKn: TraceableParameter<number>; // per engine
    stage1ThrustVacuumKn: TraceableParameter<number>;
    stage1IspSeaLevelS: TraceableParameter<number>;
    stage1IspVacuumS: TraceableParameter<number>;
    stage1ChamberPressureBar: TraceableParameter<number>;
    stage1ExpansionRatio: TraceableParameter<number>;
    stage1MixtureRatio: TraceableParameter<number>;
    stage1ThrottleMinPercent: TraceableParameter<number>;
    stage1ThrottleMaxPercent: TraceableParameter<number>;
    stage1GimbalRangeDeg: TraceableParameter<number>;
    stage1TotalBurnTimeS: TraceableParameter<number>;
    stage1PropellantMassKg: TraceableParameter<number>;

    stage2EngineCount: TraceableParameter<number>;
    stage2EngineName: TraceableParameter<string>;
    stage2ThrustVacuumKn: TraceableParameter<number>;
    stage2IspVacuumS: TraceableParameter<number>;
    stage2ChamberPressureBar: TraceableParameter<number>;
    stage2ExpansionRatio: TraceableParameter<number>;
    stage2BurnTimeS: TraceableParameter<number>;
    stage2PropellantMassKg: TraceableParameter<number>;
  };
  structures: {
    primaryMaterial: TraceableParameter<StructuralMaterialId>;
    stage1SkinThicknessMm: TraceableParameter<number>;
    stage2SkinThicknessMm: TraceableParameter<number>;
    tankOperatingPressureBar: TraceableParameter<number>;
    designSafetyFactor: TraceableParameter<number>;
    maxAllowableAxialG: TraceableParameter<number>;
    maxAllowableLateralG: TraceableParameter<number>;
    stringerCount: TraceableParameter<number>;
    ringFrameSpacingM: TraceableParameter<number>;
  };
  tanks: {
    stage1LoxVolumeM3: TraceableParameter<number>;
    stage1FuelVolumeM3: TraceableParameter<number>;
    stage2LoxVolumeM3: TraceableParameter<number>;
    stage2FuelVolumeM3: TraceableParameter<number>;
    ullageFractionPercent: TraceableParameter<number>;
    pressurantGas: TraceableParameter<'HELIUM' | 'AUTOGENOUS'>;
    insulationType: TraceableParameter<'SPRAY_ON_FOAM' | 'MLI_BLANKET' | 'NONE'>;
  };
  aerodynamics: {
    dragCoefficientSubsonic: TraceableParameter<number>;
    dragCoefficientTransonic: TraceableParameter<number>;
    dragCoefficientSupersonic: TraceableParameter<number>;
    referenceAreaM2: TraceableParameter<number>;
    centerOfPressureNormalized: TraceableParameter<number>; // 0 to 1 from nose
  };
  thermal: {
    maxSkinTemperatureK: TraceableParameter<number>;
    nozzleThroatHeatFluxMwM2: TraceableParameter<number>;
    avionicsBayMaxTempK: TraceableParameter<number>;
    cryogenicBoiloffRatePercentPerHr: TraceableParameter<number>;
    tpsMaterial: TraceableParameter<'PICA_X' | 'CORK_PHENOLIC' | 'SIRCA' | 'ALUMINA_TILES'>;
  };
  avionics: {
    flightComputerRedundancy: TraceableParameter<number>; // 1 = single, 3 = TMR
    imuSensorCount: TraceableParameter<number>;
    telemetryDataRateKbps: TraceableParameter<number>;
    batteryCapacityKwh: TraceableParameter<number>;
    gnssConstellations: TraceableParameter<string>;
  };
  payload: {
    targetMassKg: TraceableParameter<number>;
    targetOrbitType: TraceableParameter<'LEO' | 'SSO' | 'GTO' | 'MEO'>;
    targetAltitudeKm: TraceableParameter<number>;
    targetInclinationDeg: TraceableParameter<number>;
    fairingJettisonAltitudeKm: TraceableParameter<number>;
  };
  recovery: {
    reusableStage1: TraceableParameter<boolean>;
    landingLegCount: TraceableParameter<number>;
    gridFinCount: TraceableParameter<number>;
    recoveryPropellantReserveKg: TraceableParameter<number>;
    landingSiteType: TraceableParameter<'DRONESHIP' | 'RETURN_TO_LAUNCH_SITE'>;
  };
}

export interface MassPropertiesSummary {
  liftoffMassKg: number;
  dryMassKg: number;
  stage1DryMassKg: number;
  stage1PropellantMassKg: number;
  stage2DryMassKg: number;
  stage2PropellantMassKg: number;
  payloadMassKg: number;
  fairingMassKg: number;
  centerOfGravityFromBaseM: number;
  momentOfInertiaPitchYawKgM2: number;
  momentOfInertiaRollKgM2: number;
  thrustToWeightRatioLiftoff: number;
  stage1DeltaVMs: number;
  stage2DeltaVMs: number;
  totalDeltaVMs: number;
}

export interface DigitalTwinState {
  vehicleId: string;
  vehicleName: string;
  configurationName: string;
  revision: string;
  revisionHistory: {
    revision: string;
    timestamp: string;
    author: string;
    description: string;
    parameterHash: string;
    summaryMetrics: Partial<MassPropertiesSummary>;
  }[];
  manufacturingStatusPercent: number;
  assemblyStatusPercent: number;
  qualityTestStatusPercent: number;
  flightStatus: 'NOT_FLOWN' | 'GROUND_TESTING' | 'FLIGHT_READY' | 'ACTIVE_FLIGHT' | 'POST_FLIGHT_ANALYSIS';
  healthScorePercent: number;
  activeAlerts: {
    id: string;
    severity: 'INFO' | 'WARNING' | 'CRITICAL';
    subsystem: string;
    message: string;
    timestamp: string;
  }[];
}

export interface CanonicalRocket {
  id: string;
  name: string;
  serialNumber: string;
  digitalTwin: DigitalTwinState;
  config: RocketSubsystemConfig;
  calculatedMassProperties: MassPropertiesSummary;
  inspections: ComponentInspectionRecord[];
}
