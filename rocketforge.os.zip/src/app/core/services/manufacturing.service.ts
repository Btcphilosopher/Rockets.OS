import { Injectable, signal, computed, inject } from '@angular/core';
import { 
  ManufacturingProcessStep, 
  FactoryWorkstation, 
  FactoryKpis 
} from '../models/simulation.model';
import { DigitalTwinService } from './digital-twin.service';
import { EventBusService } from './event-bus.service';

@Injectable({
  providedIn: 'root',
})
export class ManufacturingService {
  private readonly digitalTwin = inject(DigitalTwinService);
  private readonly eventBus = inject(EventBusService);

  readonly activeStepIndex = signal<number>(3); // Friction stir welding active by default
  readonly isSimulating = signal<boolean>(false);
  readonly sequenceSpeed = signal<number>(1.0);

  // 12-Step Manufacturing Sequence
  readonly steps = signal<ManufacturingProcessStep[]>([
    {
      id: 'RAW_MATERIAL_INTAKE',
      name: 'Al-Li 2195 Billet Receiving & Spec Verification',
      stationName: 'Intake Bay M-01',
      department: 'MATERIALS',
      order: 1,
      estimatedDurationHours: 18,
      standardCostUsd: 145000,
      equipmentRequired: 'Spectro-Lab Glow Discharge Mass Spec',
      operatorRole: 'Materials Metallurgist Tier 3',
      defectProbability: 0.008,
      status: 'COMPLETED',
      progressPercent: 100,
      qualityGatePassed: true,
      activeCycleTimeMinutes: 1080,
      kpiMetrics: {
        energyKwh: 420,
        dimensionalDeviationMm: 0.02,
        operatorCertLevel: 'ASNT Level III',
      },
    },
    {
      id: 'MATERIAL_SPEC_SPECTROMETRY',
      name: 'Ultrasonic Ingot Internal Void Screening',
      stationName: 'Non-Destructive Test Cell N-02',
      department: 'INSPECTION',
      order: 2,
      estimatedDurationHours: 12,
      standardCostUsd: 85000,
      equipmentRequired: 'Multi-Axis Immersion Ultrasonic Scanner',
      operatorRole: 'NDT Specialist',
      defectProbability: 0.012,
      status: 'COMPLETED',
      progressPercent: 100,
      qualityGatePassed: true,
      activeCycleTimeMinutes: 720,
      kpiMetrics: {
        energyKwh: 280,
        dimensionalDeviationMm: 0.01,
        operatorCertLevel: 'ASNT Level III',
      },
    },
    {
      id: 'CNC_CYLINDER_FORMING',
      name: '3-Roll Cylinder Barrel Section Forming',
      stationName: 'Plate Rolling Machine Bay R-04',
      department: 'MACHINING',
      order: 3,
      estimatedDurationHours: 36,
      standardCostUsd: 220000,
      equipmentRequired: 'Davi 4-Roll CNC Hydraulic Plate Roller',
      operatorRole: 'Senior CNC Machinist',
      defectProbability: 0.022,
      status: 'COMPLETED',
      progressPercent: 100,
      qualityGatePassed: true,
      activeCycleTimeMinutes: 2160,
      kpiMetrics: {
        energyKwh: 1840,
        dimensionalDeviationMm: 0.15,
        operatorCertLevel: 'Master Toolmaker',
      },
    },
    {
      id: 'FRICTION_STIR_WELDING',
      name: 'Robotic Longitudinal & Circumferential FSW',
      stationName: 'Robotic Gantry FSW Cell W-01',
      department: 'WELDING',
      order: 4,
      estimatedDurationHours: 48,
      standardCostUsd: 380000,
      equipmentRequired: 'KUKA Dual-Arm Heavy Gantry FSW Head',
      operatorRole: 'FSW Automation Engineer',
      defectProbability: 0.015,
      status: 'IN_PROGRESS',
      progressPercent: 78,
      qualityGatePassed: true,
      activeCycleTimeMinutes: 2240,
      kpiMetrics: {
        energyKwh: 2450,
        weldPorosityPct: 0.002,
        dimensionalDeviationMm: 0.08,
        operatorCertLevel: 'AWS Certified FSW Tech',
      },
    },
    {
      id: 'HEAT_TREATMENT_AGING',
      name: 'Artificial Aging & Thermal Stress Relief',
      stationName: 'Drop-Bottom Solution Furnace H-03',
      department: 'MATERIALS',
      order: 5,
      estimatedDurationHours: 24,
      standardCostUsd: 110000,
      equipmentRequired: 'Despatch Aerospace High-Uniformity Furnace',
      operatorRole: 'Thermal Processing Lead',
      defectProbability: 0.005,
      status: 'PENDING',
      progressPercent: 0,
      qualityGatePassed: false,
      activeCycleTimeMinutes: 0,
      kpiMetrics: {
        energyKwh: 8600,
        dimensionalDeviationMm: 0.05,
        operatorCertLevel: 'AMS-2750 Thermal Metrology',
      },
    },
    {
      id: 'SURFACE_ANODIZATION',
      name: 'Electrochemical Chromic Acid Anodize & Primer',
      stationName: 'Chemical Tank Processing Line C-02',
      department: 'MATERIALS',
      order: 6,
      estimatedDurationHours: 16,
      standardCostUsd: 95000,
      equipmentRequired: 'Closed-Loop Acid Bath & Automated Hoist',
      operatorRole: 'Chemical Finishing Specialist',
      defectProbability: 0.010,
      status: 'PENDING',
      progressPercent: 0,
      qualityGatePassed: false,
      activeCycleTimeMinutes: 0,
      kpiMetrics: {
        energyKwh: 1200,
        dimensionalDeviationMm: 0.005,
        operatorCertLevel: 'NADCAP Chemical Tech',
      },
    },
    {
      id: 'NDT_PHASED_ARRAY_SCAN',
      name: 'Full Barrel Phased Array Ultrasonic Weld NDT',
      stationName: 'Inspection Enclosure QA-01',
      department: 'INSPECTION',
      order: 7,
      estimatedDurationHours: 20,
      standardCostUsd: 175000,
      equipmentRequired: 'Olympus Omniscan X3 Phased Array Crawler',
      operatorRole: 'Lead Quality Inspector',
      defectProbability: 0.006,
      status: 'PENDING',
      progressPercent: 0,
      qualityGatePassed: false,
      activeCycleTimeMinutes: 0,
      kpiMetrics: {
        energyKwh: 340,
        dimensionalDeviationMm: 0.02,
        operatorCertLevel: 'ASNT Level III',
      },
    },
    {
      id: 'TANK_HYDROSTATIC_PROOF',
      name: 'Cryo-Hydrostatic Proof & Helium Leak Mass Spec',
      stationName: 'Reinforced Hydrostatic Bunker B-01',
      department: 'TEST',
      order: 8,
      estimatedDurationHours: 32,
      standardCostUsd: 290000,
      equipmentRequired: 'High-Pressure Hydro Pump & Mass Spectrometer',
      operatorRole: 'Test Operations Director',
      defectProbability: 0.018,
      status: 'PENDING',
      progressPercent: 0,
      qualityGatePassed: false,
      activeCycleTimeMinutes: 0,
      kpiMetrics: {
        energyKwh: 3100,
        dimensionalDeviationMm: 0.00,
        operatorCertLevel: 'NASA Test Stand Certified',
      },
    },
    {
      id: 'OCTAWEB_POWERPACK_MOUNT',
      name: 'Octaweb Thrust Structure & 9-Engine Integration',
      stationName: 'Engine Integration Clean Bay E-01',
      department: 'INTEGRATION',
      order: 9,
      estimatedDurationHours: 64,
      standardCostUsd: 840000,
      equipmentRequired: 'Automated Hydraulic Engine Lift Fixture',
      operatorRole: 'Propulsion Integration Specialist',
      defectProbability: 0.014,
      status: 'PENDING',
      progressPercent: 0,
      qualityGatePassed: false,
      activeCycleTimeMinutes: 0,
      kpiMetrics: {
        energyKwh: 1540,
        dimensionalDeviationMm: 0.04,
        operatorCertLevel: 'Master Engine Mech',
      },
    },
    {
      id: 'AVIONICS_HARNESS_DOCKING',
      name: 'Triple-Redundant Avionics & Harness Installation',
      stationName: 'Class 10,000 Cleanroom CR-02',
      department: 'INTEGRATION',
      order: 10,
      estimatedDurationHours: 40,
      standardCostUsd: 460000,
      equipmentRequired: 'Automated Wire Harness Continuity Tester',
      operatorRole: 'Aerospace Avionics Engineer',
      defectProbability: 0.009,
      status: 'PENDING',
      progressPercent: 0,
      qualityGatePassed: false,
      activeCycleTimeMinutes: 0,
      kpiMetrics: {
        energyKwh: 880,
        dimensionalDeviationMm: 0.01,
        operatorCertLevel: 'IPC/WHMA-A-620 Lead',
      },
    },
    {
      id: 'STAGE_INTEGRATION_STACKING',
      name: 'Stage 1 to Interstage Vertical Mate & Alignment',
      stationName: 'Vertical Integration Building VIB-01',
      department: 'INTEGRATION',
      order: 11,
      estimatedDurationHours: 50,
      standardCostUsd: 520000,
      equipmentRequired: '150-Ton Overhead Demag Bridge Crane & Laser Tracker',
      operatorRole: 'Chief Stacking Rig Master',
      defectProbability: 0.011,
      status: 'PENDING',
      progressPercent: 0,
      qualityGatePassed: false,
      activeCycleTimeMinutes: 0,
      kpiMetrics: {
        energyKwh: 4200,
        dimensionalDeviationMm: 0.06,
        operatorCertLevel: 'Laser Metrology Master',
      },
    },
    {
      id: 'FINAL_SYSTEM_CHECKOUT',
      name: 'Combined Systems Wet Dress & Gimbal Checkout',
      stationName: 'Factory Checkout Stand ST-01',
      department: 'TEST',
      order: 12,
      estimatedDurationHours: 30,
      standardCostUsd: 310000,
      equipmentRequired: 'Automated Launch Control Checkout Rack',
      operatorRole: 'Vehicle Integration Test Director',
      defectProbability: 0.007,
      status: 'PENDING',
      progressPercent: 0,
      qualityGatePassed: false,
      activeCycleTimeMinutes: 0,
      kpiMetrics: {
        energyKwh: 5600,
        dimensionalDeviationMm: 0.00,
        operatorCertLevel: 'Flight Readiness Board Lead',
      },
    },
  ]);

  // 3D Factory Floor Workstations
  readonly workstations = signal<FactoryWorkstation[]>([
    {
      id: 'WS-01',
      name: 'Friction Stir Welding Gantry W-01',
      zone: 'Heavy Fabrication Bay A',
      type: 'FSW_GANTRY',
      status: 'OPERATING',
      efficiencyPercent: 94.2,
      temperatureC: 22.4,
      vibrationMmS: 0.42,
      powerDrawKw: 74.5,
      currentPartId: 'T-01-LOX-BARREL-03',
      position: { x: -15, y: 0, z: -8 },
    },
    {
      id: 'WS-02',
      name: 'Plate Rolling Forming Cell R-04',
      zone: 'Heavy Fabrication Bay A',
      type: 'CNC_MILL',
      status: 'IDLE',
      efficiencyPercent: 88.5,
      temperatureC: 21.8,
      vibrationMmS: 0.12,
      powerDrawKw: 12.0,
      currentPartId: null,
      position: { x: -28, y: 0, z: -8 },
    },
    {
      id: 'WS-03',
      name: 'Robotic Phased Array Scanner QA-01',
      zone: 'Inspection Cleanroom Bay',
      type: 'NDT_ROBOT',
      status: 'CALIBRATING',
      efficiencyPercent: 97.0,
      temperatureC: 20.0,
      vibrationMmS: 0.02,
      powerDrawKw: 4.8,
      currentPartId: 'E-01-OCTAWEB-MNT',
      position: { x: 0, y: 0, z: -18 },
    },
    {
      id: 'WS-04',
      name: 'High-Pressure Hydro Proof Bunker B-01',
      zone: 'Safety Bunker Zone C',
      type: 'HYDRO_CELL',
      status: 'IDLE',
      efficiencyPercent: 91.0,
      temperatureC: 18.5,
      vibrationMmS: 0.05,
      powerDrawKw: 18.2,
      currentPartId: null,
      position: { x: 22, y: 0, z: -14 },
    },
    {
      id: 'WS-05',
      name: 'Class 10,000 Cleanroom CR-02',
      zone: 'Avionics Docking Hub',
      type: 'CLEANROOM_BAY',
      status: 'OPERATING',
      efficiencyPercent: 99.1,
      temperatureC: 20.1,
      vibrationMmS: 0.01,
      powerDrawKw: 38.6,
      currentPartId: 'AV-01-FC-CORE',
      position: { x: 18, y: 0, z: 8 },
    },
    {
      id: 'WS-06',
      name: 'Overhead 150T Demag Bridge Crane CR-01',
      zone: 'Vertical Stacking High-Bay',
      type: 'OVERHEAD_CRANE',
      status: 'OPERATING',
      efficiencyPercent: 96.5,
      temperatureC: 22.0,
      vibrationMmS: 0.35,
      powerDrawKw: 55.0,
      currentPartId: 'S-01-INTERSTAGE',
      position: { x: 0, y: 12, z: 5 },
    },
    {
      id: 'WS-07',
      name: 'Autonomous Guided Vehicle AGV-04',
      zone: 'Factory Transit Spine',
      type: 'AUTONOMOUS_AGV',
      status: 'OPERATING',
      efficiencyPercent: 95.0,
      temperatureC: 21.0,
      vibrationMmS: 0.20,
      powerDrawKw: 6.2,
      currentPartId: 'T-02-FUEL-DOME',
      position: { x: -8, y: 0, z: 4 },
    },
  ]);

  // Overall Factory KPI Metrics
  readonly factoryKpis = computed<FactoryKpis>(() => {
    const stepsList = this.steps();
    const totalHours = stepsList.reduce((acc, s) => acc + s.estimatedDurationHours, 0);
    const totalCost = stepsList.reduce((acc, s) => acc + s.standardCostUsd, 0);
    const totalEnergy = stepsList.reduce((acc, s) => acc + s.kpiMetrics.energyKwh, 0);

    return {
      stage1CycleTimeDays: Number((totalHours / 24).toFixed(1)),
      annualThroughputUnits: 26, // 26 rockets/year baseline
      overallEquipmentEffectivenessPct: 89.4,
      averageQueueTimeHours: 4.8,
      machineAvailabilityPct: 96.2,
      firstPassYieldPct: 98.2,
      scrapAndReworkRatePct: 1.8,
      materialEfficiencyPct: 94.6,
      totalEnergyConsumptionMwh: Number((totalEnergy / 1000).toFixed(2)),
      estimatedStageManufacturingCostUsd: totalCost,
    };
  });

  readonly isRunning = computed(() => this.isSimulating());
  readonly processGraph = computed(() => this.steps());
  readonly kpis = computed(() => {
    const fk = this.factoryKpis();
    return {
      firstPassYield: fk.firstPassYieldPct / 100,
      totalCycleTimeHours: fk.stage1CycleTimeDays * 24,
      totalVehicleCostUsd: fk.estimatedStageManufacturingCostUsd,
      materialsCostUsd: fk.estimatedStageManufacturingCostUsd * 0.42,
      bottleneckStation: 'WS-01 Friction Stir Welding',
    };
  });

  readonly activeStep = computed(() => {
    const list = this.steps();
    const idx = Math.min(list.length - 1, Math.max(0, this.activeStepIndex()));
    return list[idx];
  });

  selectStep(index: number): void {
    this.activeStepIndex.set(index);
    this.eventBus.emit('MANUFACTURING_STEP_STARTED', { step: this.steps()[index] });
  }

  nextStep(): void {
    if (this.activeStepIndex() < this.steps().length - 1) {
      this.activeStepIndex.update((i) => i + 1);
    }
  }

  previousStep(): void {
    if (this.activeStepIndex() > 0) {
      this.activeStepIndex.update((i) => i - 1);
    }
  }

  stepForward(): void {
    this.nextStep();
  }

  startProduction(): void {
    this.isSimulating.set(true);
  }

  pauseProduction(): void {
    this.isSimulating.set(false);
  }

  resetProduction(): void {
    this.activeStepIndex.set(0);
    this.isSimulating.set(false);
  }

  toggleSimulation(): void {
    this.isSimulating.update((v) => !v);
  }
}
