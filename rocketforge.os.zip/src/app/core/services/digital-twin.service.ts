import { Injectable, signal, computed, inject } from '@angular/core';
import { 
  CanonicalRocket, 
  RocketSubsystemConfig, 
  MassPropertiesSummary, 
  UnitSystem, 
  ComponentInspectionRecord, 
  DigitalTwinState 
} from '../models/rocket.model';
import { EventBusService } from './event-bus.service';
import { MATERIALS_REGISTRY, G0 } from '../physics/constants';
import { PropulsionSolver } from '../physics/propulsion-solver';

@Injectable({
  providedIn: 'root',
})
export class DigitalTwinService {
  private readonly eventBus = inject(EventBusService);

  readonly unitSystem = signal<UnitSystem>('SI');
  readonly selectedPartId = signal<string | null>(null);

  // Authoritative Canonical Rocket Object
  readonly rocket = signal<CanonicalRocket>(this.createDefaultDemoRocket());

  // Unit conversion helpers
  readonly lengthUnit = computed(() => this.unitSystem() === 'SI' ? 'm' : 'ft');
  readonly massUnit = computed(() => this.unitSystem() === 'SI' ? 'kg' : 'lbs');
  readonly forceUnit = computed(() => this.unitSystem() === 'SI' ? 'kN' : 'lbf');
  readonly pressureUnit = computed(() => this.unitSystem() === 'SI' ? 'bar' : 'psi');

  constructor() {
    this.recalculateAllDerivedProperties();
  }

  setUnitSystem(unit: UnitSystem): void {
    this.unitSystem.set(unit);
  }

  selectPart(partId: string | null): void {
    this.selectedPartId.set(partId);
    if (partId) {
      this.eventBus.emit('3D_PART_SELECTED', { partId });
    }
  }

  updateParameter<T>(path: string, newValue: T): void {
    const currentRocket = JSON.parse(JSON.stringify(this.rocket())) as CanonicalRocket;
    const parts = path.split('.');
    
    let target: Record<string, unknown> = currentRocket.config as unknown as Record<string, unknown>;
    for (let i = 0; i < parts.length - 1; i++) {
      target = target[parts[i]] as Record<string, unknown>;
    }
    
    if (target && target[parts[parts.length - 1]]) {
      const field = target[parts[parts.length - 1]] as { value: unknown; source: string; lastUpdated: string };
      field.value = newValue;
      field.source = 'USER-SUPPLIED';
      field.lastUpdated = new Date().toISOString();
    }

    this.rocket.set(currentRocket);
    this.recalculateAllDerivedProperties();
    this.eventBus.emit('VEHICLE_PARAMETER_CHANGED', { path, newValue });
  }

  createRevision(description: string, author = 'Flight Dynamics & Systems Arch'): void {
    const currentRocket = JSON.parse(JSON.stringify(this.rocket())) as CanonicalRocket;
    const revNum = currentRocket.digitalTwin.revisionHistory.length + 1;
    const newRev = `R${revNum.toString().padStart(2, '0')}`;

    currentRocket.digitalTwin.revision = newRev;
    currentRocket.digitalTwin.revisionHistory.unshift({
      revision: newRev,
      timestamp: new Date().toISOString(),
      author,
      description,
      parameterHash: `SHA-${Math.random().toString(36).substring(2, 10).toUpperCase()}`,
      summaryMetrics: { ...currentRocket.calculatedMassProperties },
    });

    this.rocket.set(currentRocket);
    this.eventBus.emit('REVISION_SAVED', { revision: newRev, description });
  }

  recalculateAllDerivedProperties(): void {
    const current = this.rocket();
    const config = current.config;

    const diameter = config.geometry.coreDiameter.value;
    const radius = diameter / 2;
    const totalHeight = config.geometry.totalHeight.value;
    const s1Height = config.geometry.stage1Height.value;
    const s2Height = config.geometry.stage2Height.value;
    const fairingHeight = config.geometry.fairingHeight.value;
    const materialId = config.structures.primaryMaterial.value;
    const material = MATERIALS_REGISTRY[materialId] || MATERIALS_REGISTRY.AL_LI_2195;

    // Structural mass estimation from geometry & skin thickness
    const s1ThicknessM = config.structures.stage1SkinThicknessMm.value / 1000;
    const s2ThicknessM = config.structures.stage2SkinThicknessMm.value / 1000;

    const s1CylinderArea = 2 * Math.PI * radius * s1Height;
    const s2CylinderArea = 2 * Math.PI * radius * s2Height;
    const domeArea = 2 * (2 * Math.PI * Math.pow(radius, 2)); // 2 domes per stage approx

    const s1SkinMass = (s1CylinderArea + domeArea) * s1ThicknessM * material.density;
    const s2SkinMass = (s2CylinderArea + domeArea) * s2ThicknessM * material.density;

    // Internal structural stiffeners, frames, brackets (~35% of skin)
    const s1InternalMass = s1SkinMass * 0.35;
    const s2InternalMass = s2SkinMass * 0.35;

    // Engines mass (~500 kg per sea-level engine, ~750 kg vacuum engine)
    const s1EngineCount = config.propulsion.stage1EngineCount.value;
    const s1EnginesMass = s1EngineCount * 470;
    const s2EngineCount = config.propulsion.stage2EngineCount.value;
    const s2EnginesMass = s2EngineCount * 680;

    // Avionics & recovery mass
    const avionicsMass = 750;
    const landingLegsMass = config.recovery.reusableStage1.value ? (config.recovery.landingLegCount.value * 520) : 0;
    const gridFinsMass = config.recovery.reusableStage1.value ? (config.recovery.gridFinCount.value * 140) : 0;

    const stage1Dry = Math.round(s1SkinMass + s1InternalMass + s1EnginesMass + landingLegsMass + gridFinsMass);
    const stage2Dry = Math.round(s2SkinMass + s2InternalMass + s2EnginesMass + avionicsMass);

    const fairingMass = Math.round(Math.PI * radius * fairingHeight * 0.003 * 1560 * 1.5); // carbon composite fairing
    const payloadMass = config.payload.targetMassKg.value;

    const s1PropMass = config.propulsion.stage1PropellantMassKg.value;
    const s2PropMass = config.propulsion.stage2PropellantMassKg.value;

    const dryMass = stage1Dry + stage2Dry + fairingMass;
    const liftoffMass = dryMass + s1PropMass + s2PropMass + payloadMass;

    // Center of gravity from base
    const cgS1 = s1Height * 0.45;
    const cgS2 = s1Height + config.geometry.interstageHeight.value + s2Height * 0.45;
    const cgPayload = totalHeight - fairingHeight * 0.5;

    const totalMoment = 
      (stage1Dry + s1PropMass) * cgS1 + 
      (stage2Dry + s2PropMass) * cgS2 + 
      (payloadMass + fairingMass) * cgPayload;
    const cgFromBase = totalMoment / Math.max(1, liftoffMass);

    // Thrust to weight ratio
    const s1ThrustSL = config.propulsion.stage1ThrustSeaLevelKn.value * s1EngineCount;
    const twrLiftoff = (s1ThrustSL * 1000) / (liftoffMass * G0);

    // Delta-V calculation via propulsion solver
    const propEval = PropulsionSolver.evaluateSubsystem(config, dryMass, stage1Dry, stage2Dry, payloadMass);

    const massProps: MassPropertiesSummary = {
      liftoffMassKg: Math.round(liftoffMass),
      dryMassKg: Math.round(dryMass),
      stage1DryMassKg: stage1Dry,
      stage1PropellantMassKg: s1PropMass,
      stage2DryMassKg: stage2Dry,
      stage2PropellantMassKg: s2PropMass,
      payloadMassKg: payloadMass,
      fairingMassKg: fairingMass,
      centerOfGravityFromBaseM: Number(cgFromBase.toFixed(2)),
      momentOfInertiaPitchYawKgM2: Math.round(0.0833 * liftoffMass * Math.pow(totalHeight, 2)),
      momentOfInertiaRollKgM2: Math.round(0.5 * liftoffMass * Math.pow(radius, 2)),
      thrustToWeightRatioLiftoff: Number(twrLiftoff.toFixed(2)),
      stage1DeltaVMs: Math.round(propEval.stagedTsiolkovskyDeltaVMs.stage1DeltaV),
      stage2DeltaVMs: Math.round(propEval.stagedTsiolkovskyDeltaVMs.stage2DeltaV),
      totalDeltaVMs: Math.round(propEval.stagedTsiolkovskyDeltaVMs.totalDeltaV),
    };

    const updatedRocket = { ...this.rocket(), calculatedMassProperties: massProps };
    this.rocket.set(updatedRocket);
    this.eventBus.emit('MASS_PROPERTIES_UPDATED', massProps);
  }

  private createDefaultDemoRocket(): CanonicalRocket {
    const defaultInspections: ComponentInspectionRecord[] = [
      {
        id: 'INSP-1049',
        partId: 'T-01-LOX-DOME',
        componentName: 'Stage 1 Forward LOX Bulkhead Dome',
        process: 'Friction Stir Welding Inspection',
        technicianId: 'QA-TECH-882',
        timestamp: '2026-08-28T14:32:00Z',
        status: 'PASS',
        ndtMethod: 'ULTRASONIC',
        nominalDimensionMm: 5500.0,
        measuredDimensionMm: 5500.3,
        tolerancePlusMm: 1.0,
        toleranceMinusMm: 0.5,
        flawSeverityScore: 3,
        notes: 'Full circumferential weld pass verified zero porosity, meeting NASA-STD-5009 standard.',
      },
      {
        id: 'INSP-1050',
        partId: 'E-01-OCTAWEB-MNT',
        componentName: 'Stage 1 Engine Octaweb Thrust Puck',
        process: '5-Axis CNC Milling Metrology',
        technicianId: 'QA-TECH-419',
        timestamp: '2026-08-29T09:15:00Z',
        status: 'PASS',
        ndtMethod: 'CMM_DIMENSIONAL',
        nominalDimensionMm: 1250.0,
        measuredDimensionMm: 1249.95,
        tolerancePlusMm: 0.2,
        toleranceMinusMm: 0.2,
        flawSeverityScore: 1,
        notes: 'Coordinate Measuring Machine laser scan verified concentricity within 0.05mm.',
      },
      {
        id: 'INSP-1051',
        partId: 'S-01-INTERSTAGE-RING',
        componentName: 'Carbon Composite Interstage Separation Ring',
        process: 'Autoclave Curing & Ultrasonic NDT',
        technicianId: 'QA-TECH-733',
        timestamp: '2026-08-30T16:45:00Z',
        status: 'PASS',
        ndtMethod: 'ULTRASONIC',
        nominalDimensionMm: 5500.0,
        measuredDimensionMm: 5500.1,
        tolerancePlusMm: 0.8,
        toleranceMinusMm: 0.8,
        flawSeverityScore: 2,
        notes: 'Zero delamination detected along all 36 pneumatic separation collet attachment points.',
      },
      {
        id: 'INSP-1052',
        partId: 'E-04-MAIN-CHAMBER',
        componentName: 'Raptor-Class Vacuum Regen Channel Nozzle',
        process: 'DMLS Inconel 718 Additive Sintering',
        technicianId: 'QA-TECH-204',
        timestamp: '2026-08-31T11:20:00Z',
        status: 'PASS',
        ndtMethod: 'MASS_SPECTROMETER_LEAK',
        nominalDimensionMm: 350.0,
        measuredDimensionMm: 350.02,
        tolerancePlusMm: 0.1,
        toleranceMinusMm: 0.1,
        flawSeverityScore: 0,
        notes: 'Helium mass spec leak rate < 1.0e-9 sccs at 450 bar hydrostatic proof pressure.',
      }
    ];

    const initialHistory = [
      {
        revision: 'R17',
        timestamp: '2026-08-31T18:00:00Z',
        author: 'Lead Propulsion & Structures Engineer',
        description: 'Baseline production lock for Block-1 heavy configuration with Al-Li 2195 common bulkhead.',
        parameterHash: 'SHA-8F4C2A1E',
        summaryMetrics: {
          liftoffMassKg: 549000,
          dryMassKg: 34500,
          totalDeltaVMs: 9240,
        }
      },
      {
        revision: 'R16',
        timestamp: '2026-08-15T10:12:00Z',
        author: 'Aerodynamic Modeling Team',
        description: 'Optimized grid fin titanium forged hub aspect ratio for hypersonic reentry control.',
        parameterHash: 'SHA-3D90A5F2',
        summaryMetrics: {
          liftoffMassKg: 548600,
          dryMassKg: 34350,
          totalDeltaVMs: 9260,
        }
      },
      {
        revision: 'R15',
        timestamp: '2026-07-22T08:45:00Z',
        author: 'Manufacturing Systems Group',
        description: 'Reduced stage 1 skin thickness from 4.8mm to 4.2mm following robotic FSW grain validation.',
        parameterHash: 'SHA-1C88B974',
        summaryMetrics: {
          liftoffMassKg: 551200,
          dryMassKg: 36200,
          totalDeltaVMs: 9110,
        }
      }
    ];

    const digitalTwin: DigitalTwinState = {
      vehicleId: 'RF-001',
      vehicleName: 'RocketForge Demo Vehicle',
      configurationName: 'BLOCK-1 HEAVY',
      revision: 'R17',
      revisionHistory: initialHistory,
      manufacturingStatusPercent: 88,
      assemblyStatusPercent: 74,
      qualityTestStatusPercent: 92,
      flightStatus: 'FLIGHT_READY',
      healthScorePercent: 98.4,
      activeAlerts: [
        {
          id: 'ALT-01',
          severity: 'INFO',
          subsystem: 'DIGITAL_TWIN',
          message: 'All 4 Stage 1 NDT quality gates verified compliant with NASA-STD-5009.',
          timestamp: '2026-08-31T18:00:00Z',
        }
      ],
    };

    const config: RocketSubsystemConfig = {
      geometry: {
        totalHeight: { value: 72.0, unit: 'm', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0.1, min: 40, max: 120 },
        coreDiameter: { value: 5.5, unit: 'm', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0.1, min: 3.0, max: 10.0 },
        fairingDiameter: { value: 5.8, unit: 'm', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0.2, min: 3.5, max: 11.0 },
        fairingHeight: { value: 14.5, unit: 'm', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0.2, min: 8, max: 25 },
        stage1Height: { value: 44.0, unit: 'm', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0.2, min: 25, max: 75 },
        interstageHeight: { value: 3.5, unit: 'm', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0.5, min: 2, max: 6 },
        stage2Height: { value: 10.0, unit: 'm', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0.2, min: 6, max: 20 },
        finCount: { value: 4, unit: 'count', source: 'USER-SUPPLIED', fidelity: 'MEDIUM', uncertaintyPercent: 0, min: 0, max: 8 },
        finSpan: { value: 1.8, unit: 'm', source: 'USER-SUPPLIED', fidelity: 'MEDIUM', uncertaintyPercent: 1.0, min: 0, max: 4 },
        finRootChord: { value: 2.2, unit: 'm', source: 'USER-SUPPLIED', fidelity: 'MEDIUM', uncertaintyPercent: 1.0, min: 0.5, max: 5 },
        finTipChord: { value: 1.1, unit: 'm', source: 'USER-SUPPLIED', fidelity: 'MEDIUM', uncertaintyPercent: 1.0, min: 0.2, max: 3 },
        finSweepAngleDeg: { value: 45, unit: 'deg', source: 'USER-SUPPLIED', fidelity: 'MEDIUM', uncertaintyPercent: 0.5, min: 0, max: 65 },
        noseConeType: { value: 'VON_KARMAN', unit: 'profile', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0 },
        noseConeFineness: { value: 2.5, unit: 'ratio', source: 'USER-SUPPLIED', fidelity: 'MEDIUM', uncertaintyPercent: 1.0, min: 1.5, max: 4.5 },
      },
      propulsion: {
        propellantType: { value: 'LOX_METHANE', unit: 'chem', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0 },
        stage1EngineCount: { value: 9, unit: 'count', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0, min: 1, max: 33 },
        stage1EngineName: { value: 'Forge-1X Methalox Gas-Generator', unit: 'model', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0 },
        stage1ThrustSeaLevelKn: { value: 920, unit: 'kN', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 1.0, min: 400, max: 2600 },
        stage1ThrustVacuumKn: { value: 1040, unit: 'kN', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 1.0, min: 500, max: 3000 },
        stage1IspSeaLevelS: { value: 318, unit: 's', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0.8, min: 250, max: 380 },
        stage1IspVacuumS: { value: 352, unit: 's', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0.8, min: 290, max: 460 },
        stage1ChamberPressureBar: { value: 180, unit: 'bar', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 2.0, min: 60, max: 320 },
        stage1ExpansionRatio: { value: 35, unit: 'ratio', source: 'USER-SUPPLIED', fidelity: 'MEDIUM', uncertaintyPercent: 1.0, min: 15, max: 60 },
        stage1MixtureRatio: { value: 3.55, unit: 'ratio', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 1.0, min: 2.0, max: 6.0 },
        stage1ThrottleMinPercent: { value: 40, unit: '%', source: 'USER-SUPPLIED', fidelity: 'MEDIUM', uncertaintyPercent: 2.0, min: 20, max: 60 },
        stage1ThrottleMaxPercent: { value: 100, unit: '%', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0 },
        stage1GimbalRangeDeg: { value: 8.0, unit: 'deg', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0.2, min: 3, max: 15 },
        stage1TotalBurnTimeS: { value: 162, unit: 's', source: 'SIMULATED', fidelity: 'HIGH', uncertaintyPercent: 1.2 },
        stage1PropellantMassKg: { value: 420000, unit: 'kg', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0.5, min: 100000, max: 2000000 },

        stage2EngineCount: { value: 1, unit: 'count', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0, min: 1, max: 4 },
        stage2EngineName: { value: 'Forge-1Vac Expanded Nozzle', unit: 'model', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0 },
        stage2ThrustVacuumKn: { value: 1180, unit: 'kN', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 1.0, min: 200, max: 2000 },
        stage2IspVacuumS: { value: 378, unit: 's', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0.8, min: 300, max: 465 },
        stage2ChamberPressureBar: { value: 165, unit: 'bar', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 2.0, min: 60, max: 250 },
        stage2ExpansionRatio: { value: 165, unit: 'ratio', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 1.0, min: 80, max: 250 },
        stage2BurnTimeS: { value: 345, unit: 's', source: 'SIMULATED', fidelity: 'HIGH', uncertaintyPercent: 1.5 },
        stage2PropellantMassKg: { value: 92000, unit: 'kg', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0.5, min: 20000, max: 400000 },
      },
      structures: {
        primaryMaterial: { value: 'AL_LI_2195', unit: 'alloy', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0 },
        stage1SkinThicknessMm: { value: 4.2, unit: 'mm', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 2.0, min: 2.0, max: 12.0 },
        stage2SkinThicknessMm: { value: 3.2, unit: 'mm', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 2.0, min: 1.5, max: 8.0 },
        tankOperatingPressureBar: { value: 3.2, unit: 'bar', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 1.0, min: 1.5, max: 8.0 },
        designSafetyFactor: { value: 1.4, unit: 'SF', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0, min: 1.1, max: 2.0 },
        maxAllowableAxialG: { value: 5.5, unit: 'G', source: 'USER-SUPPLIED', fidelity: 'MEDIUM', uncertaintyPercent: 3.0, min: 3.0, max: 9.0 },
        maxAllowableLateralG: { value: 1.8, unit: 'G', source: 'USER-SUPPLIED', fidelity: 'MEDIUM', uncertaintyPercent: 5.0, min: 0.8, max: 3.0 },
        stringerCount: { value: 48, unit: 'count', source: 'USER-SUPPLIED', fidelity: 'MEDIUM', uncertaintyPercent: 0, min: 12, max: 96 },
        ringFrameSpacingM: { value: 1.2, unit: 'm', source: 'USER-SUPPLIED', fidelity: 'MEDIUM', uncertaintyPercent: 1.0, min: 0.5, max: 3.0 },
      },
      tanks: {
        stage1LoxVolumeM3: { value: 285.0, unit: 'm3', source: 'SIMULATED', fidelity: 'HIGH', uncertaintyPercent: 0.5 },
        stage1FuelVolumeM3: { value: 195.0, unit: 'm3', source: 'SIMULATED', fidelity: 'HIGH', uncertaintyPercent: 0.5 },
        stage2LoxVolumeM3: { value: 62.0, unit: 'm3', source: 'SIMULATED', fidelity: 'HIGH', uncertaintyPercent: 0.5 },
        stage2FuelVolumeM3: { value: 42.0, unit: 'm3', source: 'SIMULATED', fidelity: 'HIGH', uncertaintyPercent: 0.5 },
        ullageFractionPercent: { value: 4.5, unit: '%', source: 'USER-SUPPLIED', fidelity: 'MEDIUM', uncertaintyPercent: 5.0, min: 2.0, max: 10.0 },
        pressurantGas: { value: 'AUTOGENOUS', unit: 'system', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0 },
        insulationType: { value: 'SPRAY_ON_FOAM', unit: 'type', source: 'USER-SUPPLIED', fidelity: 'MEDIUM', uncertaintyPercent: 0 },
      },
      aerodynamics: {
        dragCoefficientSubsonic: { value: 0.22, unit: 'Cd', source: 'ESTIMATED', fidelity: 'MEDIUM', uncertaintyPercent: 5.0, min: 0.12, max: 0.45 },
        dragCoefficientTransonic: { value: 0.56, unit: 'Cd', source: 'ESTIMATED', fidelity: 'MEDIUM', uncertaintyPercent: 8.0, min: 0.35, max: 0.85 },
        dragCoefficientSupersonic: { value: 0.36, unit: 'Cd', source: 'ESTIMATED', fidelity: 'MEDIUM', uncertaintyPercent: 6.0, min: 0.20, max: 0.60 },
        referenceAreaM2: { value: 23.76, unit: 'm2', source: 'SIMULATED', fidelity: 'HIGH', uncertaintyPercent: 0.1 },
        centerOfPressureNormalized: { value: 0.62, unit: 'X/L', source: 'SIMULATED', fidelity: 'MEDIUM', uncertaintyPercent: 3.0 },
      },
      thermal: {
        maxSkinTemperatureK: { value: 1050, unit: 'K', source: 'USER-SUPPLIED', fidelity: 'MEDIUM', uncertaintyPercent: 5.0, min: 500, max: 1800 },
        nozzleThroatHeatFluxMwM2: { value: 45.0, unit: 'MW/m2', source: 'SIMULATED', fidelity: 'MEDIUM', uncertaintyPercent: 10.0, min: 15, max: 80 },
        avionicsBayMaxTempK: { value: 335, unit: 'K', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 2.0, min: 300, max: 360 },
        cryogenicBoiloffRatePercentPerHr: { value: 0.12, unit: '%/hr', source: 'ESTIMATED', fidelity: 'MEDIUM', uncertaintyPercent: 15.0, min: 0.02, max: 0.8 },
        tpsMaterial: { value: 'PICA_X', unit: 'spec', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0 },
      },
      avionics: {
        flightComputerRedundancy: { value: 3, unit: 'channels', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0, min: 1, max: 4 },
        imuSensorCount: { value: 6, unit: 'sensors', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0, min: 2, max: 12 },
        telemetryDataRateKbps: { value: 2048, unit: 'kbps', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0, min: 256, max: 10000 },
        batteryCapacityKwh: { value: 24.5, unit: 'kWh', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 2.0, min: 5, max: 60 },
        gnssConstellations: { value: 'GPS L1/L2/L5 + Galileo E1/E5a + BeiDou B1/B2a', unit: 'bands', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0 },
      },
      payload: {
        targetMassKg: { value: 16500, unit: 'kg', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0, min: 1000, max: 65000 },
        targetOrbitType: { value: 'LEO', unit: 'orbit', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0 },
        targetAltitudeKm: { value: 250, unit: 'km', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0, min: 150, max: 36000 },
        targetInclinationDeg: { value: 28.5, unit: 'deg', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0, min: 0, max: 98 },
        fairingJettisonAltitudeKm: { value: 115, unit: 'km', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 1.0, min: 80, max: 160 },
      },
      recovery: {
        reusableStage1: { value: true, unit: 'bool', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0 },
        landingLegCount: { value: 4, unit: 'legs', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0, min: 0, max: 6 },
        gridFinCount: { value: 4, unit: 'fins', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0, min: 0, max: 6 },
        recoveryPropellantReserveKg: { value: 28000, unit: 'kg', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 2.0, min: 5000, max: 60000 },
        landingSiteType: { value: 'DRONESHIP', unit: 'zone', source: 'USER-SUPPLIED', fidelity: 'HIGH', uncertaintyPercent: 0 },
      },
    };

    return {
      id: 'RF-001',
      name: 'RocketForge Demo Vehicle',
      serialNumber: 'SN-001-B1',
      digitalTwin,
      config,
      calculatedMassProperties: {
        liftoffMassKg: 554500,
        dryMassKg: 34500,
        stage1DryMassKg: 24800,
        stage1PropellantMassKg: 420000,
        stage2DryMassKg: 7800,
        stage2PropellantMassKg: 92000,
        payloadMassKg: 16500,
        fairingMassKg: 1900,
        centerOfGravityFromBaseM: 28.4,
        momentOfInertiaPitchYawKgM2: 245000000,
        momentOfInertiaRollKgM2: 2100000,
        thrustToWeightRatioLiftoff: 1.52,
        stage1DeltaVMs: 4320,
        stage2DeltaVMs: 5120,
        totalDeltaVMs: 9440,
      },
      inspections: defaultInspections,
    };
  }
}
