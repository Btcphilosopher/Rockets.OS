import { Injectable, signal, computed } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class SimulationClockService {
  // Master time in seconds (can be negative during countdown, e.g. -10s to +600s)
  readonly currentTimeS = signal<number>(0);
  readonly isRunning = signal<boolean>(false);
  readonly timeWarp = signal<number>(1.0); // 1, 2, 5, 10
  readonly isMuted = signal<boolean>(false);

  private intervalHandle: ReturnType<typeof setInterval> | null = null;
  private lastTickMs = 0;

  readonly formattedTime = computed(() => {
    const t = this.currentTimeS();
    const isNegative = t < 0;
    const absT = Math.abs(t);
    const totalSecs = Math.floor(absT);
    const hours = Math.floor(totalSecs / 3600);
    const minutes = Math.floor((totalSecs % 3600) / 60);
    const seconds = totalSecs % 60;
    const tenths = Math.floor((absT % 1) * 10);

    const pad = (n: number) => n.toString().padStart(2, '0');
    const sign = isNegative ? 'T-' : 'T+';
    return `${sign}${pad(hours)}:${pad(minutes)}:${pad(seconds)}.${tenths}`;
  });

  start(): void {
    if (this.isRunning()) return;
    this.isRunning.set(true);
    this.lastTickMs = performance.now();

    this.intervalHandle = setInterval(() => {
      const now = performance.now();
      const elapsedSecs = (now - this.lastTickMs) / 1000;
      this.lastTickMs = now;

      const delta = elapsedSecs * this.timeWarp();
      this.currentTimeS.update((t) => Number((t + delta).toFixed(2)));
    }, 50); // 20 Hz update
  }

  pause(): void {
    this.isRunning.set(false);
    if (this.intervalHandle) {
      clearInterval(this.intervalHandle);
      this.intervalHandle = null;
    }
  }

  toggle(): void {
    if (this.isRunning()) {
      this.pause();
    } else {
      this.start();
    }
  }

  reset(timeS = 0): void {
    this.pause();
    this.currentTimeS.set(timeS);
  }

  setTimeWarp(speed: number): void {
    this.timeWarp.set(speed);
  }

  seek(timeS: number): void {
    this.currentTimeS.set(Number(timeS.toFixed(2)));
  }

  step(direction = 1, stepSecs = 0.5): void {
    this.currentTimeS.update((t) => Math.max(-60, Number((t + direction * stepSecs).toFixed(2))));
  }
}
