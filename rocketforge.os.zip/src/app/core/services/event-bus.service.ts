import { Injectable } from '@angular/core';
import { Subject, Observable, filter, map } from 'rxjs';

export type AerospaceEventType = 
  | 'VEHICLE_PARAMETER_CHANGED'
  | 'MASS_PROPERTIES_UPDATED'
  | 'ENGINE_IGNITION'
  | 'ENGINE_SHUTDOWN'
  | 'MAX_Q_REACHED'
  | 'STAGE_SEPARATION'
  | 'FAIRING_JETTISON'
  | 'ORBIT_INSERTION'
  | 'MANUFACTURING_STEP_STARTED'
  | 'MANUFACTURING_STEP_COMPLETED'
  | 'INSPECTION_COMPLETED'
  | 'FAULT_INJECTED'
  | 'FAULT_CLEARED'
  | 'SIMULATION_STARTED'
  | 'SIMULATION_PAUSED'
  | 'SIMULATION_RESET'
  | 'TELEMETRY_FRAME_EMITTED'
  | 'REVISION_SAVED'
  | '3D_PART_SELECTED';

export interface AerospaceEvent<T = unknown> {
  type: AerospaceEventType;
  payload: T;
  timestamp: string;
  source: string;
}

@Injectable({
  providedIn: 'root',
})
export class EventBusService {
  private readonly eventStream$ = new Subject<AerospaceEvent>();

  emit<T>(type: AerospaceEventType, payload: T, source = 'ROCKETFORGE_CORE'): void {
    this.eventStream$.next({
      type,
      payload,
      timestamp: new Date().toISOString(),
      source,
    });
  }

  on<T>(type: AerospaceEventType): Observable<AerospaceEvent<T>> {
    return this.eventStream$.pipe(
      filter((e) => e.type === type),
      map((e) => e as AerospaceEvent<T>)
    );
  }

  stream(): Observable<AerospaceEvent> {
    return this.eventStream$.asObservable();
  }
}
