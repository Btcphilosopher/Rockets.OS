import { Injectable, signal, computed, inject } from '@angular/core';
import { TelemetryFrame, TrajectorySummary, InjectedFault, FaultId } from '../models/simulation.model';
import { DigitalTwinService } from './digital-twin.service';
import { SimulationClockService } from './simulation-clock.service';
import { EventBusService } from './event-bus.service';
import { TrajectorySolver } from '../physics/trajectory-solver';

@Injectable({
  providedIn: 'root',
})
export class TelemetryService {
  private readonly digitalTwin = inject(DigitalTwinService);
  private readonly clock = inject(SimulationClockService);
  private readonly eventBus = inject(EventBusService);

  readonly mode = signal<'LIVE' | 'REPLAY' | 'COMPARE'>('LIVE');
  readonly activeFault = signal<InjectedFault>({
    id: 'NONE',
    name: 'Nominal Operational State',
    category: 'PROPULSION',
    severity: 'MODERATE',
    triggerTimeS: 45,
    description: 'All vehicle subsystems operating within 3-sigma specification limits.',
    telemetrySignature: 'Nominal telemetry profiles',
    downstreamEffects: [],
    investigationGuidance: [],
    active: false,
  });

  readonly availableFaults: InjectedFault[] = [
    {
      id: 'NONE',
      name: 'Nominal (No Fault Injected)',
      category: 'PROPULSION',
      severity: 'MODERATE',
      triggerTimeS: 0,
      description: 'Zero anomalies. All avionics, turbopumps, and structures nominal.',
      telemetrySignature: 'Nominal',
      downstreamEffects: [],
      investigationGuidance: [],
      active: false,
    },
    {
      id: 'LOX_TURBOPUMP_SEAL_LEAK',
      name: 'LOX Turbopump Dynamic Face Seal Degraded Leak',
      category: 'PROPULSION',
      severity: 'SEVERE',
      triggerTimeS: 42,
      description: 'Intermediate purge seal pressure drop leading to 35% chamber pressure and thrust degradation.',
      telemetrySignature: 'Abrupt 35% drop in Chamber P & Thrust; Turbopump RPM oscillates; Downrange trajectory droop.',
      downstreamEffects: [
        'Under-performance on Stage 1 burn',
        'Loss of stage 1 booster recovery margin',
        'Upper stage must extend burn by +42s to reach nominal LEO parking orbit',
      ],
      investigationGuidance: [
        'Inspect helium dynamic purge seal carbon ring micro-wear logs',
        'Check cryogenic chill-down pre-ignition temperature soak profiles',
      ],
      active: true,
    },
    {
      id: 'GIMBAL_ACTUATOR_HYDRAULIC_STALL',
      name: 'Primary Gimbal Actuator Hydraulic Servo Stall',
      category: 'PROPULSION',
      severity: 'SEVERE',
      triggerTimeS: 55,
      description: 'Yaw gimbal actuator hydraulic servo valve sticks at +4.5 degrees off-axis during Max-Q.',
      telemetrySignature: 'Static +4.5 deg Yaw telemetry offset; RCS thruster duty cycle spikes to 100%; Lateral G-force rise.',
      downstreamEffects: [
        'Continuous aerodynamic drag increase',
        'Vehicle orientation bias requiring differential engine throttling compensation',
      ],
      investigationGuidance: [
        'Perform fluid particle contamination count on Moog servo manifold',
        'Verify backup electromechanical actuator transition threshold',
      ],
      active: true,
    },
    {
      id: 'AVIONICS_BUS_BROWNOUT',
      name: 'Avionics Primary 28V DC Power Bus Transient Drop',
      category: 'AVIONICS',
      severity: 'MODERATE',
      triggerTimeS: 28,
      description: 'Secondary DC-DC converter trip causes voltage sag to 22.1V for 1.8 seconds.',
      telemetrySignature: 'Bus voltage telemetry dip to 22V; Telemetry packet error rate rises to 1.8%; IMU channel B failover.',
      downstreamEffects: [
        'Failover to Tri-Modular Redundant Flight Computer 2',
        'Minor telemetry frame drop for 2 samples',
      ],
      investigationGuidance: [
        'Check solid-state power distribution module (SSPDM) current limiters',
        'Audit lithium-ion bus capacitor ripple voltage during high-transient valve pulses',
      ],
      active: true,
    },
    {
      id: 'TANK_DOME_MICRO_CRACK',
      name: 'Stage 1 Inter-tank Dome Stress Delamination',
      category: 'STRUCTURES',
      severity: 'CATASTROPHIC',
      triggerTimeS: 65,
      description: 'Structural micro-crack at weld heat-affected zone propagates under Max-Q aerodynamic bending load.',
      telemetrySignature: 'Strain gauge channel 3 reads +160% stress surge; Von Mises stress spikes above 480 MPa; Safety factor drops below 1.0.',
      downstreamEffects: [
        'Loss of structural margin',
        'Flight termination system (FTS) auto-abort boundary advisory',
      ],
      investigationGuidance: [
        'Inspect friction stir weld phased-array radiograms for root-pass voids',
        'Review raw billet material grain orientation certs',
      ],
      active: true,
    }
  ];

  // Pre-calculated trajectory dataset
  readonly trajectoryData = signal<TrajectorySummary>(this.calculateTrajectory());
  
  // Baseline trajectory for COMPARISON mode (Flight 1 vs Flight 2)
  readonly comparisonTrajectoryData = signal<TrajectorySummary | null>(null);

  // Live interpolated frame based on current simulation clock
  readonly currentFrame = computed<TelemetryFrame>(() => {
    const traj = this.trajectoryData();
    const t = this.clock.currentTimeS();
    if (!traj.frames.length) return this.createDummyFrame(t);

    if (t <= 0) {
      return traj.frames[0];
    }

    const last = traj.frames[traj.frames.length - 1];
    if (t >= last.timeS) {
      return last;
    }

    // Find closest frame
    let closest = traj.frames[0];
    let minDiff = Math.abs(t - closest.timeS);
    for (let i = 1; i < traj.frames.length; i++) {
      const diff = Math.abs(t - traj.frames[i].timeS);
      if (diff < minDiff) {
        minDiff = diff;
        closest = traj.frames[i];
      }
    }
    return closest;
  });

  constructor() {
    this.eventBus.on('VEHICLE_PARAMETER_CHANGED').subscribe(() => {
      this.recalculateTrajectory();
    });
  }

  injectFault(faultId: FaultId): void {
    const fault = this.availableFaults.find((f) => f.id === faultId) || this.availableFaults[0];
    this.activeFault.set({ ...fault });
    this.recalculateTrajectory();
    this.eventBus.emit(faultId === 'NONE' ? 'FAULT_CLEARED' : 'FAULT_INJECTED', { faultId });
  }

  setMode(mode: 'LIVE' | 'REPLAY' | 'COMPARE'): void {
    this.mode.set(mode);
    if (mode === 'COMPARE' && !this.comparisonTrajectoryData()) {
      // Store current as baseline and perturb
      this.comparisonTrajectoryData.set(JSON.parse(JSON.stringify(this.trajectoryData())));
    }
  }

  recalculateTrajectory(): void {
    const traj = this.calculateTrajectory();
    this.trajectoryData.set(traj);
  }

  private calculateTrajectory(): TrajectorySummary {
    return TrajectorySolver.simulateFlight(this.digitalTwin.rocket(), this.activeFault());
  }

  exportTelemetryCsv(): string {
    const frames = this.trajectoryData().frames;
    if (!frames.length) return '';

    const headers = [
      'Time_s', 'Stage', 'Altitude_m', 'Downrange_km', 'Velocity_m_s', 
      'Accel_G', 'DynPressure_kPa', 'Mach', 'Pitch_deg', 'Mass_kg', 
      'S1_Prop_kg', 'S2_Prop_kg', 'S1_Thrust_kN', 'ChamberP_bar', 
      'Turbopump_RPM', 'SkinTemp_K', 'Stress_MPa', 'SafetyFactor'
    ];

    const rows = frames.map((f) => [
      f.timeS, f.stage, f.altitudeM, f.downrangeKm, f.velocityMs,
      f.accelerationG, f.dynamicPressureKPa, f.machNumber, f.pitchAngleDeg, f.totalMassKg,
      f.stage1PropellantRemainingKg, f.stage2PropellantRemainingKg, f.stage1ThrustKn, f.chamberPressureBar,
      f.turbopumpRpm, f.skinTemperatureK, f.structuralStressMpa, f.safetyFactor
    ].join(','));

    return [headers.join(','), ...rows].join('\n');
  }

  private createDummyFrame(t: number): TelemetryFrame {
    return {
      timeS: t,
      stage: 'PAD_COUNTDOWN',
      altitudeM: 0,
      downrangeKm: 0,
      velocityMs: 0,
      accelerationG: 1.0,
      dynamicPressureKPa: 0,
      machNumber: 0,
      pitchAngleDeg: 90,
      flightPathAngleDeg: 90,
      totalMassKg: 554500,
      stage1PropellantRemainingKg: 420000,
      stage2PropellantRemainingKg: 92000,
      stage1ThrustKn: 0,
      stage2ThrustKn: 0,
      chamberPressureBar: 0,
      turbopumpRpm: 0,
      engineTemperatureK: 293,
      skinTemperatureK: 293,
      structuralStressMpa: 85,
      safetyFactor: 2.4,
      vibrationGrms: 0.1,
      batteryVoltageV: 28.4,
      telemetryLinkDbm: -68,
      gimbalPitchDeg: 0,
      gimbalYawDeg: 0,
    };
  }
}
