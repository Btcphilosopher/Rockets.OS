import { Injectable, signal, inject } from '@angular/core';
import { DigitalTwinService } from './digital-twin.service';
import { TelemetryService } from './telemetry.service';
import { ManufacturingService } from './manufacturing.service';
import { EventBusService } from './event-bus.service';

export interface AerospaceScenario {
  id: string;
  code: string;
  name: string;
  description: string;
  category: 'MANUFACTURING' | 'FLIGHT' | 'OPTIMIZATION' | 'RELIABILITY';
  targetSubsystem: string;
  keyParameters: { label: string; value: string }[];
  applyConfig: (digitalTwin: DigitalTwinService, telemetry: TelemetryService, mfg: ManufacturingService) => void;
}

@Injectable({
  providedIn: 'root',
})
export class ScenarioService {
  private readonly digitalTwin = inject(DigitalTwinService);
  private readonly telemetry = inject(TelemetryService);
  private readonly mfg = inject(ManufacturingService);
  private readonly eventBus = inject(EventBusService);

  readonly activeScenarioId = signal<string>('SCEN-001');

  readonly scenarios: AerospaceScenario[] = [
    {
      id: 'SCEN-001',
      code: 'Scenario 001',
      name: 'Baseline Manufacturing & Nominal Integration',
      description: 'Standard Al-Li 2195 dual-stage configuration undergoing nominal friction stir welding and 9-engine octaweb integration.',
      category: 'MANUFACTURING',
      targetSubsystem: 'Factory & Assembly',
      keyParameters: [
        { label: 'Vehicle ID', value: 'RF-001 Block-1' },
        { label: 'Material', value: 'Al-Li 2195-T8' },
        { label: 'Propellant', value: 'LOX / Methane' },
        { label: 'Stage 1 Engines', value: '9x Forge-1X' },
      ],
      applyConfig: (dt, tel, mfg) => {
        dt.updateParameter('structures.primaryMaterial', 'AL_LI_2195');
        dt.updateParameter('structures.stage1SkinThicknessMm', 4.2);
        dt.updateParameter('propulsion.stage1EngineCount', 9);
        tel.injectFault('NONE');
        mfg.selectStep(3);
      },
    },
    {
      id: 'SCEN-002',
      code: 'Scenario 002',
      name: 'High-Throughput Robotic Factory (50 Units/Yr)',
      description: 'Factory optimization scenario with dual FSW robotic gantries, automated laser weld seam tracking, and 16-day cycle time.',
      category: 'MANUFACTURING',
      targetSubsystem: 'Factory Floor Simulation',
      keyParameters: [
        { label: 'Throughput', value: '50 Rockets/Year' },
        { label: 'Cycle Time', value: '16.2 Days' },
        { label: 'OEE', value: '94.8%' },
        { label: 'Weld Automation', value: 'Dual-Arm Robotic FSW' },
      ],
      applyConfig: (dt, tel, mfg) => {
        dt.updateParameter('structures.stage1SkinThicknessMm', 3.8);
        tel.injectFault('NONE');
        mfg.selectStep(0);
      },
    },
    {
      id: 'SCEN-003',
      code: 'Scenario 003',
      name: 'Mass Optimised Carbon Composite Vehicle',
      description: 'Lightweight IM7 carbon epoxy structure reducing booster dry mass by 18% and unlocking 20,500 kg payload capacity to LEO.',
      category: 'OPTIMIZATION',
      targetSubsystem: 'Structural & Propulsion',
      keyParameters: [
        { label: 'Primary Alloy', value: 'IM7 / Cycom Carbon Epoxy' },
        { label: 'Dry Mass', value: '28,300 kg (-18%)' },
        { label: 'Payload to LEO', value: '20,500 kg' },
        { label: 'Delta-V', value: '9,820 m/s' },
      ],
      applyConfig: (dt, tel) => {
        dt.updateParameter('structures.primaryMaterial', 'CARBON_COMPOSITE');
        dt.updateParameter('structures.stage1SkinThicknessMm', 2.8);
        dt.updateParameter('structures.stage2SkinThicknessMm', 2.2);
        dt.updateParameter('payload.targetMassKg', 20500);
        tel.injectFault('NONE');
      },
    },
    {
      id: 'SCEN-004',
      code: 'Scenario 004',
      name: 'Severe Aerodynamic Thermal Stress Re-entry',
      description: 'Atmospheric boundary layer stress test simulating Mach 6 hypersonic re-entry heat fluxes and stagnation point hot spot analysis.',
      category: 'FLIGHT',
      targetSubsystem: 'Thermal & Aerodynamics',
      keyParameters: [
        { label: 'Peak Heat Flux', value: '74.2 kW/m²' },
        { label: 'Stagnation Temp', value: '1,420 K' },
        { label: 'TPS System', value: 'PICA-X Phenolic Tiles' },
        { label: 'Mach Number', value: 'Mach 6.2' },
      ],
      applyConfig: (dt, tel) => {
        dt.updateParameter('thermal.maxSkinTemperatureK', 1450);
        dt.updateParameter('aerodynamics.dragCoefficientSupersonic', 0.42);
        tel.injectFault('NONE');
      },
    },
    {
      id: 'SCEN-005',
      code: 'Scenario 005',
      name: 'Manufacturing Weld Delamination Defect',
      description: 'Simulates an injected structural micro-void during FSW that triggers an automated ultrasonic NDT quarantine alert in the digital twin.',
      category: 'RELIABILITY',
      targetSubsystem: 'Quality & Failure Analysis',
      keyParameters: [
        { label: 'Defect Type', value: 'FSW Root Delamination' },
        { label: 'Affected Part', value: 'T-01-LOX-DOME' },
        { label: 'Severity', value: 'High Stress Spike' },
        { label: 'Trigger Time', value: 'T+00:01:05 (Max-Q)' },
      ],
      applyConfig: (dt, tel) => {
        tel.injectFault('TANK_DOME_MICRO_CRACK');
      },
    },
    {
      id: 'SCEN-006',
      code: 'Scenario 006',
      name: 'Nominal Orbital Ascent & Booster Droneship Landing',
      description: 'Full 650-second flight profile with nominal MECO, stage separation, 250 km orbit insertion, and simulated drone-ship landing burn.',
      category: 'FLIGHT',
      targetSubsystem: 'Trajectory & Telemetry',
      keyParameters: [
        { label: 'Target Orbit', value: '250 km x 250 km LEO' },
        { label: 'Insertion Vel', value: '7,820 m/s' },
        { label: 'Max-Q', value: '38.4 kPa' },
        { label: 'Booster Recovery', value: 'ASDS Droneship Nominal' },
      ],
      applyConfig: (dt, tel) => {
        dt.updateParameter('recovery.reusableStage1', true);
        dt.updateParameter('recovery.landingSiteType', 'DRONESHIP');
        tel.injectFault('NONE');
      },
    },
    {
      id: 'SCEN-007',
      code: 'Scenario 007',
      name: 'Monte Carlo 1,000-Flight Uncertainty Campaign',
      description: 'Massive statistical dispersion test validating 3-sigma structural safety factor margins and propellant depletion thresholds.',
      category: 'RELIABILITY',
      targetSubsystem: 'Monte Carlo Engine',
      keyParameters: [
        { label: 'Iterations', value: '1,000 Flights' },
        { label: 'Success Prob', value: '98.6%' },
        { label: 'Mass StdDev', value: '±2.0%' },
        { label: 'Thrust StdDev', value: '±1.5%' },
      ],
      applyConfig: (_dt, tel) => {
        tel.injectFault('NONE');
      },
    },
  ];

  loadScenario(id: string): void {
    const scen = this.scenarios.find((s) => s.id === id);
    if (!scen) return;
    this.activeScenarioId.set(id);
    scen.applyConfig(this.digitalTwin, this.telemetry, this.mfg);
  }
}
