import { G0, G_CONSTANT, M_EARTH, R_EARTH } from './constants';
import { CanonicalRocket } from '../models/rocket.model';
import { TelemetryFrame, TrajectorySummary, SimulationStage, InjectedFault } from '../models/simulation.model';
import { PropulsionSolver } from './propulsion-solver';
import { AerodynamicsSolver } from './aerodynamics-solver';
import { StructuresSolver } from './structures-solver';
import { ThermalSolver } from './thermal-solver';

export class TrajectorySolver {
  /**
   * Numerically integrates the launch trajectory and generates high-resolution telemetry frames
   */
  static simulateFlight(
    rocket: CanonicalRocket,
    fault: InjectedFault = { id: 'NONE', name: 'Nominal', category: 'PROPULSION', severity: 'MODERATE', triggerTimeS: 0, description: '', telemetrySignature: '', downstreamEffects: [], investigationGuidance: [], active: false }
  ): TrajectorySummary {
    const config = rocket.config;
    const massProps = rocket.calculatedMassProperties;

    const dt = 0.2; // 5 Hz physics step for crisp performance & precision
    const maxTimeS = 650; // Total simulation envelope

    let timeS = 0;
    let altitudeM = 0;
    let downrangeKm = 0;
    let velocityMs = 0;
    let pitchAngleDeg = 90.0; // Vertical at pad
    let flightPathAngleDeg = 90.0;
    
    let stage1PropKg = config.propulsion.stage1PropellantMassKg.value;
    let stage2PropKg = config.propulsion.stage2PropellantMassKg.value;
    const stage1DryKg = massProps.stage1DryMassKg;
    const stage2DryKg = massProps.stage2DryMassKg;
    const payloadKg = massProps.payloadMassKg;
    const fairingKg = massProps.fairingMassKg;

    let isStage1Active = true;
    let isStage2Active = false;
    let isFairingAttached = true;
    let hasSeparated = false;

    let stage: SimulationStage = 'PAD_COUNTDOWN';
    const frames: TelemetryFrame[] = [];

    let maxAlt = 0;
    let maxVel = 0;
    let maxAccelG = 1.0;
    let maxQ_KPa = 0;
    let maxQTimeS = 0;
    let mecoTimeS = 0;
    let secoTimeS = 0;

    // Simulation Loop
    while (timeS <= maxTimeS) {
      const r = R_EARTH + altitudeM;
      const g_local = (G_CONSTANT * M_EARTH) / Math.pow(r, 2);

      // Fault checks
      let thrustDegradationFactor = 1.0;
      let gimbalOffsetYaw = 0;
      let gimbalOffsetPitch = 0;
      let structuralDamageFactor = 1.0;

      if (fault.active && timeS >= fault.triggerTimeS) {
        if (fault.id === 'LOX_TURBOPUMP_SEAL_LEAK') {
          thrustDegradationFactor = 0.65;
        } else if (fault.id === 'GIMBAL_ACTUATOR_HYDRAULIC_STALL') {
          gimbalOffsetYaw = 4.5;
        } else if (fault.id === 'TANK_DOME_MICRO_CRACK') {
          structuralDamageFactor = 1.6; // High stress amplification
        } else if (fault.id === 'AVIONICS_BUS_BROWNOUT') {
          gimbalOffsetPitch = 2.0;
        }
      }

      // Calculate total vehicle mass
      let currentTotalMassKg = 0;
      if (isStage1Active) {
        currentTotalMassKg = stage1DryKg + stage1PropKg + stage2DryKg + stage2PropKg + payloadKg + (isFairingAttached ? fairingKg : 0);
      } else {
        // Upper stage only
        currentTotalMassKg = stage2DryKg + stage2PropKg + payloadKg + (isFairingAttached ? fairingKg : 0);
      }

      // Propulsion State
      let thrustKn = 0;
      let s1ThrustKn = 0;
      let s2ThrustKn = 0;
      let chamberPBar = 0;
      let turbopumpRpm = 0;
      let throttle = 100;

      if (timeS < 0) {
        stage = 'PAD_COUNTDOWN';
      } else if (isStage1Active && stage1PropKg > 10) {
        stage = 'LIFTOFF';
        const s1Engines = config.propulsion.stage1EngineCount.value;
        const s1ThrustSL = config.propulsion.stage1ThrustSeaLevelKn.value;
        const s1ThrustVac = config.propulsion.stage1ThrustVacuumKn.value;
        const s1IspSL = config.propulsion.stage1IspSeaLevelS.value;
        const s1IspVac = config.propulsion.stage1IspVacuumS.value;

        // Throttle back during Max-Q if needed to maintain structural limits
        if (velocityMs > 250 && velocityMs < 550 && altitudeM > 7000 && altitudeM < 16000) {
          throttle = 78;
        }

        const propState = PropulsionSolver.calculateThrustAtAltitude(
          s1Engines,
          s1ThrustSL,
          s1ThrustVac,
          s1IspSL,
          s1IspVac,
          altitudeM
        );

        s1ThrustKn = propState.thrustKn * (throttle / 100) * thrustDegradationFactor;
        thrustKn = s1ThrustKn;
        chamberPBar = config.propulsion.stage1ChamberPressureBar.value * (throttle / 100) * thrustDegradationFactor;
        turbopumpRpm = 24000 * (throttle / 100) * Math.sqrt(thrustDegradationFactor);

        const mdot = (s1ThrustKn * 1000) / Math.max(1, propState.currentIsp * G0);
        stage1PropKg = Math.max(0, stage1PropKg - mdot * dt);

        if (stage1PropKg <= 10) {
          isStage1Active = false;
          mecoTimeS = timeS;
          stage = 'MECO';
        }
      } else if (!isStage2Active && !hasSeparated && timeS > mecoTimeS + 2.5) {
        stage = 'STAGE_SEPARATION';
        hasSeparated = true;
        isStage2Active = true;
      } else if (isStage2Active && stage2PropKg > 10) {
        stage = 'STAGE2_IGNITION';
        const s2Engines = config.propulsion.stage2EngineCount.value;
        const s2ThrustVac = config.propulsion.stage2ThrustVacuumKn.value * s2Engines;
        const s2IspVac = config.propulsion.stage2IspVacuumS.value;

        s2ThrustKn = s2ThrustVac * thrustDegradationFactor;
        thrustKn = s2ThrustKn;
        chamberPBar = config.propulsion.stage2ChamberPressureBar.value * thrustDegradationFactor;
        turbopumpRpm = 32000 * Math.sqrt(thrustDegradationFactor);

        const mdot = (s2ThrustKn * 1000) / Math.max(1, s2IspVac * G0);
        stage2PropKg = Math.max(0, stage2PropKg - mdot * dt);

        // Fairing jettison check (> 115 km altitude)
        if (isFairingAttached && altitudeM > 115000) {
          isFairingAttached = false;
          stage = 'FAIRING_JETTISON';
        }

        // Orbit insertion cutoff
        if (velocityMs >= 7800 || stage2PropKg <= 10) {
          isStage2Active = false;
          secoTimeS = timeS;
          stage = 'SECO_ORBIT_INSERTION';
        }
      } else if (timeS > secoTimeS && secoTimeS > 0) {
        stage = 'MISSION_COMPLETE';
      }

      // Aerodynamics
      const aeroState = AerodynamicsSolver.calculateAeroState(
        altitudeM,
        velocityMs,
        Math.abs(pitchAngleDeg - flightPathAngleDeg),
        config,
        config.geometry.totalHeight.value * 0.45
      );

      if (aeroState.dynamicPressureKPa > maxQ_KPa) {
        maxQ_KPa = aeroState.dynamicPressureKPa;
        maxQTimeS = timeS;
        if (stage === 'LIFTOFF') {
          stage = 'MAX_Q';
        }
      }

      // Guidance & Gravity Turn Pitch Program
      if (altitudeM > 1200 && isStage1Active) {
        // Gradual pitchover towards 0 deg horizontal
        const targetPitch = Math.max(12, 90 - 78 * Math.pow(altitudeM / 75000, 0.55));
        pitchAngleDeg = pitchAngleDeg + (targetPitch - pitchAngleDeg) * 0.05;
      } else if (isStage2Active) {
        const targetPitch = Math.max(0, 15 - 15 * (timeS - mecoTimeS) / 300);
        pitchAngleDeg = pitchAngleDeg + (targetPitch - pitchAngleDeg) * 0.08;
      }

      const pitchRad = (pitchAngleDeg * Math.PI) / 180;
      const gammaRad = (flightPathAngleDeg * Math.PI) / 180;
      const alphaRad = pitchRad - gammaRad;

      // Acceleration calculation
      const thrustN = thrustKn * 1000;
      const dragN = aeroState.dragForceKn * 1000;
      const liftN = aeroState.liftForceKn * 1000;

      const f_tangent = thrustN * Math.cos(alphaRad) - dragN - currentTotalMassKg * g_local * Math.sin(gammaRad);
      const accelTangent = f_tangent / Math.max(100, currentTotalMassKg);
      const accelG = (thrustN / Math.max(100, currentTotalMassKg)) / G0;

      // Update state
      if (timeS >= 0) {
        velocityMs = Math.max(0, velocityMs + accelTangent * dt);
        const vVertical = velocityMs * Math.sin(gammaRad);
        const vHorizontal = velocityMs * Math.cos(gammaRad);

        altitudeM = Math.max(0, altitudeM + vVertical * dt);
        downrangeKm += (vHorizontal * dt) / 1000;

        // Flight path angle rate
        if (velocityMs > 20) {
          const dGamma = ((thrustN * Math.sin(alphaRad) + liftN) / (currentTotalMassKg * velocityMs) - (g_local / velocityMs - velocityMs / r) * Math.cos(gammaRad)) * dt;
          flightPathAngleDeg = (gammaRad + dGamma) * 180 / Math.PI;
        }
      }

      // Structural analysis for current instant
      const structAnalysis = StructuresSolver.analyzeLoadCase(
        stage === 'MAX_Q' ? 'MAX_Q' : 'MAX_ACCELERATION',
        config,
        currentTotalMassKg,
        accelG,
        aeroState.dynamicPressureKPa,
        Math.abs(pitchAngleDeg - flightPathAngleDeg)
      );

      // Thermal analysis
      const thermalState = ThermalSolver.evaluateThermalState(
        altitudeM,
        velocityMs,
        aeroState.machNumber,
        throttle,
        config
      );

      // Max metrics tracking
      maxAlt = Math.max(maxAlt, altitudeM);
      maxVel = Math.max(maxVel, velocityMs);
      maxAccelG = Math.max(maxAccelG, accelG);

      const frame: TelemetryFrame = {
        timeS: Number(timeS.toFixed(1)),
        stage,
        altitudeM: Math.round(altitudeM),
        downrangeKm: Number(downrangeKm.toFixed(2)),
        velocityMs: Math.round(velocityMs),
        accelerationG: Number(accelG.toFixed(2)),
        dynamicPressureKPa: Number(aeroState.dynamicPressureKPa.toFixed(2)),
        machNumber: Number(aeroState.machNumber.toFixed(2)),
        pitchAngleDeg: Number(pitchAngleDeg.toFixed(1)),
        flightPathAngleDeg: Number(flightPathAngleDeg.toFixed(1)),
        totalMassKg: Math.round(currentTotalMassKg),
        stage1PropellantRemainingKg: Math.round(stage1PropKg),
        stage2PropellantRemainingKg: Math.round(stage2PropKg),
        stage1ThrustKn: Math.round(s1ThrustKn),
        stage2ThrustKn: Math.round(s2ThrustKn),
        chamberPressureBar: Number(chamberPBar.toFixed(1)),
        turbopumpRpm: Math.round(turbopumpRpm),
        engineTemperatureK: Math.round(thermalState.engineCombustionChamberTempK),
        skinTemperatureK: Math.round(thermalState.fairingSkinTempK),
        structuralStressMpa: Math.round(structAnalysis.vonMisesStressMpa * structuralDamageFactor),
        safetyFactor: Number((structAnalysis.safetyFactorYield / structuralDamageFactor).toFixed(2)),
        vibrationGrms: Number((0.8 + 2.5 * (aeroState.dynamicPressureKPa / 45) + (accelG > 3 ? 1.2 : 0)).toFixed(2)),
        batteryVoltageV: Number((28.4 - (timeS / 600) * 1.8).toFixed(1)),
        telemetryLinkDbm: Number((-72 - (downrangeKm / 10)).toFixed(1)),
        gimbalPitchDeg: Number((Math.sin(timeS * 0.2) * 0.4 + gimbalOffsetPitch).toFixed(2)),
        gimbalYawDeg: Number((Math.cos(timeS * 0.15) * 0.3 + gimbalOffsetYaw).toFixed(2)),
      };

      // Push telemetry frame every 0.8s to keep array light yet continuous
      if (Math.round(timeS * 10) % 8 === 0 || stage === 'MECO' || stage === 'STAGE_SEPARATION' || stage === 'SECO_ORBIT_INSERTION') {
        frames.push(frame);
      }

      timeS += dt;
    }

    const finalPerigee = Math.round(altitudeM / 1000);
    const finalApogee = Math.round((altitudeM + 80000) / 1000);

    return {
      maxAltitudeM: Math.round(maxAlt),
      maxVelocityMs: Math.round(maxVel),
      maxAccelerationG: Number(maxAccelG.toFixed(2)),
      maxDynamicPressureKPa: Number(maxQ_KPa.toFixed(2)),
      maxQTimeS,
      mecoTimeS,
      secoTimeS,
      finalOrbitPerigeeKm: finalPerigee,
      finalOrbitApogeeKm: finalApogee,
      finalOrbitInclinationDeg: config.payload.targetInclinationDeg.value || 28.5,
      insertionVelocityMs: Math.round(maxVel),
      missionSuccess: maxVel >= 7600 && finalPerigee >= 180,
      totalBurnTimeS: mecoTimeS + (secoTimeS - mecoTimeS),
      frames,
    };
  }
}
