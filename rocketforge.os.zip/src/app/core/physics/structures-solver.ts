import { MATERIALS_REGISTRY, G0 } from './constants';
import { RocketSubsystemConfig } from '../models/rocket.model';

export type LoadCaseType = 'STATIC_PAD' | 'MAX_Q' | 'MAX_ACCELERATION' | 'STAGE_SEP' | 'LANDING_BURDEN';

export interface StructuralStressReport {
  loadCase: LoadCaseType;
  axialForceKn: number;
  bendingMomentKnM: number;
  internalPressureBar: number;
  hoopStressMpa: number;
  longitudinalStressMpa: number;
  bendingStressMpa: number;
  vonMisesStressMpa: number;
  bucklingCriticalStressMpa: number;
  yieldStrengthMpa: number;
  safetyFactorYield: number;
  safetyFactorUltimate: number;
  marginOfSafety: number; // MS = (SF / DesignSF) - 1
  isSafe: boolean;
  criticalStationDescription: string;
}

export class StructuresSolver {
  /**
   * Evaluates stress and safety factor under various flight load cases
   */
  static analyzeLoadCase(
    loadCase: LoadCaseType,
    config: RocketSubsystemConfig,
    totalMassKg: number,
    axialAccelerationG: number,
    dynamicPressureKPa = 0,
    angleAttackDeg = 0
  ): StructuralStressReport {
    const materialId = config.structures.primaryMaterial.value;
    const material = MATERIALS_REGISTRY[materialId] || MATERIALS_REGISTRY.AL_LI_2195;
    const radiusM = config.geometry.coreDiameter.value / 2;
    const thicknessM = (config.structures.stage1SkinThicknessMm.value) / 1000;
    const heightM = config.geometry.totalHeight.value;
    const tankPressureBar = config.structures.tankOperatingPressureBar.value;
    const designSF = config.structures.designSafetyFactor.value;

    const pressurePa = tankPressureBar * 100000;
    const crossSectionArea = 2 * Math.PI * radiusM * thicknessM;
    const sectionModulusZ = Math.PI * Math.pow(radiusM, 2) * thicknessM;

    let axialForceN = totalMassKg * axialAccelerationG * G0;
    let bendingMomentNm = 0;

    if (loadCase === 'MAX_Q') {
      // Wind shear / aerodynamic normal force creates bending moment
      const q = dynamicPressureKPa * 1000;
      const alphaRad = (angleAttackDeg * Math.PI) / 180;
      const normalForceN = q * (2 * radiusM * heightM * 0.4) * Math.sin(alphaRad || 0.035); // 2 deg default
      bendingMomentNm = normalForceN * (heightM * 0.45);
    } else if (loadCase === 'STATIC_PAD') {
      axialForceN = totalMassKg * 1.0 * G0;
      bendingMomentNm = 0.05 * axialForceN * radiusM; // small wind moment
    } else if (loadCase === 'MAX_ACCELERATION') {
      axialForceN = totalMassKg * axialAccelerationG * G0;
      bendingMomentNm = 0.02 * axialForceN * radiusM;
    } else if (loadCase === 'LANDING_BURDEN') {
      axialForceN = (totalMassKg * 0.15) * 4.5 * G0; // dry booster landing impact
      bendingMomentNm = 0.1 * axialForceN * radiusM;
    }

    // Hoop stress: sigma_h = p * r / t (in MPa)
    const hoopStressMpa = (pressurePa * radiusM / thicknessM) / 1e6;

    // Longitudinal stress: sigma_L = p * r / (2*t) - F_axial / A (in MPa)
    // Tensile pressure minus compressive flight load
    const pressureLongStressMpa = (pressurePa * radiusM / (2 * thicknessM)) / 1e6;
    const mechanicalLongStressMpa = (axialForceN / crossSectionArea) / 1e6;
    const bendingStressMpa = (bendingMomentNm / sectionModulusZ) / 1e6;

    // Maximum compressive / tensile longitudinal stress at outer skin fiber
    const maxLongStressMpa = Math.abs(pressureLongStressMpa - mechanicalLongStressMpa - bendingStressMpa);

    // Von Mises Equivalent Stress: sqrt(sigma1^2 - sigma1*sigma2 + sigma2^2)
    const vonMisesStressMpa = Math.sqrt(
      Math.pow(hoopStressMpa, 2) - hoopStressMpa * maxLongStressMpa + Math.pow(maxLongStressMpa, 2)
    );

    // Classical NASA SP-8007 Shell Buckling critical stress:
    // sigma_cl = gamma * (E / sqrt(3*(1 - nu^2))) * (t / r)
    const E_Mpa = material.youngsModulus * 1000;
    const nu = 0.33; // Poisson ratio
    const gammaKnockdown = 0.33; // Empirical knockdown for manufactured cylindrical shells
    const bucklingCriticalStressMpa = gammaKnockdown * (E_Mpa / Math.sqrt(3 * (1 - nu * nu))) * (thicknessM / radiusM);

    const effectiveStressMpa = Math.max(vonMisesStressMpa, mechanicalLongStressMpa + bendingStressMpa);
    const safetyFactorYield = material.yieldStrength / Math.max(0.1, effectiveStressMpa);
    const safetyFactorUltimate = material.ultimateStrength / Math.max(0.1, effectiveStressMpa);
    const marginOfSafety = (safetyFactorYield / designSF) - 1.0;

    let criticalStation = 'Stage 1 Inter-tank Ring Station 420';
    if (loadCase === 'MAX_Q') criticalStation = 'Interstage Transition Shell Section';
    if (loadCase === 'MAX_ACCELERATION') criticalStation = 'Aft Thrust Structure Puck Ring';
    if (loadCase === 'STATIC_PAD') criticalStation = 'Launch Hold-down Pad Clamp Interface';

    return {
      loadCase,
      axialForceKn: axialForceN / 1000,
      bendingMomentKnM: bendingMomentNm / 1000,
      internalPressureBar: tankPressureBar,
      hoopStressMpa,
      longitudinalStressMpa: maxLongStressMpa,
      bendingStressMpa,
      vonMisesStressMpa,
      bucklingCriticalStressMpa,
      yieldStrengthMpa: material.yieldStrength,
      safetyFactorYield,
      safetyFactorUltimate,
      marginOfSafety,
      isSafe: marginOfSafety >= 0 && effectiveStressMpa < bucklingCriticalStressMpa,
      criticalStationDescription: criticalStation,
    };
  }
}
