import { CanonicalRocket } from '../models/rocket.model';
import { MonteCarloAnalysisResult, MonteCarloParameterVariations, MonteCarloScenarioResult } from '../models/simulation.model';
import { TrajectorySolver } from './trajectory-solver';

export class MonteCarloSolver {
  /**
   * Deterministic Pseudo-Random Number Generator (PRNG - Mulberry32)
   */
  private static mulberry32(seed: number): () => number {
    return () => {
      let t = (seed += 0x6d2b79f5);
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /**
   * Box-Muller standard normal transform
   */
  private static randomGaussian(prng: () => number, mean = 0, stdDev = 1): number {
    const u1 = Math.max(1e-7, prng());
    const u2 = prng();
    const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    return mean + z0 * stdDev;
  }

  /**
   * Runs N-iteration Monte Carlo dispersion analysis
   */
  static runCampaign(
    rocket: CanonicalRocket,
    iterations = 200,
    variations: MonteCarloParameterVariations = {
      dryMassStdDevPercent: 2.0,
      propellantMassStdDevPercent: 0.5,
      engineThrustStdDevPercent: 1.5,
      engineIspStdDevPercent: 1.0,
      aerodynamicDragStdDevPercent: 4.0,
      tankThicknessStdDevMm: 0.05,
      highAltitudeWindGustMs: 12.0,
      sensorNoiseG: 0.05,
    },
    baseSeed = 42
  ): MonteCarloAnalysisResult {
    const results: MonteCarloScenarioResult[] = [];
    let successCount = 0;
    let sumApogee = 0;
    let sumMaxQ = 0;
    let sumSF = 0;
    let sumDryMass = 0;
    const maxQList: number[] = [];
    const sfList: number[] = [];
    const apogeeList: number[] = [];

    const originalDryMass = rocket.calculatedMassProperties.dryMassKg;
    const originalThrust = rocket.config.propulsion.stage1ThrustSeaLevelKn.value;
    const originalIsp = rocket.config.propulsion.stage1IspSeaLevelS.value;

    for (let i = 0; i < iterations; i++) {
      const runSeed = baseSeed + i * 1337;
      const prng = this.mulberry32(runSeed);

      // Perturb parameters
      const massScale = 1 + this.randomGaussian(prng, 0, variations.dryMassStdDevPercent / 100);
      const thrustScale = 1 + this.randomGaussian(prng, 0, variations.engineThrustStdDevPercent / 100);
      const ispScale = 1 + this.randomGaussian(prng, 0, variations.engineIspStdDevPercent / 100);
      const dragScale = 1 + this.randomGaussian(prng, 0, variations.aerodynamicDragStdDevPercent / 100);

      // Clone rocket and apply perturbations
      const clonedRocket: CanonicalRocket = JSON.parse(JSON.stringify(rocket));
      clonedRocket.calculatedMassProperties.dryMassKg = originalDryMass * massScale;
      clonedRocket.calculatedMassProperties.stage1DryMassKg *= massScale;
      clonedRocket.calculatedMassProperties.stage2DryMassKg *= massScale;
      clonedRocket.config.propulsion.stage1ThrustSeaLevelKn.value = originalThrust * thrustScale;
      clonedRocket.config.propulsion.stage1IspSeaLevelS.value = originalIsp * ispScale;
      clonedRocket.config.aerodynamics.dragCoefficientSubsonic.value *= dragScale;
      clonedRocket.config.aerodynamics.dragCoefficientTransonic.value *= dragScale;

      // Run trajectory
      const traj = TrajectorySolver.simulateFlight(clonedRocket);

      const liftoffMass = clonedRocket.calculatedMassProperties.dryMassKg + 
        clonedRocket.config.propulsion.stage1PropellantMassKg.value + 
        clonedRocket.config.propulsion.stage2PropellantMassKg.value;

      const minSF = traj.frames.reduce((min, f) => Math.min(min, f.safetyFactor), 99);
      const maxStress = traj.frames.reduce((max, f) => Math.max(max, f.structuralStressMpa), 0);
      const isSuccess = traj.missionSuccess && minSF >= 1.25;

      if (isSuccess) successCount++;
      sumApogee += traj.finalOrbitApogeeKm;
      sumMaxQ += traj.maxDynamicPressureKPa;
      sumSF += minSF;
      sumDryMass += clonedRocket.calculatedMassProperties.dryMassKg;

      maxQList.push(traj.maxDynamicPressureKPa);
      sfList.push(minSF);
      apogeeList.push(traj.finalOrbitApogeeKm);

      results.push({
        runIndex: i + 1,
        seed: runSeed,
        liftoffMassKg: Math.round(liftoffMass),
        maxQ_kPa: traj.maxDynamicPressureKPa,
        maxStressMpa: maxStress,
        minSafetyFactor: Number(minSF.toFixed(2)),
        insertionApogeeKm: traj.finalOrbitApogeeKm,
        insertionPerigeeKm: traj.finalOrbitPerigeeKm,
        finalDeltaVRemainingMs: Math.round(traj.insertionVelocityMs - 7800),
        missionSuccess: isSuccess,
        failureReason: !isSuccess ? (minSF < 1.25 ? 'Structural Margin Exceeded (<1.25 SF)' : 'Under-speed Insertion (<7800 m/s)') : undefined,
      });
    }

    maxQList.sort((a, b) => a - b);
    sfList.sort((a, b) => a - b);

    const meanApogee = sumApogee / iterations;
    const stdDevApogee = Math.sqrt(
      apogeeList.reduce((acc, val) => acc + Math.pow(val - meanApogee, 2), 0) / iterations
    );

    const p99Index = Math.floor(iterations * 0.99);
    const p01Index = Math.floor(iterations * 0.01);

    return {
      totalRuns: iterations,
      successProbabilityPercent: Number(((successCount / iterations) * 100).toFixed(1)),
      meanApogeeKm: Math.round(meanApogee),
      stdDevApogeeKm: Number(stdDevApogee.toFixed(1)),
      meanMaxQ_kPa: Number((sumMaxQ / iterations).toFixed(2)),
      p99MaxQ_kPa: Number((maxQList[p99Index] || maxQList[maxQList.length - 1]).toFixed(2)),
      meanSafetyFactor: Number((sumSF / iterations).toFixed(2)),
      p01MinSafetyFactor: Number((sfList[p01Index] || sfList[0]).toFixed(2)),
      meanDryMassKg: Math.round(sumDryMass / iterations),
      runs: results,
    };
  }
}
