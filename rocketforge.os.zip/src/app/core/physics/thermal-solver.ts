import { STEFAN_BOLTZMANN, getAtmosphereProperties } from './constants';
import { RocketSubsystemConfig } from '../models/rocket.model';

export interface ThermalSubsystemState {
  noseTipTempK: number;
  fairingSkinTempK: number;
  stage1LoxTankSkinTempK: number;
  stage1FuelTankSkinTempK: number;
  interstageTempK: number;
  engineNozzleTempK: number;
  engineCombustionChamberTempK: number;
  avionicsBayTempK: number;
  aerodynamicHeatFluxKwM2: number;
  nozzleThroatHeatFluxMwM2: number;
  maxAllowableTempK: number;
  thermalMarginK: number;
  cryogenicBoiloffKgHr: number;
  hotspotDetected: boolean;
}

export class ThermalSolver {
  /**
   * Computes thermal node temperatures during flight or ground hold
   */
  static evaluateThermalState(
    altitudeM: number,
    velocityMs: number,
    machNumber: number,
    engineThrottlePercent: number,
    config: RocketSubsystemConfig
  ): ThermalSubsystemState {
    const atmo = getAtmosphereProperties(altitudeM);
    const ambientT = atmo.temperatureK;
    const density = atmo.densityKgM3;

    // Stagnation point aero heating (Fay-Riddell simplified)
    const noseRadiusM = 0.35; // typical nose bluntness
    let q_aero_W_m2 = 0;
    if (velocityMs > 50 && density > 1e-6) {
      q_aero_W_m2 = 1.83e-4 * Math.sqrt(density / noseRadiusM) * Math.pow(velocityMs, 3);
    }
    const q_aero_KwM2 = q_aero_W_m2 / 1000;

    // Recovery temperature for turbulent boundary layer (recovery factor r ~ 0.89)
    // Radiative equilibrium: epsilon * sigma * T_eq^4 = q_aero + alpha * q_solar
    const epsilon = 0.85; // High emissivity aerospace coating
    const T_rad_nose = Math.pow((q_aero_W_m2 + 1361 * 0.2) / (epsilon * STEFAN_BOLTZMANN), 0.25);
    const noseTipTempK = Math.max(ambientT, Math.min(2200, T_rad_nose));

    // Skin temperature downstream
    const fairingSkinTempK = Math.min(850, ambientT + (noseTipTempK - ambientT) * 0.45);
    const interstageTempK = Math.min(650, ambientT + (noseTipTempK - ambientT) * 0.30);

    // Cryogenic tanks (LOX at ~90K internally, cooled skin + boundary layer heating)
    const loxInternalT = 90.15; // K
    const fuelInternalT = 280; // RP-1 or ~111K for Methane
    const insulationCoeff = 0.05; // foam insulation effect
    const stage1LoxTankSkinTempK = loxInternalT + (fairingSkinTempK - loxInternalT) * insulationCoeff;
    const stage1FuelTankSkinTempK = fuelInternalT + (fairingSkinTempK - fuelInternalT) * insulationCoeff;

    // Cryogenic boil-off calculation
    const boiloffRateBasePct = config.thermal.cryogenicBoiloffRatePercentPerHr.value || 0.15;
    const thermalExcursionFactor = Math.max(1.0, fairingSkinTempK / 300);
    const totalPropMass = config.propulsion.stage1PropellantMassKg.value;
    const boiloffKgHr = (totalPropMass * (boiloffRateBasePct / 100) * thermalExcursionFactor);

    // Engine Section & Nozzle (Regeneratively cooled)
    const isEngineActive = engineThrottlePercent > 5;
    const throatHeatFluxMw = isEngineActive ? (config.thermal.nozzleThroatHeatFluxMwM2.value * (engineThrottlePercent / 100)) : 0;
    const engineCombustionChamberTempK = isEngineActive ? (3400 * (engineThrottlePercent / 100)) : 300;
    // Outer regeneratively cooled nozzle wall temperature
    const engineNozzleTempK = isEngineActive ? (950 + 250 * (engineThrottlePercent / 100)) : 300;

    // Avionics Bay (Actively climate controlled with heat pipe radiators)
    const avionicsWasteHeatW = 1200; // 1.2 kW avionics heat
    const avionicsBayTempK = Math.min(335, 293.15 + (interstageTempK > 350 ? 15 : 0) + (avionicsWasteHeatW / 200));

    const maxAllowableSkinTempK = config.thermal.maxSkinTemperatureK.value || 1100;
    const peakObservedTemp = Math.max(noseTipTempK, fairingSkinTempK, interstageTempK);
    const thermalMarginK = maxAllowableSkinTempK - peakObservedTemp;
    const hotspotDetected = thermalMarginK < 50 || avionicsBayTempK > 340;

    return {
      noseTipTempK,
      fairingSkinTempK,
      stage1LoxTankSkinTempK,
      stage1FuelTankSkinTempK,
      interstageTempK,
      engineNozzleTempK,
      engineCombustionChamberTempK,
      avionicsBayTempK,
      aerodynamicHeatFluxKwM2: q_aero_KwM2,
      nozzleThroatHeatFluxMwM2: throatHeatFluxMw,
      maxAllowableTempK: maxAllowableSkinTempK,
      thermalMarginK,
      cryogenicBoiloffKgHr: boiloffKgHr,
      hotspotDetected,
    };
  }
}
