import { G0, getAtmosphereProperties } from './constants';
import { RocketSubsystemConfig } from '../models/rocket.model';

export interface PropulsionPerformance {
  stage1TotalThrustSeaLevelKn: number;
  stage1TotalThrustVacuumKn: number;
  stage1TotalMassFlowKgS: number;
  stage1LoxFlowKgS: number;
  stage1FuelFlowKgS: number;
  stage1ChamberPressureBar: number;
  stage1NozzleExitVelocitySLMs: number;
  stage1NozzleExitVelocityVacMs: number;
  stage1EffectiveIspSL: number;
  stage1EffectiveIspVac: number;
  stage1BurnDurationS: number;

  stage2TotalThrustVacuumKn: number;
  stage2TotalMassFlowKgS: number;
  stage2LoxFlowKgS: number;
  stage2FuelFlowKgS: number;
  stage2EffectiveIspVac: number;
  stage2BurnDurationS: number;

  stagedTsiolkovskyDeltaVMs: {
    stage1DeltaV: number;
    stage2DeltaV: number;
    totalDeltaV: number;
  };
}

export class PropulsionSolver {
  /**
   * Calculates instantaneous thrust and Isp at a given altitude
   */
  static calculateThrustAtAltitude(
    engineCount: number,
    thrustSLKn: number,
    thrustVacKn: number,
    ispSL: number,
    ispVac: number,
    altitudeM: number
  ): { thrustKn: number; currentIsp: number; massFlowKgS: number } {
    const atmo = getAtmosphereProperties(altitudeM);
    const ambientPressureRatio = atmo.pressurePa / 101325; // 1 at SL, 0 in vacuum

    // Linearly interpolate thrust & Isp based on ambient pressure reduction
    const thrustPerEngineKn = thrustVacKn - (thrustVacKn - thrustSLKn) * ambientPressureRatio;
    const currentIsp = ispVac - (ispVac - ispSL) * ambientPressureRatio;

    const totalThrustKn = thrustPerEngineKn * engineCount;
    // Mass flow mdot = F / (Isp * g0)
    const massFlowKgS = (totalThrustKn * 1000) / (currentIsp * G0);

    return {
      thrustKn: totalThrustKn,
      currentIsp,
      massFlowKgS,
    };
  }

  /**
   * Evaluates overall propulsion subsystem performance and staged delta-V
   */
  static evaluateSubsystem(
    config: RocketSubsystemConfig,
    dryMassKg: number,
    stage1DryMassKg: number,
    stage2DryMassKg: number,
    payloadMassKg: number
  ): PropulsionPerformance {
    const s1EngineCount = config.propulsion.stage1EngineCount.value;
    const s1ThrustSL = config.propulsion.stage1ThrustSeaLevelKn.value * s1EngineCount;
    const s1ThrustVac = config.propulsion.stage1ThrustVacuumKn.value * s1EngineCount;
    const s1IspSL = config.propulsion.stage1IspSeaLevelS.value;
    const s1IspVac = config.propulsion.stage1IspVacuumS.value;
    const s1PropMass = config.propulsion.stage1PropellantMassKg.value;
    const s1MR = config.propulsion.stage1MixtureRatio.value;

    const s1MassFlowSL = (s1ThrustSL * 1000) / (s1IspSL * G0);
    const s1LoxFlow = (s1MassFlowSL * s1MR) / (1 + s1MR);
    const s1FuelFlow = s1MassFlowSL / (1 + s1MR);
    const s1BurnTime = s1PropMass / Math.max(1, s1MassFlowSL);

    const s2EngineCount = config.propulsion.stage2EngineCount.value;
    const s2ThrustVac = config.propulsion.stage2ThrustVacuumKn.value * s2EngineCount;
    const s2IspVac = config.propulsion.stage2IspVacuumS.value;
    const s2PropMass = config.propulsion.stage2PropellantMassKg.value;
    const s2MassFlowVac = (s2ThrustVac * 1000) / (s2IspVac * G0);
    const s2LoxFlow = (s2MassFlowVac * s1MR) / (1 + s1MR);
    const s2FuelFlow = s2MassFlowVac / (1 + s1MR);
    const s2BurnTime = s2PropMass / Math.max(1, s2MassFlowVac);

    // Tsiolkovsky rocket equation:
    // Stage 1: m_initial = m_dry1 + m_prop1 + m_dry2 + m_prop2 + m_payload
    //          m_final = m_dry1 + m_dry2 + m_prop2 + m_payload
    const m_initial_s1 = stage1DryMassKg + s1PropMass + stage2DryMassKg + s2PropMass + payloadMassKg;
    const m_final_s1 = stage1DryMassKg + stage2DryMassKg + s2PropMass + payloadMassKg;
    const avgIsp_s1 = (s1IspSL + s1IspVac) / 2;
    const deltaV_s1 = avgIsp_s1 * G0 * Math.log(m_initial_s1 / Math.max(1, m_final_s1));

    // Stage 2: m_initial = m_dry2 + m_prop2 + m_payload
    //          m_final = m_dry2 + m_payload
    const m_initial_s2 = stage2DryMassKg + s2PropMass + payloadMassKg;
    const m_final_s2 = stage2DryMassKg + payloadMassKg;
    const deltaV_s2 = s2IspVac * G0 * Math.log(m_initial_s2 / Math.max(1, m_final_s2));

    return {
      stage1TotalThrustSeaLevelKn: s1ThrustSL,
      stage1TotalThrustVacuumKn: s1ThrustVac,
      stage1TotalMassFlowKgS: s1MassFlowSL,
      stage1LoxFlowKgS: s1LoxFlow,
      stage1FuelFlowKgS: s1FuelFlow,
      stage1ChamberPressureBar: config.propulsion.stage1ChamberPressureBar.value,
      stage1NozzleExitVelocitySLMs: s1IspSL * G0,
      stage1NozzleExitVelocityVacMs: s1IspVac * G0,
      stage1EffectiveIspSL: s1IspSL,
      stage1EffectiveIspVac: s1IspVac,
      stage1BurnDurationS: s1BurnTime,

      stage2TotalThrustVacuumKn: s2ThrustVac,
      stage2TotalMassFlowKgS: s2MassFlowVac,
      stage2LoxFlowKgS: s2LoxFlow,
      stage2FuelFlowKgS: s2FuelFlow,
      stage2EffectiveIspVac: s2IspVac,
      stage2BurnDurationS: s2BurnTime,

      stagedTsiolkovskyDeltaVMs: {
        stage1DeltaV: deltaV_s1,
        stage2DeltaV: deltaV_s2,
        totalDeltaV: deltaV_s1 + deltaV_s2,
      },
    };
  }
}
