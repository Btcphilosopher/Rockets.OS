import { CanonicalRocket } from '../models/rocket.model';
import { CandidateDesign, OptimizationWeights } from '../models/simulation.model';

export class OptimizerSolver {
  /**
   * Generates candidate designs and ranks them based on user-weighted multi-objective criteria
   */
  static runOptimization(
    currentRocket: CanonicalRocket,
    weights: OptimizationWeights = {
      minimizeMassWeight: 30,
      minimizeCostWeight: 20,
      minimizeCycleTimeWeight: 20,
      maximizePayloadWeight: 20,
      maximizeSafetyMarginWeight: 10,
      maximizeThroughputWeight: 0,
    }
  ): CandidateDesign[] {
    const baseDryMass = currentRocket.calculatedMassProperties.dryMassKg;
    const basePayload = currentRocket.config.payload.targetMassKg.value;

    const candidates: CandidateDesign[] = [
      {
        id: 'DESIGN_A',
        designName: 'Design Alpha: Ultra-Lightweight Carbon Composite',
        archetype: 'MINIMAL_MASS',
        score: 0,
        rank: 1,
        massSavingsKg: Math.round(baseDryMass * 0.18),
        costDeltaUsd: 14500000,
        manufacturingDays: 32,
        payloadCapacityKg: Math.round(basePayload * 1.22),
        safetyFactor: 1.48,
        keyChanges: [
          'Switch Stage 1 & 2 tank structure to IM7 / Cycom 5320-1 Toughened Carbon Epoxy',
          'Reduce skin thickness from 4.2mm to 2.8mm composite laminate',
          'Optimize dome polar boss titanium co-cured inserts',
          'Upgrade stage 2 nozzle to carbon-carbon radiative extension',
        ],
        tradeOffRationale: 'Maximizes payload capacity by +22% and reduces dry mass by 18%. Incurs higher raw material cost ($350/kg vs $120/kg) and requires cleanroom autoclave curing cycles.',
        configSnapshot: {
          material: 'IM7 Carbon Composite',
          skinThicknessMm: 2.8,
          engineCount: 9,
          propellantMassKg: currentRocket.config.propulsion.stage1PropellantMassKg.value,
          diameterM: currentRocket.config.geometry.coreDiameter.value,
        },
      },
      {
        id: 'DESIGN_B',
        designName: 'Design Bravo: High-Throughput Rapid Friction Stir Welded',
        archetype: 'BALANCED_PRODUCTION',
        score: 0,
        rank: 2,
        massSavingsKg: Math.round(baseDryMass * 0.06),
        costDeltaUsd: -4800000,
        manufacturingDays: 16,
        payloadCapacityKg: Math.round(basePayload * 1.05),
        safetyFactor: 1.62,
        keyChanges: [
          'Standardize on Al-Li 2195 barrel sections with automated robotic FSW gantries',
          'Orthogrid isogrid milling replaced with laser-welded stringer stiffeners',
          'Common bulkhead integration between LOX and fuel tanks',
          'Standardized engine powerpack mounts',
        ],
        tradeOffRationale: 'Cuts manufacturing cycle time by 50% (16 days vs 32 days) and unit cost by $4.8M while maintaining a robust 1.62 yield safety factor.',
        configSnapshot: {
          material: 'Al-Li 2195-T8',
          skinThicknessMm: 3.6,
          engineCount: 9,
          propellantMassKg: currentRocket.config.propulsion.stage1PropellantMassKg.value,
          diameterM: currentRocket.config.geometry.coreDiameter.value,
        },
      },
      {
        id: 'DESIGN_C',
        designName: 'Design Charlie: Stainless Cryo-Pressure Heavy Booster',
        archetype: 'LOW_COST_EXPENDABLE',
        score: 0,
        rank: 3,
        massSavingsKg: -Math.round(baseDryMass * 0.28), // heavier
        costDeltaUsd: -18200000,
        manufacturingDays: 12,
        payloadCapacityKg: Math.round(basePayload * 0.92),
        safetyFactor: 2.10,
        keyChanges: [
          'Switch to AISI 301 Full-Hard Stainless Steel sheet roll-welded construction',
          'Eliminate exterior TPS due to high high-temperature capability of steel (1120K)',
          'Increase tank operating pressure to 3.8 bar autogenous',
          'Expand core diameter from 5.5m to 5.8m to recover propellant volume',
        ],
        tradeOffRationale: 'Drastically cuts unit cost by $18.2M (-45%) with lowest material cost ($30/kg) and highest safety factor (2.10). Slightly heavier dry mass offsets payload to 92%.',
        configSnapshot: {
          material: 'AISI 301 Stainless',
          skinThicknessMm: 4.5,
          engineCount: 9,
          propellantMassKg: Math.round(currentRocket.config.propulsion.stage1PropellantMassKg.value * 1.12),
          diameterM: 5.8,
        },
      },
    ];

    // Compute weighted scores
    const totalWeight = Math.max(1, 
      weights.minimizeMassWeight + 
      weights.minimizeCostWeight + 
      weights.minimizeCycleTimeWeight + 
      weights.maximizePayloadWeight + 
      weights.maximizeSafetyMarginWeight + 
      weights.maximizeThroughputWeight
    );

    candidates.forEach((cand) => {
      const massScore = (cand.massSavingsKg > 0 ? 80 : 30) * (weights.minimizeMassWeight / totalWeight);
      const costScore = (cand.costDeltaUsd < 0 ? 95 : 40) * (weights.minimizeCostWeight / totalWeight);
      const timeScore = (60 / Math.max(1, cand.manufacturingDays)) * 30 * (weights.minimizeCycleTimeWeight / totalWeight);
      const payloadScore = ((cand.payloadCapacityKg / basePayload) * 60) * (weights.maximizePayloadWeight / totalWeight);
      const sfScore = (cand.safetyFactor / 1.5) * 50 * (weights.maximizeSafetyMarginWeight / totalWeight);

      cand.score = Number((massScore + costScore + timeScore + payloadScore + sfScore).toFixed(1));
    });

    candidates.sort((a, b) => b.score - a.score);
    candidates.forEach((cand, idx) => {
      cand.rank = idx + 1;
    });

    return candidates;
  }
}
