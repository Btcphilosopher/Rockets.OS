import { MaterialProperties, PropellantProperties, StructuralMaterialId, PropellantType } from '../models/rocket.model';

export const G0 = 9.80665; // Standard gravity m/s2
export const R_EARTH = 6371000; // Mean Earth radius m
export const M_EARTH = 5.9722e24; // Earth mass kg
export const G_CONSTANT = 6.67430e-11; // Gravitational constant m3/(kg*s2)
export const STEFAN_BOLTZMANN = 5.670374e-8; // W/(m2*K4)
export const R_AIR = 287.058; // Specific gas constant for air J/(kg*K)
export const GAMMA_AIR = 1.4;

export const MATERIALS_REGISTRY: Record<StructuralMaterialId, MaterialProperties> = {
  AL_LI_2195: {
    id: 'AL_LI_2195',
    name: 'Aluminum-Lithium 2195-T8',
    density: 2710,
    yieldStrength: 535,
    ultimateStrength: 580,
    youngsModulus: 76,
    thermalConductivity: 130,
    maxServiceTemp: 410,
    costPerKg: 120,
    weldability: 'EXCELLENT', // Friction Stir Weldable
    machinabilityIndex: 0.85,
  },
  CARBON_COMPOSITE: {
    id: 'CARBON_COMPOSITE',
    name: 'IM7 / Cycom 5320-1 Toughened Epoxy',
    density: 1560,
    yieldStrength: 850,
    ultimateStrength: 1950,
    youngsModulus: 145,
    thermalConductivity: 5,
    maxServiceTemp: 450,
    costPerKg: 350,
    weldability: 'SPECIALIZED', // Co-cured / bonded
    machinabilityIndex: 0.45,
  },
  STAINLESS_301: {
    id: 'STAINLESS_301',
    name: 'Full-Hard AISI 301 Stainless Steel',
    density: 7900,
    yieldStrength: 965,
    ultimateStrength: 1275,
    youngsModulus: 193,
    thermalConductivity: 16.2,
    maxServiceTemp: 1120,
    costPerKg: 30,
    weldability: 'EXCELLENT',
    machinabilityIndex: 0.60,
  },
  INCONEL_718: {
    id: 'INCONEL_718',
    name: 'Inconel 718 Superalloy (DMLS / Forged)',
    density: 8190,
    yieldStrength: 1100,
    ultimateStrength: 1375,
    youngsModulus: 205,
    thermalConductivity: 11.4,
    maxServiceTemp: 1255,
    costPerKg: 280,
    weldability: 'GOOD',
    machinabilityIndex: 0.35,
  },
  TITANIUM_6AL4V: {
    id: 'TITANIUM_6AL4V',
    name: 'Titanium Grade 5 (Ti-6Al-4V)',
    density: 4430,
    yieldStrength: 880,
    ultimateStrength: 950,
    youngsModulus: 114,
    thermalConductivity: 6.7,
    maxServiceTemp: 673,
    costPerKg: 195,
    weldability: 'GOOD',
    machinabilityIndex: 0.40,
  },
};

export const PROPELLANTS_REGISTRY: Record<PropellantType, PropellantProperties> = {
  LOX_RP1: {
    type: 'LOX_RP1',
    name: 'Liquid Oxygen / RP-1 Kerosene',
    oxidizerName: 'LOX (90K)',
    fuelName: 'RP-1 Rocket Propellant 1',
    oxidizerDensity: 1141,
    fuelDensity: 810,
    nominalMixtureRatio: 2.56,
    nominalSeaLevelIsp: 282,
    nominalVacuumIsp: 311,
    flameTemperature: 3670,
    molecularWeight: 22.1,
    gamma: 1.24,
  },
  LOX_METHANE: {
    type: 'LOX_METHANE',
    name: 'Liquid Oxygen / Liquid Methane (Methalox)',
    oxidizerName: 'LOX (90K)',
    fuelName: 'LCH4 (111K)',
    oxidizerDensity: 1141,
    fuelDensity: 422,
    nominalMixtureRatio: 3.55,
    nominalSeaLevelIsp: 327,
    nominalVacuumIsp: 363,
    flameTemperature: 3550,
    molecularWeight: 20.3,
    gamma: 1.22,
  },
  LOX_LH2: {
    type: 'LOX_LH2',
    name: 'Liquid Oxygen / Liquid Hydrogen (Hydrolox)',
    oxidizerName: 'LOX (90K)',
    fuelName: 'LH2 (20K)',
    oxidizerDensity: 1141,
    fuelDensity: 71,
    nominalMixtureRatio: 5.50,
    nominalSeaLevelIsp: 366,
    nominalVacuumIsp: 452,
    flameTemperature: 3250,
    molecularWeight: 14.5,
    gamma: 1.26,
  },
  N2O4_UDMH: {
    type: 'N2O4_UDMH',
    name: 'Dinitrogen Tetroxide / UDMH (Hypergolic)',
    oxidizerName: 'N2O4',
    fuelName: 'UDMH',
    oxidizerDensity: 1442,
    fuelDensity: 793,
    nominalMixtureRatio: 2.15,
    nominalSeaLevelIsp: 275,
    nominalVacuumIsp: 318,
    flameTemperature: 3410,
    molecularWeight: 24.8,
    gamma: 1.25,
  },
};

/**
 * 1976 US Standard Atmosphere Model
 * Returns: temperature (K), pressure (Pa), density (kg/m3), speed of sound (m/s)
 */
export function getAtmosphereProperties(altitudeM: number): {
  temperatureK: number;
  pressurePa: number;
  densityKgM3: number;
  speedOfSoundMs: number;
} {
  const h = Math.max(0, altitudeM);

  let T = 288.15;
  let p = 101325;
  const p0 = 101325;
  const T0 = 288.15;

  if (h <= 11000) {
    // Troposphere
    const lapseRate = -0.0065;
    T = T0 + lapseRate * h;
    p = p0 * Math.pow(T / T0, -G0 / (lapseRate * R_AIR));
  } else if (h <= 20000) {
    // Tropopause
    const T11 = 216.65;
    const p11 = 22632.1;
    T = T11;
    p = p11 * Math.exp(-G0 * (h - 11000) / (R_AIR * T11));
  } else if (h <= 32000) {
    // Stratosphere 1
    const T20 = 216.65;
    const p20 = 5474.89;
    const lapseRate = 0.001;
    T = T20 + lapseRate * (h - 20000);
    p = p20 * Math.pow(T / T20, -G0 / (lapseRate * R_AIR));
  } else if (h <= 47000) {
    // Stratosphere 2
    const T32 = 228.65;
    const p32 = 868.02;
    const lapseRate = 0.0028;
    T = T32 + lapseRate * (h - 32000);
    p = p32 * Math.pow(T / T32, -G0 / (lapseRate * R_AIR));
  } else if (h <= 51000) {
    // Stratopause
    const T47 = 270.65;
    const p47 = 110.91;
    T = T47;
    p = p47 * Math.exp(-G0 * (h - 47000) / (R_AIR * T47));
  } else if (h <= 71000) {
    // Mesosphere 1
    const T51 = 270.65;
    const p51 = 66.94;
    const lapseRate = -0.0028;
    T = T51 + lapseRate * (h - 51000);
    p = p51 * Math.pow(T / T51, -G0 / (lapseRate * R_AIR));
  } else if (h <= 84852) {
    // Mesosphere 2
    const T71 = 214.65;
    const p71 = 3.96;
    const lapseRate = -0.002;
    T = T71 + lapseRate * (h - 71000);
    p = p71 * Math.pow(T / T71, -G0 / (lapseRate * R_AIR));
  } else {
    // Exosphere / Vacuum approximation
    const scaleHeight = 7200;
    T = 186.87;
    p = 0.3734 * Math.exp(-(h - 84852) / scaleHeight);
  }

  // Clamping for numerical stability in vacuum
  p = Math.max(1e-7, p);
  T = Math.max(2.7, T);
  const density = p / (R_AIR * T);
  const a = Math.sqrt(GAMMA_AIR * R_AIR * T);

  return {
    temperatureK: T,
    pressurePa: p,
    densityKgM3: density,
    speedOfSoundMs: a,
  };
}
