import { getAtmosphereProperties } from './constants';
import { RocketSubsystemConfig } from '../models/rocket.model';

export interface AerodynamicState {
  altitudeM: number;
  velocityMs: number;
  machNumber: number;
  dynamicPressureKPa: number;
  dragCoefficient: number;
  dragForceKn: number;
  normalForceKn: number;
  liftForceKn: number;
  centerOfPressureFromNoseM: number;
  centerOfGravityFromNoseM: number;
  staticMarginCalibers: number;
  isStaticallyStable: boolean;
  bowShockAngleDeg: number;
}

export class AerodynamicsSolver {
  /**
   * Evaluates drag coefficient as a function of Mach number
   */
  static getDragCoefficient(mach: number, config: RocketSubsystemConfig): number {
    const cdSub = config.aerodynamics.dragCoefficientSubsonic.value || 0.22;
    const cdTrans = config.aerodynamics.dragCoefficientTransonic.value || 0.58;
    const cdSuper = config.aerodynamics.dragCoefficientSupersonic.value || 0.38;

    if (mach < 0.8) {
      // Subsonic regime: mild skin friction variation
      return cdSub + 0.05 * Math.pow(mach / 0.8, 2);
    } else if (mach <= 1.2) {
      // Transonic wave drag shock formation
      const t = (mach - 0.8) / 0.4;
      return cdSub + (cdTrans - cdSub) * Math.sin(t * Math.PI * 0.5);
    } else if (mach <= 5.0) {
      // Supersonic regime: asymptotic decay
      return cdSuper + (cdTrans - cdSuper) / Math.sqrt(Math.max(1.1, Math.pow(mach, 2) - 1));
    } else {
      // Hypersonic modified Newtonian flow
      return cdSuper * 0.75 + 0.05;
    }
  }

  /**
   * Calculates aerodynamic state at a given flight condition
   */
  static calculateAeroState(
    altitudeM: number,
    velocityMs: number,
    angleAttackDeg: number,
    config: RocketSubsystemConfig,
    cgFromNoseM: number
  ): AerodynamicState {
    const atmo = getAtmosphereProperties(altitudeM);
    const mach = velocityMs / Math.max(1, atmo.speedOfSoundMs);
    const q_Pa = 0.5 * atmo.densityKgM3 * Math.pow(velocityMs, 2);
    const q_KPa = q_Pa / 1000;

    const diameter = config.geometry.coreDiameter.value;
    const refAreaM2 = Math.PI * Math.pow(diameter / 2, 2);

    const cd = this.getDragCoefficient(mach, config);
    const dragForceN = q_Pa * refAreaM2 * cd;

    // Barrowman-derived normal force slope & CP:
    // Nose cone contribution
    const noseLength = config.geometry.fairingHeight.value;
    const noseXcp = noseLength * 0.466; // For Von Karman / parabolic
    const noseCNa = 2.0;

    // Fins contribution (if equipped)
    const finCount = config.geometry.finCount.value;
    const finSpan = config.geometry.finSpan.value;
    const rootChord = config.geometry.finRootChord.value;
    const tipChord = config.geometry.finTipChord.value;
    const totalHeight = config.geometry.totalHeight.value;

    let totalCNa = noseCNa;
    let weightedCP = noseCNa * noseXcp;

    if (finCount >= 3 && finSpan > 0) {
      const finAreaOne = 0.5 * (rootChord + tipChord) * finSpan;
      const finAspect = (2 * Math.pow(finSpan, 2)) / Math.max(0.1, finAreaOne);
      const finCNa1 = (2 * Math.PI * finAspect) / (2 + Math.sqrt(4 + Math.pow(finAspect, 2)));
      const finInterference = 1 + (diameter / (2 * finSpan + diameter));
      const finTotalCNa = finCNa1 * finInterference * (finCount / 2);

      const finXb = totalHeight - rootChord;
      const finXcp = finXb + (rootChord / 3) * ((rootChord + 2 * tipChord) / (rootChord + tipChord));

      totalCNa += finTotalCNa;
      weightedCP += finTotalCNa * finXcp;
    }

    const cpFromNoseM = weightedCP / Math.max(0.1, totalCNa);

    const alphaRad = (angleAttackDeg * Math.PI) / 180;
    const normalForceN = q_Pa * refAreaM2 * totalCNa * alphaRad;
    const liftForceN = normalForceN * Math.cos(alphaRad) - dragForceN * Math.sin(alphaRad);

    // Static margin: (X_cp - X_cg) / Diameter
    // Positive when CP is behind CG (stable)
    const staticMarginCalibers = (cpFromNoseM - cgFromNoseM) / diameter;

    // Mach angle for shockwave cone
    let bowShockAngleDeg = 90;
    if (mach > 1.0) {
      const muRad = Math.asin(1 / mach);
      bowShockAngleDeg = (muRad * 180) / Math.PI;
    }

    return {
      altitudeM,
      velocityMs,
      machNumber: mach,
      dynamicPressureKPa: q_KPa,
      dragCoefficient: cd,
      dragForceKn: dragForceN / 1000,
      normalForceKn: normalForceN / 1000,
      liftForceKn: liftForceN / 1000,
      centerOfPressureFromNoseM: cpFromNoseM,
      centerOfGravityFromNoseM: cgFromNoseM,
      staticMarginCalibers,
      isStaticallyStable: staticMarginCalibers > 0.5, // 1.0-2.0 calibers is nominal aerospace margin
      bowShockAngleDeg,
    };
  }
}
