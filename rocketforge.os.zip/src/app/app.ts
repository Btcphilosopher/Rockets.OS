import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderBar, AppWorkstationView } from './components/header-bar/header-bar';
import { Viewport3d } from './components/viewport-3d/viewport-3d';
import { SubsystemInspector } from './components/subsystem-inspector/subsystem-inspector';
import { ParametricDesigner } from './components/parametric-designer/parametric-designer';
import { ManufacturingView } from './components/manufacturing-view/manufacturing-view';
import { TelemetryDashboard } from './components/telemetry-dashboard/telemetry-dashboard';
import { MonteCarloView } from './components/monte-carlo-view/monte-carlo-view';
import { AuditQaView } from './components/audit-qa-view/audit-qa-view';
import { DigitalTwinService } from './core/services/digital-twin.service';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    HeaderBar,
    Viewport3d,
    SubsystemInspector,
    ParametricDesigner,
    ManufacturingView,
    TelemetryDashboard,
    MonteCarloView,
    AuditQaView,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly digitalTwin = inject(DigitalTwinService);
  readonly currentView = signal<AppWorkstationView>('VIEWPORT_3D');

  onViewChange(view: AppWorkstationView): void {
    this.currentView.set(view);
  }
}
