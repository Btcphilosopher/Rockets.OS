import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TelemetryService } from '../../core/services/telemetry.service';
import { SimulationClockService } from '../../core/services/simulation-clock.service';
import { FaultId } from '../../core/models/simulation.model';

@Component({
  selector: 'app-telemetry-dashboard',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0D1117] border border-[#1F2937] rounded-lg overflow-hidden font-mono text-xs shadow-2xl">
      <!-- Master Flight Simulation Controls & Clock -->
      <div class="p-3 bg-[#0D1117] border-b border-[#1F2937] flex flex-wrap items-center justify-between gap-3">
        <div class="flex items-center gap-3">
          <div class="flex items-center gap-2">
            <span class="w-2.5 h-2.5 rounded-sm bg-cyan-400 animate-pulse shadow-[0_0_8px_rgba(34,211,238,0.5)]"></span>
            <div>
              <div class="text-xs font-bold text-slate-100 uppercase tracking-wider">REAL-TIME FLIGHT TELEMETRY & GNC STREAM</div>
              <div class="text-[9px] text-slate-400">TRAJECTORY SOLVER: 5 Hz INTEGRATOR • HIGH-FIDELITY FLIGHT DYNAMICS</div>
            </div>
          </div>
          <div class="px-2.5 py-1 bg-[#161B22] border border-[#1F2937] rounded text-cyan-400 font-bold text-xs">
            {{ clock.formattedTime() }}
          </div>
        </div>

        <div class="flex items-center gap-2">
          <!-- Play / Pause -->
          <button 
            (click)="toggleFlightSim()"
            [class.bg-amber-500]="clock.isRunning()"
            [class.text-slate-950]="clock.isRunning()"
            [class.bg-cyan-500]="!clock.isRunning()"
            [class.text-slate-950]="!clock.isRunning()"
            class="px-3 py-1 font-bold rounded flex items-center gap-1.5 transition text-xs shadow-[0_0_12px_rgba(34,211,238,0.3)]">
            @if (clock.isRunning()) {
              <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
              <span>HOLD</span>
            } @else {
              <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
              <span>LAUNCH</span>
            }
          </button>

          <!-- Time Warp Multiplier Buttons -->
          <div class="flex bg-[#161B22] border border-[#1F2937] rounded overflow-hidden">
            @for (speed of [1, 2, 5, 10]; track speed) {
              <button 
                (click)="clock.setTimeWarp(speed)"
                [class.bg-cyan-500]="clock.timeWarp() === speed"
                [class.text-slate-950]="clock.timeWarp() === speed"
                [class.font-bold]="clock.timeWarp() === speed"
                [class.text-slate-300]="clock.timeWarp() !== speed"
                class="px-2 py-1 text-[11px] transition">
                {{ speed }}x
              </button>
            }
          </div>

          <!-- Reset -->
          <button 
            (click)="resetFlightSim()"
            class="px-2.5 py-1 bg-[#161B22] hover:bg-[#1F2937] text-slate-300 rounded border border-[#1F2937] text-xs">
            Reset
          </button>

          <!-- Export CSV -->
          <button 
            (click)="exportCsv()"
            class="px-2.5 py-1 bg-[#161B22] hover:bg-[#1F2937] text-cyan-400 rounded border border-[#1F2937] text-xs flex items-center gap-1">
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
            CSV
          </button>
        </div>
      </div>

      <!-- Live Flight Scrub Bar -->
      <div class="px-4 py-2 bg-[#0A0C10] border-b border-[#1F2937] flex items-center gap-3">
        <label for="timeScrubRange" class="text-[9px] text-slate-400 uppercase">SCRUB:</label>
        <input 
          id="timeScrubRange"
          type="range" 
          min="0" 
          [max]="600" 
          step="0.5"
          [value]="clock.currentTimeS()"
          (input)="onScrubChange($event)"
          class="w-full accent-cyan-400 cursor-pointer">
        <span class="text-slate-400 text-[10px] w-24 text-right font-mono">
          {{ clock.currentTimeS().toFixed(0) }} / 600s
        </span>
      </div>

      <!-- Live Flight Event Sequence Tag Bar -->
      <div class="p-2 bg-[#0D1117] border-b border-[#1F2937] flex items-center gap-2 overflow-x-auto">
        <span class="text-[9px] text-slate-400 uppercase">STAGE:</span>
        <span class="px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300 font-bold text-xs uppercase">
          {{ telemetry.currentFrame().stage }}
        </span>
        @if (telemetry.activeFault().id !== 'NONE') {
          <span class="px-2 py-0.5 rounded bg-rose-950 border border-rose-500/40 text-rose-300 font-bold text-xs uppercase animate-pulse">
            FAULT: {{ telemetry.activeFault().name }}
          </span>
        }
      </div>

      <!-- Primary Telemetry Gauges Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 p-3 bg-[#0A0C10] border-b border-[#1F2937]">
        <!-- Altitude -->
        <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
          <div class="text-[9px] text-slate-400 uppercase">Altitude</div>
          <div class="text-sm font-bold text-cyan-400">{{ (telemetry.currentFrame().altitudeM / 1000).toFixed(2) }} km</div>
          <div class="text-[9px] text-slate-500">{{ telemetry.currentFrame().altitudeM.toFixed(0) }} m</div>
        </div>

        <!-- Velocity -->
        <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
          <div class="text-[9px] text-slate-400 uppercase">Inertial Velocity</div>
          <div class="text-sm font-bold text-emerald-400">{{ telemetry.currentFrame().velocityMs.toFixed(1) }} m/s</div>
          <div class="text-[9px] text-slate-500">Mach {{ telemetry.currentFrame().machNumber.toFixed(2) }}</div>
        </div>

        <!-- Dynamic Pressure (Q) -->
        <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
          <div class="text-[9px] text-slate-400 uppercase">Dynamic Pressure (Q)</div>
          <div class="text-sm font-bold text-amber-400">{{ telemetry.currentFrame().dynamicPressureKPa.toFixed(1) }} kPa</div>
          <div class="text-[9px] text-slate-500">Limit: 45.0 kPa</div>
        </div>

        <!-- G-Force -->
        <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
          <div class="text-[9px] text-slate-400 uppercase">Axial Acceleration</div>
          <div class="text-sm font-bold text-slate-200">{{ telemetry.currentFrame().accelerationG.toFixed(2) }} G</div>
          <div class="text-[9px] text-slate-500">Max Limit: 5.5 G</div>
        </div>

        <!-- Thrust -->
        <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
          <div class="text-[9px] text-slate-400 uppercase">Total Thrust</div>
          <div class="text-sm font-bold text-cyan-300">
            {{ (telemetry.currentFrame().stage1ThrustKn + telemetry.currentFrame().stage2ThrustKn).toFixed(0) }} kN
          </div>
          <div class="text-[9px] text-slate-500">S1: {{ telemetry.currentFrame().stage1ThrustKn.toFixed(0) }} kN</div>
        </div>

        <!-- Vehicle Mass & Propellant -->
        <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
          <div class="text-[9px] text-slate-400 uppercase">Vehicle Mass</div>
          <div class="text-sm font-bold text-slate-200">{{ (telemetry.currentFrame().totalMassKg / 1000).toFixed(1) }} t</div>
          <div class="text-[9px] text-slate-500">SF: {{ telemetry.currentFrame().safetyFactor.toFixed(2) }}</div>
        </div>
      </div>

      <!-- Main Body: Trajectory Graph & Fault Injection Panel -->
      <div class="flex-1 overflow-y-auto p-4 grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- Trajectory Chart (SVG based) -->
        <div class="lg:col-span-8 p-3 bg-[#161B22] border border-[#1F2937] rounded-lg space-y-3">
          <div class="flex items-center justify-between text-xs text-slate-200 font-bold">
            <span>TRAJECTORY PROFILE: ALTITUDE vs TIME</span>
            <span class="text-cyan-400 text-[10px]">APOGEE: {{ telemetry.trajectoryData().finalOrbitApogeeKm }} KM</span>
          </div>

          <!-- SVG Chart Area -->
          <div class="w-full h-52 bg-[#0D1117] rounded border border-[#1F2937] relative overflow-hidden p-2">
            <svg class="w-full h-full" viewBox="0 0 500 180" preserveAspectRatio="none">
              <!-- Grid Lines -->
              <line x1="0" y1="45" x2="500" y2="45" stroke="#1F2937" stroke-dasharray="2,2"/>
              <line x1="0" y1="90" x2="500" y2="90" stroke="#1F2937" stroke-dasharray="2,2"/>
              <line x1="0" y1="135" x2="500" y2="135" stroke="#1F2937" stroke-dasharray="2,2"/>

              <!-- Altitude Curve -->
              <path 
                d="M 0 170 C 100 165, 180 140, 260 80 C 340 30, 420 15, 500 10" 
                fill="none" 
                stroke="#22d3ee" 
                stroke-width="2.5" />

              <!-- Dynamic Pressure Q Curve -->
              <path 
                d="M 0 170 C 40 160, 60 70, 90 60 C 120 70, 160 140, 260 170" 
                fill="none" 
                stroke="#f59e0b" 
                stroke-width="1.5"
                stroke-dasharray="4,4" />

              <!-- Current Position Marker -->
              <circle 
                [attr.cx]="Math.min(500, Math.max(0, (telemetry.currentFrame().timeS / 600) * 500))" 
                [attr.cy]="Math.max(5, 170 - (telemetry.currentFrame().altitudeM / 220000) * 160)" 
                r="5" 
                fill="#22d3ee" 
                stroke="#ffffff" 
                stroke-width="2" />
            </svg>
          </div>

          <div class="flex justify-between text-[10px] text-slate-400">
            <span class="flex items-center gap-1.5"><span class="w-3 h-0.5 bg-cyan-400 inline-block"></span> Altitude (m)</span>
            <span class="flex items-center gap-1.5"><span class="w-3 h-0.5 bg-amber-400 inline-block"></span> Dynamic Pressure Q (kPa)</span>
            <span>T+0s (Liftoff) → T+600s (SECO-1 Orbit)</span>
          </div>
        </div>

        <!-- Fault Injection & Stress Panel -->
        <div class="lg:col-span-4 p-3 bg-[#161B22] border border-[#1F2937] rounded-lg space-y-3">
          <div class="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center justify-between">
            <span>Fault Injection Sandbox</span>
            <span class="text-[9px] px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-500/30">MONTE CARLO READY</span>
          </div>

          <div class="text-[11px] text-slate-400 leading-relaxed">
            Select a failure mode to inject into the live simulation stream:
          </div>

          <div class="space-y-1.5">
            <label for="faultSelector" class="block text-slate-400 text-[10px] uppercase">Failure Mode Trigger:</label>
            <select 
              id="faultSelector"
              [value]="selectedFault()"
              (change)="onSelectFault($event)"
              class="w-full bg-[#0D1117] border border-[#1F2937] rounded p-1.5 text-slate-200 text-xs font-mono focus:border-cyan-400 focus:outline-none">
              @for (f of telemetry.availableFaults; track f.id) {
                <option [value]="f.id">{{ f.name }}</option>
              }
            </select>
          </div>

          <div class="flex gap-2 pt-2">
            <button 
              (click)="injectSelectedFault()"
              class="flex-1 px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded text-xs transition">
              Inject Fault
            </button>
            <button 
              (click)="clearFault()"
              class="px-3 py-1.5 bg-[#0D1117] hover:bg-[#161B22] text-slate-300 border border-[#1F2937] rounded text-xs">
              Clear
            </button>
          </div>

          <!-- Active Fault Alert Display -->
          @if (telemetry.activeFault().id !== 'NONE') {
            <div class="p-2.5 bg-rose-950/60 border border-rose-500/50 rounded text-rose-200 text-[11px] space-y-1">
              <div class="font-bold flex items-center gap-1.5">
                <span class="w-2 h-2 rounded-full bg-rose-400 animate-ping"></span>
                ACTIVE ANOMALY DETECTED
              </div>
              <div>{{ telemetry.activeFault().description }}</div>
              <div class="text-[10px] text-rose-300 font-semibold">Signature: {{ telemetry.activeFault().telemetrySignature }}</div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `]
})
export class TelemetryDashboard {
  readonly telemetry = inject(TelemetryService);
  readonly clock = inject(SimulationClockService);

  readonly selectedFault = signal<FaultId>('NONE');
  readonly Math = Math;

  toggleFlightSim(): void {
    if (this.clock.isRunning()) {
      this.clock.pause();
    } else {
      this.clock.start();
    }
  }

  resetFlightSim(): void {
    this.clock.reset();
  }

  onScrubChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.clock.seek(val);
  }

  onSelectFault(event: Event): void {
    const val = (event.target as HTMLSelectElement).value as FaultId;
    this.selectedFault.set(val);
  }

  injectSelectedFault(): void {
    this.telemetry.injectFault(this.selectedFault());
  }

  clearFault(): void {
    this.selectedFault.set('NONE');
    this.telemetry.injectFault('NONE');
  }

  exportCsv(): void {
    const csv = this.telemetry.exportTelemetryCsv();
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RocketForge_Telemetry_T${this.telemetry.currentFrame().timeS.toFixed(0)}s.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  }
}

