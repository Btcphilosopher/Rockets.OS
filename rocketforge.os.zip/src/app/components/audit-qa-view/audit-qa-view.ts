import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-audit-qa-view',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0D1117] border border-[#1F2937] rounded-lg overflow-hidden font-mono text-xs shadow-2xl">
      <!-- Header -->
      <div class="p-3 bg-[#0D1117] border-b border-[#1F2937] flex flex-wrap items-center justify-between gap-3">
        <div class="flex items-center gap-2">
          <span class="w-2.5 h-2.5 rounded-sm bg-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.5)]"></span>
          <div>
            <div class="text-xs font-bold text-slate-100 uppercase tracking-wider">DIGITAL TWIN AUDIT TRAIL, QUALITY ASSURANCE & NDT LOGS</div>
            <div class="text-[9px] text-slate-400">NASA-STD-5009 COMPLIANT • CRYPTOGRAPHIC REVISION TRACEABILITY</div>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <button 
            (click)="exportDigitalTwinJson()"
            class="px-3 py-1 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded text-xs flex items-center gap-1.5 transition shadow-[0_0_12px_rgba(34,211,238,0.3)]">
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
            Export Complete Digital Twin (.JSON)
          </button>
        </div>
      </div>

      <!-- Main Audit Content -->
      <div class="flex-1 overflow-y-auto p-4 grid grid-cols-1 lg:grid-cols-2 gap-4">
        <!-- Left: Revision History & Engineering Change Orders (ECO) -->
        <div class="space-y-3">
          <div class="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center justify-between">
            <span>Engineering Revision Log (ECO History)</span>
            <span class="text-cyan-400 text-[10px]">CURRENT REV: {{ digitalTwin.rocket().digitalTwin.revision }}</span>
          </div>

          <div class="space-y-2 max-h-[600px] overflow-y-auto pr-1">
            @for (rev of digitalTwin.rocket().digitalTwin.revisionHistory; track rev.revision) {
              <div class="p-3 bg-[#161B22] border border-[#1F2937] rounded-md space-y-1.5 hover:border-slate-600 transition">
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-2">
                    <span class="px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-500/30 font-bold text-xs">
                      {{ rev.revision }}
                    </span>
                    <span class="font-bold text-slate-200 text-xs">{{ rev.author }}</span>
                  </div>
                  <span class="text-[10px] text-slate-400">{{ rev.timestamp | date:'medium' }}</span>
                </div>

                <div class="text-[11px] text-slate-300 leading-relaxed">
                  {{ rev.description }}
                </div>

                <div class="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-[#1F2937]">
                  <span>HASH: <strong class="text-slate-300">{{ rev.parameterHash }}</strong></span>
                  @if (rev.summaryMetrics) {
                    <span>
                      MASS: <strong class="text-cyan-400">{{ rev.summaryMetrics.liftoffMassKg | number }} kg</strong> | 
                      DV: <strong class="text-emerald-400">{{ rev.summaryMetrics.totalDeltaVMs | number }} m/s</strong>
                    </span>
                  }
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Right: Non-Destructive Testing (NDT) Quality Inspection Database -->
        <div class="space-y-3">
          <div class="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center justify-between">
            <span>Component NDT Inspection Metrology</span>
            <span class="text-emerald-400 text-[10px]">ALL 4 GATES PASSED</span>
          </div>

          <div class="space-y-2 max-h-[600px] overflow-y-auto pr-1">
            @for (insp of digitalTwin.rocket().inspections; track insp.id) {
              <div class="p-3 bg-[#161B22] border border-[#1F2937] rounded-md space-y-2">
                <div class="flex items-center justify-between">
                  <div>
                    <div class="font-bold text-slate-200 text-xs">{{ insp.componentName }}</div>
                    <div class="text-[10px] text-slate-400">{{ insp.id }} • {{ insp.process }}</div>
                  </div>
                  <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/30 font-bold text-[10px]">
                    {{ insp.status }}
                  </span>
                </div>

                <div class="text-[11px] text-slate-300 leading-relaxed bg-[#0D1117] p-2 rounded border border-[#1F2937]">
                  {{ insp.notes }}
                </div>

                <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px] text-slate-400 pt-1">
                  <div>METHOD: <span class="text-slate-200 font-semibold">{{ insp.ndtMethod }}</span></div>
                  <div>NOMINAL: <span class="text-slate-200">{{ insp.nominalDimensionMm }} mm</span></div>
                  <div>MEASURED: <span class="text-emerald-400 font-semibold">{{ insp.measuredDimensionMm }} mm</span></div>
                  <div>DEV: <span class="text-slate-200">±{{ (insp.measuredDimensionMm - insp.nominalDimensionMm).toFixed(2) }} mm</span></div>
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `]
})
export class AuditQaView {
  readonly digitalTwin = inject(DigitalTwinService);

  exportDigitalTwinJson(): void {
    const data = JSON.stringify(this.digitalTwin.rocket(), null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RocketForge_DigitalTwin_${this.digitalTwin.rocket().digitalTwin.revision}_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    window.URL.revokeObjectURL(url);
  }
}

