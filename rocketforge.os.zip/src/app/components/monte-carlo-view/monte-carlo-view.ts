import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonteCarloSolver } from '../../core/physics/monte-carlo-solver';
import { OptimizerSolver } from '../../core/physics/optimizer-solver';
import { DigitalTwinService } from '../../core/services/digital-twin.service';
import { MonteCarloAnalysisResult, CandidateDesign } from '../../core/models/simulation.model';

@Component({
  selector: 'app-monte-carlo-view',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0D1117] border border-[#1F2937] rounded-lg overflow-hidden font-mono text-xs shadow-2xl">
      <!-- Header Bar -->
      <div class="p-3 bg-[#0D1117] border-b border-[#1F2937] flex flex-wrap items-center justify-between gap-3">
        <div class="flex items-center gap-2">
          <span class="w-2.5 h-2.5 rounded-sm bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.5)]"></span>
          <div>
            <div class="text-xs font-bold text-slate-100 uppercase tracking-wider">MONTE CARLO STOCHASTIC ENGINE & DESIGN TRADE OPTIMIZER</div>
            <div class="text-[9px] text-slate-400">MULBERRY32 DETERMINISTIC PRNG • 3-SIGMA MARGIN VERIFICATION</div>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <div class="flex bg-[#161B22] border border-[#1F2937] rounded overflow-hidden">
            @for (n of [100, 500, 1000]; track n) {
              <button 
                (click)="runMonteCarlo(n)"
                [class.bg-cyan-500]="iterationCount() === n"
                [class.text-slate-950]="iterationCount() === n"
                [class.font-bold]="iterationCount() === n"
                [class.text-slate-300]="iterationCount() !== n"
                class="px-3 py-1 text-xs transition">
                {{ n }} Iterations
              </button>
            }
          </div>
          <button 
            (click)="runTradeStudy()"
            class="px-3 py-1 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded text-xs transition shadow-[0_0_12px_rgba(34,211,238,0.3)]">
            Re-run Pareto Optimizer
          </button>
        </div>
      </div>

      <!-- Monte Carlo Summary Metrics -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 p-3 bg-[#0A0C10] border-b border-[#1F2937]">
        <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
          <div class="text-[9px] text-slate-400 uppercase">Mission Success Rate</div>
          <div class="text-sm font-bold text-emerald-400">{{ mcResults().successProbabilityPercent }}%</div>
          <div class="text-[9px] text-slate-500">3-Sigma Req: >98%</div>
        </div>
        <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
          <div class="text-[9px] text-slate-400 uppercase">Mean Apogee (μ ± 1σ)</div>
          <div class="text-sm font-bold text-cyan-400">{{ mcResults().meanApogeeKm }} ± {{ mcResults().stdDevApogeeKm }} km</div>
          <div class="text-[9px] text-slate-500">Target: 250 km Orbit</div>
        </div>
        <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
          <div class="text-[9px] text-slate-400 uppercase">Peak Dynamic P (Max-Q)</div>
          <div class="text-sm font-bold text-amber-400">{{ mcResults().meanMaxQ_kPa }} kPa (99th: {{ mcResults().p99MaxQ_kPa }} kPa)</div>
          <div class="text-[9px] text-slate-500">Design Limit: 45.0 kPa</div>
        </div>
        <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
          <div class="text-[9px] text-slate-400 uppercase">Min Structural Safety Factor</div>
          <div class="text-sm font-bold text-slate-100">{{ mcResults().meanSafetyFactor }} SF (1st %ile: {{ mcResults().p01MinSafetyFactor }})</div>
          <div class="text-[9px] text-emerald-400">Zero Structural Failures</div>
        </div>
      </div>

      <!-- Main Content: Scatter / Dispersion Plots and Pareto Trade Study -->
      <div class="flex-1 overflow-y-auto p-4 grid grid-cols-1 lg:grid-cols-2 gap-4">
        <!-- Left: Stochastic Flight Dispersion Scatter Plot -->
        <div class="bg-[#161B22] border border-[#1F2937] rounded-lg p-4 flex flex-col space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-200 uppercase tracking-wider">Flight Trajectory Dispersion Scatter</span>
            <span class="text-[10px] text-slate-400">Apogee vs. Max-Q (N = {{ mcResults().totalRuns }})</span>
          </div>

          <!-- Scatter SVG Chart -->
          <div class="relative w-full h-64 bg-[#0D1117] border border-[#1F2937] rounded flex items-center justify-center overflow-hidden">
            <svg class="w-full h-full p-6 overflow-visible" viewBox="0 0 400 200">
              <!-- Grid Lines -->
              <line x1="40" y1="20" x2="380" y2="20" stroke="#1F2937" stroke-dasharray="2,2" />
              <line x1="40" y1="60" x2="380" y2="60" stroke="#1F2937" stroke-dasharray="2,2" />
              <line x1="40" y1="100" x2="380" y2="100" stroke="#1F2937" stroke-dasharray="2,2" />
              <line x1="40" y1="140" x2="380" y2="140" stroke="#1F2937" stroke-dasharray="2,2" />
              <line x1="40" y1="180" x2="380" y2="180" stroke="#374151" stroke-width="1.5" />
              <line x1="40" y1="20" x2="40" y2="180" stroke="#374151" stroke-width="1.5" />

              <!-- Axis Labels -->
              <text x="35" y="25" fill="#64748b" font-size="8" text-anchor="end">350 km</text>
              <text x="35" y="105" fill="#64748b" font-size="8" text-anchor="end">250 km</text>
              <text x="35" y="180" fill="#64748b" font-size="8" text-anchor="end">150 km</text>

              <text x="40" y="195" fill="#64748b" font-size="8">30 kPa</text>
              <text x="210" y="195" fill="#64748b" font-size="8" text-anchor="middle">38 kPa (Max-Q)</text>
              <text x="380" y="195" fill="#64748b" font-size="8" text-anchor="end">46 kPa</text>

              <!-- Scatter Points from Monte Carlo Runs -->
              @for (run of mcResults().runs.slice(0, 150); track run.runIndex) {
                <circle 
                  [attr.cx]="40 + ((run.maxQ_kPa - 30) / 16) * 340"
                  [attr.cy]="180 - ((run.insertionApogeeKm - 150) / 200) * 160"
                  r="2.5"
                  [attr.fill]="run.missionSuccess ? '#22d3ee' : '#f43f5e'"
                  opacity="0.7"
                />
              }

              <!-- Nominal Target Marker -->
              <circle cx="210" cy="100" r="5" fill="#22d3ee" stroke="#ffffff" stroke-width="1.5" />
              <text x="220" y="96" fill="#22d3ee" font-size="9" font-weight="bold">Nominal Design Center</text>
            </svg>
          </div>

          <div class="text-[10px] text-slate-400 flex items-center justify-between">
            <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-cyan-400"></span> Nominal Flights</span>
            <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-rose-500"></span> Out of Spec Dispersions</span>
            <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-cyan-400"></span> Design Baseline</span>
          </div>
        </div>

        <!-- Right: Multi-Objective Pareto Trade Study & Architectural Optimization -->
        <div class="bg-[#161B22] border border-[#1F2937] rounded-lg p-4 flex flex-col space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-200 uppercase tracking-wider">Multi-Objective Pareto Design Candidates</span>
            <span class="text-[10px] text-cyan-400">AI / MULTI-CRITERIA SCORING</span>
          </div>

          <div class="space-y-3 overflow-y-auto max-h-80 pr-1">
            @for (cand of candidateDesigns(); track cand.id) {
              <div 
                class="p-3 rounded-md border transition space-y-2 bg-[#0D1117] border-[#1F2937] hover:border-slate-600">
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-2">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                      [class.bg-cyan-950]="cand.archetype === 'MINIMAL_MASS'"
                      [class.text-cyan-300]="cand.archetype === 'MINIMAL_MASS'"
                      [class.bg-emerald-950]="cand.archetype === 'BALANCED_PRODUCTION'"
                      [class.text-emerald-300]="cand.archetype === 'BALANCED_PRODUCTION'"
                      [class.bg-amber-950]="cand.archetype === 'LOW_COST_EXPENDABLE'"
                      [class.text-amber-300]="cand.archetype === 'LOW_COST_EXPENDABLE'">
                      #{{ cand.rank }} {{ cand.archetype }}
                    </span>
                    <span class="font-bold text-slate-200 text-xs">{{ cand.designName }}</span>
                  </div>
                  <span class="text-xs font-bold text-cyan-400">SCORE: {{ cand.score }}</span>
                </div>

                <div class="text-[11px] text-slate-300 leading-relaxed">
                  {{ cand.tradeOffRationale }}
                </div>

                <!-- Metrics Grid -->
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px] text-slate-400 pt-1 border-t border-[#1F2937]">
                  <div>MASS SAVINGS: <span class="text-emerald-400 font-semibold">{{ cand.massSavingsKg > 0 ? '+' : '' }}{{ cand.massSavingsKg }} kg</span></div>
                  <div>COST DELTA: <span class="text-cyan-400 font-semibold">\${{ (cand.costDeltaUsd / 1000000).toFixed(1) }}M</span></div>
                  <div>MFG TIME: <span class="text-slate-200 font-semibold">{{ cand.manufacturingDays }} Days</span></div>
                  <div>SAFETY FACTOR: <span class="text-cyan-300 font-semibold">{{ cand.safetyFactor }} SF</span></div>
                </div>
              </div>
            }
          </div>

          <div class="p-2 bg-[#0D1117] border border-cyan-500/20 rounded text-[11px] text-slate-300">
            <strong class="text-cyan-400">Optimization Verdict:</strong> Multi-objective Pareto frontier confirms Design Bravo (FSW Al-Li) provides optimal manufacturing throughput and safety margin balance.
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `]
})
export class MonteCarloView {
  private readonly digitalTwin = inject(DigitalTwinService);

  readonly iterationCount = signal<number>(100);
  readonly mcResults = signal<MonteCarloAnalysisResult>(
    MonteCarloSolver.runCampaign(this.digitalTwin.rocket(), 100)
  );
  readonly candidateDesigns = signal<CandidateDesign[]>(
    OptimizerSolver.runOptimization(this.digitalTwin.rocket())
  );

  runMonteCarlo(count: number): void {
    this.iterationCount.set(count);
    const res = MonteCarloSolver.runCampaign(this.digitalTwin.rocket(), count);
    this.mcResults.set(res);
  }

  runTradeStudy(): void {
    const res = OptimizerSolver.runOptimization(this.digitalTwin.rocket());
    this.candidateDesigns.set(res);
  }
}

