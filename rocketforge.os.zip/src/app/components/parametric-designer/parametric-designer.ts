import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-parametric-designer',
  imports: [CommonModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0D1117] border border-[#1F2937] rounded-lg overflow-hidden font-mono text-xs shadow-2xl">
      <!-- Header Toolbar -->
      <div class="p-3 bg-[#0D1117] border-b border-[#1F2937] flex items-center justify-between">
        <div class="flex items-center gap-2">
          <span class="w-2.5 h-2.5 rounded-sm bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.5)]"></span>
          <span class="text-xs font-bold text-slate-100 tracking-wider uppercase">Parametric Rocket Configurator</span>
          <span class="text-[9px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-500/30 uppercase font-semibold">REV: {{ digitalTwin.rocket().digitalTwin.revision }}</span>
        </div>
        <div class="flex items-center gap-2">
          <button 
            (click)="openRevisionModal()"
            class="px-3 py-1 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded text-xs flex items-center gap-1.5 transition shadow-[0_0_15px_rgba(34,211,238,0.3)]">
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4"/></svg>
            Commit Revision
          </button>
        </div>
      </div>

      <!-- Navigation Tabs -->
      <div class="flex overflow-x-auto bg-[#0A0C10] border-b border-[#1F2937] p-1 gap-1">
        @for (tab of tabs; track tab.id) {
          <button 
            (click)="activeTab.set(tab.id)"
            [class.bg-[#161B22]]="activeTab() === tab.id"
            [class.text-cyan-400]="activeTab() === tab.id"
            [class.border-cyan-500/40]="activeTab() === tab.id"
            [class.text-slate-400]="activeTab() !== tab.id"
            [class.border-transparent]="activeTab() !== tab.id"
            class="px-3 py-1.5 rounded border hover:bg-[#161B22]/80 uppercase tracking-wider font-semibold whitespace-nowrap transition-colors">
            {{ tab.label }}
          </button>
        }
      </div>

      <!-- Scrollable Tab Content Panels -->
      <div class="flex-1 overflow-y-auto p-4 space-y-4 text-slate-300">
        <!-- 1. GEOMETRY TAB -->
        @if (activeTab() === 'GEOMETRY') {
          <div class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div class="p-3 bg-[#161B22] border border-[#1F2937] rounded-md">
                <label for="coreDiaRange" class="block text-slate-400 font-semibold mb-1">Core Diameter: <strong class="text-cyan-300">{{ rocket().config.geometry.coreDiameter.value }} m</strong></label>
                <input 
                  id="coreDiaRange"
                  type="range" min="3.0" max="9.0" step="0.1" 
                  [value]="rocket().config.geometry.coreDiameter.value"
                  (input)="onParamChange('geometry.coreDiameter', $event)"
                  class="w-full accent-cyan-400 cursor-pointer">
                <div class="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>3.0 m (Falcon 9)</span>
                  <span>9.0 m (Starship)</span>
                </div>
              </div>

              <div class="p-3 bg-[#161B22] border border-[#1F2937] rounded-md">
                <label for="s1HeightRange" class="block text-slate-400 font-semibold mb-1">Stage 1 Height: <strong class="text-cyan-300">{{ rocket().config.geometry.stage1Height.value }} m</strong></label>
                <input 
                  id="s1HeightRange"
                  type="range" min="25" max="65" step="0.5" 
                  [value]="rocket().config.geometry.stage1Height.value"
                  (input)="onParamChange('geometry.stage1Height', $event)"
                  class="w-full accent-cyan-400 cursor-pointer">
                <div class="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>25 m</span>
                  <span>65 m</span>
                </div>
              </div>

              <div class="p-3 bg-[#161B22] border border-[#1F2937] rounded-md">
                <label for="s2HeightRange" class="block text-slate-400 font-semibold mb-1">Stage 2 Height: <strong class="text-cyan-300">{{ rocket().config.geometry.stage2Height.value }} m</strong></label>
                <input 
                  id="s2HeightRange"
                  type="range" min="6" max="18" step="0.5" 
                  [value]="rocket().config.geometry.stage2Height.value"
                  (input)="onParamChange('geometry.stage2Height', $event)"
                  class="w-full accent-cyan-400 cursor-pointer">
                <div class="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>6 m</span>
                  <span>18 m</span>
                </div>
              </div>

              <div class="p-3 bg-[#161B22] border border-[#1F2937] rounded-md">
                <label for="fairingHeightRange" class="block text-slate-400 font-semibold mb-1">Fairing Height: <strong class="text-cyan-300">{{ rocket().config.geometry.fairingHeight.value }} m</strong></label>
                <input 
                  id="fairingHeightRange"
                  type="range" min="8" max="22" step="0.5" 
                  [value]="rocket().config.geometry.fairingHeight.value"
                  (input)="onParamChange('geometry.fairingHeight', $event)"
                  class="w-full accent-cyan-400 cursor-pointer">
                <div class="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>8 m (Standard)</span>
                  <span>22 m (Deep Space Extended)</span>
                </div>
              </div>
            </div>
          </div>
        }

        <!-- 2. PROPULSION TAB -->
        @if (activeTab() === 'PROPULSION') {
          <div class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div class="p-3 bg-[#161B22] border border-[#1F2937] rounded-md">
                <label for="propellantSelect" class="block text-slate-400 font-semibold mb-1">Propellant Chemical Couple</label>
                <select 
                  id="propellantSelect"
                  [value]="rocket().config.propulsion.propellantType.value"
                  (change)="onSelectChange('propulsion.propellantType', $event)"
                  class="w-full bg-[#0D1117] border border-[#1F2937] rounded p-1.5 text-slate-200">
                  <option value="LOX_METHANE">LOX / LCH4 (Methalox - 352s Vac Isp)</option>
                  <option value="LOX_RP1">LOX / RP-1 (Keralox - 311s Vac Isp)</option>
                  <option value="LOX_LH2">LOX / LH2 (Hydrolox - 450s Vac Isp)</option>
                </select>
              </div>

              <div class="p-3 bg-[#161B22] border border-[#1F2937] rounded-md">
                <label for="s1EngineCountRange" class="block text-slate-400 font-semibold mb-1">Stage 1 Engine Count: <strong class="text-cyan-300">{{ rocket().config.propulsion.stage1EngineCount.value }} Engines</strong></label>
                <input 
                  id="s1EngineCountRange"
                  type="range" min="1" max="33" step="1" 
                  [value]="rocket().config.propulsion.stage1EngineCount.value"
                  (input)="onParamChange('propulsion.stage1EngineCount', $event)"
                  class="w-full accent-cyan-400 cursor-pointer">
                <div class="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>1 (Light)</span>
                  <span>9 (Octaweb)</span>
                  <span>33 (Super Heavy)</span>
                </div>
              </div>

              <div class="p-3 bg-[#161B22] border border-[#1F2937] rounded-md">
                <label for="chamberPressureRange" class="block text-slate-400 font-semibold mb-1">Chamber Pressure: <strong class="text-cyan-300">{{ rocket().config.propulsion.stage1ChamberPressureBar.value }} bar</strong></label>
                <input 
                  id="chamberPressureRange"
                  type="range" min="70" max="300" step="5" 
                  [value]="rocket().config.propulsion.stage1ChamberPressureBar.value"
                  (input)="onParamChange('propulsion.stage1ChamberPressureBar', $event)"
                  class="w-full accent-cyan-400 cursor-pointer">
                <div class="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>70 bar (Gas Gen)</span>
                  <span>300 bar (Full-Flow Staged)</span>
                </div>
              </div>

              <div class="p-3 bg-[#161B22] border border-[#1F2937] rounded-md">
                <label for="thrustRange" class="block text-slate-400 font-semibold mb-1">Sea-Level Thrust per Engine: <strong class="text-cyan-300">{{ rocket().config.propulsion.stage1ThrustSeaLevelKn.value }} kN</strong></label>
                <input 
                  id="thrustRange"
                  type="range" min="400" max="2500" step="25" 
                  [value]="rocket().config.propulsion.stage1ThrustSeaLevelKn.value"
                  (input)="onParamChange('propulsion.stage1ThrustSeaLevelKn', $event)"
                  class="w-full accent-cyan-400 cursor-pointer">
                <div class="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>400 kN</span>
                  <span>2,500 kN</span>
                </div>
              </div>
            </div>
          </div>
        }

        <!-- 3. STRUCTURES & MATERIALS TAB -->
        @if (activeTab() === 'STRUCTURES') {
          <div class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div class="p-3 bg-[#161B22] border border-[#1F2937] rounded-md">
                <label for="materialSelect" class="block text-slate-400 font-semibold mb-1">Primary Airframe Material</label>
                <select 
                  id="materialSelect"
                  [value]="rocket().config.structures.primaryMaterial.value"
                  (change)="onSelectChange('structures.primaryMaterial', $event)"
                  class="w-full bg-[#0D1117] border border-[#1F2937] rounded p-1.5 text-slate-200">
                  <option value="AL_LI_2195">Al-Li 2195 (NASA SLS / Falcon 9 Baseline)</option>
                  <option value="CARBON_COMPOSITE">Carbon Composite IM7 (High Specific Modulus)</option>
                  <option value="STAINLESS_304L">Stainless Steel 304L (Starship Cryogenic)</option>
                  <option value="TI_6AL_4V">Titanium Ti-6Al-4V (High Temp Ring Forgings)</option>
                </select>
              </div>

              <div class="p-3 bg-[#161B22] border border-[#1F2937] rounded-md">
                <label for="s1SkinThicknessRange" class="block text-slate-400 font-semibold mb-1">Stage 1 Skin Thickness: <strong class="text-cyan-300">{{ rocket().config.structures.stage1SkinThicknessMm.value }} mm</strong></label>
                <input 
                  id="s1SkinThicknessRange"
                  type="range" min="2.0" max="10.0" step="0.2" 
                  [value]="rocket().config.structures.stage1SkinThicknessMm.value"
                  (input)="onParamChange('structures.stage1SkinThicknessMm', $event)"
                  class="w-full accent-cyan-400 cursor-pointer">
                <div class="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>2.0 mm (Extreme Light)</span>
                  <span>10.0 mm (Heavy Stiffened)</span>
                </div>
              </div>

              <div class="p-3 bg-[#161B22] border border-[#1F2937] rounded-md">
                <label for="tankPressureRange" class="block text-slate-400 font-semibold mb-1">Tank Operating Pressure: <strong class="text-cyan-300">{{ rocket().config.structures.tankOperatingPressureBar.value }} bar</strong></label>
                <input 
                  id="tankPressureRange"
                  type="range" min="1.5" max="6.0" step="0.1" 
                  [value]="rocket().config.structures.tankOperatingPressureBar.value"
                  (input)="onParamChange('structures.tankOperatingPressureBar', $event)"
                  class="w-full accent-cyan-400 cursor-pointer">
                <div class="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>1.5 bar</span>
                  <span>6.0 bar</span>
                </div>
              </div>

              <div class="p-3 bg-[#161B22] border border-[#1F2937] rounded-md">
                <label for="safetyFactorRange" class="block text-slate-400 font-semibold mb-1">Design Safety Factor: <strong class="text-cyan-300">{{ rocket().config.structures.designSafetyFactor.value }} SF</strong></label>
                <input 
                  id="safetyFactorRange"
                  type="range" min="1.1" max="2.0" step="0.05" 
                  [value]="rocket().config.structures.designSafetyFactor.value"
                  (input)="onParamChange('structures.designSafetyFactor', $event)"
                  class="w-full accent-cyan-400 cursor-pointer">
                <div class="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>1.1 (Experimental)</span>
                  <span>1.4 (NASA Human-Rated Standard)</span>
                  <span>2.0 (Conservative)</span>
                </div>
              </div>
            </div>
          </div>
        }

        <!-- 4. RECOVERY & PAYLOAD TAB -->
        @if (activeTab() === 'RECOVERY') {
          <div class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div class="p-3 bg-[#161B22] border border-[#1F2937] rounded-md">
                <label for="payloadMassRange" class="block text-slate-400 font-semibold mb-1">Payload Mass to LEO: <strong class="text-cyan-300">{{ rocket().config.payload.targetMassKg.value | number }} kg</strong></label>
                <input 
                  id="payloadMassRange"
                  type="range" min="1000" max="45000" step="500" 
                  [value]="rocket().config.payload.targetMassKg.value"
                  (input)="onParamChange('payload.targetMassKg', $event)"
                  class="w-full accent-cyan-400 cursor-pointer">
                <div class="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>1,000 kg</span>
                  <span>45,000 kg</span>
                </div>
              </div>

              <div class="p-3 bg-[#161B22] border border-[#1F2937] rounded-md">
                <span class="block text-slate-400 font-semibold mb-1">Booster Reusability Mode</span>
                <div class="flex items-center gap-4 mt-2">
                  <label for="recoveryCheck" class="flex items-center gap-2 cursor-pointer text-slate-200">
                    <input 
                      id="recoveryCheck"
                      type="checkbox" 
                      [checked]="rocket().config.recovery.reusableStage1.value"
                      (change)="onCheckboxChange('recovery.reusableStage1', $event)"
                      class="rounded bg-[#0D1117] border-[#1F2937] text-cyan-500">
                    <span>Enable Stage 1 Reusable Recovery (Legs + Grid Fins)</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
        }
      </div>

      <!-- Live Derived Mass & Performance Banner Footer -->
      <div class="p-3 bg-[#0D1117] border-t border-[#1F2937] grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
        <div class="p-2 bg-[#161B22] rounded border border-[#1F2937]">
          <div class="text-[10px] text-slate-400 uppercase">Liftoff Mass</div>
          <div class="text-sm font-bold text-slate-100">{{ rocket().calculatedMassProperties.liftoffMassKg | number }} kg</div>
        </div>
        <div class="p-2 bg-[#161B22] rounded border border-[#1F2937]">
          <div class="text-[10px] text-slate-400 uppercase">Liftoff TWR</div>
          <div class="text-sm font-bold text-emerald-400">{{ rocket().calculatedMassProperties.thrustToWeightRatioLiftoff }} : 1</div>
        </div>
        <div class="p-2 bg-[#161B22] rounded border border-[#1F2937]">
          <div class="text-[10px] text-slate-400 uppercase">Total Delta-V</div>
          <div class="text-sm font-bold text-cyan-400">{{ rocket().calculatedMassProperties.totalDeltaVMs | number }} m/s</div>
        </div>
        <div class="p-2 bg-[#161B22] rounded border border-[#1F2937]">
          <div class="text-[10px] text-slate-400 uppercase">Dry Mass Margin</div>
          <div class="text-sm font-bold text-amber-400">{{ rocket().calculatedMassProperties.dryMassKg | number }} kg</div>
        </div>
      </div>

      <!-- Revision Modal -->
      @if (showRevisionModal()) {
        <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div class="w-full max-w-md bg-[#161B22] border border-cyan-500/40 rounded-xl p-5 shadow-2xl space-y-4">
            <div class="flex items-center justify-between border-b border-[#1F2937] pb-2">
              <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wider">Commit Vehicle Digital Twin Revision</h3>
              <button (click)="showRevisionModal.set(false)" class="text-slate-400 hover:text-slate-100">✕</button>
            </div>
            <div>
              <label for="ecoDescInput" class="block text-slate-400 text-xs mb-1">Revision Description / Engineering Change Order (ECO)</label>
              <textarea 
                #descInput
                id="ecoDescInput"
                rows="3" 
                placeholder="e.g. Baseline lock with Al-Li 2195 and 9x methalox engines"
                class="w-full bg-[#0D1117] border border-[#1F2937] rounded p-2 text-slate-200 text-xs focus:border-cyan-400 focus:outline-none"></textarea>
            </div>
            <div class="flex justify-end gap-2 pt-2">
              <button 
                (click)="showRevisionModal.set(false)"
                class="px-3 py-1.5 bg-[#0D1117] hover:bg-[#1F2937] text-slate-300 rounded text-xs">
                Cancel
              </button>
              <button 
                (click)="commitRevision(descInput.value)"
                class="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded text-xs shadow-[0_0_15px_rgba(34,211,238,0.3)]">
                Commit Revision
              </button>
            </div>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `]
})
export class ParametricDesigner {
  readonly digitalTwin = inject(DigitalTwinService);
  readonly rocket = this.digitalTwin.rocket;

  readonly activeTab = signal<string>('GEOMETRY');
  readonly showRevisionModal = signal<boolean>(false);

  readonly tabs = [
    { id: 'GEOMETRY', label: 'Geometry' },
    { id: 'PROPULSION', label: 'Propulsion' },
    { id: 'STRUCTURES', label: 'Structures & Tanks' },
    { id: 'RECOVERY', label: 'Payload & Recovery' },
  ];

  onParamChange(path: string, event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.digitalTwin.updateParameter(path, val);
  }

  onSelectChange(path: string, event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.digitalTwin.updateParameter(path, val);
  }

  onCheckboxChange(path: string, event: Event): void {
    const val = (event.target as HTMLInputElement).checked;
    this.digitalTwin.updateParameter(path, val);
  }

  openRevisionModal(): void {
    this.showRevisionModal.set(true);
  }

  commitRevision(description: string): void {
    if (!description.trim()) {
      description = 'Design parameter update and mass recalculation';
    }
    this.digitalTwin.createRevision(description);
    this.showRevisionModal.set(false);
  }
}

