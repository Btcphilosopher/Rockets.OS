import { 
  ChangeDetectionStrategy, 
  Component, 
  ElementRef, 
  OnDestroy, 
  OnInit, 
  ViewChild, 
  inject, 
  input, 
  signal, 
  effect 
} from '@angular/core';
import { CommonModule } from '@angular/common';
import * as THREE from 'three';
import { DigitalTwinService } from '../../core/services/digital-twin.service';
import { TelemetryService } from '../../core/services/telemetry.service';
import { SimulationClockService } from '../../core/services/simulation-clock.service';
import { ManufacturingService } from '../../core/services/manufacturing.service';

export type ViewportRenderMode = 
  | 'CAD' 
  | 'EXPLODED' 
  | 'CUTAWAY' 
  | 'XRAY' 
  | 'THERMAL' 
  | 'STRESS' 
  | 'PROPULSION' 
  | 'AERODYNAMICS' 
  | 'LAUNCH_PAD' 
  | 'FACTORY';

@Component({
  selector: 'app-viewport-3d',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full bg-[#050505] overflow-hidden select-none tech-radial-grid">
      <!-- 3D Canvas Container -->
      <div #canvasContainer class="w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Mode & View Controls Top Left Overlay -->
      <div class="absolute top-3 left-3 z-10 flex flex-wrap gap-1.5 p-1.5 bg-[#0D1117]/90 backdrop-blur border border-[#1F2937] rounded-md shadow-xl max-w-[85%] font-mono">
        @for (m of availableModes; track m.id) {
          <button 
            (click)="setRenderMode(m.id)"
            [class.bg-cyan-500]="renderMode() === m.id"
            [class.text-slate-950]="renderMode() === m.id"
            [class.font-bold]="renderMode() === m.id"
            [class.shadow-[0_0_12px_rgba(34,211,238,0.3)]]="renderMode() === m.id"
            [class.text-slate-300]="renderMode() !== m.id"
            [class.hover:bg-[#161B22]]="renderMode() !== m.id"
            class="px-2.5 py-1 text-xs uppercase tracking-wider rounded transition-colors flex items-center gap-1.5">
            <span class="w-1.5 h-1.5 rounded-full" [class.bg-slate-950]="renderMode() === m.id" [class.bg-cyan-400]="renderMode() !== m.id"></span>
            {{ m.label }}
          </button>
        }
      </div>

      <!-- Exploded View Slider (When Exploded mode is active) -->
      @if (renderMode() === 'EXPLODED') {
        <div class="absolute top-16 left-3 z-10 flex items-center gap-3 px-3 py-2 bg-[#0D1117]/95 backdrop-blur border border-[#1F2937] rounded-md shadow-xl text-xs font-mono">
          <label for="explosionRange" class="text-cyan-400 font-semibold uppercase tracking-wider">Explosion Separation:</label>
          <input 
            id="explosionRange"
            type="range" 
            min="0" 
            max="2.5" 
            step="0.05" 
            [value]="explosionFactor()" 
            (input)="onExplosionSliderChange($event)"
            class="w-36 accent-cyan-400 cursor-pointer">
          <span class="text-slate-200 font-mono w-12">{{ (explosionFactor() * 100).toFixed(0) }}%</span>
        </div>
      }

      <!-- Subsystem Overlay & Camera Toolbar Top Right -->
      <div class="absolute top-3 right-3 z-10 flex items-center gap-2 font-mono">
        <button 
          (click)="resetCamera()"
          class="px-3 py-1.5 bg-[#0D1117]/90 hover:bg-[#161B22] text-cyan-400 border border-[#1F2937] rounded text-xs uppercase tracking-wider flex items-center gap-1.5 transition">
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
          Reset View
        </button>
        <button 
          (click)="toggleAutoRotate()"
          [class.bg-cyan-500]="isAutoRotating()"
          [class.text-slate-950]="isAutoRotating()"
          [class.text-slate-300]="!isAutoRotating()"
          class="px-3 py-1.5 bg-[#0D1117]/90 hover:bg-[#161B22] border border-[#1F2937] rounded text-xs uppercase tracking-wider flex items-center gap-1.5 transition">
          Auto Orbit
        </button>
      </div>

      <!-- Bottom HUD Status Overlay -->
      <div class="absolute bottom-3 left-3 z-10 flex items-center gap-4 px-3 py-1.5 bg-[#0D1117]/90 backdrop-blur border border-[#1F2937] rounded text-[11px] font-mono text-slate-400">
        <div class="flex items-center gap-1.5">
          <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span class="text-slate-200 font-semibold">WEBGL 3D DIGITAL TWIN</span>
        </div>
        <div>RENDER MODE: <span class="text-cyan-400 font-semibold">{{ renderMode() }}</span></div>
        <div>PARTS: <span class="text-slate-200">14 SUBASSEMBLIES</span></div>
        @if (digitalTwin.selectedPartId()) {
          <div>SELECTED: <span class="text-amber-400 font-semibold">{{ digitalTwin.selectedPartId() }}</span></div>
        }
      </div>

      <!-- Stress / Thermal Color Legend (Bottom Right) -->
      @if (renderMode() === 'STRESS' || renderMode() === 'THERMAL') {
        <div class="absolute bottom-3 right-3 z-10 px-3 py-2 bg-[#0D1117]/95 backdrop-blur border border-[#1F2937] rounded shadow-2xl text-[10px] font-mono">
          <div class="text-slate-300 font-semibold mb-1 flex justify-between">
            <span>{{ renderMode() === 'STRESS' ? 'VON MISES STRESS (MPa)' : 'SKIN TEMPERATURE (K)' }}</span>
            <span class="text-cyan-400">{{ renderMode() === 'STRESS' ? '0 - 550 MPa' : '90K - 1800K' }}</span>
          </div>
          <div class="w-48 h-3 rounded overflow-hidden" 
               [style.background]="renderMode() === 'STRESS' 
                 ? 'linear-gradient(to right, #0022ff, #00ccff, #00ff66, #ffff00, #ff0000)' 
                 : 'linear-gradient(to right, #0011aa, #00ffff, #ffbb00, #ff2200, #ffffff)'">
          </div>
          <div class="flex justify-between text-slate-400 mt-1">
            <span>{{ renderMode() === 'STRESS' ? '0 MPa (Safe)' : '90K (Cryo)' }}</span>
            <span>{{ renderMode() === 'STRESS' ? '535 MPa (Yield)' : '1800K (Ablative)' }}</span>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `]
})
export class Viewport3d implements OnInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) canvasContainer!: ElementRef<HTMLDivElement>;

  readonly digitalTwin = inject(DigitalTwinService);
  readonly telemetry = inject(TelemetryService);
  readonly clock = inject(SimulationClockService);
  readonly mfg = inject(ManufacturingService);

  readonly initialMode = input<ViewportRenderMode>('CAD');
  readonly renderMode = signal<ViewportRenderMode>('CAD');
  readonly explosionFactor = signal<number>(0.0);
  readonly isAutoRotating = signal<boolean>(false);

  readonly availableModes: { id: ViewportRenderMode; label: string }[] = [
    { id: 'CAD', label: 'CAD Shaded' },
    { id: 'EXPLODED', label: 'Exploded View' },
    { id: 'CUTAWAY', label: 'Cutaway / Internals' },
    { id: 'XRAY', label: 'X-Ray Structure' },
    { id: 'THERMAL', label: 'Thermal Heat Map' },
    { id: 'STRESS', label: 'Stress FEA Map' },
    { id: 'PROPULSION', label: 'Propulsion & Flow' },
    { id: 'AERODYNAMICS', label: 'Aero Streamlines' },
    { id: 'LAUNCH_PAD', label: 'Launch Complex' },
    { id: 'FACTORY', label: 'Factory Digital Twin' },
  ];

  // Three.js Core
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId: number | null = null;
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();

  // 3D Object Groups
  private rocketGroup = new THREE.Group();
  private launchPadGroup = new THREE.Group();
  private factoryGroup = new THREE.Group();
  private plumeParticles!: THREE.Points;
  private aeroStreamlinesGroup = new THREE.Group();

  // Subsystem component meshes map for exploded/cutaway transformations
  private subsystemMeshes = new Map<string, THREE.Object3D>();

  // Mouse interaction state
  private isDragging = false;
  private previousMousePosition = { x: 0, y: 0 };
  private cameraTarget = new THREE.Vector3(0, 30, 0);
  private cameraSpherical = { radius: 75, theta: Math.PI / 4, phi: Math.PI / 3 };

  constructor() {
    // React to vehicle config changes to rebuild rocket geometry
    effect(() => {
      this.digitalTwin.rocket();
      if (this.scene) {
        this.buildRocketGeometry();
      }
    });

    // React to initial mode input
    effect(() => {
      const mode = this.initialMode();
      if (mode) {
        this.setRenderMode(mode);
      }
    });
  }

  ngOnInit(): void {
    this.initThree();
    this.buildLaunchPadGeometry();
    this.buildFactoryGeometry();
    this.buildRocketGeometry();
    this.setupEventListeners();
    this.animate();
  }

  ngOnDestroy(): void {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  setRenderMode(mode: ViewportRenderMode): void {
    this.renderMode.set(mode);
    if (mode === 'EXPLODED') {
      if (this.explosionFactor() === 0) {
        this.explosionFactor.set(1.0);
      }
    } else {
      this.explosionFactor.set(0.0);
    }
    this.updateVisibilityAndMaterials();
  }

  onExplosionSliderChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.explosionFactor.set(val);
    this.applyExplosionTransforms(val);
  }

  toggleAutoRotate(): void {
    this.isAutoRotating.update((v) => !v);
  }

  resetCamera(): void {
    const mode = this.renderMode();
    if (mode === 'FACTORY') {
      this.cameraSpherical = { radius: 90, theta: Math.PI / 3, phi: Math.PI / 3.2 };
      this.cameraTarget.set(0, 10, 0);
    } else if (mode === 'LAUNCH_PAD') {
      this.cameraSpherical = { radius: 85, theta: Math.PI / 3.5, phi: Math.PI / 2.6 };
      this.cameraTarget.set(0, 25, 0);
    } else {
      this.cameraSpherical = { radius: 75, theta: Math.PI / 4, phi: Math.PI / 3 };
      this.cameraTarget.set(0, 30, 0);
    }
    this.updateCameraPosition();
  }

  private initThree(): void {
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x060a12);
    this.scene.fog = new THREE.FogExp2(0x060a12, 0.005);

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.5, 2000);
    this.updateCameraPosition();

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    this.scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xffffff, 1.4);
    sunLight.position.set(60, 120, 80);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    this.scene.add(sunLight);

    const blueRimLight = new THREE.DirectionalLight(0x38bdf8, 0.8);
    blueRimLight.position.set(-60, 40, -80);
    this.scene.add(blueRimLight);

    // Grid Floor
    const gridHelper = new THREE.GridHelper(200, 50, 0x0284c7, 0x1e293b);
    gridHelper.position.y = -0.05;
    this.scene.add(gridHelper);

    this.scene.add(this.rocketGroup);
    this.scene.add(this.launchPadGroup);
    this.scene.add(this.factoryGroup);
    this.scene.add(this.aeroStreamlinesGroup);

    this.createPlumeParticles();
    this.createAeroStreamlines();
  }

  private buildRocketGeometry(): void {
    // Clear existing rocket parts
    while (this.rocketGroup.children.length > 0) {
      this.rocketGroup.remove(this.rocketGroup.children[0]);
    }
    this.subsystemMeshes.clear();

    const config = this.digitalTwin.rocket().config;
    const diameter = config.geometry.coreDiameter.value;
    const radius = diameter / 2;
    const s1Height = config.geometry.stage1Height.value;
    const interstageH = config.geometry.interstageHeight.value;
    const s2Height = config.geometry.stage2Height.value;
    const fairingH = config.geometry.fairingHeight.value;
    const s1Engines = config.propulsion.stage1EngineCount.value;

    let currentY = 0;

    // 1. Stage 1 Engine Section & Octaweb Puck
    const octawebGroup = new THREE.Group();
    octawebGroup.name = 'E-01-OCTAWEB-MNT';

    // Thrust puck base
    const puckGeo = new THREE.CylinderGeometry(radius * 0.95, radius, 1.2, 32);
    const puckMat = new THREE.MeshStandardMaterial({ color: 0x242d3d, metalness: 0.8, roughness: 0.3 });
    const puckMesh = new THREE.Mesh(puckGeo, puckMat);
    puckMesh.position.y = 0.6;
    octawebGroup.add(puckMesh);

    // 9 Engines Cluster
    const nozzleMat = new THREE.MeshStandardMaterial({ color: 0x1a1e29, metalness: 0.9, roughness: 0.2 });
    const nozzleBellGeo = new THREE.ConeGeometry(0.7, 1.8, 24, 1, true);

    // Center engine
    const centerNozzle = new THREE.Mesh(nozzleBellGeo, nozzleMat);
    centerNozzle.rotation.x = Math.PI;
    centerNozzle.position.set(0, -0.6, 0);
    octawebGroup.add(centerNozzle);

    // Outer ring engines
    const ringRadius = radius * 0.65;
    const outerEngineCount = Math.max(1, s1Engines - 1);
    for (let i = 0; i < outerEngineCount; i++) {
      const angle = (i / outerEngineCount) * Math.PI * 2;
      const nozzle = new THREE.Mesh(nozzleBellGeo, nozzleMat);
      nozzle.rotation.x = Math.PI;
      nozzle.position.set(Math.cos(angle) * ringRadius, -0.6, Math.sin(angle) * ringRadius);
      octawebGroup.add(nozzle);
    }

    octawebGroup.position.y = currentY;
    this.subsystemMeshes.set('OCTAWEB', octawebGroup);
    this.rocketGroup.add(octawebGroup);
    currentY += 1.2;

    // 2. Stage 1 Aft Fuel Tank
    const fuelTankH = s1Height * 0.42;
    const fuelTankGeo = new THREE.CylinderGeometry(radius, radius, fuelTankH, 48);
    const bodyMat = new THREE.MeshStandardMaterial({ 
      color: 0xededed, 
      metalness: 0.4, 
      roughness: 0.35,
      bumpScale: 0.05
    });
    const fuelTankMesh = new THREE.Mesh(fuelTankGeo, bodyMat);
    fuelTankMesh.position.y = currentY + fuelTankH / 2;
    fuelTankMesh.name = 'T-02-FUEL-TANK';
    this.subsystemMeshes.set('S1_FUEL_TANK', fuelTankMesh);
    this.rocketGroup.add(fuelTankMesh);

    // Internal Fuel Baffles (for Cutaway view)
    const fuelInternalGeo = new THREE.CylinderGeometry(radius * 0.94, radius * 0.94, fuelTankH * 0.9, 24, 4, true);
    const internalBaffleMat = new THREE.MeshBasicMaterial({ color: 0x0284c7, wireframe: true });
    const fuelInternal = new THREE.Mesh(fuelInternalGeo, internalBaffleMat);
    fuelInternal.name = 'INTERNAL_FUEL_BAFFLES';
    fuelTankMesh.add(fuelInternal);

    currentY += fuelTankH;

    // 3. Stage 1 Forward LOX Tank
    const loxTankH = s1Height * 0.58;
    const loxTankGeo = new THREE.CylinderGeometry(radius, radius, loxTankH, 48);
    const loxTankMesh = new THREE.Mesh(loxTankGeo, bodyMat.clone());
    loxTankMesh.position.y = currentY + loxTankH / 2;
    loxTankMesh.name = 'T-01-LOX-TANK';
    this.subsystemMeshes.set('S1_LOX_TANK', loxTankMesh);
    this.rocketGroup.add(loxTankMesh);

    // 4 Landing Legs (Aft Stage 1)
    if (config.recovery.reusableStage1.value) {
      const legMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.7, roughness: 0.3 });
      const legGeo = new THREE.BoxGeometry(0.3, 8.0, 0.4);
      for (let i = 0; i < 4; i++) {
        const angle = (i / 4) * Math.PI * 2;
        const leg = new THREE.Mesh(legGeo, legMat);
        leg.position.set(Math.cos(angle) * (radius + 0.15), 4.2, Math.sin(angle) * (radius + 0.15));
        leg.rotation.y = -angle;
        leg.name = `LANDING_LEG_${i + 1}`;
        this.rocketGroup.add(leg);
      }

      // 4 Grid Fins (Forward Stage 1)
      const finMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8, roughness: 0.2 });
      const finGeo = new THREE.BoxGeometry(1.2, 0.1, 0.8);
      for (let i = 0; i < 4; i++) {
        const angle = (i / 4) * Math.PI * 2 + Math.PI / 4;
        const fin = new THREE.Mesh(finGeo, finMat);
        fin.position.set(Math.cos(angle) * (radius + 0.6), currentY + loxTankH - 1.5, Math.sin(angle) * (radius + 0.6));
        fin.rotation.y = -angle;
        fin.name = `GRID_FIN_${i + 1}`;
        this.rocketGroup.add(fin);
      }
    }

    currentY += loxTankH;

    // 4. Interstage Section
    const interstageGeo = new THREE.CylinderGeometry(radius, radius, interstageH, 48);
    const interstageMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.5, roughness: 0.5 });
    const interstageMesh = new THREE.Mesh(interstageGeo, interstageMat);
    interstageMesh.position.y = currentY + interstageH / 2;
    interstageMesh.name = 'S-01-INTERSTAGE';
    this.subsystemMeshes.set('INTERSTAGE', interstageMesh);
    this.rocketGroup.add(interstageMesh);
    currentY += interstageH;

    // 5. Stage 2 Vacuum Engine & Tank
    const s2TankGeo = new THREE.CylinderGeometry(radius, radius, s2Height, 48);
    const s2TankMesh = new THREE.Mesh(s2TankGeo, bodyMat.clone());
    s2TankMesh.position.y = currentY + s2Height / 2;
    s2TankMesh.name = 'S2-TANK-SECTION';
    this.subsystemMeshes.set('STAGE2_TANK', s2TankMesh);

    // Stage 2 Expanded Vacuum Nozzle inside Interstage
    const vacNozzleGeo = new THREE.ConeGeometry(1.4, 2.8, 32, 1, true);
    const vacNozzle = new THREE.Mesh(vacNozzleGeo, nozzleMat);
    vacNozzle.rotation.x = Math.PI;
    vacNozzle.position.set(0, -s2Height / 2 - 1.2, 0);
    s2TankMesh.add(vacNozzle);

    this.rocketGroup.add(s2TankMesh);
    currentY += s2Height;

    // 6. Avionics Bay Ring
    const avionicsH = 1.4;
    const avionicsGeo = new THREE.CylinderGeometry(radius, radius, avionicsH, 48);
    const avionicsMat = new THREE.MeshStandardMaterial({ color: 0x0f766e, metalness: 0.6, roughness: 0.4 });
    const avionicsMesh = new THREE.Mesh(avionicsGeo, avionicsMat);
    avionicsMesh.position.y = currentY + avionicsH / 2;
    avionicsMesh.name = 'AV-01-AVIONICS-BAY';
    this.subsystemMeshes.set('AVIONICS', avionicsMesh);
    this.rocketGroup.add(avionicsMesh);
    currentY += avionicsH;

    // 7. Payload (Satellite / Test Article inside Fairing)
    const payloadGroup = new THREE.Group();
    payloadGroup.name = 'PL-01-PAYLOAD';
    const satBusGeo = new THREE.BoxGeometry(2.2, 3.2, 2.2);
    const satMat = new THREE.MeshStandardMaterial({ color: 0xeab308, metalness: 0.9, roughness: 0.1 }); // Gold foil MLI
    const satBus = new THREE.Mesh(satBusGeo, satMat);
    satBus.position.y = currentY + 2.5;
    payloadGroup.add(satBus);

    // Solar panels
    const panelGeo = new THREE.BoxGeometry(4.8, 1.8, 0.05);
    const panelMat = new THREE.MeshStandardMaterial({ color: 0x1d4ed8, metalness: 0.8, roughness: 0.2 });
    const panel = new THREE.Mesh(panelGeo, panelMat);
    panel.position.y = currentY + 2.5;
    payloadGroup.add(panel);

    this.subsystemMeshes.set('PAYLOAD', payloadGroup);
    this.rocketGroup.add(payloadGroup);

    // 8. Payload Fairing & Nose Cone
    const fairingCylH = fairingH * 0.45;
    const noseConeH = fairingH * 0.55;

    const fairingGroup = new THREE.Group();
    fairingGroup.name = 'F-01-FAIRING';

    const fairingCylGeo = new THREE.CylinderGeometry(radius, radius, fairingCylH, 48);
    const fairingCyl = new THREE.Mesh(fairingCylGeo, bodyMat.clone());
    fairingCyl.position.y = currentY + fairingCylH / 2;
    fairingGroup.add(fairingCyl);

    const noseGeo = new THREE.ConeGeometry(radius, noseConeH, 48);
    const noseMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, metalness: 0.3, roughness: 0.4 });
    const noseMesh = new THREE.Mesh(noseGeo, noseMat);
    noseMesh.position.y = currentY + fairingCylH + noseConeH / 2;
    fairingGroup.add(noseMesh);

    this.subsystemMeshes.set('FAIRING', fairingGroup);
    this.rocketGroup.add(fairingGroup);

    this.updateVisibilityAndMaterials();
  }

  private buildLaunchPadGeometry(): void {
    while (this.launchPadGroup.children.length > 0) {
      this.launchPadGroup.remove(this.launchPadGroup.children[0]);
    }

    // Launch Mount Table
    const tableGeo = new THREE.BoxGeometry(22, 6, 22);
    const concreteMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.9 });
    const tableMesh = new THREE.Mesh(tableGeo, concreteMat);
    tableMesh.position.set(0, 3, 0);
    tableMesh.receiveShadow = true;
    this.launchPadGroup.add(tableMesh);

    // Flame Trench Opening
    const openingGeo = new THREE.CylinderGeometry(4.5, 4.5, 7, 32);
    const darkMat = new THREE.MeshBasicMaterial({ color: 0x020617 });
    const openingMesh = new THREE.Mesh(openingGeo, darkMat);
    openingMesh.position.set(0, 3, 0);
    this.launchPadGroup.add(openingMesh);

    // Umbilical / Service Tower
    const towerH = 75;
    const towerGeo = new THREE.BoxGeometry(6, towerH, 6);
    const trussMat = new THREE.MeshStandardMaterial({ color: 0x991b1b, metalness: 0.6, roughness: 0.4 });
    const towerMesh = new THREE.Mesh(towerGeo, trussMat);
    towerMesh.position.set(14, towerH / 2, 0);
    towerMesh.castShadow = true;
    this.launchPadGroup.add(towerMesh);

    // Retracting Service Umbilical Arms
    const armMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.7 });
    const arm1Geo = new THREE.BoxGeometry(12, 1.2, 1.2);
    const arm1 = new THREE.Mesh(arm1Geo, armMat);
    arm1.position.set(8, 62, 0);
    this.launchPadGroup.add(arm1);

    const arm2 = new THREE.Mesh(arm1Geo, armMat);
    arm2.position.set(8, 45, 0);
    this.launchPadGroup.add(arm2);
  }

  private buildFactoryGeometry(): void {
    while (this.factoryGroup.children.length > 0) {
      this.factoryGroup.remove(this.factoryGroup.children[0]);
    }

    // Factory Floor Tiles
    const floorGeo = new THREE.PlaneGeometry(160, 160);
    const floorMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.8 });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.receiveShadow = true;
    this.factoryGroup.add(floorMesh);

    // Workstations (FSW Gantry, CNC Roll, Inspection Scanner, Autoclave)
    const fswGantryGeo = new THREE.BoxGeometry(18, 14, 8);
    const machineMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.7, roughness: 0.3 });
    const fswMesh = new THREE.Mesh(fswGantryGeo, machineMat);
    fswMesh.position.set(-20, 7, -10);
    this.factoryGroup.add(fswMesh);

    // Cleanroom Bay Enclosure
    const cleanroomGeo = new THREE.BoxGeometry(25, 12, 20);
    const glassMat = new THREE.MeshStandardMaterial({ color: 0x0f766e, transparent: true, opacity: 0.35, roughness: 0.1 });
    const cleanroomMesh = new THREE.Mesh(cleanroomGeo, glassMat);
    cleanroomMesh.position.set(22, 6, 12);
    this.factoryGroup.add(cleanroomMesh);

    // AGVs (Automated Guided Vehicles)
    const agvGeo = new THREE.BoxGeometry(4, 1.2, 2.5);
    const agvMat = new THREE.MeshStandardMaterial({ color: 0xeab308, roughness: 0.4 });
    const agv1 = new THREE.Mesh(agvGeo, agvMat);
    agv1.position.set(-5, 0.6, 15);
    this.factoryGroup.add(agv1);

    const agv2 = new THREE.Mesh(agvGeo, agvMat);
    agv2.position.set(8, 0.6, -15);
    this.factoryGroup.add(agv2);
  }

  private createPlumeParticles(): void {
    const count = 400;
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 2.5;
      positions[i * 3 + 1] = -Math.random() * 25;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 2.5;

      colors[i * 3] = 1.0; // R
      colors[i * 3 + 1] = 0.5 + Math.random() * 0.5; // G
      colors[i * 3 + 2] = 0.1; // B
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({
      size: 1.2,
      vertexColors: true,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
    });

    this.plumeParticles = new THREE.Points(geometry, material);
    this.plumeParticles.visible = false;
    this.rocketGroup.add(this.plumeParticles);
  }

  private createAeroStreamlines(): void {
    while (this.aeroStreamlinesGroup.children.length > 0) {
      this.aeroStreamlinesGroup.remove(this.aeroStreamlinesGroup.children[0]);
    }

    const lineMat = new THREE.LineBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.6 });
    const radius = 3.0;

    for (let i = 0; i < 24; i++) {
      const angle = (i / 24) * Math.PI * 2;
      const points: THREE.Vector3[] = [];
      for (let y = -5; y <= 75; y += 4) {
        const expand = y > 60 ? (75 - y) * 0.2 : 0;
        const r = radius + expand + Math.sin(y * 0.2) * 0.2;
        points.push(new THREE.Vector3(Math.cos(angle) * r, y, Math.sin(angle) * r));
      }
      const geo = new THREE.BufferGeometry().setFromPoints(points);
      const line = new THREE.Line(geo, lineMat);
      this.aeroStreamlinesGroup.add(line);
    }
  }

  private updateVisibilityAndMaterials(): void {
    const mode = this.renderMode();

    this.launchPadGroup.visible = (mode === 'LAUNCH_PAD');
    this.factoryGroup.visible = (mode === 'FACTORY');
    this.aeroStreamlinesGroup.visible = (mode === 'AERODYNAMICS');
    this.rocketGroup.visible = true;

    // Adjust rocket positioning according to mode
    if (mode === 'LAUNCH_PAD') {
      this.rocketGroup.position.set(0, 6.0, 0); // Sits on launch table
    } else if (mode === 'FACTORY') {
      this.rocketGroup.position.set(0, 4.0, 0);
      this.rocketGroup.rotation.z = Math.PI / 2; // Horizontal assembly cradle in factory
    } else {
      this.rocketGroup.position.set(0, 0, 0);
      this.rocketGroup.rotation.z = 0;
    }

    // Update shaders and materials based on mode
    this.subsystemMeshes.forEach((mesh, key) => {
      mesh.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          if (mode === 'XRAY') {
            child.material = new THREE.MeshBasicMaterial({ 
              color: 0x0284c7, 
              wireframe: true, 
              transparent: true, 
              opacity: 0.6 
            });
          } else if (mode === 'THERMAL') {
            // Gradient false color thermal map
            let tempColor = 0x00ffff; // Cyan/Cool
            if (key === 'FAIRING') tempColor = 0xff6600;
            if (key === 'OCTAWEB') tempColor = 0xff0033;
            if (key === 'S1_LOX_TANK') tempColor = 0x0033aa;
            child.material = new THREE.MeshStandardMaterial({ 
              color: tempColor, 
              emissive: tempColor, 
              emissiveIntensity: 0.35, 
              roughness: 0.5 
            });
          } else if (mode === 'STRESS') {
            // Von Mises Stress false color map
            let stressColor = 0x00ff88; // Low stress green
            if (key === 'OCTAWEB' || key === 'INTERSTAGE') stressColor = 0xff2200; // High stress red
            if (key === 'S1_FUEL_TANK') stressColor = 0xffcc00; // Medium stress yellow
            child.material = new THREE.MeshStandardMaterial({ 
              color: stressColor, 
              roughness: 0.4, 
              metalness: 0.2 
            });
          } else if (mode === 'CUTAWAY') {
            if (key === 'FAIRING' || key === 'S1_LOX_TANK') {
              child.material = new THREE.MeshStandardMaterial({ 
                color: 0xffffff, 
                transparent: true, 
                opacity: 0.35, 
                roughness: 0.2 
              });
            } else {
              child.material = new THREE.MeshStandardMaterial({ color: 0xdde4ed, metalness: 0.5, roughness: 0.3 });
            }
          } else {
            // Default CAD Shaded
            if (key === 'OCTAWEB' || key === 'INTERSTAGE') {
              child.material = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.7, roughness: 0.3 });
            } else if (key === 'AVIONICS') {
              child.material = new THREE.MeshStandardMaterial({ color: 0x0f766e, metalness: 0.6, roughness: 0.4 });
            } else {
              child.material = new THREE.MeshStandardMaterial({ color: 0xededed, metalness: 0.4, roughness: 0.35 });
            }
          }
        }
      });
    });

    if (mode === 'EXPLODED') {
      this.applyExplosionTransforms(this.explosionFactor());
    } else {
      this.applyExplosionTransforms(0);
    }
  }

  private applyExplosionTransforms(factor: number): void {
    const separation = factor * 14.0;

    const fairing = this.subsystemMeshes.get('FAIRING');
    if (fairing) fairing.position.y = fairing.userData['origY'] || fairing.position.y;
    if (fairing && !fairing.userData['origY']) fairing.userData['origY'] = fairing.position.y;
    if (fairing) fairing.position.y = fairing.userData['origY'] + separation * 4.5;

    const payload = this.subsystemMeshes.get('PAYLOAD');
    if (payload) payload.position.y = (payload.userData['origY'] || payload.position.y);
    if (payload && !payload.userData['origY']) payload.userData['origY'] = payload.position.y;
    if (payload) payload.position.y = payload.userData['origY'] + separation * 3.5;

    const avionics = this.subsystemMeshes.get('AVIONICS');
    if (avionics) avionics.position.y = (avionics.userData['origY'] || avionics.position.y);
    if (avionics && !avionics.userData['origY']) avionics.userData['origY'] = avionics.position.y;
    if (avionics) avionics.position.y = avionics.userData['origY'] + separation * 2.8;

    const s2Tank = this.subsystemMeshes.get('STAGE2_TANK');
    if (s2Tank) s2Tank.position.y = (s2Tank.userData['origY'] || s2Tank.position.y);
    if (s2Tank && !s2Tank.userData['origY']) s2Tank.userData['origY'] = s2Tank.position.y;
    if (s2Tank) s2Tank.position.y = s2Tank.userData['origY'] + separation * 2.0;

    const interstage = this.subsystemMeshes.get('INTERSTAGE');
    if (interstage) interstage.position.y = (interstage.userData['origY'] || interstage.position.y);
    if (interstage && !interstage.userData['origY']) interstage.userData['origY'] = interstage.position.y;
    if (interstage) interstage.position.y = interstage.userData['origY'] + separation * 1.2;

    const octaweb = this.subsystemMeshes.get('OCTAWEB');
    if (octaweb) octaweb.position.y = (octaweb.userData['origY'] || octaweb.position.y);
    if (octaweb && !octaweb.userData['origY']) octaweb.userData['origY'] = octaweb.position.y;
    if (octaweb) octaweb.position.y = octaweb.userData['origY'] - separation * 1.5;
  }

  private setupEventListeners(): void {
    const container = this.canvasContainer.nativeElement;

    container.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mousemove', (e) => {
      if (this.isDragging) {
        const deltaX = e.clientX - this.previousMousePosition.x;
        const deltaY = e.clientY - this.previousMousePosition.y;

        this.cameraSpherical.theta -= deltaX * 0.008;
        this.cameraSpherical.phi = Math.max(0.1, Math.min(Math.PI / 2 + 0.1, this.cameraSpherical.phi + deltaY * 0.008));

        this.updateCameraPosition();
        this.previousMousePosition = { x: e.clientX, y: e.clientY };
      }
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });

    container.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.cameraSpherical.radius = Math.max(10, Math.min(300, this.cameraSpherical.radius + e.deltaY * 0.1));
      this.updateCameraPosition();
    });

    // Raycast part selection on click
    container.addEventListener('click', (e) => {
      const rect = container.getBoundingClientRect();
      this.mouse.x = ((e.clientX - rect.left) / container.clientWidth) * 2 - 1;
      this.mouse.y = -((e.clientY - rect.top) / container.clientHeight) * 2 + 1;

      this.raycaster.setFromCamera(this.mouse, this.camera);
      const intersects = this.raycaster.intersectObjects(this.rocketGroup.children, true);

      if (intersects.length > 0) {
        let obj: THREE.Object3D | null = intersects[0].object;
        while (obj && !obj.name && obj !== this.rocketGroup) {
          obj = obj.parent;
        }
        if (obj && obj.name) {
          this.digitalTwin.selectPart(obj.name);
        }
      }
    });

    window.addEventListener('resize', () => {
      if (!this.canvasContainer) return;
      const w = this.canvasContainer.nativeElement.clientWidth;
      const h = this.canvasContainer.nativeElement.clientHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    });
  }

  private updateCameraPosition(): void {
    const { radius, theta, phi } = this.cameraSpherical;
    this.camera.position.x = this.cameraTarget.x + radius * Math.sin(phi) * Math.sin(theta);
    this.camera.position.y = this.cameraTarget.y + radius * Math.cos(phi);
    this.camera.position.z = this.cameraTarget.z + radius * Math.sin(phi) * Math.cos(theta);
    this.camera.lookAt(this.cameraTarget);
  }

  private animate = (): void => {
    this.animationFrameId = requestAnimationFrame(this.animate);

    if (this.isAutoRotating()) {
      this.cameraSpherical.theta += 0.005;
      this.updateCameraPosition();
    }

    // Plume particles animation during launch
    const frame = this.telemetry.currentFrame();
    if (this.plumeParticles && (frame.stage1ThrustKn > 0 || frame.stage2ThrustKn > 0)) {
      this.plumeParticles.visible = true;
      const pos = this.plumeParticles.geometry.attributes['position'] as THREE.BufferAttribute;
      for (let i = 0; i < pos.count; i++) {
        pos.setY(i, pos.getY(i) - 1.2);
        if (pos.getY(i) < -35) {
          pos.setY(i, -0.5);
        }
      }
      pos.needsUpdate = true;
    } else if (this.plumeParticles) {
      this.plumeParticles.visible = false;
    }

    // Factory AGV animation
    if (this.renderMode() === 'FACTORY') {
      const time = performance.now() * 0.001;
      const agv1 = this.factoryGroup.children[3];
      if (agv1) agv1.position.x = -5 + Math.sin(time * 0.8) * 12;
    }

    this.renderer.render(this.scene, this.camera);
  };
}
