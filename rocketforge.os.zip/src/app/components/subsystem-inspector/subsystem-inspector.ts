import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwinService } from '../../core/services/digital-twin.service';
import { TelemetryService } from '../../core/services/telemetry.service';
import { MATERIALS_REGISTRY } from '../../core/physics/constants';

@Component({
  selector: 'app-subsystem-inspector',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (digitalTwin.selectedPartId()) {
      <div class="w-full bg-[#0D1117]/95 border border-[#1F2937] rounded-lg p-4 shadow-2xl backdrop-blur font-mono text-xs text-slate-300">
        <!-- Header with Close button -->
        <div class="flex items-center justify-between border-b border-[#1F2937] pb-2.5 mb-3">
          <div class="flex items-center gap-2">
            <span class="w-2.5 h-2.5 rounded-sm bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.5)]"></span>
            <div>
              <div class="text-[10px] text-cyan-400 tracking-widest uppercase font-semibold">SUBSYSTEM TELEMETRY & DIGITAL TWIN RECORD</div>
              <div class="text-sm font-bold text-slate-100">{{ partDetails().title }}</div>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <span class="px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500/40 text-emerald-400 font-bold text-[10px] uppercase">
              {{ partDetails().status }}
            </span>
            <button (click)="close()" class="text-slate-400 hover:text-slate-100 p-1 rounded hover:bg-[#161B22] transition">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
          </div>
        </div>

        <!-- Specs Grid -->
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
          <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
            <div class="text-[10px] text-slate-400 uppercase">Part ID</div>
            <div class="text-xs font-semibold text-cyan-300">{{ digitalTwin.selectedPartId() }}</div>
          </div>
          <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
            <div class="text-[10px] text-slate-400 uppercase">Material Alloy</div>
            <div class="text-xs font-semibold text-slate-200">{{ partDetails().material }}</div>
          </div>
          <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
            <div class="text-[10px] text-slate-400 uppercase">Estimated Mass</div>
            <div class="text-xs font-semibold text-slate-200">{{ partDetails().mass }}</div>
          </div>
          <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
            <div class="text-[10px] text-slate-400 uppercase">Operating Temp</div>
            <div class="text-xs font-semibold text-amber-300">{{ partDetails().temp }}</div>
          </div>
        </div>

        <!-- NDT / QA Inspection Record -->
        @if (partDetails().inspection; as insp) {
          <div class="p-2.5 bg-[#161B22] border border-[#1F2937] rounded-md mb-3">
            <div class="flex items-center justify-between mb-1.5">
              <span class="text-[10px] text-amber-400 uppercase font-semibold">Latest Non-Destructive Inspection (NDT)</span>
              <span class="text-[10px] text-slate-400 font-mono">{{ insp.timestamp | date:'short' }}</span>
            </div>
            <div class="text-[11px] text-slate-300 mb-1 leading-relaxed">
              {{ insp.notes }}
            </div>
            <div class="flex flex-wrap gap-4 text-[10px] text-slate-400 mt-2 pt-2 border-t border-[#1F2937]">
              <div>METHOD: <span class="text-slate-200 font-semibold">{{ insp.ndtMethod }}</span></div>
              <div>NOMINAL: <span class="text-slate-200">{{ insp.nominalDimensionMm }} mm</span></div>
              <div>MEASURED: <span class="text-emerald-400 font-semibold">{{ insp.measuredDimensionMm }} mm</span></div>
              <div>SEVERITY SCORE: <span class="text-emerald-400 font-semibold">{{ insp.flawSeverityScore }} / 100</span></div>
            </div>
          </div>
        }

        <!-- Engineering Traceability Footer -->
        <div class="flex items-center justify-between text-[10px] text-slate-400 pt-1">
          <div class="flex items-center gap-3">
            <span>SOURCE: <strong class="text-cyan-400">SIMULATED</strong></span>
            <span>FIDELITY: <strong class="text-slate-200">HIGH (NASA-SP-8007)</strong></span>
          </div>
          <span>DIGITAL TWIN REVISION: <strong class="text-slate-200">{{ digitalTwin.rocket().digitalTwin.revision }}</strong></span>
        </div>
      </div>
    }
  `,
  styles: [`
    :host {
      display: block;
    }
  `]
})
export class SubsystemInspector {
  readonly digitalTwin = inject(DigitalTwinService);
  readonly telemetry = inject(TelemetryService);

  readonly partDetails = computed(() => {
    const partId = this.digitalTwin.selectedPartId() || '';
    const rocket = this.digitalTwin.rocket();
    const inspections = rocket.inspections;
    const material = MATERIALS_REGISTRY[rocket.config.structures.primaryMaterial.value]?.name || 'Al-Li 2195';

    let title = 'Subsystem Assembly';
    let mat = material;
    let mass = '4,200 kg';
    let temp = '293 K';
    const status = 'PASS / CERTIFIED';

    if (partId.includes('OCTAWEB') || partId.includes('ENGINE')) {
      title = 'Stage 1 Octaweb & 9-Engine Powerpack Cluster';
      mat = 'Inconel 718 / Ti-6Al-4V';
      mass = `${rocket.config.propulsion.stage1EngineCount.value * 470 + 2400} kg`;
      temp = '1,050 K (Regen Cooled)';
    } else if (partId.includes('LOX')) {
      title = 'Stage 1 Cryogenic Liquid Oxygen (LOX) Tank';
      mass = `${Math.round(rocket.calculatedMassProperties.stage1DryMassKg * 0.45)} kg`;
      temp = '90.15 K (-183°C)';
    } else if (partId.includes('FUEL')) {
      title = 'Stage 1 Liquid Methane / RP-1 Fuel Tank';
      mass = `${Math.round(rocket.calculatedMassProperties.stage1DryMassKg * 0.35)} kg`;
      temp = '111.6 K (-161°C)';
    } else if (partId.includes('INTERSTAGE')) {
      title = 'Carbon Composite Interstage & Pneumatic Pushers';
      mat = 'IM7 Carbon Composite';
      mass = '1,450 kg';
      temp = '340 K';
    } else if (partId.includes('AVIONICS')) {
      title = 'Triple-Modular Redundant Flight Computer & IMU Ring';
      mat = '6061-T6 Al / Heat Pipes';
      mass = '750 kg';
      temp = '298 K';
    } else if (partId.includes('FAIRING') || partId.includes('PAYLOAD')) {
      title = 'Carbon Bismaleimide (BMI) 5.8m Payload Fairing';
      mat = 'Carbon BMI Sandwich';
      mass = `${rocket.calculatedMassProperties.fairingMassKg} kg`;
      temp = '420 K (Aero Heated)';
    }

    const matchedInsp = inspections.find((i) => i.partId === partId) || inspections[0];

    return {
      title,
      material: mat,
      mass,
      temp,
      status,
      inspection: matchedInsp,
    };
  });

  close(): void {
    this.digitalTwin.selectPart(null);
  }
}
