import { ChangeDetectionStrategy, Component, inject, output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwinService } from '../../core/services/digital-twin.service';
import { ScenarioService } from '../../core/services/scenario.service';
import { SimulationClockService } from '../../core/services/simulation-clock.service';

export type AppWorkstationView = 
  | 'VIEWPORT_3D' 
  | 'DESIGNER' 
  | 'MANUFACTURING' 
  | 'TELEMETRY' 
  | 'MONTE_CARLO' 
  | 'AUDIT_QA';

@Component({
  selector: 'app-header-bar',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="w-full bg-[#0D1117] border-b border-[#1F2937] px-4 py-2 flex flex-wrap items-center justify-between gap-3 select-none font-mono">
      <!-- Left: Logo & System Identifier & Metadata Tags -->
      <div class="flex items-center gap-3">
        <!-- Diamond Logo Mark -->
        <div class="w-8 h-8 bg-cyan-500 rounded-sm flex items-center justify-center shadow-[0_0_15px_rgba(34,211,238,0.35)] shrink-0">
          <div class="w-4 h-4 border-2 border-slate-950 rotate-45"></div>
        </div>

        <div>
          <div class="flex items-center gap-2">
            <span class="text-sm font-bold tracking-wider text-slate-100">RocketForge<span class="text-cyan-400">.OS</span></span>
            <span class="text-[9px] px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-500/30 uppercase font-bold tracking-wider">v3.7 Master</span>
          </div>
          <div class="flex items-center gap-2 text-[10px] text-slate-400">
            <span>Vehicle: <strong class="text-slate-200">RF-77-X</strong></span>
            <span>•</span>
            <span>Conf: <strong class="text-slate-200">Block-1C</strong></span>
            <span>•</span>
            <span>Rev: <strong class="text-cyan-400">{{ digitalTwin.rocket().digitalTwin.revision }}</strong></span>
          </div>
        </div>
      </div>

      <!-- Center: Main Workstation View Switcher Tabs -->
      <nav class="flex items-center bg-[#161B22] border border-[#1F2937] rounded-md p-1 gap-1 overflow-x-auto max-w-full">
        @for (view of navViews; track view.id) {
          <button 
            (click)="selectView(view.id)"
            [class.bg-cyan-500]="activeView() === view.id"
            [class.text-slate-950]="activeView() === view.id"
            [class.font-bold]="activeView() === view.id"
            [class.shadow-[0_0_12px_rgba(34,211,238,0.3)]]="activeView() === view.id"
            [class.text-slate-300]="activeView() !== view.id"
            [class.hover:bg-[#1F2937]]="activeView() !== view.id"
            class="px-2.5 py-1 text-xs uppercase tracking-wider rounded transition-colors whitespace-nowrap flex items-center gap-1.5">
            <span>{{ view.icon }}</span>
            <span>{{ view.label }}</span>
          </button>
        }
      </nav>

      <!-- Right: Global Simulation Clock, Scenario Selector & Health Tag -->
      <div class="flex items-center gap-3">
        <!-- Simulation Clock Display -->
        <div class="hidden xl:flex flex-col items-end px-3 py-0.5 bg-[#161B22] border border-[#1F2937] rounded">
          <span class="text-sm font-bold text-cyan-400 tracking-tighter">{{ clock.formattedTime() }}</span>
          <span class="text-[8px] text-slate-500 uppercase tracking-widest">Simulation Clock</span>
        </div>

        <!-- Scenario Presets Dropdown -->
        <div class="flex items-center gap-1.5 bg-[#161B22] border border-[#1F2937] rounded px-2.5 py-1">
          <label for="scenarioSelect" class="text-[10px] text-slate-400 uppercase hidden md:inline font-semibold">Preset:</label>
          <select 
            id="scenarioSelect"
            [value]="scenarios.activeScenarioId()"
            (change)="onScenarioChange($event)"
            class="bg-transparent text-slate-200 text-xs font-semibold focus:outline-none cursor-pointer">
            @for (s of scenarios.scenarios; track s.id) {
              <option [value]="s.id" class="bg-[#161B22] text-slate-200">
                {{ s.code }} - {{ s.name }}
              </option>
            }
          </select>
        </div>

        <!-- SI vs Imperial Unit Switcher -->
        <div class="flex bg-[#161B22] border border-[#1F2937] rounded p-0.5 text-[10px] font-bold">
          <button 
            (click)="digitalTwin.setUnitSystem('SI')"
            [class.bg-cyan-500]="digitalTwin.unitSystem() === 'SI'"
            [class.text-slate-950]="digitalTwin.unitSystem() === 'SI'"
            [class.text-slate-400]="digitalTwin.unitSystem() !== 'SI'"
            class="px-2 py-0.5 rounded transition">
            SI (m, kg)
          </button>
          <button 
            (click)="digitalTwin.setUnitSystem('IMPERIAL')"
            [class.bg-cyan-500]="digitalTwin.unitSystem() === 'IMPERIAL'"
            [class.text-slate-950]="digitalTwin.unitSystem() === 'IMPERIAL'"
            [class.text-slate-400]="digitalTwin.unitSystem() !== 'IMPERIAL'"
            class="px-2 py-0.5 rounded transition">
            US (ft, lbs)
          </button>
        </div>

        <!-- Digital Twin Status Indicators -->
        <div class="flex items-center gap-1.5">
          <span class="px-2 py-1 bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            Nominal
          </span>
          <span class="hidden lg:inline px-2 py-1 bg-[#161B22] border border-[#1F2937] text-slate-300 rounded text-[10px] font-semibold uppercase">
            {{ digitalTwin.rocket().digitalTwin.healthScorePercent }}% Health
          </span>
        </div>
      </div>
    </header>
  `,
  styles: [`
    :host {
      display: block;
    }
  `]
})
export class HeaderBar {
  readonly digitalTwin = inject(DigitalTwinService);
  readonly scenarios = inject(ScenarioService);
  readonly clock = inject(SimulationClockService);

  readonly viewChanged = output<AppWorkstationView>();
  readonly activeView = signal<AppWorkstationView>('VIEWPORT_3D');

  readonly navViews: { id: AppWorkstationView; label: string; icon: string }[] = [
    { id: 'VIEWPORT_3D', label: '3D Digital Twin', icon: '🚀' },
    { id: 'DESIGNER', label: 'Parametric CAD', icon: '⚙️' },
    { id: 'MANUFACTURING', label: 'Manufacturing & Flow', icon: '🏭' },
    { id: 'TELEMETRY', label: 'Flight Telemetry', icon: '📡' },
    { id: 'MONTE_CARLO', label: 'Monte Carlo & Trades', icon: '📊' },
    { id: 'AUDIT_QA', label: 'Audit & QA', icon: '📋' },
  ];

  selectView(view: AppWorkstationView): void {
    this.activeView.set(view);
    this.viewChanged.emit(view);
  }

  onScenarioChange(event: Event): void {
    const id = (event.target as HTMLSelectElement).value;
    this.scenarios.loadScenario(id);
  }
}

