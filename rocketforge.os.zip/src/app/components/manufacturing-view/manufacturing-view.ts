import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManufacturingService } from '../../core/services/manufacturing.service';

@Component({
  selector: 'app-manufacturing-view',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0D1117] border border-[#1F2937] rounded-lg overflow-hidden font-mono text-xs shadow-2xl">
      <!-- Master Manufacturing Control Bar -->
      <div class="p-3 bg-[#0D1117] border-b border-[#1F2937] flex flex-wrap items-center justify-between gap-3">
        <div class="flex items-center gap-2">
          <span class="w-2.5 h-2.5 rounded-sm bg-emerald-400 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]"></span>
          <div>
            <div class="text-xs font-bold text-slate-100 uppercase tracking-wider">FACTORY WORKCELL DIGITAL TWIN & PRODUCTION SCHEDULER</div>
            <div class="text-[9px] text-slate-400">12-STEP STAGE 1 FABRICATION SEQUENCE • DISCRETE EVENT SIMULATOR</div>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <!-- Play / Pause Production -->
          <button 
            (click)="toggleFactorySim()"
            [class.bg-amber-500]="mfg.isRunning()"
            [class.text-slate-950]="mfg.isRunning()"
            [class.bg-emerald-500]="!mfg.isRunning()"
            [class.text-slate-950]="!mfg.isRunning()"
            class="px-3 py-1 font-bold rounded flex items-center gap-1.5 transition text-xs shadow-[0_0_12px_rgba(16,185,129,0.3)]">
            @if (mfg.isRunning()) {
              <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
              <span>PAUSE LINE</span>
            } @else {
              <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
              <span>RUN FACTORY</span>
            }
          </button>

          <!-- Step Forward -->
          <button 
            (click)="mfg.stepForward()"
            class="px-2.5 py-1 bg-[#161B22] hover:bg-[#1F2937] text-slate-300 rounded border border-[#1F2937] text-xs">
            Next Step
          </button>

          <!-- Reset -->
          <button 
            (click)="mfg.resetProduction()"
            class="px-2.5 py-1 bg-[#161B22] hover:bg-[#1F2937] text-slate-300 rounded border border-[#1F2937] text-xs">
            Reset
          </button>
        </div>
      </div>

      <!-- Factory KPI Summary Bar -->
      <div class="grid grid-cols-2 sm:grid-cols-5 gap-2 p-3 bg-[#0A0C10] border-b border-[#1F2937]">
        <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
          <div class="text-[9px] text-slate-400 uppercase">First Pass Yield</div>
          <div class="text-sm font-bold text-emerald-400">{{ (mfg.kpis().firstPassYield * 100).toFixed(1) }}%</div>
          <div class="text-[9px] text-slate-500">Target: >95.0%</div>
        </div>
        <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
          <div class="text-[9px] text-slate-400 uppercase">Total Stage Cycle Time</div>
          <div class="text-sm font-bold text-cyan-400">{{ mfg.kpis().totalCycleTimeHours.toFixed(0) }} Hours</div>
          <div class="text-[9px] text-slate-500">~{{ (mfg.kpis().totalCycleTimeHours / 24).toFixed(1) }} Prod. Days</div>
        </div>
        <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
          <div class="text-[9px] text-slate-400 uppercase">Stage Manufacturing Cost</div>
          <div class="text-sm font-bold text-amber-400">\${{ (mfg.kpis().totalVehicleCostUsd / 1000000).toFixed(2) }}M</div>
          <div class="text-[9px] text-slate-500">Materials: \${{ (mfg.kpis().materialsCostUsd / 1000000).toFixed(2) }}M</div>
        </div>
        <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
          <div class="text-[9px] text-slate-400 uppercase">Active Bottleneck</div>
          <div class="text-sm font-bold text-rose-400">{{ mfg.kpis().bottleneckStation }}</div>
          <div class="text-[9px] text-slate-500">WIP Queue: 2 Cores</div>
        </div>
        <div class="p-2 bg-[#161B22] border border-[#1F2937] rounded">
          <div class="text-[9px] text-slate-400 uppercase">Annual Throughput</div>
          <div class="text-sm font-bold text-slate-100">26 Vehicles / Year</div>
          <div class="text-[9px] text-emerald-400">OEE: 89.4%</div>
        </div>
      </div>

      <!-- Main Manufacturing Flow Grid -->
      <div class="flex-1 overflow-y-auto p-4 space-y-3">
        <div class="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between">
          <span>12-Step Integrated Fabrication Sequence</span>
          <span class="text-cyan-400 font-mono text-[11px]">ACTIVE PROCESS GRAPH</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          @for (step of mfg.processGraph(); track step.id) {
            <button 
              type="button"
              class="p-3 bg-[#161B22] border rounded-md flex flex-col justify-between transition cursor-pointer hover:border-slate-600 text-left w-full"
              (click)="mfg.selectStep(step.order - 1)"
              [class.border-cyan-400]="step.status === 'IN_PROGRESS'"
              [class.shadow-[0_0_15px_rgba(34,211,238,0.2)]]="step.status === 'IN_PROGRESS'"
              [class.border-emerald-500/40]="step.status === 'COMPLETED'"
              [class.border-[#1F2937]]="step.status === 'PENDING'"
              [class.border-rose-500]="step.status === 'REWORK_REQUIRED'">
              
              <div class="w-full">
                <!-- Step Top Row -->
                <div class="flex items-center justify-between mb-2">
                  <span class="px-2 py-0.5 rounded bg-[#0D1117] text-slate-400 font-bold text-[10px] border border-[#1F2937]">
                    STEP {{ step.order }} • {{ step.department }}
                  </span>
                  <span 
                    class="px-2 py-0.5 rounded font-bold text-[10px] uppercase border"
                    [class.bg-emerald-950]="step.status === 'COMPLETED'"
                    [class.text-emerald-400]="step.status === 'COMPLETED'"
                    [class.border-emerald-500/30]="step.status === 'COMPLETED'"
                    [class.bg-cyan-950]="step.status === 'IN_PROGRESS'"
                    [class.text-cyan-300]="step.status === 'IN_PROGRESS'"
                    [class.border-cyan-500/40]="step.status === 'IN_PROGRESS'"
                    [class.bg-[#0D1117]]="step.status === 'PENDING'"
                    [class.text-slate-400]="step.status === 'PENDING'"
                    [class.border-[#1F2937]]="step.status === 'PENDING'"
                    [class.bg-rose-950]="step.status === 'REWORK_REQUIRED'"
                    [class.text-rose-400]="step.status === 'REWORK_REQUIRED'"
                    [class.border-rose-500/30]="step.status === 'REWORK_REQUIRED'">
                    {{ step.status }}
                  </span>
                </div>

                <div class="font-bold text-slate-200 text-xs mb-1">{{ step.name }}</div>
                <div class="text-[11px] text-slate-400 mb-2 leading-relaxed">
                  {{ step.stationName }} • {{ step.equipmentRequired }}
                </div>
              </div>

              <!-- Metrics & Progress -->
              <div class="space-y-2 pt-2 border-t border-[#1F2937] text-[10px] w-full">
                <div class="flex justify-between text-slate-400">
                  <span>Operator: <strong class="text-slate-300">{{ step.operatorRole }}</strong></span>
                  <span>Duration: <strong class="text-cyan-400">{{ step.estimatedDurationHours }}h</strong></span>
                </div>

                <!-- Progress Bar -->
                <div class="w-full h-1.5 bg-[#0D1117] rounded-full overflow-hidden">
                  <div 
                    class="h-full bg-cyan-400 transition-all duration-300 shadow-[0_0_8px_rgba(34,211,238,0.5)]"
                    [style.width.%]="step.progressPercent"></div>
                </div>

                <div class="flex justify-between text-slate-400">
                  <span>Standard Cost: <strong class="text-amber-400">\${{ (step.standardCostUsd / 1000).toFixed(0) }}k</strong></span>
                  <span>Quality Gate: <strong class="text-emerald-400">{{ step.qualityGatePassed ? 'PASSED' : 'PENDING' }}</strong></span>
                </div>
              </div>
            </button>
          }
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `]
})
export class ManufacturingView {
  readonly mfg = inject(ManufacturingService);

  toggleFactorySim(): void {
    if (this.mfg.isRunning()) {
      this.mfg.pauseProduction();
    } else {
      this.mfg.startProduction();
    }
  }
}

