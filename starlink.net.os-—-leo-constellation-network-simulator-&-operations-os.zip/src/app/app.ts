import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TelemetryRibbon } from './features/telemetry/telemetry-ribbon';
import { NetworkMap } from './features/map/network-map';
import { NodeInspector } from './features/inspector/node-inspector';
import { RoutingLab } from './features/routing-lab/routing-lab';
import { CapacityPlanner } from './features/capacity/capacity-planner';
import { AnalyticsView } from './features/analytics/analytics-view';
import { TerminalCli } from './features/cli/terminal-cli';
import { ScenarioPanel } from './features/scenarios/scenario-panel';
import { SimulationService } from './core/services/simulation.service';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    CommonModule,
    TelemetryRibbon,
    NetworkMap,
    NodeInspector,
    RoutingLab,
    CapacityPlanner,
    AnalyticsView,
    TerminalCli,
    ScenarioPanel
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  public simService = inject(SimulationService);
}

