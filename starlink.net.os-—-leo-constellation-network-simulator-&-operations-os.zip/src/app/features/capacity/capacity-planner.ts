// STARLINK.NET.OS — Constellation Capacity Planning & Bottleneck Diagnostic Engine
// Evaluates orbital plane capacity limits, ground station feeder saturation, and calculates expansion requirements

import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';
import { CapacityPlanResult } from '../../core/models/types';

interface RegionProfile {
  name: string;
  population: number;
  subscribers: number;
  currentDemandGbps: number;
  description: string;
}

const REGION_PRESETS: RegionProfile[] = [
  {
    name: 'North America (US & Canada)',
    population: 375000000,
    subscribers: 2400000,
    currentDemandGbps: 1850.0,
    description: 'Dense residential, enterprise starlink aviation & maritime high-traffic corridor.'
  },
  {
    name: 'Western & Central Europe',
    population: 450000000,
    subscribers: 1100000,
    currentDemandGbps: 980.0,
    description: 'High terrestrial fiber penetration with rural broadband and maritime demand in North Sea.'
  },
  {
    name: 'Southeast Asia & Pacific Archipelagos',
    population: 680000000,
    subscribers: 850000,
    currentDemandGbps: 720.0,
    description: 'Island connectivity challenges, heavy maritime fishing and inter-island ferry demand.'
  },
  {
    name: 'Latin America (South & Central)',
    population: 650000000,
    subscribers: 750000,
    currentDemandGbps: 580.0,
    description: 'Amazon basin rural mining, agricultural IoT, and Andean mountain community coverage.'
  },
  {
    name: 'Sub-Saharan Africa Rural Education',
    population: 1100000000,
    subscribers: 420000,
    currentDemandGbps: 340.0,
    description: 'Remote village schools, health clinic connectivity, and cross-border logistics.'
  },
  {
    name: 'Trans-Polar Aviation Corridor',
    population: 50000,
    subscribers: 12000,
    currentDemandGbps: 190.0,
    description: 'High-latitude commercial air traffic routes relying exclusively on inter-satellite laser ISLs.'
  }
];

@Component({
  selector: 'app-capacity-planner',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="w-full h-full bg-[#06090e] p-4 flex flex-col gap-4 overflow-y-auto custom-scrollbar select-none">
      <!-- Capacity Planner Header -->
      <div class="bg-[#0b121f] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4 shadow-lg">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400">query_stats</mat-icon>
            <h1 class="text-base font-display font-black tracking-wider text-slate-100">
              CONSTELLATION CAPACITY PLANNING & BOTTLENECK DIAGNOSTIC
            </h1>
            <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-800">
              ORBITAL OPTIMIZATION
            </span>
          </div>
          <p class="text-xs font-mono text-slate-400 mt-1">
            Simulates long-term subscriber adoption, orbital plane pass frequency, and computes recommended satellite & ground station expansions.
          </p>
        </div>

        <!-- Annual Growth Rate Config -->
        <div class="flex items-center gap-2 bg-[#080d16] border border-slate-800 rounded-lg px-3 py-1.5 text-xs font-mono">
          <span class="text-slate-400">ANNUAL TRAFFIC GROWTH:</span>
          <button
            (click)="growthRate.set(15)"
            [class.text-cyan-400]="growthRate() === 15"
            [class.text-slate-500]="growthRate() !== 15"
            class="px-1.5 py-0.5 font-bold"
          >
            15%
          </button>
          <button
            (click)="growthRate.set(25)"
            [class.text-cyan-400]="growthRate() === 25"
            [class.text-slate-500]="growthRate() !== 25"
            class="px-1.5 py-0.5 font-bold"
          >
            25%
          </button>
          <button
            (click)="growthRate.set(40)"
            [class.text-cyan-400]="growthRate() === 40"
            [class.text-slate-500]="growthRate() !== 40"
            class="px-1.5 py-0.5 font-bold"
          >
            40%
          </button>
          <button
            (click)="growthRate.set(65)"
            [class.text-cyan-400]="growthRate() === 65"
            [class.text-slate-500]="growthRate() !== 65"
            class="px-1.5 py-0.5 font-bold"
          >
            65% (Aggressive)
          </button>
        </div>
      </div>

      <!-- Region Selection Row -->
      <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2.5">
        @for (region of regions; track region.name) {
          <button
            (click)="selectedRegion.set(region)"
            [class.border-cyan-500]="selectedRegion().name === region.name"
            [class.bg-cyan-950/30]="selectedRegion().name === region.name"
            [class.border-slate-800]="selectedRegion().name !== region.name"
            class="p-2.5 rounded-xl border bg-[#0b121f] hover:bg-slate-800/60 text-left transition-all space-y-1 shadow-sm"
          >
            <div class="font-mono text-xs font-bold text-slate-200 truncate">{{ region.name }}</div>
            <div class="text-[10px] font-mono text-slate-400">Pop: {{ (region.population / 1e6).toFixed(0) }}M</div>
            <div class="text-[10px] font-mono text-cyan-400 font-semibold">{{ region.currentDemandGbps }} Gbps Load</div>
          </button>
        }
      </div>

      <!-- Main Analytical Dashboard -->
      @let plan = currentPlan();
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
        <!-- Key Metrics Cards (5 Cols) -->
        <div class="lg:col-span-5 flex flex-col gap-3">
          <!-- Region Profile Card -->
          <div class="bg-[#0b121f] border border-slate-800 rounded-xl p-4 space-y-2 shadow">
            <div class="flex items-center justify-between">
              <span class="text-xs font-mono font-bold text-slate-300 uppercase">{{ plan.region }}</span>
              <span class="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300">
                GROWTH: {{ growthRate() }}% YoY
              </span>
            </div>
            <p class="text-xs font-mono text-slate-400">{{ selectedRegion().description }}</p>

            <div class="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800 text-xs font-mono">
              <div class="bg-slate-900/80 p-2 rounded border border-slate-800">
                <div class="text-[10px] text-slate-500">CURRENT REGIONAL LOAD</div>
                <div class="text-base font-bold text-cyan-400 tabular-nums">{{ plan.currentDemandGbps }} Gbps</div>
              </div>
              <div class="bg-slate-900/80 p-2 rounded border border-slate-800">
                <div class="text-[10px] text-slate-500">PROJECTED PEAK LOAD</div>
                <div class="text-base font-bold text-amber-400 tabular-nums">{{ plan.projectedDemandGbps }} Gbps</div>
              </div>
              <div class="bg-slate-900/80 p-2 rounded border border-slate-800">
                <div class="text-[10px] text-slate-500">AVG VISIBLE SATS (PASS)</div>
                <div class="text-base font-bold text-slate-200 tabular-nums">{{ plan.visibleSatsAvg }} Sats</div>
              </div>
              <div class="bg-slate-900/80 p-2 rounded border border-slate-800">
                <div class="text-[10px] text-slate-500">CONSTELLATION SUPPLY</div>
                <div class="text-base font-bold text-emerald-400 tabular-nums">{{ plan.simultaneousCapacityGbps }} Gbps</div>
              </div>
            </div>
          </div>

          <!-- Bottleneck Health Diagnostic Card -->
          <div class="bg-[#0b121f] border border-slate-800 rounded-xl p-4 space-y-3 shadow">
            <div class="flex items-center gap-2 border-b border-slate-800 pb-2">
              <mat-icon class="text-sm text-cyan-400">tune</mat-icon>
              <span class="font-mono text-xs font-bold text-slate-200 uppercase">
                BOTTLENECK IDENTIFICATION
              </span>
            </div>

            <div class="space-y-2 text-xs font-mono">
              <div>
                <div class="flex justify-between text-[11px] mb-1">
                  <span class="text-slate-400">Satellite RF Downlink Saturation:</span>
                  <span [class.text-rose-400]="plan.satelliteBottleneckGbps > 0" [class.text-emerald-400]="plan.satelliteBottleneckGbps === 0">
                    {{ plan.satelliteBottleneckGbps > 0 ? '+' + plan.satelliteBottleneckGbps + ' Gbps Deficit' : 'SUFFICIENT' }}
                  </span>
                </div>
                <div class="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    class="h-full rounded-full transition-all"
                    [class.bg-emerald-500]="plan.satelliteBottleneckGbps === 0"
                    [class.bg-rose-500]="plan.satelliteBottleneckGbps > 0"
                    [style.width.%]="Math.min(100, (plan.projectedDemandGbps / Math.max(1, plan.simultaneousCapacityGbps)) * 100)"
                  ></div>
                </div>
              </div>

              <div>
                <div class="flex justify-between text-[11px] mb-1">
                  <span class="text-slate-400">Ground Feeder Teleport Capacity:</span>
                  <span [class.text-rose-400]="plan.groundStationBottleneckGbps > 0" [class.text-emerald-400]="plan.groundStationBottleneckGbps === 0">
                    {{ plan.groundStationBottleneckGbps > 0 ? '+' + plan.groundStationBottleneckGbps + ' Gbps Deficit' : 'SUFFICIENT' }}
                  </span>
                </div>
                <div class="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    class="h-full rounded-full transition-all"
                    [class.bg-emerald-500]="plan.groundStationBottleneckGbps === 0"
                    [class.bg-rose-500]="plan.groundStationBottleneckGbps > 0"
                    [style.width.%]="Math.min(100, (plan.projectedDemandGbps / Math.max(1, plan.groundStationCapacityGbps)) * 100)"
                  ></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Expansion Recommendations & Engineering Strategy (7 Cols) -->
        <div class="lg:col-span-7 bg-[#0b121f] border border-cyan-900/60 rounded-xl p-4 flex flex-col gap-3 shadow-lg">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400">verified</mat-icon>
              <span class="font-mono text-xs font-bold text-slate-100 uppercase">
                RECOMMENDED CONSTELLATION AUGMENTATION
              </span>
            </div>
            <span class="text-[10px] font-mono text-cyan-400">MATHEMATICAL SYNTHESIS</span>
          </div>

          <!-- Recommendation Action Cards -->
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div class="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-1">
              <div class="text-[10px] font-mono text-slate-400 uppercase">ORBITAL EXPANSION</div>
              <div class="text-lg font-mono font-bold text-cyan-300 tabular-nums">
                +{{ plan.recommendedSatsIncrease }} SATELLITES
              </div>
              <p class="text-[11px] font-mono text-slate-400">
                Add {{ Math.ceil(plan.recommendedSatsIncrease / (simService.config().satellitesPerPlane || 20)) }} orbital plane(s) at {{ simService.config().inclinationDeg }}° inclination to maintain un-congested spot-beam density.
              </p>
            </div>

            <div class="bg-slate-900/90 border border-slate-800 rounded-lg p-3 space-y-1">
              <div class="text-[10px] font-mono text-slate-400 uppercase">GROUND TELEPORTS</div>
              <div class="text-lg font-mono font-bold text-emerald-300 tabular-nums">
                +{{ plan.recommendedNewGroundStations }} GATEWAYS
              </div>
              <p class="text-[11px] font-mono text-slate-400">
                Deploy {{ plan.recommendedNewGroundStations }} new multi-dish ground teleport facility with direct tier-1 optical fiber interconnects to avoid terrestrial bottlenecks.
              </p>
            </div>
          </div>

          <!-- Provenance Summary Quote -->
          <div class="bg-[#080d16] border border-slate-800/80 rounded-lg p-3 text-xs font-mono text-slate-300 space-y-1">
            <div class="font-bold text-cyan-400 uppercase text-[10px]">Data Provenance Chain:</div>
            <p class="text-[11px] text-slate-400">{{ plan.provenanceSummary }}</p>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CapacityPlanner {
  public simService = inject(SimulationService);
  public Math = Math;

  public regions = REGION_PRESETS;
  public selectedRegion = signal<RegionProfile>(REGION_PRESETS[0]);
  public growthRate = signal<number>(25);

  public currentPlan = computed<CapacityPlanResult>(() => {
    const reg = this.selectedRegion();
    return this.simService.runCapacityAnalysis(reg.name, reg.population, this.growthRate());
  });
}
