// STARLINK.NET.OS — Aerospace Interactive Network Operations CLI Terminal
// Emulates full command line interface with auto-complete, history scroll, and diagnostic telemetry output

import { ChangeDetectionStrategy, Component, ElementRef, ViewChild, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-terminal-cli',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="w-full h-full bg-[#05080e] p-4 flex flex-col gap-3 font-mono select-none overflow-hidden">
      <!-- CLI Top Bar -->
      <div class="bg-[#0b121f] border border-slate-800 rounded-xl px-4 py-3 flex items-center justify-between shadow">
        <div class="flex items-center gap-2">
          <div class="flex gap-1.5 mr-2">
            <span class="w-3 h-3 rounded-full bg-rose-500/80 inline-block"></span>
            <span class="w-3 h-3 rounded-full bg-amber-500/80 inline-block"></span>
            <span class="w-3 h-3 rounded-full bg-emerald-500/80 inline-block"></span>
          </div>
          <mat-icon class="text-xs text-cyan-400">terminal</mat-icon>
          <span class="text-xs font-bold text-slate-200">STARLINK.NET.OS OPERATIONS CLI</span>
          <span class="text-[10px] text-slate-500">| TTY-01 [ACTIVE]</span>
        </div>

        <!-- Quick Command Chips -->
        <div class="hidden sm:flex items-center gap-1.5 text-xs">
          <span class="text-[10px] text-slate-500">QUICK:</span>
          <button
            (click)="runQuickCommand('starlink-net coverage')"
            class="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 text-[10px]"
          >
            coverage
          </button>
          <button
            (click)="runQuickCommand('starlink-net metrics')"
            class="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 text-[10px]"
          >
            metrics
          </button>
          <button
            (click)="runQuickCommand('starlink-net scenario traffic-surge')"
            class="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 text-[10px]"
          >
            surge scenario
          </button>
          <button
            (click)="runQuickCommand('help')"
            class="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px]"
          >
            help
          </button>
        </div>
      </div>

      <!-- Main Terminal Buffer Window -->
      <div
        #terminalWindow
        class="flex-1 bg-[#02050a] border border-slate-900 rounded-xl p-4 overflow-y-auto custom-scrollbar font-mono text-xs space-y-3 shadow-inner"
      >
        <!-- Welcome banner -->
        <div class="text-slate-400 space-y-1">
          <div class="text-cyan-400 font-bold">
            ╔══════════════════════════════════════════════════════════════════════════╗
          </div>
          <div class="text-cyan-400 font-bold">
            ║  STARLINK.NET.OS — CONSTELLATION GRAPH DIGITAL TWIN CONSOLE v4.2         ║
          </div>
          <div class="text-cyan-400 font-bold">
            ╚══════════════════════════════════════════════════════════════════════════╝
          </div>
          <div class="text-[11px] text-slate-500">
            Type 'help' to inspect all constellation commands, 'clear' to clear console.
          </div>
        </div>

        <!-- History stream -->
        @for (item of simService.cliHistory(); track $index) {
          <div class="space-y-1">
            <div class="flex items-center gap-2 text-cyan-300">
              <span class="text-slate-500">[{{ item.timestamp }}]</span>
              <span class="text-emerald-400">ops&#64;starlink-net:~$</span>
              <span class="font-bold text-white">{{ item.command }}</span>
            </div>
            <pre
              class="text-[11px] pl-4 whitespace-pre-wrap leading-relaxed"
              [class.text-rose-400]="item.isError"
              [class.text-slate-300]="!item.isError"
            >{{ item.output }}</pre>
          </div>
        }

        <!-- Active Input Line -->
        <div class="flex items-center gap-2 pt-2 text-sm">
          <span class="text-emerald-400 font-bold">ops&#64;starlink-net:~$</span>
          <input
            #cliInputRef
            type="text"
            [value]="currentInput()"
            (input)="onInputChange($event)"
            (keydown)="onKeyDown($event)"
            placeholder="Type a command (e.g. 'starlink-net coverage', 'starlink-net inspect SAT-P01-01', 'help')..."
            class="flex-1 bg-transparent border-none outline-none text-cyan-300 font-mono text-xs placeholder:text-slate-700"
            autocomplete="off"
            spellcheck="false"
          />
        </div>
      </div>
    </div>
  `
})
export class TerminalCli {
  public simService = inject(SimulationService);

  @ViewChild('terminalWindow') terminalWindow!: ElementRef<HTMLDivElement>;
  @ViewChild('cliInputRef') cliInputRef!: ElementRef<HTMLInputElement>;

  public currentInput = signal<string>('');
  private historyIndex = -1;

  public onInputChange(e: Event): void {
    const val = (e.target as HTMLInputElement).value;
    this.currentInput.set(val);
  }

  public onKeyDown(e: KeyboardEvent): void {
    if (e.key === 'Enter') {
      const cmd = this.currentInput();
      if (cmd.trim()) {
        this.simService.executeCli(cmd);
        this.currentInput.set('');
        if (this.cliInputRef) {
          this.cliInputRef.nativeElement.value = '';
        }
        this.historyIndex = -1;
        this.scrollToBottom();
      }
    }
  }

  public runQuickCommand(cmd: string): void {
    this.simService.executeCli(cmd);
    this.scrollToBottom();
  }

  private scrollToBottom(): void {
    setTimeout(() => {
      if (this.terminalWindow) {
        this.terminalWindow.nativeElement.scrollTop = this.terminalWindow.nativeElement.scrollHeight;
      }
    }, 50);
  }
}
