// STARLINK.NET.OS — Multi-Entity Deep Engineering Node Inspector
// Displays full physical telemetry, steerable beam allocations, candidate handover scoring, and latency breakdown

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';
import { GroundStation, Satellite, UserTerminal } from '../../core/models/types';

@Component({
  selector: 'app-node-inspector',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <aside class="w-80 h-full bg-[#080d16] border-l border-slate-800/90 flex flex-col z-20 select-none overflow-hidden">
      <!-- Inspector Header -->
      <div class="px-4 py-2.5 border-b border-slate-800 flex items-center justify-between bg-[#0b121f]">
        <div class="flex items-center gap-2">
          <mat-icon class="text-sm text-cyan-400">biotech</mat-icon>
          <span class="font-mono text-xs font-bold text-slate-200 uppercase tracking-wider">
            NODE INSPECTOR
          </span>
        </div>
        @if (simService.selectedObject()) {
          <button
            (click)="simService.clearSelection()"
            class="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
            title="Close Inspector"
          >
            <mat-icon class="text-xs scale-75">close</mat-icon>
          </button>
        }
      </div>

      <!-- Inspector Body Scrollable -->
      <div class="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-4">
        @if (!simService.selectedObject()) {
          <!-- Empty State / Constellation Summary -->
          <div class="text-center py-10 px-4">
            <mat-icon class="text-3xl text-slate-600 mb-2">radar</mat-icon>
            <div class="font-mono text-xs font-semibold text-slate-300">NO NODE SELECTED</div>
            <p class="text-[11px] font-mono text-slate-500 mt-1">
              Select any Satellite, Teleport Ground Station, or User Terminal from the map or list to inspect real-time orbital and RF telemetry.
            </p>

            <!-- Quick Selection Dropdown -->
            <div class="mt-6 text-left space-y-2">
              <div class="text-[10px] font-mono text-slate-400 uppercase">Quick Terminal Jump:</div>
              <div class="space-y-1">
                @for (term of simService.terminals().slice(0, 6); track term.id) {
                  <button
                    (click)="simService.selectTerminal(term.id)"
                    class="w-full text-left px-2 py-1.5 rounded bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-[11px] font-mono text-slate-300 flex items-center justify-between"
                  >
                    <span>{{ term.name }}</span>
                    <span class="text-[9px] text-cyan-400">{{ term.type }}</span>
                  </button>
                }
              </div>
            </div>
          </div>
        } @else if (simService.selectedObject()?.type === 'SATELLITE') {
          <!-- SATELLITE INSPECTION PANEL -->
          @let sat = getAsSatellite(simService.selectedObject()!.data);
          <div class="space-y-3">
            <!-- Title & Status Badge -->
            <div class="flex items-start justify-between">
              <div>
                <div class="text-sm font-display font-bold text-slate-100">{{ sat.name }}</div>
                <div class="text-[10px] font-mono text-cyan-400">{{ sat.id }} • PLANE {{ sat.planeIndex + 1 }}</div>
              </div>
              <span
                class="px-2 py-0.5 rounded text-[10px] font-mono font-bold"
                [class.bg-emerald-950]="sat.health === 'NOMINAL'"
                [class.text-emerald-400]="sat.health === 'NOMINAL'"
                [class.border]="true"
                [class.border-emerald-800]="sat.health === 'NOMINAL'"
                [class.bg-rose-950]="sat.health === 'OFFLINE'"
                [class.text-rose-400]="sat.health === 'OFFLINE'"
                [class.border-rose-800]="sat.health === 'OFFLINE'"
              >
                {{ sat.health }}
              </span>
            </div>

            <!-- Action: Inject / Clear Failure -->
            <button
              (click)="simService.triggerFailure(sat.id)"
              [class.bg-rose-900]="sat.health === 'NOMINAL'"
              [class.hover:bg-rose-800]="sat.health === 'NOMINAL'"
              [class.bg-emerald-900]="sat.health === 'OFFLINE'"
              [class.hover:bg-emerald-800]="sat.health === 'OFFLINE'"
              class="w-full py-1 px-2 rounded text-xs font-mono font-bold text-white transition-colors flex items-center justify-center gap-1 shadow"
            >
              <mat-icon class="text-xs scale-75">{{ sat.health === 'NOMINAL' ? 'warning' : 'build' }}</mat-icon>
              {{ sat.health === 'NOMINAL' ? 'INJECT SATELLITE FAULT' : 'RESTORE TO NOMINAL' }}
            </button>

            <!-- Physical & Orbital Telemetry -->
            <div class="bg-[#0b121f] border border-slate-800 rounded-lg p-2.5 space-y-1.5 text-xs font-mono">
              <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800 pb-1 flex items-center justify-between">
                <span>ORBITAL KINEMATICS</span>
                <span class="text-cyan-400">J2 KEPLERIAN</span>
              </div>
              <div class="grid grid-cols-2 gap-1.5 text-[11px]">
                <div>
                  <span class="text-slate-500">Latitude:</span>
                  <span class="text-slate-200 float-right tabular-nums">{{ sat.lat }}°</span>
                </div>
                <div>
                  <span class="text-slate-500">Longitude:</span>
                  <span class="text-slate-200 float-right tabular-nums">{{ sat.lon }}°</span>
                </div>
                <div>
                  <span class="text-slate-500">Altitude:</span>
                  <span class="text-slate-200 float-right tabular-nums">{{ sat.altKm }} km</span>
                </div>
                <div>
                  <span class="text-slate-500">Velocity:</span>
                  <span class="text-slate-200 float-right tabular-nums">{{ sat.velocityKmS }} km/s</span>
                </div>
                <div>
                  <span class="text-slate-500">Orbital Period:</span>
                  <span class="text-slate-200 float-right tabular-nums">{{ sat.orbitalPeriodMin.toFixed(1) }} min</span>
                </div>
                <div>
                  <span class="text-slate-500">Inclination:</span>
                  <span class="text-slate-200 float-right tabular-nums">{{ ((sat.inclinationRad * 180) / 3.14159).toFixed(1) }}°</span>
                </div>
              </div>
            </div>

            <!-- Subsystem Health -->
            <div class="bg-[#0b121f] border border-slate-800 rounded-lg p-2.5 space-y-1.5 text-xs font-mono">
              <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800 pb-1">
                BUS SUBSYSTEM TELEMETRY
              </div>
              <div class="space-y-1 text-[11px]">
                <div class="flex justify-between">
                  <span class="text-slate-500">Solar Array Power:</span>
                  <span class="text-emerald-400 tabular-nums">{{ sat.powerStateW }}W / {{ sat.maxPowerW }}W</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-500">Thermal Radiator:</span>
                  <span class="text-cyan-400 tabular-nums">{{ sat.thermalStateC }}°C (Nominal)</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-500">Total Throughput:</span>
                  <span class="text-amber-400 tabular-nums font-bold">{{ sat.throughputGbps }} / {{ sat.downlinkCapacityGbps }} Gbps</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-500">Switch Utilization:</span>
                  <span class="text-slate-200 tabular-nums">{{ sat.utilizationPct }}% ({{ sat.congestionState }})</span>
                </div>
              </div>
            </div>

            <!-- Active Spot Beams Table -->
            <div class="bg-[#0b121f] border border-slate-800 rounded-lg p-2.5 space-y-1.5 text-xs font-mono">
              <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800 pb-1 flex justify-between">
                <span>ACTIVE STEERABLE BEAMS</span>
                <span class="text-cyan-400">{{ sat.activeBeams.length }}/{{ sat.maxBeams }}</span>
              </div>
              @if (!sat.activeBeams.length) {
                <div class="text-[11px] text-slate-500 py-1">No active beam footprints over ground cells.</div>
              } @else {
                <div class="space-y-1 max-h-36 overflow-y-auto custom-scrollbar">
                  @for (beam of sat.activeBeams; track beam.id) {
                    <div class="p-1.5 rounded bg-slate-900/60 border border-slate-800 text-[10px] space-y-0.5">
                      <div class="flex justify-between font-semibold text-slate-300">
                        <span>{{ beam.id }}</span>
                        <span [class.text-rose-400]="beam.status === 'CONGESTED'" [class.text-cyan-400]="beam.status === 'ACTIVE'">
                          {{ beam.utilizationPct }}% UTIL
                        </span>
                      </div>
                      <div class="text-slate-400 flex justify-between">
                        <span>Users: {{ beam.userCount }}</span>
                        <span>{{ beam.usedCapacityMbps }} / {{ beam.allocatedCapacityMbps }} Mbps</span>
                      </div>
                    </div>
                  }
                </div>
              }
            </div>

            <!-- Active ISL Crosslinks -->
            <div class="bg-[#0b121f] border border-slate-800 rounded-lg p-2.5 space-y-1.5 text-xs font-mono">
              <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800 pb-1">
                OPTICAL ISL CROSSLINKS ({{ sat.activeLinks.length }})
              </div>
              <div class="space-y-1">
                @for (linkId of sat.activeLinks; track linkId) {
                  <div class="text-[10px] text-slate-400 bg-slate-900/80 p-1 rounded border border-slate-800/80 flex items-center justify-between">
                    <span class="text-cyan-300 truncate max-w-[170px]">{{ linkId }}</span>
                    <span class="text-emerald-400">LOCKED</span>
                  </div>
                }
              </div>
            </div>
          </div>
        } @else if (simService.selectedObject()?.type === 'GROUND_STATION') {
          <!-- GROUND STATION INSPECTION PANEL -->
          @let gs = getAsGroundStation(simService.selectedObject()!.data);
          <div class="space-y-3">
            <div class="flex items-start justify-between">
              <div>
                <div class="text-sm font-display font-bold text-slate-100">{{ gs.name }}</div>
                <div class="text-[10px] font-mono text-emerald-400">{{ gs.id }} • {{ gs.city }}, {{ gs.country }}</div>
              </div>
              <span
                class="px-2 py-0.5 rounded text-[10px] font-mono font-bold"
                [class.bg-emerald-950]="gs.availability === 'ONLINE'"
                [class.text-emerald-400]="gs.availability === 'ONLINE'"
                [class.bg-rose-950]="gs.availability === 'OFFLINE'"
                [class.text-rose-400]="gs.availability === 'OFFLINE'"
              >
                {{ gs.availability }}
              </span>
            </div>

            <button
              (click)="simService.triggerFailure(gs.id)"
              class="w-full py-1 px-2 rounded text-xs font-mono font-bold text-white bg-rose-900 hover:bg-rose-800 transition-colors flex items-center justify-center gap-1 shadow"
            >
              <mat-icon class="text-xs scale-75">cloud_off</mat-icon>
              {{ gs.availability === 'ONLINE' ? 'INJECT BACKHAUL FIBER CUT' : 'RESTORE GATEWAY' }}
            </button>

            <div class="bg-[#0b121f] border border-slate-800 rounded-lg p-2.5 space-y-1.5 text-xs font-mono">
              <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800 pb-1">
                GATEWAY TELEPORT SPECS
              </div>
              <div class="space-y-1 text-[11px]">
                <div class="flex justify-between">
                  <span class="text-slate-500">Geographic Region:</span>
                  <span class="text-slate-200">{{ gs.region }}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-500">Antenna Dishes:</span>
                  <span class="text-emerald-400 tabular-nums font-bold">{{ gs.activeAntennas }} tracking / {{ gs.antennaCount }} total</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-500">Backhaul Capacity:</span>
                  <span class="text-slate-200 tabular-nums">{{ gs.backhaulCapacityGbps }} Gbps Optical</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-500">Current Feeder Load:</span>
                  <span class="text-amber-400 tabular-nums font-bold">{{ gs.currentThroughputGbps }} Gbps ({{ gs.backhaulUtilizationPct }}%)</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-500">POP Latency:</span>
                  <span class="text-cyan-400 tabular-nums">{{ gs.latencyToCoreMs }} ms to Core</span>
                </div>
              </div>
            </div>

            <!-- Connected Visible Satellites -->
            <div class="bg-[#0b121f] border border-slate-800 rounded-lg p-2.5 space-y-1.5 text-xs font-mono">
              <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800 pb-1">
                VISIBLE FEEDER SATELLITES ({{ gs.connectedSats.length }})
              </div>
              <div class="flex flex-wrap gap-1">
                @for (satId of gs.connectedSats; track satId) {
                  <button
                    (click)="simService.selectSatellite(satId)"
                    class="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px] text-cyan-300 hover:border-cyan-500"
                  >
                    {{ satId }}
                  </button>
                }
              </div>
            </div>
          </div>
        } @else if (simService.selectedObject()?.type === 'TERMINAL') {
          <!-- USER TERMINAL INSPECTION PANEL -->
          @let term = getAsTerminal(simService.selectedObject()!.data);
          <div class="space-y-3">
            <div class="flex items-start justify-between">
              <div>
                <div class="text-sm font-display font-bold text-slate-100">{{ term.name }}</div>
                <div class="text-[10px] font-mono text-cyan-400">{{ term.id }} • {{ term.type }}</div>
              </div>
              <span
                class="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase"
                [class.bg-emerald-950]="term.sessionState === 'CONNECTED'"
                [class.text-emerald-400]="term.sessionState === 'CONNECTED'"
                [class.bg-amber-950]="term.sessionState === 'HANDOVER' || term.sessionState === 'SEARCHING'"
                [class.text-amber-400]="term.sessionState === 'HANDOVER' || term.sessionState === 'SEARCHING'"
              >
                {{ term.sessionState }}
              </span>
            </div>

            <!-- RF Link Telemetry -->
            <div class="bg-[#0b121f] border border-slate-800 rounded-lg p-2.5 space-y-1.5 text-xs font-mono">
              <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800 pb-1 flex justify-between">
                <span>PHASED-ARRAY RF LINK</span>
                <span class="text-cyan-400">Ku/Ka-BAND</span>
              </div>
              <div class="space-y-1 text-[11px]">
                <div class="flex justify-between">
                  <span class="text-slate-500">Connected Satellite:</span>
                  <button
                    (click)="term.connectedSatId ? simService.selectSatellite(term.connectedSatId) : null"
                    class="text-cyan-300 font-bold hover:underline"
                  >
                    {{ term.connectedSatId || 'NONE (SEARCHING)' }}
                  </button>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-500">Elevation Angle:</span>
                  <span class="text-emerald-400 tabular-nums font-bold">{{ term.elevationDeg }}° (Min 25°)</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-500">Azimuth Angle:</span>
                  <span class="text-slate-200 tabular-nums">{{ term.azimuthDeg }}°</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-500">Slant Range:</span>
                  <span class="text-slate-200 tabular-nums">{{ term.rangeKm }} km</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-500">SNR:</span>
                  <span class="text-cyan-400 tabular-nums font-bold">{{ term.snrDb }} dB</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-500">Time to LOS (Handover):</span>
                  <span class="text-amber-400 tabular-nums font-bold">{{ term.handoverEtaSec }}s ETA</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-500">Demand / Allocated:</span>
                  <span class="text-slate-200 tabular-nums">{{ term.allocatedThroughputMbps }} / {{ term.demandMbps }} Mbps</span>
                </div>
              </div>
            </div>

            <!-- Mathematical Latency Provenance Breakdown -->
            @if (term.route) {
              <div class="bg-[#0b121f] border border-cyan-900/60 rounded-lg p-2.5 space-y-1.5 text-xs font-mono shadow-md">
                <div class="text-[10px] font-bold text-cyan-300 uppercase tracking-wider border-b border-slate-800 pb-1 flex justify-between">
                  <span>LATENCY PROVENANCE CHAIN</span>
                  <span class="text-amber-400 font-bold">{{ term.route.latencyBreakdown.totalMs }} ms</span>
                </div>
                <div class="space-y-1 text-[10px]">
                  <div class="flex justify-between">
                    <span class="text-slate-400">1. Vacuum Speed of Light (c):</span>
                    <span class="text-slate-200 tabular-nums">299,792 km/s</span>
                  </div>
                  <div class="flex justify-between">
                    <span class="text-slate-400">2. RF/Optical Propagation:</span>
                    <span class="text-cyan-300 tabular-nums font-semibold">{{ term.route.latencyBreakdown.propagationMs }} ms</span>
                  </div>
                  <div class="flex justify-between">
                    <span class="text-slate-400">3. Switch Fabric Routing:</span>
                    <span class="text-slate-200 tabular-nums">{{ term.route.latencyBreakdown.routingMs }} ms ({{ term.route.latencyBreakdown.provenance.hopCount }} hops)</span>
                  </div>
                  <div class="flex justify-between">
                    <span class="text-slate-400">4. Queueing / Buffer Delay:</span>
                    <span class="text-amber-300 tabular-nums">{{ term.route.latencyBreakdown.queueingMs }} ms</span>
                  </div>
                  <div class="flex justify-between">
                    <span class="text-slate-400">5. RF Modem FEC Processing:</span>
                    <span class="text-slate-200 tabular-nums">{{ term.route.latencyBreakdown.processingMs }} ms</span>
                  </div>
                </div>
              </div>
            }

            <!-- Candidate Satellites Scoring -->
            <div class="bg-[#0b121f] border border-slate-800 rounded-lg p-2.5 space-y-1.5 text-xs font-mono">
              <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800 pb-1">
                TOP VISIBLE SATELLITE CANDIDATES
              </div>
              <div class="space-y-1">
                @for (cand of term.candidateSats; track cand.satId) {
                  <div class="p-1.5 rounded bg-slate-900/60 border border-slate-800 text-[10px] flex items-center justify-between">
                    <div>
                      <span class="font-bold text-slate-200">{{ cand.satId }}</span>
                      <span class="text-slate-400 ml-1.5">{{ cand.elevationDeg }}° Elev</span>
                    </div>
                    <div class="text-right">
                      <span class="text-cyan-400 font-bold">Score {{ cand.score }}</span>
                    </div>
                  </div>
                }
              </div>
            </div>

            <!-- Handover History Logs -->
            <div class="bg-[#0b121f] border border-slate-800 rounded-lg p-2.5 space-y-1.5 text-xs font-mono">
              <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800 pb-1">
                HANDOVER EVENT HISTORY
              </div>
              @if (!term.handoverHistory.length) {
                <div class="text-[11px] text-slate-500 py-1">No prior handovers recorded on session.</div>
              } @else {
                <div class="space-y-1 max-h-32 overflow-y-auto custom-scrollbar">
                  @for (ho of term.handoverHistory; track ho.id) {
                    <div class="p-1 rounded bg-slate-900/70 border border-slate-800 text-[9px] space-y-0.5">
                      <div class="text-slate-300 font-semibold flex justify-between">
                        <span>{{ ho.simTimeFormatted }}</span>
                        <span class="text-emerald-400">{{ ho.durationMs }}ms switch</span>
                      </div>
                      <div class="text-slate-400">{{ ho.fromSatId }} → {{ ho.toSatId }}</div>
                      <div class="text-slate-500 truncate">{{ ho.triggerReason }}</div>
                    </div>
                  }
                </div>
              }
            </div>
          </div>
        }
      </div>
    </aside>
  `
})
export class NodeInspector {
  public simService = inject(SimulationService);

  public getAsSatellite(data: unknown): Satellite {
    return data as Satellite;
  }

  public getAsGroundStation(data: unknown): GroundStation {
    return data as GroundStation;
  }

  public getAsTerminal(data: unknown): UserTerminal {
    return data as UserTerminal;
  }
}
