// STARLINK.NET.OS — Operations Control Telemetry Ribbon & Playback Bar
// Mission time, simulation clock control, constellation presets, and top-level network health

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-telemetry-ribbon',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <header class="w-full bg-[#080d16] border-b border-slate-800/90 px-4 py-2 flex items-center justify-between z-30 select-none">
      <!-- Left: Constellation Brand & Operational Mode -->
      <div class="flex items-center gap-4">
        <div class="flex items-center gap-2">
          <div class="w-6 h-6 rounded bg-gradient-to-br from-cyan-500 to-blue-700 flex items-center justify-center font-mono font-black text-white text-xs shadow-[0_0_12px_rgba(6,182,212,0.4)]">
            OS
          </div>
          <div>
            <div class="flex items-center gap-2">
              <span class="font-display font-black text-sm tracking-wider text-slate-100">STARLINK.NET.OS</span>
              <span class="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-800/60 uppercase">
                DIGITAL TWIN v4.2
              </span>
            </div>
            <div class="text-[10px] font-mono text-slate-400">
              PHYSICS RUNTIME • ORBITAL GRAPH PROPAGATOR
            </div>
          </div>
        </div>

        <div class="h-6 w-px bg-slate-800 hidden md:block"></div>

        <!-- Constellation Presets -->
        <div class="hidden lg:flex items-center gap-1 bg-[#0b121f] border border-slate-800/80 rounded-lg p-0.5 text-xs">
          <button
            (click)="simService.resetSimulation('small_demo')"
            [class.bg-slate-800]="simService.config().name.includes('Small')"
            [class.text-cyan-400]="simService.config().name.includes('Small')"
            [class.text-slate-400]="!simService.config().name.includes('Small')"
            class="px-2 py-1 rounded text-[11px] font-mono transition-colors hover:text-white"
          >
            120 Sats
          </button>
          <button
            (click)="simService.resetSimulation('regional')"
            [class.bg-slate-800]="simService.config().name.includes('Regional')"
            [class.text-cyan-400]="simService.config().name.includes('Regional')"
            [class.text-slate-400]="!simService.config().name.includes('Regional')"
            class="px-2 py-1 rounded text-[11px] font-mono transition-colors hover:text-white"
          >
            300 Sats
          </button>
          <button
            (click)="simService.resetSimulation('global')"
            [class.bg-slate-800]="simService.config().name.includes('Global')"
            [class.text-cyan-400]="simService.config().name.includes('Global')"
            [class.text-slate-400]="!simService.config().name.includes('Global')"
            class="px-2 py-1 rounded text-[11px] font-mono transition-colors hover:text-white"
          >
            500 Sats (Baseline)
          </button>
          <button
            (click)="simService.resetSimulation('large_constellation')"
            [class.bg-slate-800]="simService.config().name.includes('Large')"
            [class.text-cyan-400]="simService.config().name.includes('Large')"
            [class.text-slate-400]="!simService.config().name.includes('Large')"
            class="px-2 py-1 rounded text-[11px] font-mono transition-colors hover:text-white"
          >
            1200 Sats (Mega)
          </button>
        </div>
      </div>

      <!-- Center: Mission Time Clock & Simulation Controls -->
      <div class="flex items-center gap-3">
        <!-- Play / Pause / Step Controls -->
        <div class="flex items-center gap-1 bg-[#0b121f] border border-slate-800/80 rounded-lg p-1">
          <button
            (click)="simService.togglePlay()"
            [class.text-emerald-400]="simService.isPlaying()"
            [class.text-amber-400]="!simService.isPlaying()"
            class="p-1.5 rounded hover:bg-slate-800 transition-colors"
            [title]="simService.isPlaying() ? 'Pause Simulation' : 'Resume Simulation'"
          >
            <mat-icon class="text-base scale-90">{{ simService.isPlaying() ? 'pause' : 'play_arrow' }}</mat-icon>
          </button>
          <button
            (click)="simService.stepForward()"
            class="p-1.5 rounded text-slate-300 hover:bg-slate-800 hover:text-white transition-colors"
            title="Step Forward (+Δt)"
          >
            <mat-icon class="text-base scale-90">skip_next</mat-icon>
          </button>

          <div class="h-4 w-px bg-slate-800 mx-1"></div>

          <!-- Speed Multipliers -->
          <button
            (click)="simService.setSpeed(1)"
            [class.bg-cyan-500/20]="simService.playbackSpeed() === 1"
            [class.text-cyan-400]="simService.playbackSpeed() === 1"
            [class.text-slate-400]="simService.playbackSpeed() !== 1"
            class="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold"
          >
            1x
          </button>
          <button
            (click)="simService.setSpeed(5)"
            [class.bg-cyan-500/20]="simService.playbackSpeed() === 5"
            [class.text-cyan-400]="simService.playbackSpeed() === 5"
            [class.text-slate-400]="simService.playbackSpeed() !== 5"
            class="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold"
          >
            5x
          </button>
          <button
            (click)="simService.setSpeed(20)"
            [class.bg-cyan-500/20]="simService.playbackSpeed() === 20"
            [class.text-cyan-400]="simService.playbackSpeed() === 20"
            [class.text-slate-400]="simService.playbackSpeed() !== 20"
            class="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold"
          >
            20x
          </button>
          <button
            (click)="simService.setSpeed(60)"
            [class.bg-cyan-500/20]="simService.playbackSpeed() === 60"
            [class.text-cyan-400]="simService.playbackSpeed() === 60"
            [class.text-slate-400]="simService.playbackSpeed() !== 60"
            class="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold"
          >
            60x
          </button>
        </div>

        <!-- Simulation Clock Display -->
        <div class="bg-[#04070d] border border-cyan-900/50 rounded-lg px-3 py-1 flex items-center gap-2 shadow-inner">
          <mat-icon class="text-xs text-cyan-400">schedule</mat-icon>
          <span class="font-mono text-xs font-bold text-cyan-300 tracking-wider tabular-nums">
            {{ simService.simTimeFormatted() }}
          </span>
          <span class="text-[10px] font-mono text-slate-500">
            (Δt={{ simService.timeStepSec() }}s)
          </span>
        </div>

        <!-- Time Step Selector -->
        <div class="hidden sm:flex items-center gap-1 bg-[#0b121f] border border-slate-800/80 rounded-lg p-0.5 text-xs">
          <button
            (click)="simService.setTimeStep(1)"
            [class.text-cyan-400]="simService.timeStepSec() === 1"
            [class.text-slate-500]="simService.timeStepSec() !== 1"
            class="px-1.5 py-0.5 text-[10px] font-mono"
          >
            1s
          </button>
          <button
            (click)="simService.setTimeStep(5)"
            [class.text-cyan-400]="simService.timeStepSec() === 5"
            [class.text-slate-500]="simService.timeStepSec() !== 5"
            class="px-1.5 py-0.5 text-[10px] font-mono"
          >
            5s
          </button>
          <button
            (click)="simService.setTimeStep(30)"
            [class.text-cyan-400]="simService.timeStepSec() === 30"
            [class.text-slate-500]="simService.timeStepSec() !== 30"
            class="px-1.5 py-0.5 text-[10px] font-mono"
          >
            30s
          </button>
          <button
            (click)="simService.setTimeStep(60)"
            [class.text-cyan-400]="simService.timeStepSec() === 60"
            [class.text-slate-500]="simService.timeStepSec() !== 60"
            class="px-1.5 py-0.5 text-[10px] font-mono"
          >
            1m
          </button>
        </div>
      </div>

      <!-- Right: View Modes Navigation & Data Export -->
      <div class="flex items-center gap-2">
        <div class="flex items-center bg-[#0b121f] border border-slate-800/80 rounded-lg p-0.5">
          <button
            (click)="simService.viewMode.set('MAP')"
            [class.bg-cyan-500/20]="simService.viewMode() === 'MAP'"
            [class.text-cyan-300]="simService.viewMode() === 'MAP'"
            [class.text-slate-400]="simService.viewMode() !== 'MAP'"
            class="px-2.5 py-1 rounded text-xs font-mono font-medium flex items-center gap-1 transition-colors"
          >
            <mat-icon class="text-xs scale-75">public</mat-icon>
            MAP
          </button>
          <button
            (click)="simService.viewMode.set('LAB')"
            [class.bg-cyan-500/20]="simService.viewMode() === 'LAB'"
            [class.text-cyan-300]="simService.viewMode() === 'LAB'"
            [class.text-slate-400]="simService.viewMode() !== 'LAB'"
            class="px-2.5 py-1 rounded text-xs font-mono font-medium flex items-center gap-1 transition-colors"
          >
            <mat-icon class="text-xs scale-75">alt_route</mat-icon>
            ROUTING LAB
          </button>
          <button
            (click)="simService.viewMode.set('CAPACITY')"
            [class.bg-cyan-500/20]="simService.viewMode() === 'CAPACITY'"
            [class.text-cyan-300]="simService.viewMode() === 'CAPACITY'"
            [class.text-slate-400]="simService.viewMode() !== 'CAPACITY'"
            class="px-2.5 py-1 rounded text-xs font-mono font-medium flex items-center gap-1 transition-colors"
          >
            <mat-icon class="text-xs scale-75">query_stats</mat-icon>
            CAPACITY
          </button>
          <button
            (click)="simService.viewMode.set('ANALYTICS')"
            [class.bg-cyan-500/20]="simService.viewMode() === 'ANALYTICS'"
            [class.text-cyan-300]="simService.viewMode() === 'ANALYTICS'"
            [class.text-slate-400]="simService.viewMode() !== 'ANALYTICS'"
            class="px-2.5 py-1 rounded text-xs font-mono font-medium flex items-center gap-1 transition-colors"
          >
            <mat-icon class="text-xs scale-75">insights</mat-icon>
            ANALYTICS
          </button>
          <button
            (click)="simService.viewMode.set('CLI')"
            [class.bg-cyan-500/20]="simService.viewMode() === 'CLI'"
            [class.text-cyan-300]="simService.viewMode() === 'CLI'"
            [class.text-slate-400]="simService.viewMode() !== 'CLI'"
            class="px-2.5 py-1 rounded text-xs font-mono font-medium flex items-center gap-1 transition-colors"
          >
            <mat-icon class="text-xs scale-75">terminal</mat-icon>
            CLI
          </button>
        </div>

        <!-- Export Data Dropdown -->
        <button
          (click)="simService.exportData('JSON')"
          class="px-2.5 py-1 bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-mono flex items-center gap-1 transition-colors"
          title="Export Parquet/JSON Telemetry"
        >
          <mat-icon class="text-xs scale-75">download</mat-icon>
          EXPORT
        </button>
      </div>
    </header>
  `
})
export class TelemetryRibbon {
  public simService = inject(SimulationService);
}
