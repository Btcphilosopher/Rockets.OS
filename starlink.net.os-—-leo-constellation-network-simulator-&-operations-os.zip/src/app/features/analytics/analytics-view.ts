// STARLINK.NET.OS — Constellation Analytics & Network Telemetry Dashboard
// Displays latency distribution histograms, throughput time-series, and live mission event log

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-analytics-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="w-full h-full bg-[#06090e] p-4 flex flex-col gap-4 overflow-y-auto custom-scrollbar select-none">
      <!-- Analytics Header -->
      <div class="bg-[#0b121f] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4 shadow-lg">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400">insights</mat-icon>
            <h1 class="text-base font-display font-black tracking-wider text-slate-100">
              NETWORK TELEMETRY & STATISTICAL ANALYTICS
            </h1>
            <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-800">
              HIGH DENSITY REAL-TIME
            </span>
          </div>
          <p class="text-xs font-mono text-slate-400 mt-1">
            Global percentile latency distributions, switch utilization sparklines, and mission event logs.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button
            (click)="simService.exportData('CSV')"
            class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-xs font-mono text-slate-200 flex items-center gap-1 transition-colors"
          >
            <mat-icon class="text-xs scale-75">table_chart</mat-icon>
            EXPORT CSV TIMESERIES
          </button>
        </div>
      </div>

      <!-- Top Statistical KPI Cards -->
      @let m = simService.currentMetrics();
      @if (m) {
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div class="bg-[#0b121f] border border-slate-800 rounded-xl p-3">
            <div class="text-[10px] font-mono text-slate-500 uppercase">GLOBAL THROUGHPUT</div>
            <div class="text-lg font-mono font-bold text-cyan-400 mt-1 tabular-nums">
              {{ m.globalThroughputGbps }} Gbps
            </div>
            <div class="text-[10px] font-mono text-slate-400 mt-0.5">
              {{ simService.terminals().length }} active terminal links
            </div>
          </div>

          <div class="bg-[#0b121f] border border-slate-800 rounded-xl p-3">
            <div class="text-[10px] font-mono text-slate-500 uppercase">MEAN UTILIZATION</div>
            <div class="text-lg font-mono font-bold text-slate-200 mt-1 tabular-nums">
              {{ m.meanUtilizationPct }}%
            </div>
            <div class="text-[10px] font-mono text-amber-400 mt-0.5">
              Peak: {{ m.peakUtilizationPct }}%
            </div>
          </div>

          <div class="bg-[#0b121f] border border-slate-800 rounded-xl p-3">
            <div class="text-[10px] font-mono text-slate-500 uppercase">LATENCY (P50)</div>
            <div class="text-lg font-mono font-bold text-emerald-400 mt-1 tabular-nums">
              {{ m.p50LatencyMs }} ms
            </div>
            <div class="text-[10px] font-mono text-slate-400 mt-0.5">
              Avg: {{ m.avgLatencyMs }} ms
            </div>
          </div>

          <div class="bg-[#0b121f] border border-slate-800 rounded-xl p-3">
            <div class="text-[10px] font-mono text-slate-500 uppercase">LATENCY (P95)</div>
            <div class="text-lg font-mono font-bold text-amber-400 mt-1 tabular-nums">
              {{ m.p95LatencyMs }} ms
            </div>
            <div class="text-[10px] font-mono text-slate-400 mt-0.5">
              P99: {{ m.p99LatencyMs }} ms
            </div>
          </div>

          <div class="bg-[#0b121f] border border-slate-800 rounded-xl p-3">
            <div class="text-[10px] font-mono text-slate-500 uppercase">GEODETIC COVERAGE</div>
            <div class="text-lg font-mono font-bold text-cyan-300 mt-1 tabular-nums">
              {{ m.globalCoveragePct }}%
            </div>
            <div class="text-[10px] font-mono text-slate-400 mt-0.5">
              Threshold: {{ simService.config().minElevationDeg }}° elev
            </div>
          </div>

          <div class="bg-[#0b121f] border border-slate-800 rounded-xl p-3">
            <div class="text-[10px] font-mono text-slate-500 uppercase">TOTAL HANDOVERS</div>
            <div class="text-lg font-mono font-bold text-slate-100 mt-1 tabular-nums">
              {{ m.totalHandoversCompleted }}
            </div>
            <div class="text-[10px] font-mono text-emerald-400 mt-0.5">
              Active: {{ m.activeHandoversCount }}
            </div>
          </div>
        </div>
      }

      <!-- Grid 2: Left = Latency Histogram & Throughput History, Right = Live Event Bus Feed -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
        <!-- Left 7 Cols: Distribution Histograms -->
        <div class="lg:col-span-7 flex flex-col gap-4">
          <!-- Latency Distribution Bars -->
          <div class="bg-[#0b121f] border border-slate-800 rounded-xl p-4 space-y-3 shadow">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="font-mono text-xs font-bold text-slate-200 uppercase">
                LATENCY PERCENTILE DISTRIBUTION
              </span>
              <span class="text-[10px] font-mono text-cyan-400">ONE-WAY RTT</span>
            </div>

            @if (m) {
              <div class="space-y-2 text-xs font-mono">
                <div>
                  <div class="flex justify-between text-[11px] mb-1">
                    <span class="text-slate-400">p50 Median Latency:</span>
                    <span class="text-emerald-400 font-bold tabular-nums">{{ m.p50LatencyMs }} ms</span>
                  </div>
                  <div class="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div class="h-full bg-emerald-500 rounded-full" [style.width.%]="(m.p50LatencyMs / 80) * 100"></div>
                  </div>
                </div>

                <div>
                  <div class="flex justify-between text-[11px] mb-1">
                    <span class="text-slate-400">p95 95th Percentile:</span>
                    <span class="text-amber-400 font-bold tabular-nums">{{ m.p95LatencyMs }} ms</span>
                  </div>
                  <div class="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div class="h-full bg-amber-500 rounded-full" [style.width.%]="(m.p95LatencyMs / 80) * 100"></div>
                  </div>
                </div>

                <div>
                  <div class="flex justify-between text-[11px] mb-1">
                    <span class="text-slate-400">p99 99th Percentile (Tail):</span>
                    <span class="text-rose-400 font-bold tabular-nums">{{ m.p99LatencyMs }} ms</span>
                  </div>
                  <div class="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div class="h-full bg-rose-500 rounded-full" [style.width.%]="(m.p99LatencyMs / 80) * 100"></div>
                  </div>
                </div>
              </div>
            }
          </div>

          <!-- Throughput Timeseries History Sparklines -->
          <div class="bg-[#0b121f] border border-slate-800 rounded-xl p-4 space-y-3 shadow">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="font-mono text-xs font-bold text-slate-200 uppercase">
                THROUGHPUT & CONGESTION TIMESERIES (LAST 30 STEPS)
              </span>
              <span class="text-[10px] font-mono text-slate-400">SAMPLES: {{ simService.metricsHistory().length }}</span>
            </div>

            <!-- Mini Sparkline Bars -->
            <div class="h-28 flex items-end gap-1 pt-2">
              @for (hist of simService.metricsHistory(); track hist.timestamp) {
                <div
                  class="flex-1 bg-cyan-500/80 hover:bg-cyan-400 rounded-t transition-all"
                  [style.height.%]="Math.max(10, Math.min(100, (hist.globalThroughputGbps / 4000) * 100))"
                  [title]="hist.simTimeFormatted + ': ' + hist.globalThroughputGbps + ' Gbps'"
                ></div>
              }
            </div>
          </div>
        </div>

        <!-- Right 5 Cols: Live Event Bus Stream -->
        <div class="lg:col-span-5 bg-[#0b121f] border border-slate-800 rounded-xl p-4 flex flex-col gap-3 shadow">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <div class="flex items-center gap-2">
              <mat-icon class="text-xs text-cyan-400">history</mat-icon>
              <span class="font-mono text-xs font-bold text-slate-200 uppercase">
                MISSION EVENT BUS STREAM
              </span>
            </div>
            <span class="text-[10px] font-mono text-slate-500">LIVE FEED</span>
          </div>

          <div class="space-y-1.5 flex-1 overflow-y-auto custom-scrollbar max-h-[480px]">
            @for (evt of simService.events(); track evt.id) {
              <div class="p-2 rounded bg-slate-900/60 border border-slate-800/80 text-xs font-mono space-y-1">
                <div class="flex items-center justify-between">
                  <span
                    class="px-1.5 py-0.2 rounded text-[9px] font-bold"
                    [class.bg-emerald-950]="evt.severity === 'SUCCESS' || evt.severity === 'INFO'"
                    [class.text-emerald-400]="evt.severity === 'SUCCESS' || evt.severity === 'INFO'"
                    [class.bg-amber-950]="evt.severity === 'WARNING'"
                    [class.text-amber-400]="evt.severity === 'WARNING'"
                    [class.bg-rose-950]="evt.severity === 'CRITICAL'"
                    [class.text-rose-400]="evt.severity === 'CRITICAL'"
                  >
                    {{ evt.type }}
                  </span>
                  <span class="text-[10px] text-slate-500 tabular-nums">{{ evt.simTimeFormatted }}</span>
                </div>
                <div class="text-[11px] text-slate-300 leading-snug">{{ evt.message }}</div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class AnalyticsView {
  public simService = inject(SimulationService);
  public Math = Math;
}
