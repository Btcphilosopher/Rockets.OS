// STARLINK.NET.OS — Operational Scenarios & Failure Injection Control
// Manages real-time fault orchestration, ground station cuts, and traffic surge stress testing

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-scenario-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="bg-[#080d16] border-t border-slate-800/90 px-4 py-2 flex items-center justify-between text-xs font-mono select-none z-20">
      <!-- Left: Active Scenario Indicator -->
      <div class="flex items-center gap-3">
        <span class="text-slate-500 font-bold uppercase text-[10px]">FAILURE & OPERATIONS SCENARIOS:</span>
        @if (simService.activeScenario()) {
          @let scen = simService.activeScenario()!;
          <div class="flex items-center gap-2 bg-amber-950/80 border border-amber-800/80 px-2.5 py-1 rounded-lg">
            <span class="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
            <span class="text-amber-300 font-bold">ACTIVE: {{ scen.name }}</span>
            <span class="text-slate-400">({{ scen.category }})</span>
            <button
              (click)="simService.clearScenario()"
              class="ml-2 text-slate-400 hover:text-white underline text-[10px]"
            >
              TERMINATE
            </button>
          </div>
        } @else {
          <span class="text-emerald-400 text-[11px] flex items-center gap-1">
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            CONSTELLATION NOMINAL (NO ACTIVE INJECTIONS)
          </span>
        }
      </div>

      <!-- Right: Scenario Trigger Chips -->
      <div class="flex items-center gap-1.5 overflow-x-auto">
        @for (scen of simService.scenarios(); track scen.code) {
          <button
            (click)="simService.activateScenario(scen.code)"
            [class.bg-amber-900/40]="simService.activeScenario()?.code === scen.code"
            [class.text-amber-300]="simService.activeScenario()?.code === scen.code"
            [class.border-amber-700]="simService.activeScenario()?.code === scen.code"
            [class.border-slate-800]="simService.activeScenario()?.code !== scen.code"
            class="px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 border text-[10px] text-slate-300 transition-colors whitespace-nowrap"
            [title]="scen.description"
          >
            {{ scen.name }}
          </button>
        }
      </div>
    </div>
  `
})
export class ScenarioPanel {
  public simService = inject(SimulationService);
}
