// STARLINK.NET.OS — Global Dynamic Network Canvas Engine
// Supports Equirectangular & Orthographic 3D Projections, ISL Laser Mesh, Spot-Beams, and Hit-Testing

import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  HostListener,
  OnDestroy,
  ViewChild,
  inject
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';
import { Satellite } from '../../core/models/types';

// Simplified high-precision vector world coastlines & landmasses
const WORLD_COASTLINES: [number, number][][] = [
  // North America
  [[-165, 65], [-140, 70], [-120, 75], [-90, 70], [-75, 60], [-60, 50], [-70, 42], [-80, 25], [-97, 26], [-105, 20], [-90, 15], [-80, 9], [-77, 8], [-85, 12], [-105, 20], [-117, 32], [-124, 48], [-135, 58], [-165, 65]],
  // South America
  [[-77, 8], [-60, 10], [-50, 0], [-35, -5], [-38, -15], [-42, -23], [-53, -34], [-65, -50], [-75, -55], [-73, -40], [-70, -20], [-80, -5], [-77, 8]],
  // Europe & Asia (Eurasia)
  [[-9, 36], [-9, 43], [0, 44], [-4, 48], [5, 54], [10, 58], [25, 71], [60, 70], [100, 76], [140, 72], [170, 65], [160, 52], [140, 48], [130, 35], [120, 30], [105, 20], [100, 5], [90, 22], [80, 10], [70, 22], [60, 25], [50, 28], [40, 30], [30, 32], [20, 38], [10, 38], [0, 38], [-9, 36]],
  // Africa
  [[-5, 36], [10, 37], [32, 31], [43, 12], [51, 11], [40, -5], [35, -25], [20, -35], [18, -34], [12, -15], [0, 5], [-17, 15], [-12, 28], [-5, 36]],
  // Australia
  [[114, -22], [125, -15], [136, -12], [142, -10], [153, -28], [150, -38], [138, -35], [115, -34], [113, -25], [114, -22]],
  // Great Britain & Ireland
  [[-5, 50], [1.5, 51], [0, 54], [-2, 58], [-5, 58], [-5, 55], [-3, 53], [-5, 50]],
  [[-10, 51.5], [-6, 52], [-6, 55], [-10, 54], [-10, 51.5]],
  // Japan
  [[130, 31], [132, 34], [140, 36], [141, 41], [145, 44], [140, 45], [138, 38], [130, 31]],
  // Greenland
  [[-50, 60], [-40, 65], [-20, 75], [-30, 83], [-55, 82], [-55, 70], [-50, 60]]
];

@Component({
  selector: 'app-network-map',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="relative w-full h-full bg-[#06090e] overflow-hidden select-none" #containerRef>
      <!-- Top HUD Telemetry Ribbon -->
      <div class="absolute top-3 left-4 z-20 flex items-center gap-3 bg-[#0c121e]/90 border border-slate-800/80 rounded-lg px-3 py-1.5 backdrop-blur-md shadow-lg">
        <div class="flex items-center gap-2">
          <span class="inline-block w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
          <span class="text-xs font-mono font-bold tracking-wider text-slate-200">GLOBAL TOPOLOGY CANVAS</span>
        </div>
        <span class="text-slate-600">|</span>
        <div class="text-[11px] font-mono text-slate-400">
          PROJECTION:
          <span class="text-cyan-400 font-semibold uppercase">{{ simService.mapProjection() }}</span>
        </div>
        <span class="text-slate-600">|</span>
        <div class="text-[11px] font-mono text-slate-400">
          SATS IN VIEW:
          <span class="text-emerald-400 font-semibold tabular-nums">{{ simService.onlineSatellitesCount() }}</span>
        </div>
        <span class="text-slate-600">|</span>
        <div class="text-[11px] font-mono text-slate-400">
          OPTICAL ISLs:
          <span class="text-cyan-400 font-semibold tabular-nums">{{ simService.activeIslCount() }}</span>
        </div>
      </div>

      <!-- Map Control Overlays & Projection Toggles -->
      <div class="absolute top-3 right-4 z-20 flex items-center gap-2">
        <!-- Layer Toggles -->
        <div class="flex items-center gap-1 bg-[#0c121e]/90 border border-slate-800 rounded-lg p-1 text-xs">
          <button
            (click)="simService.toggleLayer('islLinks')"
            [class.bg-cyan-500/20]="simService.layers().islLinks"
            [class.text-cyan-300]="simService.layers().islLinks"
            [class.text-slate-400]="!simService.layers().islLinks"
            class="px-2 py-1 rounded text-[11px] font-mono font-medium transition-colors hover:text-white"
            title="Toggle Laser ISL Crosslinks"
          >
            ISL
          </button>
          <button
            (click)="simService.toggleLayer('spotBeams')"
            [class.bg-cyan-500/20]="simService.layers().spotBeams"
            [class.text-cyan-300]="simService.layers().spotBeams"
            [class.text-slate-400]="!simService.layers().spotBeams"
            class="px-2 py-1 rounded text-[11px] font-mono font-medium transition-colors hover:text-white"
            title="Toggle Spot Beams"
          >
            BEAMS
          </button>
          <button
            (click)="simService.toggleLayer('groundTracks')"
            [class.bg-cyan-500/20]="simService.layers().groundTracks"
            [class.text-cyan-300]="simService.layers().groundTracks"
            [class.text-slate-400]="!simService.layers().groundTracks"
            class="px-2 py-1 rounded text-[11px] font-mono font-medium transition-colors hover:text-white"
            title="Toggle Orbital Ground Tracks"
          >
            TRACKS
          </button>
          <button
            (click)="simService.toggleLayer('dayNight')"
            [class.bg-cyan-500/20]="simService.layers().dayNight"
            [class.text-cyan-300]="simService.layers().dayNight"
            [class.text-slate-400]="!simService.layers().dayNight"
            class="px-2 py-1 rounded text-[11px] font-mono font-medium transition-colors hover:text-white"
            title="Toggle Solar Terminator"
          >
            DAY/NIGHT
          </button>
        </div>

        <!-- Projection Selector -->
        <div class="flex items-center bg-[#0c121e]/90 border border-slate-800 rounded-lg p-1 text-xs">
          <button
            (click)="simService.setProjection('EQUIRECTANGULAR')"
            [class.bg-slate-800]="simService.mapProjection() === 'EQUIRECTANGULAR'"
            [class.text-cyan-400]="simService.mapProjection() === 'EQUIRECTANGULAR'"
            [class.text-slate-400]="simService.mapProjection() !== 'EQUIRECTANGULAR'"
            class="px-2.5 py-1 rounded text-[11px] font-mono transition-colors"
          >
            2D FLAT
          </button>
          <button
            (click)="simService.setProjection('ORTHOGRAPHIC')"
            [class.bg-slate-800]="simService.mapProjection() === 'ORTHOGRAPHIC'"
            [class.text-cyan-400]="simService.mapProjection() === 'ORTHOGRAPHIC'"
            [class.text-slate-400]="simService.mapProjection() !== 'ORTHOGRAPHIC'"
            class="px-2.5 py-1 rounded text-[11px] font-mono transition-colors"
          >
            3D GLOBE
          </button>
        </div>

        <!-- Zoom Reset -->
        <button
          (click)="resetView()"
          class="p-1.5 bg-[#0c121e]/90 border border-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors"
          title="Reset Zoom & Pan"
        >
          <mat-icon class="text-sm scale-90">center_focus_strong</mat-icon>
        </button>
      </div>

      <!-- Primary HTML5 Canvas Renderer -->
      <canvas
        #canvasRef
        class="w-full h-full cursor-crosshair block"
        (mousedown)="onMouseDown($event)"
        (mousemove)="onMouseMove($event)"
        (mouseup)="onMouseUp()"
        (wheel)="onWheel($event)"
      ></canvas>

      <!-- Bottom Map Legend Bar -->
      <div class="absolute bottom-3 left-4 z-20 flex items-center gap-4 bg-[#0c121e]/90 border border-slate-800/80 rounded-lg px-3 py-1.5 text-[11px] font-mono backdrop-blur-md">
        <div class="flex items-center gap-1.5">
          <span class="inline-block w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.6)]"></span>
          <span class="text-slate-300">Satellite (Nominal)</span>
        </div>
        <div class="flex items-center gap-1.5">
          <span class="inline-block w-2.5 h-2.5 rounded-full bg-amber-400"></span>
          <span class="text-slate-300">Busy / Congested</span>
        </div>
        <div class="flex items-center gap-1.5">
          <span class="inline-block w-2.5 h-2.5 rounded-full bg-rose-500"></span>
          <span class="text-slate-300">Offline / Fault</span>
        </div>
        <div class="flex items-center gap-1.5">
          <span class="inline-block w-2.5 h-2.5 bg-emerald-400 rounded-sm"></span>
          <span class="text-slate-300">Ground Teleport</span>
        </div>
        <div class="flex items-center gap-1.5">
          <span class="inline-block w-3 h-0.5 bg-cyan-400"></span>
          <span class="text-slate-300">Optical ISL</span>
        </div>
        <div class="flex items-center gap-1.5">
          <span class="inline-block w-3 h-0.5 bg-amber-400"></span>
          <span class="text-slate-300">Active Packet Route</span>
        </div>
      </div>

      <!-- Hover / Probe Tooltip -->
      @if (hoveredObject) {
        <div
          class="absolute pointer-events-none z-30 bg-[#0b0f19]/95 border border-cyan-500/40 rounded-lg p-2.5 text-xs font-mono shadow-2xl backdrop-blur-md"
          [style.left.px]="hoverPos.x + 12"
          [style.top.px]="hoverPos.y + 12"
        >
          <div class="flex items-center gap-1.5 font-bold text-cyan-300 mb-1">
            <span class="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
            {{ hoveredObject.title }}
          </div>
          <div class="text-[11px] text-slate-400 space-y-0.5">
            @for (line of hoveredObject.details; track $index) {
              <div>{{ line }}</div>
            }
          </div>
        </div>
      }
    </div>
  `
})
export class NetworkMap implements AfterViewInit, OnDestroy {
  public simService = inject(SimulationService);

  @ViewChild('canvasRef') canvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('containerRef') containerRef!: ElementRef<HTMLDivElement>;

  private ctx: CanvasRenderingContext2D | null = null;
  private animId: number | null = null;
  private photonPhase = 0;

  // Viewport transforms
  private zoom = 1.0;
  private panX = 0;
  private panY = 0;
  private isDragging = false;
  private dragStartX = 0;
  private dragStartY = 0;

  // Globe 3D Rotation
  private globeRotationLon = 0;
  private globeRotationLat = 0;

  public hoveredObject: { title: string; details: string[] } | null = null;
  public hoverPos = { x: 0, y: 0 };

  ngAfterViewInit(): void {
    const canvas = this.canvasRef.nativeElement;
    this.ctx = canvas.getContext('2d', { alpha: false });
    this.resizeCanvas();
    this.startRenderLoop();
  }

  ngOnDestroy(): void {
    if (this.animId) cancelAnimationFrame(this.animId);
  }

  @HostListener('window:resize')
  onResize(): void {
    this.resizeCanvas();
  }

  private resizeCanvas(): void {
    if (!this.canvasRef || !this.containerRef) return;
    const canvas = this.canvasRef.nativeElement;
    const container = this.containerRef.nativeElement;
    const dpr = window.devicePixelRatio || 1;

    canvas.width = container.clientWidth * dpr;
    canvas.height = container.clientHeight * dpr;
    if (this.ctx) {
      this.ctx.scale(dpr, dpr);
    }
  }

  private startRenderLoop(): void {
    const render = () => {
      this.draw();
      this.photonPhase = (this.photonPhase + 0.04) % 1.0;
      this.animId = requestAnimationFrame(render);
    };
    this.animId = requestAnimationFrame(render);
  }

  public resetView(): void {
    this.zoom = 1.0;
    this.panX = 0;
    this.panY = 0;
    this.globeRotationLon = 0;
    this.globeRotationLat = 0;
  }

  // ==========================================
  // COORDINATE PROJECTIONS
  // ==========================================

  private project(latDeg: number, lonDeg: number, width: number, height: number): [number, number, boolean] {
    const isGlobe = this.simService.mapProjection() === 'ORTHOGRAPHIC';

    if (!isGlobe) {
      // 2D Equirectangular
      const x = ((lonDeg + 180) / 360) * width * this.zoom + this.panX + (width * (1 - this.zoom)) / 2;
      const y = ((90 - latDeg) / 180) * height * this.zoom + this.panY + (height * (1 - this.zoom)) / 2;
      return [x, y, true];
    } else {
      // 3D Orthographic Globe
      const radius = Math.min(width, height) * 0.42 * this.zoom;
      const cx = width / 2 + this.panX;
      const cy = height / 2 + this.panY;

      // Apply globe rotation
      const rotLon = ((lonDeg - this.globeRotationLon + 180) % 360) - 180;
      const rotLat = latDeg - this.globeRotationLat;

      const lambda = (rotLon * Math.PI) / 180;
      const phi = (rotLat * Math.PI) / 180;

      // Visible hemisphere check: cos(c) >= 0
      const cosC = Math.cos(phi) * Math.cos(lambda);
      const isVisible = cosC >= 0;

      const x = cx + radius * Math.cos(phi) * Math.sin(lambda);
      const y = cy - radius * Math.sin(phi);

      return [x, y, isVisible];
    }
  }

  // ==========================================
  // RENDERING PIPELINE
  // ==========================================

  private draw(): void {
    if (!this.ctx || !this.canvasRef) return;
    const w = this.containerRef.nativeElement.clientWidth;
    const h = this.containerRef.nativeElement.clientHeight;

    // Clear background
    this.ctx.fillStyle = '#06090e';
    this.ctx.fillRect(0, 0, w, h);

    const isGlobe = this.simService.mapProjection() === 'ORTHOGRAPHIC';

    if (isGlobe) {
      this.drawGlobeBasin(w, h);
    } else {
      this.drawGraticules2D(w, h);
    }

    if (this.simService.layers().dayNight) {
      this.drawSolarTerminator(w, h);
    }

    this.drawLandmasses(w, h);

    if (this.simService.layers().groundTracks) {
      this.drawGroundTracks(w, h);
    }

    if (this.simService.layers().spotBeams) {
      this.drawSpotBeams(w, h);
    }

    if (this.simService.layers().islLinks) {
      this.drawIslLinks(w, h);
    }

    if (this.simService.layers().groundStations) {
      this.drawGroundStations(w, h);
    }

    if (this.simService.layers().terminals) {
      this.drawTerminals(w, h);
    }

    this.drawSatellites(w, h);
    this.drawSelectedRoute(w, h);
  }

  private drawGlobeBasin(w: number, h: number): void {
    if (!this.ctx) return;
    const radius = Math.min(w, h) * 0.42 * this.zoom;
    const cx = w / 2 + this.panX;
    const cy = h / 2 + this.panY;

    // Space horizon gradient
    const grad = this.ctx.createRadialGradient(cx, cy, radius * 0.8, cx, cy, radius * 1.05);
    grad.addColorStop(0, '#0a1120');
    grad.addColorStop(0.9, '#070c17');
    grad.addColorStop(1, 'rgba(6, 9, 14, 0)');

    this.ctx.fillStyle = '#0a1120';
    this.ctx.beginPath();
    this.ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    this.ctx.fill();

    // Atmosphere rim
    this.ctx.strokeStyle = 'rgba(34, 211, 238, 0.25)';
    this.ctx.lineWidth = 1.5;
    this.ctx.stroke();

    // Latitude & Longitude rings on globe
    this.ctx.strokeStyle = 'rgba(30, 41, 59, 0.45)';
    this.ctx.lineWidth = 0.5;

    for (let lat = -60; lat <= 60; lat += 30) {
      this.ctx.beginPath();
      let first = true;
      for (let lon = -180; lon <= 180; lon += 5) {
        const [x, y, vis] = this.project(lat, lon, w, h);
        if (vis) {
          if (first) {
            this.ctx.moveTo(x, y);
            first = false;
          } else {
            this.ctx.lineTo(x, y);
          }
        } else {
          first = true;
        }
      }
      this.ctx.stroke();
    }
  }

  private drawGraticules2D(w: number, h: number): void {
    if (!this.ctx) return;
    this.ctx.strokeStyle = 'rgba(30, 41, 59, 0.35)';
    this.ctx.lineWidth = 0.75;

    // Longitude lines
    for (let lon = -180; lon <= 180; lon += 30) {
      const [x1, y1] = this.project(85, lon, w, h);
      const [x2, y2] = this.project(-85, lon, w, h);
      this.ctx.beginPath();
      this.ctx.moveTo(x1, y1);
      this.ctx.lineTo(x2, y2);
      this.ctx.stroke();
    }

    // Latitude lines
    for (let lat = -60; lat <= 60; lat += 30) {
      const [x1, y1] = this.project(lat, -180, w, h);
      const [x2, y2] = this.project(lat, 180, w, h);
      this.ctx.beginPath();
      this.ctx.moveTo(x1, y1);
      this.ctx.lineTo(x2, y2);
      this.ctx.stroke();
    }

    // Equator highlight
    this.ctx.strokeStyle = 'rgba(56, 189, 248, 0.2)';
    this.ctx.beginPath();
    const [eq1, eq2] = this.project(0, -180, w, h);
    const [eq3, eq4] = this.project(0, 180, w, h);
    this.ctx.moveTo(eq1, eq2);
    this.ctx.lineTo(eq3, eq4);
    this.ctx.stroke();
  }

  private drawSolarTerminator(w: number, h: number): void {
    if (!this.ctx) return;
    const simSec = this.simService.simTimeSec();
    // Subsolar point longitude based on UTC time (Earth rotates 360 deg in 24h)
    const sunLon = -(((simSec / 3600) % 24) / 24) * 360 + 180;
    const sunLat = 10 * Math.sin(((simSec / 86400) % 365) * 2 * Math.PI); // seasonal declination

    this.ctx.fillStyle = 'rgba(2, 6, 23, 0.35)';

    // Approximate shaded night area
    this.ctx.beginPath();
    for (let lat = -80; lat <= 80; lat += 4) {
      const cosVal = -Math.tan((lat * Math.PI) / 180) * Math.tan((sunLat * Math.PI) / 180);
      const termLon = Math.acos(Math.max(-1, Math.min(1, cosVal))) * (180 / Math.PI);
      const nightLon1 = sunLon + termLon;
      const [x, y] = this.project(lat, nightLon1, w, h);
      if (lat === -80) this.ctx.moveTo(x, y);
      else this.ctx.lineTo(x, y);
    }
    this.ctx.fill();
  }

  private drawLandmasses(w: number, h: number): void {
    if (!this.ctx) return;

    this.ctx.fillStyle = '#0e1626';
    this.ctx.strokeStyle = '#1e2d42';
    this.ctx.lineWidth = 1.0;

    for (const poly of WORLD_COASTLINES) {
      this.ctx.beginPath();
      let started = false;

      for (const [lon, lat] of poly) {
        const [x, y, vis] = this.project(lat, lon, w, h);
        if (vis) {
          if (!started) {
            this.ctx.moveTo(x, y);
            started = true;
          } else {
            this.ctx.lineTo(x, y);
          }
        } else {
          started = false;
        }
      }
      this.ctx.closePath();
      this.ctx.fill();
      this.ctx.stroke();
    }
  }

  private drawGroundTracks(w: number, h: number): void {
    if (!this.ctx) return;
    const sats = this.simService.satellites();
    if (!sats.length) return;

    this.ctx.strokeStyle = 'rgba(56, 189, 248, 0.08)';
    this.ctx.lineWidth = 0.8;

    // Draw sinusoidal ground track for representative orbital planes
    const samplePlanes = [0, 4, 8, 12, 16];
    for (const p of samplePlanes) {
      const planeSats = sats.filter(s => s.planeIndex === p);
      if (!planeSats.length) continue;

      this.ctx.beginPath();
      let first = true;
      for (let u = 0; u <= 360; u += 6) {
        const uRad = (u * Math.PI) / 180;
        const incRad = planeSats[0].inclinationRad;
        const raan = planeSats[0].raanRad;

        const latRad = Math.asin(Math.sin(incRad) * Math.sin(uRad));
        const lonRad = raan + Math.atan2(Math.cos(incRad) * Math.sin(uRad), Math.cos(uRad));

        const latDeg = (latRad * 180) / Math.PI;
        const lonDeg = (((lonRad * 180) / Math.PI + 180) % 360) - 180;

        const [x, y, vis] = this.project(latDeg, lonDeg, w, h);
        if (vis) {
          if (first) {
            this.ctx.moveTo(x, y);
            first = false;
          } else {
            this.ctx.lineTo(x, y);
          }
        } else {
          first = true;
        }
      }
      this.ctx.stroke();
    }
  }

  private drawSpotBeams(w: number, h: number): void {
    if (!this.ctx) return;
    const sats = this.simService.satellites();

    for (const sat of sats) {
      if (sat.health === 'OFFLINE' || !sat.activeBeams.length) continue;

      for (const beam of sat.activeBeams) {
        const [x, y, vis] = this.project(beam.centerLat, beam.centerLon, w, h);
        if (!vis) continue;

        const radiusPx = Math.max(8, 18 * this.zoom);

        this.ctx.fillStyle = beam.status === 'CONGESTED' ? 'rgba(239, 68, 68, 0.2)' : 'rgba(34, 211, 238, 0.12)';
        this.ctx.strokeStyle = beam.status === 'CONGESTED' ? 'rgba(239, 68, 68, 0.7)' : 'rgba(34, 211, 238, 0.45)';
        this.ctx.lineWidth = 1.0;

        this.ctx.beginPath();
        this.ctx.arc(x, y, radiusPx, 0, Math.PI * 2);
        this.ctx.fill();
        this.ctx.stroke();
      }
    }
  }

  private drawIslLinks(w: number, h: number): void {
    if (!this.ctx) return;
    const isls = this.simService.islLinks();
    const satMap = new Map<string, Satellite>();
    this.simService.satellites().forEach(s => satMap.set(s.id, s));

    for (const link of isls) {
      if (link.status === 'BROKEN') continue;

      const satA = satMap.get(link.sourceSatId);
      const satB = satMap.get(link.targetSatId);
      if (!satA || !satB) continue;

      const [x1, y1, vis1] = this.project(satA.lat, satA.lon, w, h);
      const [x2, y2, vis2] = this.project(satB.lat, satB.lon, w, h);

      if (!vis1 || !vis2) continue;

      // Handle 2D longitude wrapping across antimeridian
      if (Math.abs(x2 - x1) > w * 0.5 && this.simService.mapProjection() === 'EQUIRECTANGULAR') continue;

      if (link.status === 'POINTING_ERROR') {
        this.ctx.strokeStyle = 'rgba(239, 68, 68, 0.25)';
      } else if (link.utilizationPct > 80) {
        this.ctx.strokeStyle = 'rgba(245, 158, 11, 0.45)';
      } else {
        this.ctx.strokeStyle = link.linkType === 'INTRA_PLANE' ? 'rgba(34, 211, 238, 0.35)' : 'rgba(56, 189, 248, 0.25)';
      }

      this.ctx.lineWidth = 0.8;
      this.ctx.beginPath();
      this.ctx.moveTo(x1, y1);
      this.ctx.lineTo(x2, y2);
      this.ctx.stroke();

      // Pulsing laser data photon
      if (link.status === 'ACTIVE' && link.currentLoadGbps > 0) {
        const px = x1 + (x2 - x1) * this.photonPhase;
        const py = y1 + (y2 - y1) * this.photonPhase;
        this.ctx.fillStyle = '#38bdf8';
        this.ctx.beginPath();
        this.ctx.arc(px, py, 1.2, 0, Math.PI * 2);
        this.ctx.fill();
      }
    }
  }

  private drawGroundStations(w: number, h: number): void {
    if (!this.ctx) return;
    const gss = this.simService.groundStations();
    const sel = this.simService.selectedObject();

    for (const gs of gss) {
      const [x, y, vis] = this.project(gs.lat, gs.lon, w, h);
      if (!vis) continue;

      const isSelected = sel?.type === 'GROUND_STATION' && sel.data.id === gs.id;

      // Radar pulse ring
      if (gs.availability === 'ONLINE') {
        this.ctx.strokeStyle = isSelected ? 'rgba(52, 211, 153, 0.8)' : 'rgba(52, 211, 153, 0.3)';
        this.ctx.lineWidth = 1.0;
        this.ctx.beginPath();
        this.ctx.arc(x, y, 9, 0, Math.PI * 2);
        this.ctx.stroke();
      }

      // Station icon square
      this.ctx.fillStyle = gs.availability === 'ONLINE' ? '#10b981' : '#f43f5e';
      this.ctx.fillRect(x - 3.5, y - 3.5, 7, 7);

      // Station label
      this.ctx.fillStyle = isSelected ? '#34d399' : '#94a3b8';
      this.ctx.font = '9px IBM Plex Mono, monospace';
      this.ctx.fillText(gs.city, x + 8, y + 3);
    }
  }

  private drawTerminals(w: number, h: number): void {
    if (!this.ctx) return;
    const terms = this.simService.terminals();
    const sel = this.simService.selectedObject();

    for (const term of terms) {
      const [x, y, vis] = this.project(term.lat, term.lon, w, h);
      if (!vis) continue;

      const isSelected = sel?.type === 'TERMINAL' && sel.data.id === term.id;

      if (term.type === 'AIRCRAFT') {
        // Aircraft symbol with heading
        this.ctx.save();
        this.ctx.translate(x, y);
        if (term.headingDeg !== undefined) {
          this.ctx.rotate((term.headingDeg * Math.PI) / 180);
        }
        this.ctx.fillStyle = isSelected ? '#38bdf8' : '#e2e8f0';
        this.ctx.beginPath();
        this.ctx.moveTo(0, -6);
        this.ctx.lineTo(4, 4);
        this.ctx.lineTo(0, 2);
        this.ctx.lineTo(-4, 4);
        this.ctx.closePath();
        this.ctx.fill();
        this.ctx.restore();

        this.ctx.fillStyle = '#38bdf8';
        this.ctx.font = '9px IBM Plex Mono, monospace';
        this.ctx.fillText(term.name.split(' ')[1] || term.name, x + 8, y + 3);
      } else if (term.type === 'MARITIME') {
        // Ship symbol
        this.ctx.fillStyle = '#38bdf8';
        this.ctx.beginPath();
        this.ctx.arc(x, y, 3.5, 0, Math.PI * 2);
        this.ctx.fill();
        this.ctx.fillText(term.name.split(' ')[0], x + 7, y + 3);
      } else {
        // Fixed User Terminal
        this.ctx.fillStyle = term.sessionState === 'CONNECTED' ? '#38bdf8' : '#94a3b8';
        this.ctx.beginPath();
        this.ctx.arc(x, y, isSelected ? 4.5 : 2.5, 0, Math.PI * 2);
        this.ctx.fill();
      }
    }
  }

  private drawSatellites(w: number, h: number): void {
    if (!this.ctx) return;
    const sats = this.simService.satellites();
    const sel = this.simService.selectedObject();

    for (const sat of sats) {
      const [x, y, vis] = this.project(sat.lat, sat.lon, w, h);
      if (!vis) continue;

      const isSelected = sel?.type === 'SATELLITE' && sel.data.id === sat.id;

      let color = '#22d3ee'; // Nominal cyan
      if (sat.health === 'OFFLINE') color = '#f43f5e'; // Red
      else if (sat.congestionState === 'CONGESTED' || sat.congestionState === 'SATURATED') color = '#f59e0b'; // Amber

      if (isSelected) {
        this.ctx.strokeStyle = '#ffffff';
        this.ctx.lineWidth = 1.5;
        this.ctx.beginPath();
        this.ctx.arc(x, y, 7, 0, Math.PI * 2);
        this.ctx.stroke();
      }

      this.ctx.fillStyle = color;
      this.ctx.beginPath();
      this.ctx.arc(x, y, isSelected ? 3.5 : 2.0, 0, Math.PI * 2);
      this.ctx.fill();
    }
  }

  private drawSelectedRoute(w: number, h: number): void {
    if (!this.ctx) return;
    const route = this.simService.selectedRoute();
    if (!route || !route.hopCoords.length) return;

    this.ctx.strokeStyle = '#f59e0b'; // Telemetry amber active route
    this.ctx.lineWidth = 2.0;
    this.ctx.setLineDash([4, 3]);

    this.ctx.beginPath();
    let first = true;
    for (const coord of route.hopCoords) {
      const [x, y, vis] = this.project(coord.lat, coord.lon, w, h);
      if (vis) {
        if (first) {
          this.ctx.moveTo(x, y);
          first = false;
        } else {
          this.ctx.lineTo(x, y);
        }
      }
    }
    this.ctx.stroke();
    this.ctx.setLineDash([]); // Reset dash

    // Draw hop waypoint diamonds
    for (let i = 0; i < route.hopCoords.length; i++) {
      const coord = route.hopCoords[i];
      const type = route.hopTypes[i];
      const [x, y, vis] = this.project(coord.lat, coord.lon, w, h);
      if (!vis) continue;

      this.ctx.fillStyle = type === 'TERMINAL' ? '#38bdf8' : type === 'GROUND_STATION' ? '#10b981' : '#f59e0b';
      this.ctx.beginPath();
      this.ctx.arc(x, y, 4, 0, Math.PI * 2);
      this.ctx.fill();
    }
  }

  // ==========================================
  // MOUSE & INTERACTION HANDLERS
  // ==========================================

  onMouseDown(e: MouseEvent): void {
    this.isDragging = true;
    this.dragStartX = e.clientX;
    this.dragStartY = e.clientY;
  }

  onMouseMove(e: MouseEvent): void {
    const rect = this.canvasRef.nativeElement.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;

    if (this.isDragging) {
      const dx = e.clientX - this.dragStartX;
      const dy = e.clientY - this.dragStartY;
      this.dragStartX = e.clientX;
      this.dragStartY = e.clientY;

      if (this.simService.mapProjection() === 'ORTHOGRAPHIC') {
        // Rotate 3D Globe
        this.globeRotationLon = (this.globeRotationLon - dx * 0.4 + 360) % 360;
        this.globeRotationLat = Math.max(-80, Math.min(80, this.globeRotationLat + dy * 0.4));
      } else {
        // Pan 2D Map
        this.panX += dx;
        this.panY += dy;
      }
    } else {
      // Hit testing for hover probe tooltip
      this.probeObjectsAt(mx, my);
    }
  }

  onMouseUp(): void {
    this.isDragging = false;
  }

  onWheel(e: WheelEvent): void {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.15 : 0.88;
    this.zoom = Math.max(0.6, Math.min(4.5, this.zoom * zoomFactor));
  }

  private probeObjectsAt(mx: number, my: number): void {
    const w = this.containerRef.nativeElement.clientWidth;
    const h = this.containerRef.nativeElement.clientHeight;

    // 1. Check User Terminals
    for (const term of this.simService.terminals()) {
      const [x, y, vis] = this.project(term.lat, term.lon, w, h);
      if (vis && Math.hypot(mx - x, my - y) < 8) {
        this.hoveredObject = {
          title: `TERMINAL: ${term.name} (${term.id})`,
          details: [
            `Type: ${term.type} | Priority: ${term.priority}`,
            `Location: ${term.lat.toFixed(2)}°, ${term.lon.toFixed(2)}°`,
            `Connected Sat: ${term.connectedSatId || 'SEARCHING'}`,
            `Elevation: ${term.elevationDeg}° | SNR: ${term.snrDb} dB`,
            `Throughput: ${term.allocatedThroughputMbps}/${term.demandMbps} Mbps`,
            `Latency: ${term.latencyMs} ms`
          ]
        };
        this.hoverPos = { x: mx, y: my };
        return;
      }
    }

    // 2. Check Ground Stations
    for (const gs of this.simService.groundStations()) {
      const [x, y, vis] = this.project(gs.lat, gs.lon, w, h);
      if (vis && Math.hypot(mx - x, my - y) < 9) {
        this.hoveredObject = {
          title: `TELEPORT: ${gs.name} (${gs.id})`,
          details: [
            `City: ${gs.city}, ${gs.country} (${gs.region})`,
            `Status: ${gs.availability} | Antennas: ${gs.activeAntennas}/${gs.antennaCount}`,
            `Backhaul: ${gs.currentThroughputGbps} / ${gs.backhaulCapacityGbps} Gbps (${gs.backhaulUtilizationPct}%)`,
            `Core Latency: ${gs.latencyToCoreMs} ms`,
            `Connected Sats: ${gs.connectedSats.length}`
          ]
        };
        this.hoverPos = { x: mx, y: my };
        return;
      }
    }

    // 3. Check Satellites
    for (const sat of this.simService.satellites()) {
      const [x, y, vis] = this.project(sat.lat, sat.lon, w, h);
      if (vis && Math.hypot(mx - x, my - y) < 7) {
        this.hoveredObject = {
          title: `SATELLITE: ${sat.name} (${sat.id})`,
          details: [
            `Plane ${sat.planeIndex + 1} #${sat.satIndexInPlane + 1} | Alt: ${sat.altKm} km`,
            `Health: ${sat.health} | Velocity: ${sat.velocityKmS} km/s`,
            `Load: ${sat.throughputGbps} Gbps (${sat.utilizationPct}% ${sat.congestionState})`,
            `Active Beams: ${sat.activeBeamsCount}/${sat.maxBeams} | Users: ${sat.connectedUsers}`,
            `Optical Links: ${sat.activeLinks.length} ISLs`
          ]
        };
        this.hoverPos = { x: mx, y: my };
        return;
      }
    }

    this.hoveredObject = null;
  }
}
