// STARLINK.NET.OS — Dynamic Constellation Routing Laboratory
// Interactive Dijkstra Multi-Criteria Path Inspector, ISL Mesh Analysis, and Undersea Fiber Benchmark

import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';
import { UserTerminal } from '../../core/models/types';

@Component({
  selector: 'app-routing-lab',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="w-full h-full bg-[#06090e] p-4 flex flex-col gap-4 overflow-y-auto custom-scrollbar select-none">
      <!-- Laboratory Header & Policy Config -->
      <div class="bg-[#0b121f] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4 shadow-lg">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400">alt_route</mat-icon>
            <h1 class="text-base font-display font-black tracking-wider text-slate-100">
              DYNAMIC GRAPH ROUTING LABORATORY
            </h1>
            <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-800">
              DIJKSTRA MULTI-CRITERIA ENGINE
            </span>
          </div>
          <p class="text-xs font-mono text-slate-400 mt-1">
            Real-time shortest path recalculation across space optical mesh, satellite RF beams, and ground teleport backhaul.
          </p>
        </div>

        <!-- Policy Selector Buttons -->
        <div class="flex items-center gap-1.5 bg-[#080d16] border border-slate-800 rounded-lg p-1">
          <span class="text-[11px] font-mono text-slate-400 px-2">ROUTING POLICY:</span>
          <button
            (click)="simService.setRoutingPolicy('SHORTEST_LATENCY')"
            [class.bg-cyan-500/20]="simService.routingPolicy().name === 'SHORTEST_LATENCY'"
            [class.text-cyan-300]="simService.routingPolicy().name === 'SHORTEST_LATENCY'"
            [class.text-slate-400]="simService.routingPolicy().name !== 'SHORTEST_LATENCY'"
            class="px-2.5 py-1.5 rounded text-xs font-mono font-medium transition-colors"
          >
            Shortest Latency
          </button>
          <button
            (click)="simService.setRoutingPolicy('MAX_CAPACITY')"
            [class.bg-cyan-500/20]="simService.routingPolicy().name === 'MAX_CAPACITY'"
            [class.text-cyan-300]="simService.routingPolicy().name === 'MAX_CAPACITY'"
            [class.text-slate-400]="simService.routingPolicy().name !== 'MAX_CAPACITY'"
            class="px-2.5 py-1.5 rounded text-xs font-mono font-medium transition-colors"
          >
            Max Capacity
          </button>
          <button
            (click)="simService.setRoutingPolicy('MIN_HOPS')"
            [class.bg-cyan-500/20]="simService.routingPolicy().name === 'MIN_HOPS'"
            [class.text-cyan-300]="simService.routingPolicy().name === 'MIN_HOPS'"
            [class.text-slate-400]="simService.routingPolicy().name !== 'MIN_HOPS'"
            class="px-2.5 py-1.5 rounded text-xs font-mono font-medium transition-colors"
          >
            Min Hops
          </button>
          <button
            (click)="simService.setRoutingPolicy('BALANCED_WEIGHTED')"
            [class.bg-cyan-500/20]="simService.routingPolicy().name === 'BALANCED_WEIGHTED'"
            [class.text-cyan-300]="simService.routingPolicy().name === 'BALANCED_WEIGHTED'"
            [class.text-slate-400]="simService.routingPolicy().name !== 'BALANCED_WEIGHTED'"
            class="px-2.5 py-1.5 rounded text-xs font-mono font-medium transition-colors"
          >
            Balanced Weighted
          </button>
        </div>
      </div>

      <!-- Main Lab Grid: Left = Terminal Routes Table, Right = Active Path Deep Dive -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
        <!-- Left 5 Cols: Active Terminals & Calculated Routes -->
        <div class="lg:col-span-5 bg-[#0b121f] border border-slate-800 rounded-xl p-3.5 flex flex-col gap-3 shadow">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="font-mono text-xs font-bold text-slate-200 uppercase">
              ACTIVE TERMINAL PATHWAYS ({{ simService.terminals().length }})
            </span>
            <span class="text-[10px] font-mono text-emerald-400">
              {{ activeConnectedRoutesCount() }} CONNECTED
            </span>
          </div>

          <!-- Routes List -->
          <div class="space-y-1.5 flex-1 overflow-y-auto custom-scrollbar max-h-[580px]">
            @for (term of simService.terminals(); track term.id) {
              <button
                type="button"
                (click)="simService.selectTerminal(term.id)"
                [class.border-cyan-500]="simService.selectedObject()?.data?.id === term.id"
                [class.bg-cyan-950/20]="simService.selectedObject()?.data?.id === term.id"
                [class.border-slate-800]="simService.selectedObject()?.data?.id !== term.id"
                class="w-full text-left p-2.5 rounded-lg border bg-slate-900/50 hover:bg-slate-800/80 cursor-pointer transition-colors space-y-1.5 focus:outline-none focus:ring-1 focus:ring-cyan-400"
              >
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-1.5">
                    <mat-icon class="text-xs text-cyan-400">
                      {{ term.type === 'AIRCRAFT' ? 'flight' : term.type === 'MARITIME' ? 'directions_boat' : 'cell_tower' }}
                    </mat-icon>
                    <span class="font-mono text-xs font-bold text-slate-100">{{ term.name }}</span>
                  </div>
                  <span class="text-[10px] font-mono text-slate-400">{{ term.type }}</span>
                </div>

                @if (term.route) {
                  <div class="text-[11px] font-mono text-slate-400 flex items-center justify-between">
                    <span class="text-slate-500">Route: {{ term.route.hops.length - 1 }} hops</span>
                    <span class="text-amber-400 font-bold tabular-nums">{{ term.route.latencyBreakdown.totalMs }} ms</span>
                  </div>
                  <div class="text-[10px] font-mono text-slate-500 truncate">
                    {{ term.route.hops.join(' → ') }}
                  </div>
                } @else {
                  <div class="text-[11px] font-mono text-rose-400">DISCONNECTED / NO VISIBLE SATELLITE</div>
                }
              </button>
            }
          </div>
        </div>

        <!-- Right 7 Cols: Selected Route Hop Inspector & Terrestrial Fiber Benchmark -->
        <div class="lg:col-span-7 flex flex-col gap-4">
          @let activeRoute = currentActiveRoute();
          @if (!activeRoute) {
            <div class="bg-[#0b121f] border border-slate-800 rounded-xl p-8 text-center flex flex-col items-center justify-center flex-1">
              <mat-icon class="text-4xl text-slate-600 mb-2">linear_scale</mat-icon>
              <div class="font-mono text-sm font-semibold text-slate-300">SELECT A TERMINAL ROUTE</div>
              <p class="text-xs font-mono text-slate-500 max-w-sm mt-1">
                Click any user terminal on the left table or the global map to view physical laser propagation steps and speed-of-light comparisons.
              </p>
            </div>
          } @else {
            <!-- Selected Route Overview Card -->
            <div class="bg-[#0b121f] border border-cyan-900/60 rounded-xl p-4 shadow-lg space-y-3">
              <div class="flex items-start justify-between border-b border-slate-800 pb-2">
                <div>
                  <div class="text-sm font-display font-bold text-slate-100">
                    {{ activeRoute.sourceName }} → {{ activeRoute.destinationName }}
                  </div>
                  <div class="text-[11px] font-mono text-cyan-400 mt-0.5">
                    Total Path: {{ activeRoute.totalDistanceKm }} km • Bottleneck Capacity: {{ activeRoute.bottleneckCapacityMbps }} Mbps
                  </div>
                </div>
                <div class="text-right">
                  <div class="text-lg font-mono font-bold text-amber-400 tabular-nums">
                    {{ activeRoute.latencyBreakdown.totalMs }} ms
                  </div>
                  <div class="text-[10px] font-mono text-slate-400 uppercase">One-Way RTT (Est)</div>
                </div>
              </div>

              <!-- Mathematical Provenance Component Breakdown -->
              <div class="space-y-1.5">
                <div class="text-[11px] font-mono font-bold text-slate-300 uppercase">
                  Mathematical Delay Breakdown:
                </div>
                <div class="grid grid-cols-4 gap-2 text-center text-xs font-mono">
                  <div class="bg-slate-900/80 p-2 rounded border border-slate-800">
                    <div class="text-[10px] text-slate-500">PROPAGATION (c)</div>
                    <div class="text-cyan-400 font-bold tabular-nums">{{ activeRoute.latencyBreakdown.propagationMs }} ms</div>
                  </div>
                  <div class="bg-slate-900/80 p-2 rounded border border-slate-800">
                    <div class="text-[10px] text-slate-500">SWITCH ROUTING</div>
                    <div class="text-slate-300 font-bold tabular-nums">{{ activeRoute.latencyBreakdown.routingMs }} ms</div>
                  </div>
                  <div class="bg-slate-900/80 p-2 rounded border border-slate-800">
                    <div class="text-[10px] text-slate-500">QUEUEING/BUFFER</div>
                    <div class="text-amber-400 font-bold tabular-nums">{{ activeRoute.latencyBreakdown.queueingMs }} ms</div>
                  </div>
                  <div class="bg-slate-900/80 p-2 rounded border border-slate-800">
                    <div class="text-[10px] text-slate-500">MODEM FEC CODEC</div>
                    <div class="text-slate-300 font-bold tabular-nums">{{ activeRoute.latencyBreakdown.processingMs }} ms</div>
                  </div>
                </div>
              </div>

              <!-- Step-by-Step Hop Pipeline -->
              <div class="space-y-1.5 pt-2">
                <div class="text-[11px] font-mono font-bold text-slate-300 uppercase">
                  Physical Hop Geometry:
                </div>
                <div class="space-y-1 max-h-48 overflow-y-auto custom-scrollbar">
                  @for (hop of activeRoute.hops; track $index; let i = $index) {
                    <div class="p-2 rounded bg-slate-900/70 border border-slate-800 text-xs font-mono flex items-center justify-between">
                      <div class="flex items-center gap-2">
                        <span class="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-[10px] text-cyan-400 font-bold">
                          {{ i + 1 }}
                        </span>
                        <div>
                          <div class="font-bold text-slate-200">{{ hop }}</div>
                          <div class="text-[10px] text-slate-500">{{ activeRoute.hopTypes[i] }}</div>
                        </div>
                      </div>
                      <div class="text-right text-[11px]">
                        @if (i < activeRoute.latencyBreakdown.provenance.hopDistancesKm.length) {
                          <span class="text-cyan-300 tabular-nums">
                            {{ activeRoute.latencyBreakdown.provenance.hopDistancesKm[i] }} km
                          </span>
                        }
                      </div>
                    </div>
                  }
                </div>
              </div>
            </div>

            <!-- Undersea Fiber vs Space Optical Laser Benchmark Comparison -->
            <div class="bg-[#0b121f] border border-slate-800 rounded-xl p-4 shadow space-y-3">
              <div class="flex items-center gap-2 border-b border-slate-800 pb-2">
                <mat-icon class="text-amber-400 text-sm">speed</mat-icon>
                <span class="font-mono text-xs font-bold text-slate-200 uppercase">
                  VACUUM LASER (c) VS TERRESTRIAL OPTICAL FIBER (c/n)
                </span>
              </div>
              <div class="grid grid-cols-2 gap-3 text-xs font-mono">
                <div class="p-2.5 rounded bg-slate-900/80 border border-cyan-900/60">
                  <div class="text-[10px] text-cyan-400 font-bold uppercase">SPACE OPTICAL LASER (LEO ISL)</div>
                  <div class="text-lg font-bold text-cyan-300 mt-1 tabular-nums">
                    {{ activeRoute.latencyBreakdown.propagationMs }} ms
                  </div>
                  <div class="text-[10px] text-slate-400 mt-1">
                    Speed in vacuum: 299,792 km/s (Index n = 1.000)
                  </div>
                </div>

                <div class="p-2.5 rounded bg-slate-900/80 border border-slate-800">
                  <div class="text-[10px] text-slate-400 font-bold uppercase">EQUIVALENT TERRESTRIAL FIBER</div>
                  <div class="text-lg font-bold text-slate-300 mt-1 tabular-nums">
                    {{ (activeRoute.latencyBreakdown.propagationMs * 1.468).toFixed(2) }} ms
                  </div>
                  <div class="text-[10px] text-slate-400 mt-1">
                    Speed in silica glass: 204,100 km/s (Index n = 1.468)
                  </div>
                </div>
              </div>
              <p class="text-[11px] font-mono text-emerald-400">
                ⚡ Space laser route achieves a ~47% propagation speed advantage over trans-oceanic undersea silica cables due to refractive index in vacuum!
              </p>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class RoutingLab {
  public simService = inject(SimulationService);

  public activeConnectedRoutesCount = computed(() => {
    return this.simService.terminals().filter(t => t.sessionState === 'CONNECTED').length;
  });

  public currentActiveRoute = computed(() => {
    const sel = this.simService.selectedObject();
    if (sel?.type === 'TERMINAL') {
      const term = sel.data as UserTerminal;
      if (term.route) return term.route;
    }
    const firstConnected = this.simService.terminals().find(t => t.route);
    return firstConnected?.route || null;
  });
}
