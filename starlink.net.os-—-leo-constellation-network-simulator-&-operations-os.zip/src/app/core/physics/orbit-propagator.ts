// STARLINK.NET.OS — Keplerian Orbital Propagator & Astrodynamics Physics Engine
// Implements Walker-Delta constellation generation, J2 nodal precession, ECEF coordinate transforms, and AER calculations

import { ConstellationConfig, Satellite, VisibilityResult } from '../models/types';

export const EARTH_RADIUS_KM = 6371.0;
export const EARTH_MU_KM3_S2 = 398600.4418;
export const EARTH_J2 = 1.08263e-3;
export const EARTH_ROTATION_RAD_S = 7.292115e-5; // 360 deg / sidereal day
export const SPEED_OF_LIGHT_KM_S = 299792.458;

export class OrbitPropagator {
  /**
   * Initializes a full Walker-Delta constellation of satellites
   */
  static generateConstellation(config: ConstellationConfig): Satellite[] {
    const satellites: Satellite[] = [];
    const a = EARTH_RADIUS_KM + config.altitudeKm;
    const n = Math.sqrt(EARTH_MU_KM3_S2 / Math.pow(a, 3)); // Mean motion (rad/s)
    const orbitalPeriodMin = (2 * Math.PI / n) / 60;
    const velocityKmS = Math.sqrt(EARTH_MU_KM3_S2 / a);
    const incRad = (config.inclinationDeg * Math.PI) / 180;

    let idCounter = 1;
    const numPlanes = config.orbitalPlanes;
    const satsPerPlane = config.satellitesPerPlane;
    const totalSats = config.satellites;
    const fParam = config.fParam || 1;

    for (let p = 0; p < numPlanes; p++) {
      const raan0 = (2 * Math.PI * p) / numPlanes;

      for (let s = 0; s < satsPerPlane; s++) {
        if (satellites.length >= totalSats) break;

        // Walker phasing: phase offset between planes
        const phaseOffset = (2 * Math.PI * fParam * p) / totalSats;
        const meanAnomaly0 = ((2 * Math.PI * s) / satsPerPlane + phaseOffset) % (2 * Math.PI);

        const satId = `SAT-${idCounter.toString().padStart(4, '0')}`;
        const satName = `Starlink-${idCounter.toString().padStart(4, '0')}`;

        const sat: Satellite = {
          id: satId,
          name: satName,
          planeIndex: p,
          satIndexInPlane: s,
          semiMajorAxisKm: a,
          inclinationRad: incRad,
          raanRad: raan0,
          meanAnomalyRad: meanAnomaly0,
          trueAnomalyRad: meanAnomaly0,
          orbitalPeriodMin,
          lat: 0,
          lon: 0,
          altKm: config.altitudeKm,
          velocityKmS: Number(velocityKmS.toFixed(3)),
          ecefX: 0,
          ecefY: 0,
          ecefZ: 0,
          health: 'NOMINAL',
          powerStateW: 1450 + (idCounter % 50) * 2,
          maxPowerW: 1800,
          thermalStateC: 22.4 + (idCounter % 15) * 0.2,
          processingLoadPct: 15 + (idCounter % 20),
          downlinkCapacityGbps: config.satCapacityGbps,
          uplinkCapacityGbps: config.satCapacityGbps * 0.4,
          activeBeamsCount: Math.min(config.beamCountPerSat, 16),
          maxBeams: config.beamCountPerSat,
          throughputGbps: 0,
          utilizationPct: 0,
          congestionState: 'NORMAL',
          activeLinks: [],
          connectedUsers: 0,
          connectedGroundStations: [],
          activeBeams: [],
          handoverCount: 0,
          historyUtil: [12, 14, 15, 13, 16, 18, 15]
        };

        // Initialize position at t = 0
        this.propagateSatellite(sat, 0);
        satellites.push(sat);
        idCounter++;
      }
    }

    return satellites;
  }

  /**
   * Propagates a satellite to simulated time `simTimeSec`
   */
  static propagateSatellite(sat: Satellite, simTimeSec: number): void {
    const a = sat.semiMajorAxisKm;
    const n = Math.sqrt(EARTH_MU_KM3_S2 / Math.pow(a, 3)); // Mean motion (rad/s)
    const inc = sat.inclinationRad;

    // J2 Nodal Precession rate (rad/s)
    const j2DriftRate = -1.5 * EARTH_J2 * Math.pow(EARTH_RADIUS_KM / a, 2) * n * Math.cos(inc);

    // Current RAAN accounting for Earth rotation and J2 secular drift
    const effectiveRaan = sat.raanRad + (j2DriftRate - EARTH_ROTATION_RAD_S) * simTimeSec;

    // Current Mean & True Anomaly (circular orbit e = 0)
    const meanAnomaly = (sat.meanAnomalyRad + n * simTimeSec) % (2 * Math.PI);
    sat.trueAnomalyRad = meanAnomaly;

    // Orbital plane coordinates (x', y', z'=0)
    const u = meanAnomaly; // Argument of latitude
    const xPrime = a * Math.cos(u);
    const yPrime = a * Math.sin(u);

    // Rotate to Earth-Centered Earth-Fixed (ECEF) frame
    const cosRaan = Math.cos(effectiveRaan);
    const sinRaan = Math.sin(effectiveRaan);
    const cosInc = Math.cos(inc);
    const sinInc = Math.sin(inc);

    const ecefX = xPrime * cosRaan - yPrime * cosInc * sinRaan;
    const ecefY = xPrime * sinRaan + yPrime * cosInc * cosRaan;
    const ecefZ = yPrime * sinInc;

    sat.ecefX = ecefX;
    sat.ecefY = ecefY;
    sat.ecefZ = ecefZ;

    // Geodetic Latitude, Longitude, Altitude
    const r = Math.sqrt(ecefX * ecefX + ecefY * ecefY + ecefZ * ecefZ);
    const latRad = Math.asin(ecefZ / r);
    const lonRad = Math.atan2(ecefY, ecefX);

    sat.lat = Number(((latRad * 180) / Math.PI).toFixed(4));
    sat.lon = Number(((lonRad * 180) / Math.PI).toFixed(4));
    sat.altKm = Number((r - EARTH_RADIUS_KM).toFixed(2));
  }

  /**
   * Convert observer Geodetic (lat, lon, altM) to ECEF coordinates
   */
  static geodeticToEcef(latDeg: number, lonDeg: number, altM = 0): [number, number, number] {
    const latRad = (latDeg * Math.PI) / 180;
    const lonRad = (lonDeg * Math.PI) / 180;
    const r = EARTH_RADIUS_KM + altM / 1000.0;

    const x = r * Math.cos(latRad) * Math.cos(lonRad);
    const y = r * Math.cos(latRad) * Math.sin(lonRad);
    const z = r * Math.sin(latRad);

    return [x, y, z];
  }

  /**
   * Calculates Azimuth, Elevation, Range (AER) and visibility between Ground Observer and Satellite
   */
  static calculateAer(
    observerLat: number,
    observerLon: number,
    observerAltM: number,
    sat: Satellite,
    minElevationDeg = 25.0
  ): VisibilityResult {
    if (sat.health === 'OFFLINE') {
      return { visible: false, elevationDeg: -90, azimuthDeg: 0, rangeKm: 99999, lineOfSight: false };
    }

    const [gx, gy, gz] = this.geodeticToEcef(observerLat, observerLon, observerAltM);

    // Range vector from observer to satellite
    const dx = sat.ecefX - gx;
    const dy = sat.ecefY - gy;
    const dz = sat.ecefZ - gz;
    const rangeKm = Math.sqrt(dx * dx + dy * dy + dz * dz);

    // Observer local topocentric unit vectors (Up, East, North)
    const latRad = (observerLat * Math.PI) / 180;
    const lonRad = (observerLon * Math.PI) / 180;

    // Up unit vector
    const ux = Math.cos(latRad) * Math.cos(lonRad);
    const uy = Math.cos(latRad) * Math.sin(lonRad);
    const uz = Math.sin(latRad);

    // East unit vector
    const ex = -Math.sin(lonRad);
    const ey = Math.cos(lonRad);
    const ez = 0;

    // North unit vector
    const nx = -Math.sin(latRad) * Math.cos(lonRad);
    const ny = -Math.sin(latRad) * Math.sin(lonRad);
    const nz = Math.cos(latRad);

    // Unit vector to satellite
    const rx = dx / rangeKm;
    const ry = dy / rangeKm;
    const rz = dz / rangeKm;

    // Dot product with Up vector gives sine of elevation angle
    const sinElevation = rx * ux + ry * uy + rz * uz;
    const elevationRad = Math.asin(Math.max(-1, Math.min(1, sinElevation)));
    const elevationDeg = (elevationRad * 180) / Math.PI;

    // Projection on local horizontal plane for azimuth
    const eastComp = rx * ex + ry * ey + rz * ez;
    const northComp = rx * nx + ry * ny + rz * nz;
    let azimuthDeg = (Math.atan2(eastComp, northComp) * 180) / Math.PI;
    if (azimuthDeg < 0) azimuthDeg += 360;

    // Line of sight geometric check with Earth limb
    const isVisible = elevationDeg >= minElevationDeg;

    return {
      visible: isVisible,
      elevationDeg: Number(elevationDeg.toFixed(2)),
      azimuthDeg: Number(azimuthDeg.toFixed(2)),
      rangeKm: Number(rangeKm.toFixed(2)),
      lineOfSight: elevationDeg > 0
    };
  }

  /**
   * Distance between two ECEF points in km
   */
  static ecefDistanceKm(x1: number, y1: number, z1: number, x2: number, y2: number, z2: number): number {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const dz = z2 - z1;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }

  /**
   * Great circle distance on Earth sphere in km
   */
  static greatCircleDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const p1 = (lat1 * Math.PI) / 180;
    const p2 = (lat2 * Math.PI) / 180;
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;

    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(p1) * Math.cos(p2) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return EARTH_RADIUS_KM * c;
  }

  /**
   * Checks if direct line of sight between two satellites is occulted by Earth's atmosphere (approx 100km buffer)
   */
  static checkIslLineOfSight(sat1: Satellite, sat2: Satellite, minTangentAltKm = 80.0): boolean {
    const p1 = [sat1.ecefX, sat1.ecefY, sat1.ecefZ];
    const p2 = [sat2.ecefX, sat2.ecefY, sat2.ecefZ];

    const d = [p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2]];
    const dMagSq = d[0] * d[0] + d[1] * d[1] + d[2] * d[2];
    if (dMagSq === 0) return false;

    // Find closest approach of line segment to Earth center (0,0,0)
    const t = -(p1[0] * d[0] + p1[1] * d[1] + p1[2] * d[2]) / dMagSq;
    const clampedT = Math.max(0, Math.min(1, t));

    const closestX = p1[0] + clampedT * d[0];
    const closestY = p1[1] + clampedT * d[1];
    const closestZ = p1[2] + clampedT * d[2];
    const closestDist = Math.sqrt(closestX * closestX + closestY * closestY + closestZ * closestZ);

    return closestDist >= (EARTH_RADIUS_KM + minTangentAltKm);
  }
}
