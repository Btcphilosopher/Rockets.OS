// STARLINK.NET.OS — Core Domain Types & Data Models
// Synthetic Constellation Modeling & Network Simulation Engine

export type HealthStatus = 'NOMINAL' | 'DEGRADED' | 'OFFLINE' | 'MAINTENANCE';
export type CongestionState = 'NORMAL' | 'BUSY' | 'CONGESTED' | 'SATURATED';
export type UserType = 'HOUSEHOLD' | 'ENTERPRISE' | 'MARITIME' | 'AIRCRAFT' | 'RURAL' | 'URBAN_CLUSTER';
export type TrafficClass = 'WEB' | 'VIDEO' | 'VOICE' | 'GAMING' | 'ENTERPRISE' | 'BULK';
export type PriorityLevel = 'LOW' | 'STANDARD' | 'HIGH' | 'MISSION_CRITICAL';
export type LinkType = 'INTRA_PLANE' | 'INTER_PLANE' | 'FEEDER_DOWNLINK' | 'USER_UPLINK';
export type RoutingAlgorithm = 'SHORTEST_LATENCY' | 'MAX_CAPACITY' | 'MIN_HOPS' | 'BALANCED_WEIGHTED';
export type MapProjection = 'EQUIRECTANGULAR' | 'ORTHOGRAPHIC';

export interface ConstellationConfig {
  name: string;
  satellites: number;
  orbitalPlanes: number;
  satellitesPerPlane: number;
  altitudeKm: number;
  inclinationDeg: number;
  phaseOffsetDeg: number;
  fParam: number; // Walker F parameter
  beamCountPerSat: number;
  beamRadiusKm: number;
  beamCapacityMbps: number;
  satCapacityGbps: number;
  islBandwidthGbps: number;
  maxIslRangeKm: number;
  minElevationDeg: number;
  timeStepSec: number;
  seed: number;
}

export interface Satellite {
  id: string;
  name: string;
  planeIndex: number;
  satIndexInPlane: number;
  // Orbital state
  semiMajorAxisKm: number;
  inclinationRad: number;
  raanRad: number; // Right Ascension of Ascending Node
  meanAnomalyRad: number;
  trueAnomalyRad: number;
  orbitalPeriodMin: number;
  // Geodetic & ECEF Coordinates
  lat: number;
  lon: number;
  altKm: number;
  velocityKmS: number;
  ecefX: number;
  ecefY: number;
  ecefZ: number;
  // Subsystem health & limits
  health: HealthStatus;
  powerStateW: number;
  maxPowerW: number;
  thermalStateC: number;
  processingLoadPct: number;
  // Telemetry & Capacity
  downlinkCapacityGbps: number;
  uplinkCapacityGbps: number;
  activeBeamsCount: number;
  maxBeams: number;
  throughputGbps: number;
  utilizationPct: number;
  congestionState: CongestionState;
  activeLinks: string[]; // ISL IDs
  connectedUsers: number;
  connectedGroundStations: string[];
  activeBeams: BeamState[];
  handoverCount: number;
  historyUtil: number[];
}

export interface BeamState {
  id: string;
  beamIndex: number;
  satId: string;
  centerLat: number;
  centerLon: number;
  radiusKm: number;
  allocatedCapacityMbps: number;
  usedCapacityMbps: number;
  utilizationPct: number;
  userCount: number;
  status: 'ACTIVE' | 'CONGESTED' | 'IDLE';
}

export type GroundStationAvailability = 'ONLINE' | 'DEGRADED' | 'OFFLINE';

export interface GroundStation {
  id: string;
  name: string;
  city: string;
  country: string;
  region: string;
  lat: number;
  lon: number;
  altM: number;
  antennaCount: number;
  activeAntennas: number;
  uplinkCapacityGbps: number;
  downlinkCapacityGbps: number;
  backhaulCapacityGbps: number;
  currentThroughputGbps: number;
  backhaulUtilizationPct: number;
  availability: GroundStationAvailability;
  latencyToCoreMs: number;
  connectedSats: string[];
  coreGatewayIp: string;
}

export interface UserTerminal {
  id: string;
  name: string;
  type: UserType;
  lat: number;
  lon: number;
  altM: number;
  headingDeg?: number;
  speedKmH?: number;
  populationWeight: number;
  demandMbps: number;
  allocatedThroughputMbps: number;
  priority: PriorityLevel;
  trafficClass: TrafficClass;
  connectedSatId: string | null;
  activeBeamId: string | null;
  groundStationId: string | null;
  elevationDeg: number;
  azimuthDeg: number;
  rangeKm: number;
  snrDb: number;
  latencyMs: number;
  sessionState: 'CONNECTED' | 'HANDOVER' | 'SEARCHING' | 'DISCONNECTED';
  handoverEtaSec: number;
  candidateSats: CandidateSatellite[];
  handoverHistory: HandoverEventRecord[];
  route?: RoutingPath;
}

export interface CandidateSatellite {
  satId: string;
  elevationDeg: number;
  rangeKm: number;
  score: number;
  timeToLosSec: number;
  utilizationPct: number;
}

export interface HandoverEventRecord {
  id: string;
  timestamp: number;
  simTimeFormatted: string;
  terminalId: string;
  fromSatId: string;
  toSatId: string;
  triggerReason: string;
  durationMs: number;
  packetLossEstPct: number;
  success: boolean;
}

export interface ISLLink {
  id: string;
  sourceSatId: string;
  targetSatId: string;
  linkType: LinkType;
  distanceKm: number;
  latencyMs: number;
  capacityGbps: number;
  currentLoadGbps: number;
  utilizationPct: number;
  status: 'ACTIVE' | 'DEGRADED' | 'BROKEN' | 'POINTING_ERROR';
}

export interface LatencyBreakdown {
  propagationMs: number;
  routingMs: number;
  queueingMs: number;
  processingMs: number;
  totalMs: number;
  provenance: {
    hopDistancesKm: number[];
    speedOfLightKmS: number;
    hopCount: number;
    switchQueueLoadPct: number;
    perHopProcessingMs: number;
  };
}

export interface RoutingPath {
  id: string;
  sourceTerminalId: string;
  destinationCoreId: string;
  sourceName: string;
  destinationName: string;
  hops: string[];
  hopTypes: ('TERMINAL' | 'SATELLITE' | 'GROUND_STATION' | 'INTERNET')[];
  hopCoords: { lat: number; lon: number; altKm: number }[];
  totalDistanceKm: number;
  latencyBreakdown: LatencyBreakdown;
  bottleneckCapacityMbps: number;
  currentTrafficMbps: number;
  status: 'OPTIMAL' | 'CONGESTED' | 'REROUTED' | 'FAILED';
}

export interface RoutingPolicy {
  name: RoutingAlgorithm;
  latencyWeight: number;
  congestionWeight: number;
  hopWeight: number;
}

export interface VisibilityResult {
  visible: boolean;
  elevationDeg: number;
  azimuthDeg: number;
  rangeKm: number;
  lineOfSight: boolean;
}

export interface SimEvent {
  id: string;
  timestamp: number;
  simTimeFormatted: string;
  type:
    | 'SatelliteAdded'
    | 'SatelliteLost'
    | 'SatelliteRecovered'
    | 'UserConnected'
    | 'UserDisconnected'
    | 'HandoverStarted'
    | 'HandoverCompleted'
    | 'LinkEstablished'
    | 'LinkDropped'
    | 'CongestionDetected'
    | 'GroundStationLost'
    | 'GroundStationRecovered'
    | 'RouteChanged'
    | 'FailureInjected'
    | 'TrafficSurgeTriggered';
  severity: 'INFO' | 'WARNING' | 'CRITICAL' | 'SUCCESS';
  message: string;
  entityId: string;
  details?: Record<string, unknown>;
}

export interface ConstellationMetrics {
  timestamp: number;
  simTimeSec: number;
  simTimeFormatted: string;
  totalSatellites: number;
  onlineSatellites: number;
  degradedSatellites: number;
  offlineSatellites: number;
  totalGroundStations: number;
  onlineGroundStations: number;
  totalUsers: number;
  connectedUsers: number;
  globalThroughputGbps: number;
  meanUtilizationPct: number;
  peakUtilizationPct: number;
  activeHandoversCount: number;
  totalHandoversCompleted: number;
  avgLatencyMs: number;
  p50LatencyMs: number;
  p95LatencyMs: number;
  p99LatencyMs: number;
  activeIslLinks: number;
  congestedBeamsCount: number;
  globalCoveragePct: number;
  packetLossEstPct: number;
}

export interface FailureScenarioConfig {
  id: string;
  name: string;
  code: string;
  description: string;
  category: 'SATELLITE_FAILURE' | 'GROUND_STATION_FAILURE' | 'TRAFFIC_SURGE' | 'CLUSTER_OUTAGE' | 'AIRCRAFT_FLIGHT' | 'MARITIME_PASSAGE';
  targetEntityId?: string;
  surgeLocation?: { lat: number; lon: number; radiusKm: number; multiplier: number; cityName: string };
  movingVehicleId?: string;
  durationSec: number;
  startTimeSec: number;
}

export interface CapacityPlanResult {
  region: string;
  population: number;
  currentDemandGbps: number;
  projectedDemandGbps: number;
  visibleSatsAvg: number;
  simultaneousCapacityGbps: number;
  groundStationCapacityGbps: number;
  satelliteBottleneckGbps: number;
  groundStationBottleneckGbps: number;
  capacityDeficitGbps: number;
  coverageContinuityPct: number;
  recommendedSatsIncrease: number;
  recommendedNewGroundStations: number;
  provenanceSummary: string;
}
