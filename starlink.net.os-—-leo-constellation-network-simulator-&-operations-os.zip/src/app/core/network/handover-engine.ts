// STARLINK.NET.OS — Phased Array Satellite Handover Engine
// Implements continuous elevation tracking, hysteresis-based candidate scoring, and make-before-break session transitions

import { CandidateSatellite, HandoverEventRecord, Satellite, SimEvent, UserTerminal } from '../models/types';
import { OrbitPropagator } from '../physics/orbit-propagator';

export class HandoverEngine {
  private static readonly HYSTERESIS_SCORE_BIAS = 15.0; // Score margin required to switch and prevent ping-pong
  private static readonly WEIGHT_ELEVATION = 1.0;
  private static readonly WEIGHT_TIME_TO_LOS = 0.5;
  private static readonly WEIGHT_UTILIZATION = 0.8;

  /**
   * Evaluates visibility, candidate scoring, and executes handovers for all user terminals
   */
  static processTerminalHandovers(
    terminals: UserTerminal[],
    satellites: Satellite[],
    minElevationDeg: number,
    simTimeSec: number,
    timeStepSec: number,
    eventEmitter: (event: SimEvent) => void
  ): void {
    const onlineSats = satellites.filter(s => s.health !== 'OFFLINE');
    const satMap = new Map<string, Satellite>();
    satellites.forEach(s => satMap.set(s.id, s));

    for (const terminal of terminals) {
      // 1. Find all candidate satellites above elevation mask
      const candidates: CandidateSatellite[] = [];

      for (const sat of onlineSats) {
        // Fast bounding box distance pre-filter for performance
        const approxDlat = Math.abs(sat.lat - terminal.lat);
        if (approxDlat > 25) continue; // max ground coverage footprint is ~20-22 deg

        const aer = OrbitPropagator.calculateAer(
          terminal.lat,
          terminal.lon,
          terminal.altM,
          sat,
          minElevationDeg
        );

        if (aer.visible) {
          // Estimate time to loss-of-signal (seconds) based on orbital speed and elevation
          // At ~7.56 km/s, a satellite traverses a ground footprint in ~3-6 minutes (180-360s)
          const timeToLosSec = Math.max(
            10,
            Math.round(((aer.elevationDeg - minElevationDeg) / (70 - minElevationDeg)) * 240)
          );

          // Candidate quality score
          let score =
            this.WEIGHT_ELEVATION * aer.elevationDeg +
            this.WEIGHT_TIME_TO_LOS * (timeToLosSec / 5.0) -
            this.WEIGHT_UTILIZATION * sat.utilizationPct;

          if (sat.id === terminal.connectedSatId) {
            score += this.HYSTERESIS_SCORE_BIAS; // Hysteresis bonus to current server
          }

          candidates.push({
            satId: sat.id,
            elevationDeg: aer.elevationDeg,
            rangeKm: aer.rangeKm,
            score: Number(score.toFixed(1)),
            timeToLosSec,
            utilizationPct: sat.utilizationPct
          });
        }
      }

      // Sort candidates by score descending
      candidates.sort((a, b) => b.score - a.score);
      terminal.candidateSats = candidates.slice(0, 5);

      // Check current connection
      const currentSatId = terminal.connectedSatId;
      const currentSat = currentSatId ? satMap.get(currentSatId) : null;
      let currentVisible = false;
      let currentAer = { elevationDeg: 0, azimuthDeg: 0, rangeKm: 0, snrDb: 0 };

      if (currentSat && currentSat.health !== 'OFFLINE') {
        const aer = OrbitPropagator.calculateAer(
          terminal.lat,
          terminal.lon,
          terminal.altM,
          currentSat,
          minElevationDeg
        );
        currentVisible = aer.visible;
        currentAer = {
          elevationDeg: aer.elevationDeg,
          azimuthDeg: aer.azimuthDeg,
          rangeKm: aer.rangeKm,
          snrDb: Math.max(8, Number((18.5 - (aer.rangeKm - 550) * 0.015).toFixed(1)))
        };
      }

      // Decision logic: Trigger Handover if current sat lost or best candidate significantly outperforms
      const bestCandidate = candidates[0];

      if (!bestCandidate) {
        // Disconnected - no satellite currently in view
        if (terminal.sessionState !== 'DISCONNECTED') {
          terminal.sessionState = 'SEARCHING';
          terminal.connectedSatId = null;
          terminal.elevationDeg = 0;
          terminal.snrDb = 0;
          terminal.latencyMs = 999;
          eventEmitter({
            id: `EVT-DISC-${terminal.id}-${simTimeSec}`,
            timestamp: Date.now(),
            simTimeFormatted: this.formatSimTime(simTimeSec),
            type: 'UserDisconnected',
            severity: 'WARNING',
            message: `Terminal ${terminal.name} lost all satellite visibility (Out of coverage / low elevation).`,
            entityId: terminal.id
          });
        }
      } else if (!currentSat || !currentVisible || currentSat.health === 'OFFLINE') {
        // Immediate handover needed (LOS or satellite failure)
        const prevSatId = currentSatId || 'NONE';
        const newSatId = bestCandidate.satId;
        const newSat = satMap.get(newSatId)!;

        this.executeHandover(
          terminal,
          prevSatId,
          newSat,
          bestCandidate,
          'Loss of Line of Sight / Elevation Mask',
          simTimeSec,
          eventEmitter
        );
      } else if (bestCandidate.satId !== currentSatId && bestCandidate.score > (terminal.candidateSats.find(c => c.satId === currentSatId)?.score || 0) + this.HYSTERESIS_SCORE_BIAS) {
        // Proactive handover due to superior candidate elevation and lower beam congestion
        this.executeHandover(
          terminal,
          currentSatId || 'NONE',
          satMap.get(bestCandidate.satId)!,
          bestCandidate,
          'Higher Elevation & Optimal Link Budget',
          simTimeSec,
          eventEmitter
        );
      } else {
        // Maintain current connection & update active telemetry
        terminal.sessionState = 'CONNECTED';
        terminal.elevationDeg = currentAer.elevationDeg;
        terminal.azimuthDeg = currentAer.azimuthDeg;
        terminal.rangeKm = currentAer.rangeKm;
        terminal.snrDb = currentAer.snrDb;
        terminal.handoverEtaSec = Math.max(5, terminal.handoverEtaSec - timeStepSec);
      }
    }
  }

  private static executeHandover(
    terminal: UserTerminal,
    fromSatId: string,
    toSat: Satellite,
    candidateInfo: CandidateSatellite,
    reason: string,
    simTimeSec: number,
    eventEmitter: (event: SimEvent) => void
  ): void {
    const handoverDurationMs = Math.floor(14 + Math.random() * 18); // 14-32ms phased array beam steer time
    const packetLossEstPct = Number((0.02 + Math.random() * 0.08).toFixed(2));

    terminal.connectedSatId = toSat.id;
    terminal.sessionState = 'CONNECTED';
    terminal.elevationDeg = candidateInfo.elevationDeg;
    terminal.rangeKm = candidateInfo.rangeKm;
    terminal.snrDb = Math.max(9, Number((18.5 - (candidateInfo.rangeKm - 550) * 0.015).toFixed(1)));
    terminal.handoverEtaSec = candidateInfo.timeToLosSec;
    toSat.handoverCount = (toSat.handoverCount || 0) + 1;

    const record: HandoverEventRecord = {
      id: `HO-${terminal.id}-${simTimeSec}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now(),
      simTimeFormatted: this.formatSimTime(simTimeSec),
      terminalId: terminal.id,
      fromSatId,
      toSatId: toSat.id,
      triggerReason: reason,
      durationMs: handoverDurationMs,
      packetLossEstPct,
      success: true
    };

    terminal.handoverHistory.unshift(record);
    if (terminal.handoverHistory.length > 25) {
      terminal.handoverHistory.pop();
    }

    eventEmitter({
      id: `EVT-HO-${terminal.id}-${simTimeSec}`,
      timestamp: Date.now(),
      simTimeFormatted: this.formatSimTime(simTimeSec),
      type: 'HandoverCompleted',
      severity: 'INFO',
      message: `Handover on ${terminal.name}: ${fromSatId} → ${toSat.id} (${reason}, ${handoverDurationMs}ms switch).`,
      entityId: terminal.id,
      details: record as unknown as Record<string, unknown>
    });
  }

  private static formatSimTime(sec: number): string {
    const hrs = Math.floor(sec / 3600);
    const mins = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    return `T+${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }
}
