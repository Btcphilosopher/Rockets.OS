// STARLINK.NET.OS — Inter-Satellite Optical Laser Link (ISL) Mesh Generator
// Dynamic space topology modeling with geometric line-of-sight constraints and vacuum optical propagation

import { ConstellationConfig, ISLLink, Satellite } from '../models/types';
import { OrbitPropagator, SPEED_OF_LIGHT_KM_S } from '../physics/orbit-propagator';

export class IslMeshManager {
  /**
   * Builds or updates the full inter-satellite laser mesh topology for the constellation
   */
  static buildTopology(satellites: Satellite[], config: ConstellationConfig): ISLLink[] {
    const links: ISLLink[] = [];
    const satMap = new Map<string, Satellite>();
    const satByPlane = new Map<number, Satellite[]>();

    satellites.forEach(sat => {
      satMap.set(sat.id, sat);
      const list = satByPlane.get(sat.planeIndex) || [];
      list.push(sat);
      satByPlane.set(sat.planeIndex, list);
    });

    const maxRangeKm = config.maxIslRangeKm || 5014;
    const capacityGbps = config.islBandwidthGbps || 100;
    const numPlanes = config.orbitalPlanes;

    // Reset sat activeLinks
    satellites.forEach(s => (s.activeLinks = []));

    // 1. Intra-plane links (Fore and Aft in same orbital plane)
    for (let p = 0; p < numPlanes; p++) {
      const planeSats = satByPlane.get(p) || [];
      const count = planeSats.length;
      if (count < 2) continue;

      // Sort by anomaly
      planeSats.sort((a, b) => a.satIndexInPlane - b.satIndexInPlane);

      for (let i = 0; i < count; i++) {
        const satA = planeSats[i];
        const nextIdx = (i + 1) % count;
        const satB = planeSats[nextIdx];

        const linkId = `ISL-INTRA-P${p}-${satA.id}-${satB.id}`;
        const distKm = OrbitPropagator.ecefDistanceKm(
          satA.ecefX, satA.ecefY, satA.ecefZ,
          satB.ecefX, satB.ecefY, satB.ecefZ
        );

        let status: ISLLink['status'] = 'ACTIVE';
        if (satA.health === 'OFFLINE' || satB.health === 'OFFLINE') {
          status = 'BROKEN';
        } else if (distKm > maxRangeKm || !OrbitPropagator.checkIslLineOfSight(satA, satB)) {
          status = 'POINTING_ERROR';
        } else if (satA.health === 'DEGRADED' || satB.health === 'DEGRADED') {
          status = 'DEGRADED';
        }

        const latencyMs = Number(((distKm / SPEED_OF_LIGHT_KM_S) * 1000).toFixed(3));
        const loadGbps = status === 'ACTIVE' ? Number((Math.min(satA.throughputGbps, satB.throughputGbps) * 0.4).toFixed(2)) : 0;
        const utilPct = Number(((loadGbps / capacityGbps) * 100).toFixed(1));

        const link: ISLLink = {
          id: linkId,
          sourceSatId: satA.id,
          targetSatId: satB.id,
          linkType: 'INTRA_PLANE',
          distanceKm: Number(distKm.toFixed(1)),
          latencyMs,
          capacityGbps,
          currentLoadGbps: loadGbps,
          utilizationPct: utilPct,
          status
        };

        links.push(link);
        if (status === 'ACTIVE') {
          satA.activeLinks.push(linkId);
          satB.activeLinks.push(linkId);
        }
      }
    }

    // 2. Inter-plane links (Left and Right adjacent orbital planes)
    // Avoid cross-seam counter-rotating plane links at seam (plane 0 and plane N-1 if counter-rotating)
    for (let p = 0; p < numPlanes; p++) {
      const nextPlane = (p + 1) % numPlanes;
      // If inclination is retrograde/near-polar, omit the seam link between plane 0 and plane N-1
      if (p === numPlanes - 1 && config.inclinationDeg > 70) continue;

      const planeA = satByPlane.get(p) || [];
      const planeB = satByPlane.get(nextPlane) || [];
      if (!planeA.length || !planeB.length) continue;

      for (const satA of planeA) {
        // Find closest satellite in plane B
        let closestSatB: Satellite | null = null;
        let minDist = Infinity;

        for (const satB of planeB) {
          const dist = OrbitPropagator.ecefDistanceKm(
            satA.ecefX, satA.ecefY, satA.ecefZ,
            satB.ecefX, satB.ecefY, satB.ecefZ
          );
          if (dist < minDist) {
            minDist = dist;
            closestSatB = satB;
          }
        }

        if (closestSatB && minDist <= maxRangeKm) {
          const linkId = `ISL-INTER-P${p}xP${nextPlane}-${satA.id}-${closestSatB.id}`;
          const isLos = OrbitPropagator.checkIslLineOfSight(satA, closestSatB);

          let status: ISLLink['status'] = 'ACTIVE';
          if (satA.health === 'OFFLINE' || closestSatB.health === 'OFFLINE') {
            status = 'BROKEN';
          } else if (!isLos || minDist > maxRangeKm) {
            status = 'POINTING_ERROR';
          } else if (satA.health === 'DEGRADED' || closestSatB.health === 'DEGRADED') {
            status = 'DEGRADED';
          }

          const latencyMs = Number(((minDist / SPEED_OF_LIGHT_KM_S) * 1000).toFixed(3));
          const loadGbps = status === 'ACTIVE' ? Number(((satA.throughputGbps + closestSatB.throughputGbps) * 0.2).toFixed(2)) : 0;
          const utilPct = Number(((loadGbps / capacityGbps) * 100).toFixed(1));

          const link: ISLLink = {
            id: linkId,
            sourceSatId: satA.id,
            targetSatId: closestSatB.id,
            linkType: 'INTER_PLANE',
            distanceKm: Number(minDist.toFixed(1)),
            latencyMs,
            capacityGbps,
            currentLoadGbps: loadGbps,
            utilizationPct: utilPct,
            status
          };

          links.push(link);
          if (status === 'ACTIVE') {
            satA.activeLinks.push(linkId);
            closestSatB.activeLinks.push(linkId);
          }
        }
      }
    }

    return links;
  }
}
