// STARLINK.NET.OS — Congestion Engine, Spot-Beam Allocator & Temporal Traffic Model
// Distinguishes RF coverage footprint from capacity saturation and models diurnal human activity curves

import {
  BeamState,
  CongestionState,
  ConstellationConfig,
  GroundStation,
  Satellite,
  UserTerminal
} from '../models/types';
import { OrbitPropagator } from '../physics/orbit-propagator';

export class CongestionEngine {
  /**
   * Calculates diurnal traffic multiplier based on solar local time for a given longitude
   */
  static getDiurnalMultiplier(lonDeg: number, simTimeSec: number): number {
    // Current simulation hour of day (UTC) + local solar offset (15 deg per hour)
    const baseHourUtc = ((simTimeSec / 3600) % 24);
    const localSolarHour = (baseHourUtc + (lonDeg / 15.0) + 24) % 24;

    // Diurnal curve formula:
    // 03:00 min (0.18), 10:00 morning peak (0.85), 14:00 steady (0.75), 20:30 evening max (1.15)
    if (localSolarHour >= 0 && localSolarHour < 6) {
      // 00:00 to 06:00: deep quiet hours
      return 0.18 + 0.15 * Math.sin(((localSolarHour) / 6.0) * Math.PI);
    } else if (localSolarHour >= 6 && localSolarHour < 9) {
      // 06:00 to 09:00: sharp morning rise
      const t = (localSolarHour - 6) / 3.0;
      return 0.33 + t * 0.52; // rises to 0.85
    } else if (localSolarHour >= 9 && localSolarHour < 17) {
      // 09:00 to 17:00: enterprise/workday steady plateau
      return 0.80 + 0.08 * Math.sin(((localSolarHour - 9) / 8.0) * Math.PI);
    } else if (localSolarHour >= 17 && localSolarHour < 22) {
      // 17:00 to 22:00: peak residential streaming & gaming
      const t = (localSolarHour - 17) / 5.0;
      return 0.88 + 0.27 * Math.sin(t * Math.PI); // peaks at ~1.15
    } else {
      // 22:00 to 24:00: night decline
      const t = (localSolarHour - 22) / 2.0;
      return 0.88 - t * 0.70;
    }
  }

  /**
   * Updates spot beams, user demands, satellite switch fabrics, and ground station feeder links
   */
  static updateConstellationCongestion(
    satellites: Satellite[],
    terminals: UserTerminal[],
    groundStations: GroundStation[],
    config: ConstellationConfig,
    simTimeSec: number,
    surgeConfig?: { lat: number; lon: number; radiusKm: number; multiplier: number }
  ): void {
    const satMap = new Map<string, Satellite>();
    satellites.forEach(s => {
      satMap.set(s.id, s);
      s.activeBeams = [];
      s.connectedUsers = 0;
      s.connectedGroundStations = [];
      s.throughputGbps = 0;
    });

    // 1. Update user demands with diurnal temporal curve & optional localized traffic surge
    for (const term of terminals) {
      const diurnal = this.getDiurnalMultiplier(term.lon, simTimeSec);
      let baseDemand = 60.0;

      if (term.type === 'URBAN_CLUSTER') baseDemand = 1800.0;
      else if (term.type === 'ENTERPRISE') baseDemand = 950.0;
      else if (term.type === 'AIRCRAFT') baseDemand = 190.0;
      else if (term.type === 'MARITIME') baseDemand = 80.0;
      else if (term.type === 'RURAL') baseDemand = 120.0;
      else if (term.type === 'HOUSEHOLD') baseDemand = 75.0;

      let surgeMultiplier = 1.0;
      if (surgeConfig) {
        const distToSurge = OrbitPropagator.greatCircleDistanceKm(
          term.lat,
          term.lon,
          surgeConfig.lat,
          surgeConfig.lon
        );
        if (distToSurge <= surgeConfig.radiusKm) {
          surgeMultiplier = surgeConfig.multiplier;
        }
      }

      term.demandMbps = Number((baseDemand * diurnal * surgeMultiplier).toFixed(1));
    }

    // 2. Form spot beams and assign users to beams
    const satAssignedUsers = new Map<string, UserTerminal[]>();
    for (const term of terminals) {
      if (term.connectedSatId && satMap.has(term.connectedSatId)) {
        const list = satAssignedUsers.get(term.connectedSatId) || [];
        list.push(term);
        satAssignedUsers.set(term.connectedSatId, list);
      }
    }

    const maxBeamCapacityMbps = config.beamCapacityMbps || 650;
    const beamRadiusKm = config.beamRadiusKm || 32;

    for (const [satId, users] of satAssignedUsers.entries()) {
      const sat = satMap.get(satId)!;
      if (sat.health === 'OFFLINE') continue;

      sat.connectedUsers = users.length;
      let satThroughputMbps = 0;

      // Cluster users into active steerable beams
      const numBeams = Math.min(users.length, sat.maxBeams);
      const usersPerBeam = Math.ceil(users.length / Math.max(1, numBeams));

      for (let b = 0; b < numBeams; b++) {
        const beamUsers = users.slice(b * usersPerBeam, (b + 1) * usersPerBeam);
        if (!beamUsers.length) continue;

        // Beam center is center of mass of assigned users
        const avgLat = beamUsers.reduce((sum, u) => sum + u.lat, 0) / beamUsers.length;
        const avgLon = beamUsers.reduce((sum, u) => sum + u.lon, 0) / beamUsers.length;
        const beamDemandMbps = beamUsers.reduce((sum, u) => sum + u.demandMbps, 0);

        const beamUtilPct = Number(((beamDemandMbps / maxBeamCapacityMbps) * 100).toFixed(1));
        const status: BeamState['status'] = beamUtilPct > 95 ? 'CONGESTED' : 'ACTIVE';

        const beam: BeamState = {
          id: `BEAM-${sat.id}-B${(b + 1).toString().padStart(2, '0')}`,
          beamIndex: b + 1,
          satId: sat.id,
          centerLat: Number(avgLat.toFixed(3)),
          centerLon: Number(avgLon.toFixed(3)),
          radiusKm: beamRadiusKm,
          allocatedCapacityMbps: maxBeamCapacityMbps,
          usedCapacityMbps: Number(beamDemandMbps.toFixed(1)),
          utilizationPct: beamUtilPct,
          userCount: beamUsers.length,
          status
        };

        sat.activeBeams.push(beam);
        satThroughputMbps += Math.min(beamDemandMbps, maxBeamCapacityMbps);

        // Distribute allocated throughput to users
        const allocationRatio = Math.min(1.0, maxBeamCapacityMbps / Math.max(1, beamDemandMbps));
        beamUsers.forEach(u => {
          u.activeBeamId = beam.id;
          u.allocatedThroughputMbps = Number((u.demandMbps * allocationRatio).toFixed(1));
        });
      }

      sat.activeBeamsCount = sat.activeBeams.length;
      sat.throughputGbps = Number(((satThroughputMbps / 1000.0) + (sat.activeLinks.length * 0.85)).toFixed(2));
      const satUtil = (sat.throughputGbps / sat.downlinkCapacityGbps) * 100;
      sat.utilizationPct = Number(Math.min(100, satUtil).toFixed(1));

      sat.congestionState = this.classifyCongestion(sat.utilizationPct);

      // Historical utilization sparkline buffer (keep last 12 points)
      sat.historyUtil.push(sat.utilizationPct);
      if (sat.historyUtil.length > 15) sat.historyUtil.shift();
    }

    // 3. Ground Station Feeder Load
    for (const gs of groundStations) {
      if (gs.availability === 'OFFLINE') {
        gs.currentThroughputGbps = 0;
        gs.backhaulUtilizationPct = 0;
        continue;
      }

      // Find all satellites visible to ground station
      const visibleSats = satellites.filter(
        s => s.health !== 'OFFLINE' && OrbitPropagator.calculateAer(gs.lat, gs.lon, gs.altM, s, 10.0).visible
      );

      gs.connectedSats = visibleSats.map(s => s.id);
      gs.activeAntennas = Math.min(gs.antennaCount, visibleSats.length);

      // Feeder traffic aggregate
      const servedLoadGbps = visibleSats.reduce((sum, s) => sum + (s.throughputGbps * 0.35), 0);
      gs.currentThroughputGbps = Number(Math.min(gs.backhaulCapacityGbps, servedLoadGbps).toFixed(2));
      gs.backhaulUtilizationPct = Number(((gs.currentThroughputGbps / gs.backhaulCapacityGbps) * 100).toFixed(1));
    }
  }

  private static classifyCongestion(utilPct: number): CongestionState {
    if (utilPct < 55) return 'NORMAL';
    if (utilPct < 75) return 'BUSY';
    if (utilPct < 90) return 'CONGESTED';
    return 'SATURATED';
  }
}
