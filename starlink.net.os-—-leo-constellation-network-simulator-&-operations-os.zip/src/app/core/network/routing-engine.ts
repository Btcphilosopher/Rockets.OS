// STARLINK.NET.OS — Dynamic Constellation Graph & Multi-Criteria Dijkstra Routing Engine
// Implements full graph representation, shortest path solving, ISL cross-links, and mathematical latency provenance

import {
  GroundStation,
  ISLLink,
  LatencyBreakdown,
  RoutingPath,
  RoutingPolicy,
  Satellite,
  UserTerminal
} from '../models/types';
import { OrbitPropagator, SPEED_OF_LIGHT_KM_S } from '../physics/orbit-propagator';

interface GraphEdge {
  targetId: string;
  targetType: 'TERMINAL' | 'SATELLITE' | 'GROUND_STATION' | 'INTERNET';
  distanceKm: number;
  capacityMbps: number;
  currentTrafficMbps: number;
  weight: number;
  propagationMs: number;
  isFiber: boolean;
}

export class RoutingEngine {
  private static readonly TERRESTRIAL_FIBER_SPEED_KM_S = 204100.0; // Index of refraction n = 1.468 in silica glass

  /**
   * Computes optimal dynamic route for a user terminal to the nearest global internet backbone
   */
  static computeRouteForTerminal(
    terminal: UserTerminal,
    satellites: Satellite[],
    groundStations: GroundStation[],
    islLinks: ISLLink[],
    policy: RoutingPolicy
  ): RoutingPath | undefined {
    if (!terminal.connectedSatId || terminal.sessionState === 'DISCONNECTED') {
      return undefined;
    }

    const satMap = new Map<string, Satellite>();
    satellites.forEach(s => satMap.set(s.id, s));

    const gsMap = new Map<string, GroundStation>();
    groundStations.forEach(g => gsMap.set(g.id, g));

    const onlineGateways = groundStations.filter(g => g.availability === 'ONLINE');
    if (!onlineGateways.length) return undefined;

    // Build local routing adjacency list
    const adjacency = new Map<string, GraphEdge[]>();
    const addEdge = (u: string, edge: GraphEdge) => {
      const list = adjacency.get(u) || [];
      list.push(edge);
      adjacency.set(u, list);
    };

    // 1. Terminal -> Connected Satellite
    const connectedSat = satMap.get(terminal.connectedSatId);
    if (!connectedSat || connectedSat.health === 'OFFLINE') return undefined;

    const satDist = OrbitPropagator.ecefDistanceKm(
      terminal.lat ? OrbitPropagator.geodeticToEcef(terminal.lat, terminal.lon, terminal.altM)[0] : 0,
      terminal.lat ? OrbitPropagator.geodeticToEcef(terminal.lat, terminal.lon, terminal.altM)[1] : 0,
      terminal.lat ? OrbitPropagator.geodeticToEcef(terminal.lat, terminal.lon, terminal.altM)[2] : 0,
      connectedSat.ecefX,
      connectedSat.ecefY,
      connectedSat.ecefZ
    );

    const upPropMs = (satDist / SPEED_OF_LIGHT_KM_S) * 1000;
    addEdge(terminal.id, {
      targetId: connectedSat.id,
      targetType: 'SATELLITE',
      distanceKm: satDist,
      capacityMbps: connectedSat.downlinkCapacityGbps * 1000,
      currentTrafficMbps: connectedSat.throughputGbps * 1000,
      weight: upPropMs + 1.0,
      propagationMs: upPropMs,
      isFiber: false
    });

    // 2. ISL Laser links between satellites
    const activeIsls = islLinks.filter(l => l.status === 'ACTIVE');
    for (const link of activeIsls) {
      const dist = link.distanceKm;
      const propMs = (dist / SPEED_OF_LIGHT_KM_S) * 1000;

      // Policy weighting
      let linkWeight = propMs * policy.latencyWeight;
      if (policy.congestionWeight > 0) {
        linkWeight += (link.utilizationPct / 20.0) * policy.congestionWeight;
      }
      linkWeight += policy.hopWeight * 2.0;

      addEdge(link.sourceSatId, {
        targetId: link.targetSatId,
        targetType: 'SATELLITE',
        distanceKm: dist,
        capacityMbps: link.capacityGbps * 1000,
        currentTrafficMbps: link.currentLoadGbps * 1000,
        weight: linkWeight,
        propagationMs: propMs,
        isFiber: false
      });

      addEdge(link.targetSatId, {
        targetId: link.sourceSatId,
        targetType: 'SATELLITE',
        distanceKm: dist,
        capacityMbps: link.capacityGbps * 1000,
        currentTrafficMbps: link.currentLoadGbps * 1000,
        weight: linkWeight,
        propagationMs: propMs,
        isFiber: false
      });
    }

    // 3. Satellite -> Ground Station Feeder Links (Elevation >= 10 deg)
    for (const gs of onlineGateways) {
      for (const sat of satellites) {
        if (sat.health === 'OFFLINE') continue;

        const aer = OrbitPropagator.calculateAer(gs.lat, gs.lon, gs.altM, sat, 10.0);
        if (aer.visible) {
          const downPropMs = (aer.rangeKm / SPEED_OF_LIGHT_KM_S) * 1000;
          let weight = downPropMs * policy.latencyWeight;
          weight += (gs.backhaulUtilizationPct / 25.0) * policy.congestionWeight;
          weight += policy.hopWeight * 1.5;

          addEdge(sat.id, {
            targetId: gs.id,
            targetType: 'GROUND_STATION',
            distanceKm: aer.rangeKm,
            capacityMbps: gs.downlinkCapacityGbps * 1000,
            currentTrafficMbps: gs.currentThroughputGbps * 1000,
            weight,
            propagationMs: downPropMs,
            isFiber: false
          });
        }
      }

      // Ground Station -> Core Internet
      const corePropMs = gs.latencyToCoreMs;
      addEdge(gs.id, {
        targetId: `CORE-${gs.id}`,
        targetType: 'INTERNET',
        distanceKm: corePropMs * (this.TERRESTRIAL_FIBER_SPEED_KM_S / 1000.0),
        capacityMbps: gs.backhaulCapacityGbps * 1000,
        currentTrafficMbps: gs.currentThroughputGbps * 1000,
        weight: corePropMs * policy.latencyWeight,
        propagationMs: corePropMs,
        isFiber: true
      });
    }

    // Run Dijkstra algorithm from terminal.id to find shortest path to any INTERNET node
    const distances = new Map<string, number>();
    const previous = new Map<string, { nodeId: string; edge: GraphEdge }>();
    const unvisited = new Set<string>();

    distances.set(terminal.id, 0);
    unvisited.add(terminal.id);

    satellites.forEach(s => unvisited.add(s.id));
    groundStations.forEach(g => {
      unvisited.add(g.id);
      unvisited.add(`CORE-${g.id}`);
    });

    let bestDestCoreId: string | null = null;

    while (unvisited.size > 0) {
      // Find node with minimum distance
      let currentId: string | null = null;
      let currentDist = Infinity;

      for (const node of unvisited) {
        const d = distances.get(node) ?? Infinity;
        if (d < currentDist) {
          currentDist = d;
          currentId = node;
        }
      }

      if (!currentId || currentDist === Infinity) break;
      unvisited.delete(currentId);

      if (currentId.startsWith('CORE-')) {
        bestDestCoreId = currentId;
        break; // Reached nearest internet gateway
      }

      const neighbors = adjacency.get(currentId) || [];
      for (const edge of neighbors) {
        if (!unvisited.has(edge.targetId)) continue;
        const newDist = currentDist + edge.weight;
        const existingDist = distances.get(edge.targetId) ?? Infinity;

        if (newDist < existingDist) {
          distances.set(edge.targetId, newDist);
          previous.set(edge.targetId, { nodeId: currentId, edge });
        }
      }
    }

    if (!bestDestCoreId || !previous.has(bestDestCoreId)) {
      return undefined; // No available path to internet core
    }

    // Reconstruct path
    const hops: string[] = [];
    const hopTypes: ('TERMINAL' | 'SATELLITE' | 'GROUND_STATION' | 'INTERNET')[] = [];
    const hopCoords: { lat: number; lon: number; altKm: number }[] = [];
    const hopEdges: GraphEdge[] = [];

    let curr: string | null = bestDestCoreId;
    while (curr) {
      hops.unshift(curr);
      const prevInfo = previous.get(curr);
      if (prevInfo) {
        hopEdges.unshift(prevInfo.edge);
        curr = prevInfo.nodeId;
      } else {
        curr = null;
      }
    }

    // Extract hop coordinates and types
    let totalDistKm = 0;
    let totalPropMs = 0;
    let minCapacityMbps = Infinity;

    for (let i = 0; i < hops.length; i++) {
      const hopId = hops[i];
      if (hopId === terminal.id) {
        hopTypes.push('TERMINAL');
        hopCoords.push({ lat: terminal.lat, lon: terminal.lon, altKm: terminal.altM / 1000 });
      } else if (satMap.has(hopId)) {
        const sat = satMap.get(hopId)!;
        hopTypes.push('SATELLITE');
        hopCoords.push({ lat: sat.lat, lon: sat.lon, altKm: sat.altKm });
      } else if (gsMap.has(hopId)) {
        const gs = gsMap.get(hopId)!;
        hopTypes.push('GROUND_STATION');
        hopCoords.push({ lat: gs.lat, lon: gs.lon, altKm: gs.altM / 1000 });
        terminal.groundStationId = gs.id;
      } else if (hopId.startsWith('CORE-')) {
        const gsId = hopId.replace('CORE-', '');
        const gs = gsMap.get(gsId);
        hopTypes.push('INTERNET');
        hopCoords.push({ lat: gs ? gs.lat : 0, lon: gs ? gs.lon : 0, altKm: 0 });
      }

      if (i < hopEdges.length) {
        const edge = hopEdges[i];
        totalDistKm += edge.distanceKm;
        totalPropMs += edge.propagationMs;
        if (edge.capacityMbps < minCapacityMbps) {
          minCapacityMbps = edge.capacityMbps;
        }
      }
    }

    // Latency Model Provenance Breakdown
    const hopCount = hops.length - 1;
    const routingDelayMs = Number((hopCount * 0.14).toFixed(2)); // 140us per switch lookup
    const queueingDelayMs = Number((Math.min(12.0, (hopCount * 0.45) * (1 + (terminal.demandMbps / 500.0)))).toFixed(2));
    const processingDelayMs = Number((hopCount * 0.08).toFixed(2)); // 80us RF FEC modem processing
    const totalLatencyMs = Number((totalPropMs + routingDelayMs + queueingDelayMs + processingDelayMs).toFixed(2));

    const breakdown: LatencyBreakdown = {
      propagationMs: Number(totalPropMs.toFixed(2)),
      routingMs: routingDelayMs,
      queueingMs: queueingDelayMs,
      processingMs: processingDelayMs,
      totalMs: totalLatencyMs,
      provenance: {
        hopDistancesKm: hopEdges.map(e => Number(e.distanceKm.toFixed(1))),
        speedOfLightKmS: SPEED_OF_LIGHT_KM_S,
        hopCount,
        switchQueueLoadPct: Math.round((queueingDelayMs / 12.0) * 100),
        perHopProcessingMs: 0.08
      }
    };

    const targetGsId = bestDestCoreId.replace('CORE-', '');
    const gsName = gsMap.get(targetGsId)?.name || 'Regional Internet Core';

    const route: RoutingPath = {
      id: `ROUTE-${terminal.id}-${Date.now().toString(36)}`,
      sourceTerminalId: terminal.id,
      destinationCoreId: bestDestCoreId,
      sourceName: terminal.name,
      destinationName: gsName,
      hops,
      hopTypes,
      hopCoords,
      totalDistanceKm: Number(totalDistKm.toFixed(1)),
      latencyBreakdown: breakdown,
      bottleneckCapacityMbps: minCapacityMbps === Infinity ? 500 : Number(minCapacityMbps.toFixed(0)),
      currentTrafficMbps: terminal.demandMbps,
      status: totalLatencyMs > 65 ? 'CONGESTED' : 'OPTIMAL'
    };

    terminal.latencyMs = totalLatencyMs;
    terminal.route = route;
    return route;
  }
}
