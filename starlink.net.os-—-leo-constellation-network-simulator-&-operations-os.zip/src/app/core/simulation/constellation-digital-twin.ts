// STARLINK.NET.OS — Central Constellation Digital Twin Simulation Engine
// Maintains high-fidelity dynamic network graph, time-stepping, failure injection, event bus, and telemetry

import {
  CapacityPlanResult,
  ConstellationConfig,
  ConstellationMetrics,
  FailureScenarioConfig,
  GroundStation,
  ISLLink,
  RoutingPath,
  RoutingPolicy,
  Satellite,
  SimEvent,
  UserTerminal
} from '../models/types';
import { SYNTHETIC_GROUND_STATIONS, SYNTHETIC_USER_TERMINALS } from '../data/synthetic-dataset';
import { CongestionEngine } from '../network/congestion-engine';
import { HandoverEngine } from '../network/handover-engine';
import { IslMeshManager } from '../network/isl-mesh';
import { RoutingEngine } from '../network/routing-engine';
import { OrbitPropagator } from '../physics/orbit-propagator';

export const CONSTELLATION_PRESETS: Record<string, ConstellationConfig> = {
  small_demo: {
    name: 'Small Demo Constellation',
    satellites: 120,
    orbitalPlanes: 8,
    satellitesPerPlane: 15,
    altitudeKm: 550,
    inclinationDeg: 53.0,
    phaseOffsetDeg: 12.0,
    fParam: 1,
    beamCountPerSat: 12,
    beamRadiusKm: 36,
    beamCapacityMbps: 650,
    satCapacityGbps: 20,
    islBandwidthGbps: 100,
    maxIslRangeKm: 5014,
    minElevationDeg: 25.0,
    timeStepSec: 5,
    seed: 42
  },
  regional: {
    name: 'Regional / National Coverage',
    satellites: 300,
    orbitalPlanes: 15,
    satellitesPerPlane: 20,
    altitudeKm: 540,
    inclinationDeg: 53.2,
    phaseOffsetDeg: 8.0,
    fParam: 1,
    beamCountPerSat: 16,
    beamRadiusKm: 32,
    beamCapacityMbps: 750,
    satCapacityGbps: 24,
    islBandwidthGbps: 100,
    maxIslRangeKm: 5014,
    minElevationDeg: 25.0,
    timeStepSec: 5,
    seed: 101
  },
  global: {
    name: 'Global Baseline Constellation',
    satellites: 500,
    orbitalPlanes: 20,
    satellitesPerPlane: 25,
    altitudeKm: 550,
    inclinationDeg: 53.0,
    phaseOffsetDeg: 5.0,
    fParam: 1,
    beamCountPerSat: 16,
    beamRadiusKm: 30,
    beamCapacityMbps: 850,
    satCapacityGbps: 30,
    islBandwidthGbps: 100,
    maxIslRangeKm: 5014,
    minElevationDeg: 25.0,
    timeStepSec: 5,
    seed: 2026
  },
  large_constellation: {
    name: 'Large Mega-Constellation',
    satellites: 1200,
    orbitalPlanes: 30,
    satellitesPerPlane: 40,
    altitudeKm: 530,
    inclinationDeg: 53.0,
    phaseOffsetDeg: 3.0,
    fParam: 1,
    beamCountPerSat: 24,
    beamRadiusKm: 24,
    beamCapacityMbps: 1000,
    satCapacityGbps: 40,
    islBandwidthGbps: 150,
    maxIslRangeKm: 4800,
    minElevationDeg: 25.0,
    timeStepSec: 5,
    seed: 9999
  }
};

export class ConstellationDigitalTwin {
  public config: ConstellationConfig;
  public simTimeSec = 0;
  public isRunning = false;
  public speedMultiplier = 1;

  public satellites: Satellite[] = [];
  public groundStations: GroundStation[] = [];
  public terminals: UserTerminal[] = [];
  public islLinks: ISLLink[] = [];
  public activeRoutes: RoutingPath[] = [];

  public activeScenario: FailureScenarioConfig | null = null;
  public routingPolicy: RoutingPolicy = {
    name: 'SHORTEST_LATENCY',
    latencyWeight: 0.6,
    congestionWeight: 0.3,
    hopWeight: 0.1
  };

  public events: SimEvent[] = [];
  public metricsHistory: ConstellationMetrics[] = [];
  public currentMetrics: ConstellationMetrics;

  private eventListeners: ((event: SimEvent) => void)[] = [];

  constructor(initialPreset = 'global') {
    this.config = JSON.parse(JSON.stringify(CONSTELLATION_PRESETS[initialPreset] || CONSTELLATION_PRESETS['global']));
    this.currentMetrics = this.getInitialMetrics();
    this.initializeConstellation();
  }

  public subscribeEvents(cb: (event: SimEvent) => void): () => void {
    this.eventListeners.push(cb);
    return () => {
      this.eventListeners = this.eventListeners.filter(l => l !== cb);
    };
  }

  private emitEvent(event: SimEvent): void {
    this.events.unshift(event);
    if (this.events.length > 200) this.events.pop();
    this.eventListeners.forEach(listener => {
      try {
        listener(event);
      } catch (err) {
        console.error('Event listener error:', err);
      }
    });
  }

  public initializeConstellation(): void {
    this.simTimeSec = 0;
    this.satellites = OrbitPropagator.generateConstellation(this.config);
    this.groundStations = JSON.parse(JSON.stringify(SYNTHETIC_GROUND_STATIONS));
    this.terminals = JSON.parse(JSON.stringify(SYNTHETIC_USER_TERMINALS));
    this.islLinks = IslMeshManager.buildTopology(this.satellites, this.config);
    this.events = [];
    this.metricsHistory = [];

    this.emitEvent({
      id: `EVT-INIT-${Date.now()}`,
      timestamp: Date.now(),
      simTimeFormatted: 'T+00:00:00',
      type: 'SatelliteAdded',
      severity: 'SUCCESS',
      message: `Digital Twin initialized with ${this.satellites.length} satellites, ${this.groundStations.length} ground stations, ${this.terminals.length} terminals.`,
      entityId: 'SYSTEM'
    });

    // Run first step to settle initial network state
    this.advanceSimulation(0);
  }

  /**
   * Advances simulation by `deltaSec` seconds
   */
  public advanceSimulation(deltaSec: number = this.config.timeStepSec): void {
    this.simTimeSec += deltaSec;

    // 1. Check & execute active scenario effects
    this.processActiveScenario();

    // 2. Propagate all satellite orbital positions
    for (const sat of this.satellites) {
      OrbitPropagator.propagateSatellite(sat, this.simTimeSec);
    }

    // 3. Update moving mobile terminals (Aircraft, Ships)
    this.updateMobileTerminals(deltaSec);

    // 4. Update Inter-Satellite Optical Links
    this.islLinks = IslMeshManager.buildTopology(this.satellites, this.config);

    // 5. Evaluate Phased-Array Handovers
    HandoverEngine.processTerminalHandovers(
      this.terminals,
      this.satellites,
      this.config.minElevationDeg,
      this.simTimeSec,
      deltaSec,
      evt => this.emitEvent(evt)
    );

    // 6. Update Diurnal Congestion & Spot Beams
    const surgeParam = this.activeScenario?.category === 'TRAFFIC_SURGE' ? this.activeScenario.surgeLocation : undefined;
    CongestionEngine.updateConstellationCongestion(
      this.satellites,
      this.terminals,
      this.groundStations,
      this.config,
      this.simTimeSec,
      surgeParam
    );

    // 7. Compute dynamic routes for all connected terminals
    this.activeRoutes = [];
    for (const term of this.terminals) {
      const route = RoutingEngine.computeRouteForTerminal(
        term,
        this.satellites,
        this.groundStations,
        this.islLinks,
        this.routingPolicy
      );
      if (route) {
        this.activeRoutes.push(route);
      }
    }

    // 8. Recompute network-wide statistical metrics
    this.calculateMetrics();
  }

  private updateMobileTerminals(deltaSec: number): void {
    for (const term of this.terminals) {
      if (term.speedKmH && term.headingDeg !== undefined) {
        // Distance traveled in deltaSec: km = speedKmH * (deltaSec / 3600)
        const distKm = term.speedKmH * (deltaSec / 3600.0);
        const headingRad = (term.headingDeg * Math.PI) / 180;

        // Approx coordinate shift (1 deg lat ~ 111 km)
        const dLat = (distKm * Math.cos(headingRad)) / 111.0;
        const dLon = (distKm * Math.sin(headingRad)) / (111.0 * Math.cos((term.lat * Math.PI) / 180));

        term.lat = Number((term.lat + dLat).toFixed(4));
        term.lon = Number((term.lon + dLon).toFixed(4));

        // Wrap longitude
        if (term.lon > 180) term.lon -= 360;
        if (term.lon < -180) term.lon += 360;
      }
    }
  }

  private processActiveScenario(): void {
    if (!this.activeScenario) return;

    const elapsed = this.simTimeSec - this.activeScenario.startTimeSec;
    if (elapsed < 0) return;

    if (elapsed > this.activeScenario.durationSec) {
      // Scenario expired: restore healthy state
      this.emitEvent({
        id: `EVT-SCEN-END-${this.simTimeSec}`,
        timestamp: Date.now(),
        simTimeFormatted: this.formatSimTime(this.simTimeSec),
        type: 'SatelliteRecovered',
        severity: 'SUCCESS',
        message: `Scenario "${this.activeScenario.name}" concluded. All systems returning to nominal state.`,
        entityId: 'SCENARIO_ENGINE'
      });

      // Restore failed entities
      if (this.activeScenario.category === 'SATELLITE_FAILURE') {
        const sat = this.satellites.find(s => s.id === this.activeScenario!.targetEntityId);
        if (sat) sat.health = 'NOMINAL';
      } else if (this.activeScenario.category === 'GROUND_STATION_FAILURE') {
        const gs = this.groundStations.find(g => g.id === this.activeScenario!.targetEntityId);
        if (gs) gs.availability = 'ONLINE';
      } else if (this.activeScenario.category === 'CLUSTER_OUTAGE') {
        this.satellites.filter(s => s.planeIndex === 3 && s.satIndexInPlane < 4).forEach(s => (s.health = 'NOMINAL'));
      }

      this.activeScenario = null;
      return;
    }

    // Apply active fault
    if (this.activeScenario.category === 'SATELLITE_FAILURE' && this.activeScenario.targetEntityId) {
      const sat = this.satellites.find(s => s.id === this.activeScenario!.targetEntityId);
      if (sat && sat.health !== 'OFFLINE') {
        sat.health = 'OFFLINE';
        this.emitEvent({
          id: `EVT-FAIL-SAT-${this.simTimeSec}`,
          timestamp: Date.now(),
          simTimeFormatted: this.formatSimTime(this.simTimeSec),
          type: 'SatelliteLost',
          severity: 'CRITICAL',
          message: `Injected critical failure on ${sat.id}: Power bus loss, satellite offline. Traffic rerouting over ISL mesh.`,
          entityId: sat.id
        });
      }
    } else if (this.activeScenario.category === 'GROUND_STATION_FAILURE' && this.activeScenario.targetEntityId) {
      const gs = this.groundStations.find(g => g.id === this.activeScenario!.targetEntityId);
      if (gs && gs.availability !== 'OFFLINE') {
        gs.availability = 'OFFLINE';
        this.emitEvent({
          id: `EVT-FAIL-GS-${this.simTimeSec}`,
          timestamp: Date.now(),
          simTimeFormatted: this.formatSimTime(this.simTimeSec),
          type: 'GroundStationLost',
          severity: 'CRITICAL',
          message: `Injected terrestrial backhaul failure at ${gs.name} (${gs.id}). Traffic redirecting to alternate gateways.`,
          entityId: gs.id
        });
      }
    } else if (this.activeScenario.category === 'CLUSTER_OUTAGE') {
      const clusterSats = this.satellites.filter(s => s.planeIndex === 3 && s.satIndexInPlane < 4);
      clusterSats.forEach(s => {
        if (s.health !== 'OFFLINE') s.health = 'OFFLINE';
      });
    }
  }

  public setScenario(scenario: FailureScenarioConfig | null): void {
    this.activeScenario = scenario ? { ...scenario, startTimeSec: this.simTimeSec } : null;
    if (scenario) {
      this.emitEvent({
        id: `EVT-SCEN-START-${this.simTimeSec}`,
        timestamp: Date.now(),
        simTimeFormatted: this.formatSimTime(this.simTimeSec),
        type: 'FailureInjected',
        severity: 'WARNING',
        message: `Activated Scenario: "${scenario.name}". Duration: ${Math.round(scenario.durationSec / 60)} min.`,
        entityId: 'SCENARIO_ENGINE'
      });
    }
  }

  public setRoutingPolicy(policy: RoutingPolicy): void {
    this.routingPolicy = policy;
    this.emitEvent({
      id: `EVT-POLICY-${this.simTimeSec}`,
      timestamp: Date.now(),
      simTimeFormatted: this.formatSimTime(this.simTimeSec),
      type: 'RouteChanged',
      severity: 'INFO',
      message: `Routing policy updated to: ${policy.name} (Latency: ${policy.latencyWeight}, Congestion: ${policy.congestionWeight}, Hops: ${policy.hopWeight}).`,
      entityId: 'ROUTER'
    });
    this.advanceSimulation(0);
  }

  public changeConstellationPreset(presetKey: string): void {
    const p = CONSTELLATION_PRESETS[presetKey];
    if (p) {
      this.config = JSON.parse(JSON.stringify(p));
      this.initializeConstellation();
    }
  }

  public calculateCoveragePercentage(): number {
    // Spatial grid sampling (every 10 deg lat x 15 deg lon between -60 and +60 deg)
    let totalSamples = 0;
    let coveredSamples = 0;
    const onlineSats = this.satellites.filter(s => s.health !== 'OFFLINE');

    for (let lat = -55; lat <= 55; lat += 10) {
      for (let lon = -180; lon < 180; lon += 15) {
        totalSamples++;
        let isCovered = false;
        for (const sat of onlineSats) {
          if (Math.abs(sat.lat - lat) < 22) {
            const aer = OrbitPropagator.calculateAer(lat, lon, 0, sat, this.config.minElevationDeg);
            if (aer.visible) {
              isCovered = true;
              break;
            }
          }
        }
        if (isCovered) coveredSamples++;
      }
    }

    return Number(((coveredSamples / totalSamples) * 100).toFixed(1));
  }

  private calculateMetrics(): void {
    const totalSats = this.satellites.length;
    const onlineSats = this.satellites.filter(s => s.health === 'NOMINAL').length;
    const degradedSats = this.satellites.filter(s => s.health === 'DEGRADED').length;
    const offlineSats = this.satellites.filter(s => s.health === 'OFFLINE').length;

    const totalGs = this.groundStations.length;
    const onlineGs = this.groundStations.filter(g => g.availability === 'ONLINE').length;

    const totalUsers = this.terminals.length;
    const connectedUsers = this.terminals.filter(t => t.sessionState === 'CONNECTED').length;

    const globalThroughputGbps = Number(
      this.satellites.reduce((sum, s) => sum + s.throughputGbps, 0).toFixed(2)
    );

    const utils = this.satellites.map(s => s.utilizationPct);
    const meanUtil = utils.length ? utils.reduce((a, b) => a + b, 0) / utils.length : 0;
    const peakUtil = utils.length ? Math.max(...utils) : 0;

    const latencies = this.terminals
      .filter(t => t.sessionState === 'CONNECTED' && t.latencyMs > 0 && t.latencyMs < 500)
      .map(t => t.latencyMs)
      .sort((a, b) => a - b);

    const avgLatency = latencies.length ? latencies.reduce((a, b) => a + b, 0) / latencies.length : 32.5;
    const p50 = latencies.length ? latencies[Math.floor(latencies.length * 0.5)] : 31.0;
    const p95 = latencies.length ? latencies[Math.floor(latencies.length * 0.95)] : 48.0;
    const p99 = latencies.length ? latencies[Math.floor(latencies.length * 0.99)] : 62.0;

    const activeHandoversCount = this.terminals.filter(t => t.sessionState === 'HANDOVER').length;
    const totalHandoversCompleted = this.satellites.reduce((sum, s) => sum + (s.handoverCount || 0), 0);
    const activeIsls = this.islLinks.filter(l => l.status === 'ACTIVE').length;

    let congestedBeams = 0;
    this.satellites.forEach(s => {
      congestedBeams += s.activeBeams.filter(b => b.status === 'CONGESTED').length;
    });

    const coveragePct = this.calculateCoveragePercentage();

    const metrics: ConstellationMetrics = {
      timestamp: Date.now(),
      simTimeSec: this.simTimeSec,
      simTimeFormatted: this.formatSimTime(this.simTimeSec),
      totalSatellites: totalSats,
      onlineSatellites: onlineSats,
      degradedSatellites: degradedSats,
      offlineSatellites: offlineSats,
      totalGroundStations: totalGs,
      onlineGroundStations: onlineGs,
      totalUsers,
      connectedUsers,
      globalThroughputGbps,
      meanUtilizationPct: Number(meanUtil.toFixed(1)),
      peakUtilizationPct: Number(peakUtil.toFixed(1)),
      activeHandoversCount,
      totalHandoversCompleted,
      avgLatencyMs: Number(avgLatency.toFixed(2)),
      p50LatencyMs: Number(p50.toFixed(2)),
      p95LatencyMs: Number(p95.toFixed(2)),
      p99LatencyMs: Number(p99.toFixed(2)),
      activeIslLinks: activeIsls,
      congestedBeamsCount: congestedBeams,
      globalCoveragePct: coveragePct,
      packetLossEstPct: Number((0.04 + Math.random() * 0.02).toFixed(3))
    };

    this.currentMetrics = metrics;
    this.metricsHistory.push(metrics);
    if (this.metricsHistory.length > 100) this.metricsHistory.shift();
  }

  public runCapacityPlanning(
    regionName: string,
    population: number,
    annualGrowthRatePct = 25.0
  ): CapacityPlanResult {
    const regionalUsers = this.terminals.filter(t => t.name.toLowerCase().includes(regionName.toLowerCase()));
    const curDemandGbps = regionalUsers.reduce((sum, u) => sum + u.demandMbps, 0) / 1000.0 || (population * 0.0004);
    const projDemandGbps = curDemandGbps * (1 + annualGrowthRatePct / 100.0);

    const regionalGs = this.groundStations.filter(g => g.region.toLowerCase().includes(regionName.toLowerCase()));
    const gsCapacityGbps = regionalGs.reduce((sum, g) => sum + g.backhaulCapacityGbps, 0) || 350.0;

    const visibleSatsAvg = Number((this.satellites.length * 0.032).toFixed(1));
    const simultaneousCapGbps = Number((visibleSatsAvg * this.config.satCapacityGbps * 0.65).toFixed(1));

    const capacityDeficit = Math.max(0, projDemandGbps - Math.min(simultaneousCapGbps, gsCapacityGbps));
    const satBottleneck = Math.max(0, projDemandGbps - simultaneousCapGbps);
    const gsBottleneck = Math.max(0, projDemandGbps - gsCapacityGbps);

    const recSatsInc = satBottleneck > 0 ? Math.ceil(satBottleneck / (this.config.satCapacityGbps * 0.5)) : 0;
    const recGsInc = gsBottleneck > 0 ? Math.ceil(gsBottleneck / 400.0) : 0;

    return {
      region: regionName,
      population,
      currentDemandGbps: Number(curDemandGbps.toFixed(2)),
      projectedDemandGbps: Number(projDemandGbps.toFixed(2)),
      visibleSatsAvg,
      simultaneousCapacityGbps: simultaneousCapGbps,
      groundStationCapacityGbps: gsCapacityGbps,
      satelliteBottleneckGbps: Number(satBottleneck.toFixed(2)),
      groundStationBottleneckGbps: Number(gsBottleneck.toFixed(2)),
      capacityDeficitGbps: Number(capacityDeficit.toFixed(2)),
      coverageContinuityPct: 99.4,
      recommendedSatsIncrease: recSatsInc,
      recommendedNewGroundStations: recGsInc,
      provenanceSummary: `Derived from ${this.satellites.length}-sat Walker lattice (${this.config.altitudeKm}km, ${this.config.inclinationDeg}°) over ${population.toLocaleString()} regional pop density.`
    };
  }

  public exportParquetReadyDataset(): string {
    const payload = {
      schema: 'STARLINK_NET_OS_TELEMETRY_V1',
      generatedAt: new Date().toISOString(),
      constellationConfig: this.config,
      metricsTimeseries: this.metricsHistory,
      satellites: this.satellites.map(s => ({
        id: s.id,
        plane: s.planeIndex,
        lat: s.lat,
        lon: s.lon,
        altKm: s.altKm,
        throughputGbps: s.throughputGbps,
        utilizationPct: s.utilizationPct,
        health: s.health
      })),
      terminals: this.terminals.map(t => ({
        id: t.id,
        name: t.name,
        connectedSatId: t.connectedSatId,
        elevationDeg: t.elevationDeg,
        latencyMs: t.latencyMs,
        demandMbps: t.demandMbps
      }))
    };
    return JSON.stringify(payload, null, 2);
  }

  public formatSimTime(sec: number): string {
    const hrs = Math.floor(sec / 3600);
    const mins = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    return `T+${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }

  private getInitialMetrics(): ConstellationMetrics {
    return {
      timestamp: Date.now(),
      simTimeSec: 0,
      simTimeFormatted: 'T+00:00:00',
      totalSatellites: 500,
      onlineSatellites: 500,
      degradedSatellites: 0,
      offlineSatellites: 0,
      totalGroundStations: 20,
      onlineGroundStations: 20,
      totalUsers: 14,
      connectedUsers: 14,
      globalThroughputGbps: 1850.4,
      meanUtilizationPct: 24.8,
      peakUtilizationPct: 62.4,
      activeHandoversCount: 0,
      totalHandoversCompleted: 0,
      avgLatencyMs: 32.4,
      p50LatencyMs: 29.8,
      p95LatencyMs: 48.2,
      p99LatencyMs: 64.0,
      activeIslLinks: 980,
      congestedBeamsCount: 0,
      globalCoveragePct: 96.8,
      packetLossEstPct: 0.042
    };
  }
}
