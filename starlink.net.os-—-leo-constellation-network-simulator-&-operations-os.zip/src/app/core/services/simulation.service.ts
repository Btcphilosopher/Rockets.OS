// STARLINK.NET.OS — Client Simulation Service & Reactive Signal Store
// Manages real-time RAF loop, digital twin state, object inspection, scenario orchestration, and CLI engine

import { Injectable, PLATFORM_ID, computed, inject, signal } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import {
  CapacityPlanResult,
  ConstellationConfig,
  ConstellationMetrics,
  FailureScenarioConfig,
  GroundStation,
  ISLLink,
  MapProjection,
  RoutingPath,
  RoutingPolicy,
  Satellite,
  SimEvent,
  UserTerminal
} from '../models/types';
import { SYNTHETIC_SCENARIOS } from '../data/synthetic-dataset';
import { CONSTELLATION_PRESETS, ConstellationDigitalTwin } from '../simulation/constellation-digital-twin';

export interface CliCommandResult {
  command: string;
  timestamp: string;
  output: string;
  isError?: boolean;
  tableData?: Record<string, unknown>[];
}

@Injectable({
  providedIn: 'root'
})
export class SimulationService {
  private platformId = inject(PLATFORM_ID);
  private isBrowser = isPlatformBrowser(this.platformId);

  private twin: ConstellationDigitalTwin;
  private animFrameId: number | null = null;
  private lastRafTime = 0;
  private accumulatorSec = 0;


  // Signals
  public isPlaying = signal<boolean>(true);
  public playbackSpeed = signal<number>(1); // 1x, 5x, 20x, 60x
  public timeStepSec = signal<number>(5); // 1s, 5s, 10s, 30s, 60s, 300s
  public viewMode = signal<'MAP' | 'LAB' | 'CAPACITY' | 'ANALYTICS' | 'CLI'>('MAP');
  public mapProjection = signal<MapProjection>('EQUIRECTANGULAR');

  public simTimeFormatted = signal<string>('T+00:00:00');
  public simTimeSec = signal<number>(0);
  public config = signal<ConstellationConfig>(CONSTELLATION_PRESETS['global']);
  public currentMetrics = signal<ConstellationMetrics | null>(null);
  public metricsHistory = signal<ConstellationMetrics[]>([]);

  public satellites = signal<Satellite[]>([]);
  public groundStations = signal<GroundStation[]>([]);
  public terminals = signal<UserTerminal[]>([]);
  public islLinks = signal<ISLLink[]>([]);
  public activeRoutes = signal<RoutingPath[]>([]);
  public events = signal<SimEvent[]>([]);

  public activeScenario = signal<FailureScenarioConfig | null>(null);
  public routingPolicy = signal<RoutingPolicy>({
    name: 'SHORTEST_LATENCY',
    latencyWeight: 0.6,
    congestionWeight: 0.3,
    hopWeight: 0.1
  });

  public selectedObject = signal<{
    type: 'SATELLITE' | 'GROUND_STATION' | 'TERMINAL' | 'ROUTE';
    data: Satellite | GroundStation | UserTerminal | RoutingPath;
  } | null>(null);

  public selectedRoute = signal<RoutingPath | null>(null);

  public layers = signal({
    islLinks: true,
    spotBeams: true,
    groundTracks: true,
    groundStations: true,
    terminals: true,
    dayNight: true,
    coverageHeatmap: false
  });

  public scenarios = signal<typeof SYNTHETIC_SCENARIOS>(SYNTHETIC_SCENARIOS);
  public cliHistory = signal<CliCommandResult[]>([]);

  // Computed signals
  public onlineSatellitesCount = computed(() => this.satellites().filter(s => s.health !== 'OFFLINE').length);
  public activeIslCount = computed(() => this.islLinks().filter(l => l.status === 'ACTIVE').length);
  public activeHandoversCount = computed(() => this.terminals().filter(t => t.sessionState === 'HANDOVER').length);

  constructor() {
    this.twin = new ConstellationDigitalTwin('global');
    this.syncFromTwin();

    this.twin.subscribeEvents(evt => {
      this.events.update(list => [evt, ...list.slice(0, 150)]);
    });

    // Auto-select first terminal as default inspection target
    if (this.terminals().length > 0) {
      this.selectTerminal(this.terminals()[0].id);
    }

    this.startLoop();
  }

  private syncFromTwin(): void {
    this.config.set({ ...this.twin.config });
    this.simTimeSec.set(this.twin.simTimeSec);
    this.simTimeFormatted.set(this.twin.formatSimTime(this.twin.simTimeSec));
    this.satellites.set([...this.twin.satellites]);
    this.groundStations.set([...this.twin.groundStations]);
    this.terminals.set([...this.twin.terminals]);
    this.islLinks.set([...this.twin.islLinks]);
    this.activeRoutes.set([...this.twin.activeRoutes]);
    this.currentMetrics.set({ ...this.twin.currentMetrics });
    this.metricsHistory.set([...this.twin.metricsHistory]);
    this.activeScenario.set(this.twin.activeScenario);
    this.routingPolicy.set({ ...this.twin.routingPolicy });

    // Update inspected object reference if selected
    const sel = this.selectedObject();
    if (sel) {
      if (sel.type === 'SATELLITE') {
        const sat = this.satellites().find(s => s.id === sel.data.id);
        if (sat) this.selectedObject.set({ type: 'SATELLITE', data: sat });
      } else if (sel.type === 'GROUND_STATION') {
        const gs = this.groundStations().find(g => g.id === sel.data.id);
        if (gs) this.selectedObject.set({ type: 'GROUND_STATION', data: gs });
      } else if (sel.type === 'TERMINAL') {
        const term = this.terminals().find(t => t.id === sel.data.id);
        if (term) {
          this.selectedObject.set({ type: 'TERMINAL', data: term });
          this.selectedRoute.set(term.route || null);
        }
      }
    }
  }

  private startLoop(): void {
    if (!this.isBrowser || typeof window === 'undefined' || typeof requestAnimationFrame === 'undefined') {
      return;
    }

    const loop = (timestamp: number) => {
      if (!this.lastRafTime) this.lastRafTime = timestamp;
      const dt = (timestamp - this.lastRafTime) / 1000.0;
      this.lastRafTime = timestamp;

      if (this.isPlaying()) {
        const effectiveSimDt = dt * this.playbackSpeed();
        this.accumulatorSec += effectiveSimDt;

        const step = this.timeStepSec();
        if (this.accumulatorSec >= 1.0) {
          const stepsToRun = Math.min(5, Math.floor(this.accumulatorSec / step) || 1);
          for (let i = 0; i < stepsToRun; i++) {
            this.twin.advanceSimulation(step);
          }
          this.accumulatorSec = 0;
          this.syncFromTwin();
        }
      }

      this.animFrameId = requestAnimationFrame(loop);
    };

    this.animFrameId = requestAnimationFrame(loop);
  }

  public play(): void {
    this.isPlaying.set(true);
  }

  public pause(): void {
    this.isPlaying.set(false);
  }

  public togglePlay(): void {
    this.isPlaying.update(p => !p);
  }

  public stepForward(): void {
    this.isPlaying.set(false);
    this.twin.advanceSimulation(this.timeStepSec());
    this.syncFromTwin();
  }

  public setSpeed(speed: number): void {
    this.playbackSpeed.set(speed);
  }

  public setTimeStep(step: number): void {
    this.timeStepSec.set(step);
    this.twin.config.timeStepSec = step;
  }

  public setProjection(proj: MapProjection): void {
    this.mapProjection.set(proj);
  }

  public toggleLayer(key: keyof ReturnType<typeof this.layers>): void {
    this.layers.update(l => ({ ...l, [key]: !l[key] }));
  }

  public resetSimulation(presetKey = 'global'): void {
    this.twin.changeConstellationPreset(presetKey);
    this.syncFromTwin();
  }

  public selectSatellite(id: string): void {
    const sat = this.satellites().find(s => s.id === id);
    if (sat) {
      this.selectedObject.set({ type: 'SATELLITE', data: sat });
      this.selectedRoute.set(null);
    }
  }

  public selectGroundStation(id: string): void {
    const gs = this.groundStations().find(g => g.id === id);
    if (gs) {
      this.selectedObject.set({ type: 'GROUND_STATION', data: gs });
      this.selectedRoute.set(null);
    }
  }

  public selectTerminal(id: string): void {
    const term = this.terminals().find(t => t.id === id);
    if (term) {
      this.selectedObject.set({ type: 'TERMINAL', data: term });
      this.selectedRoute.set(term.route || null);
    }
  }

  public selectRoute(route: RoutingPath): void {
    this.selectedObject.set({ type: 'ROUTE', data: route });
    this.selectedRoute.set(route);
  }

  public clearSelection(): void {
    this.selectedObject.set(null);
    this.selectedRoute.set(null);
  }

  public triggerFailure(entityId: string): void {
    const sat = this.satellites().find(s => s.id === entityId);
    const gs = this.groundStations().find(g => g.id === entityId);

    if (sat) {
      sat.health = sat.health === 'OFFLINE' ? 'NOMINAL' : 'OFFLINE';
      this.twin.advanceSimulation(0);
      this.syncFromTwin();
    } else if (gs) {
      gs.availability = gs.availability === 'OFFLINE' ? 'ONLINE' : 'OFFLINE';
      this.twin.advanceSimulation(0);
      this.syncFromTwin();
    }
  }

  public activateScenario(code: string): void {
    const scen = SYNTHETIC_SCENARIOS.find(s => s.code === code);
    if (scen) {
      this.twin.setScenario(scen);
      this.syncFromTwin();
    }
  }

  public clearScenario(): void {
    this.twin.setScenario(null);
    this.syncFromTwin();
  }

  public setRoutingPolicy(policyName: RoutingPolicy['name']): void {
    let policy: RoutingPolicy;
    if (policyName === 'SHORTEST_LATENCY') {
      policy = { name: 'SHORTEST_LATENCY', latencyWeight: 0.9, congestionWeight: 0.05, hopWeight: 0.05 };
    } else if (policyName === 'MAX_CAPACITY') {
      policy = { name: 'MAX_CAPACITY', latencyWeight: 0.1, congestionWeight: 0.8, hopWeight: 0.1 };
    } else if (policyName === 'MIN_HOPS') {
      policy = { name: 'MIN_HOPS', latencyWeight: 0.2, congestionWeight: 0.1, hopWeight: 0.7 };
    } else {
      policy = { name: 'BALANCED_WEIGHTED', latencyWeight: 0.5, congestionWeight: 0.35, hopWeight: 0.15 };
    }
    this.twin.setRoutingPolicy(policy);
    this.syncFromTwin();
  }

  public runCapacityAnalysis(region: string, pop: number, growth: number): CapacityPlanResult {
    return this.twin.runCapacityPlanning(region, pop, growth);
  }

  public exportData(format: 'JSON' | 'CSV'): void {
    if (!this.isBrowser || typeof document === 'undefined') return;
    if (format === 'JSON') {
      const json = this.twin.exportParquetReadyDataset();
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `starlink_net_os_metrics_${Date.now()}.json`;
      a.click();
    } else {
      // CSV format
      const header = 'timestamp,simTimeSec,throughputGbps,meanUtilPct,activeHandovers,avgLatencyMs,p95LatencyMs,coveragePct\n';
      const rows = this.metricsHistory()
        .map(
          m =>
            `${m.timestamp},${m.simTimeSec},${m.globalThroughputGbps},${m.meanUtilizationPct},${m.activeHandoversCount},${m.avgLatencyMs},${m.p95LatencyMs},${m.globalCoveragePct}`
        )
        .join('\n');
      const blob = new Blob([header + rows], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `starlink_net_os_telemetry_${Date.now()}.csv`;
      a.click();
    }
  }

  public executeCli(cmdInput: string): void {
    const trimmed = cmdInput.trim();
    if (!trimmed) return;

    const parts = trimmed.split(/\s+/);
    const root = parts[0].toLowerCase();
    const timeStr = this.simTimeFormatted();

    let output = '';
    const tableData: Record<string, unknown>[] | undefined = undefined;
    let isError = false;

    try {
      if (root === 'help' || root === '--help') {
        output = `STARLINK.NET.OS CLI COMMANDS:
  starlink-net simulate --scenario <name>     Run synthetic failure or diurnal scenario
  starlink-net simulate --satellites <num>    Reconfigure constellation scale (120/300/500/1200)
  starlink-net scenario <traffic-surge|satellite-failure|ground-station-failure|cluster-outage>
  starlink-net coverage                       Compute global geodetic coverage grid
  starlink-net route <TERM_ID>                Calculate Dijkstra route with latency provenance
  starlink-net inspect <SAT_ID|GS_ID|TERM_ID> Inspect telemetry and state of node
  starlink-net fail <SAT_ID|GS_ID>            Inject or clear failure on network node
  starlink-net metrics                        Display current p50/p95/p99 latency and throughput
  starlink-net export <json|csv>              Export telemetry timeseries dataset
  clear                                       Clear CLI terminal window`;
      } else if (trimmed === 'clear') {
        this.cliHistory.set([]);
        return;
      } else if (trimmed.startsWith('starlink-net simulate') || trimmed.startsWith('simulate')) {
        if (trimmed.includes('--scenario')) {
          const scenName = parts[parts.indexOf('--scenario') + 1];
          this.activateScenario(scenName);
          output = `[SIMULATOR] Activated scenario: ${scenName}. Monitoring topology state...`;
        } else if (trimmed.includes('--satellites')) {
          const num = parseInt(parts[parts.indexOf('--satellites') + 1], 10);
          if (num <= 150) this.resetSimulation('small_demo');
          else if (num <= 350) this.resetSimulation('regional');
          else if (num <= 750) this.resetSimulation('global');
          else this.resetSimulation('large_constellation');
          output = `[SIMULATOR] Rebuilt constellation lattice with ${this.satellites().length} satellites.`;
        } else {
          this.stepForward();
          output = `[SIMULATOR] Stepped forward +${this.timeStepSec()}s. Simulation time: ${this.simTimeFormatted()}`;
        }
      } else if (trimmed.startsWith('starlink-net scenario') || trimmed.startsWith('scenario')) {
        const code = parts[parts.length - 1];
        this.activateScenario(code);
        output = `[SCENARIO] Injected scenario: ${code}`;
      } else if (trimmed.startsWith('starlink-net coverage') || trimmed === 'coverage') {
        const cov = this.twin.calculateCoveragePercentage();
        output = `GEODETIC COVERAGE ANALYSIS:
  Global Coverage: ${cov}%
  Elevation Threshold: ${this.config().minElevationDeg}°
  Active Constellation Altitude: ${this.config().altitudeKm} km
  Orbital Inclination: ${this.config().inclinationDeg}°
  Online Satellites: ${this.onlineSatellitesCount()}/${this.satellites().length}`;
      } else if (trimmed.startsWith('starlink-net route') || trimmed.startsWith('route')) {
        const termId = parts[parts.length - 1];
        const term = this.terminals().find(t => t.id.toLowerCase() === termId.toLowerCase()) || this.terminals()[0];
        if (term && term.route) {
          const r = term.route;
          output = `DYNAMIC ROUTE FOR ${term.name} (${term.id}):
  Hops: ${r.hops.join('  →  ')}
  Total Range: ${r.totalDistanceKm} km
  Total Latency: ${r.latencyBreakdown.totalMs} ms (Propagation: ${r.latencyBreakdown.propagationMs}ms, Routing: ${r.latencyBreakdown.routingMs}ms, Queueing: ${r.latencyBreakdown.queueingMs}ms)
  Gateway Destination: ${r.destinationName}`;
        } else {
          output = `[ROUTER] Terminal ${termId} not found or disconnected.`;
          isError = true;
        }
      } else if (trimmed.startsWith('starlink-net inspect') || trimmed.startsWith('inspect')) {
        const id = parts[parts.length - 1].toUpperCase();
        const sat = this.satellites().find(s => s.id === id);
        const gs = this.groundStations().find(g => g.id === id);
        const term = this.terminals().find(t => t.id === id);

        if (sat) {
          this.selectSatellite(sat.id);
          output = `SATELLITE TELEMETRY [${sat.id}]:
  Position: Lat ${sat.lat}°, Lon ${sat.lon}°, Alt ${sat.altKm} km
  Velocity: ${sat.velocityKmS} km/s (Period: ${sat.orbitalPeriodMin.toFixed(1)} min)
  Health: ${sat.health} | Power: ${sat.powerStateW}W / ${sat.maxPowerW}W | Thermal: ${sat.thermalStateC}°C
  Active Links: ${sat.activeLinks.length} ISLs | Users: ${sat.connectedUsers} | Beams: ${sat.activeBeamsCount}/${sat.maxBeams}
  Throughput: ${sat.throughputGbps} Gbps / ${sat.downlinkCapacityGbps} Gbps (${sat.utilizationPct}% ${sat.congestionState})`;
        } else if (gs) {
          this.selectGroundStation(gs.id);
          output = `GROUND STATION [${gs.name} - ${gs.id}]:
  Location: ${gs.city}, ${gs.country} (${gs.lat}°, ${gs.lon}°)
  Status: ${gs.availability} | Antennas: ${gs.activeAntennas}/${gs.antennaCount}
  Backhaul: ${gs.currentThroughputGbps} Gbps / ${gs.backhaulCapacityGbps} Gbps (${gs.backhaulUtilizationPct}%)
  Latency to Core POP: ${gs.latencyToCoreMs} ms`;
        } else if (term) {
          this.selectTerminal(term.id);
          output = `USER TERMINAL [${term.name} - ${term.id}]:
  Location: Lat ${term.lat}°, Lon ${term.lon}° (${term.type})
  Session: ${term.sessionState} | Connected Sat: ${term.connectedSatId || 'NONE'}
  Elevation: ${term.elevationDeg}° | SNR: ${term.snrDb} dB | Latency: ${term.latencyMs} ms
  Demand: ${term.demandMbps} Mbps | Allocated: ${term.allocatedThroughputMbps} Mbps`;
        } else {
          output = `Node ID "${id}" not found.`;
          isError = true;
        }
      } else if (trimmed.startsWith('starlink-net fail') || trimmed.startsWith('fail')) {
        const id = parts[parts.length - 1].toUpperCase();
        this.triggerFailure(id);
        output = `Toggled failure state for node: ${id}`;
      } else if (trimmed.startsWith('starlink-net metrics') || trimmed === 'metrics') {
        const m = this.currentMetrics();
        if (m) {
          output = `CONSTELLATION NETWORK METRICS (Sim Time ${m.simTimeFormatted}):
  Global Throughput: ${m.globalThroughputGbps} Gbps
  Mean Utilization: ${m.meanUtilizationPct}% | Peak: ${m.peakUtilizationPct}%
  Latency Distribution: Avg ${m.avgLatencyMs}ms | p50 ${m.p50LatencyMs}ms | p95 ${m.p95LatencyMs}ms | p99 ${m.p99LatencyMs}ms
  Active ISLs: ${m.activeIslLinks} | Active Handovers: ${m.activeHandoversCount} | Coverage: ${m.globalCoveragePct}%`;
        }
      } else if (trimmed.startsWith('starlink-net export') || trimmed.startsWith('export')) {
        const fmt = trimmed.includes('csv') ? 'CSV' : 'JSON';
        this.exportData(fmt);
        output = `[EXPORT] Initiated browser download for ${fmt} telemetry dataset.`;
      } else {
        output = `Unknown command "${parts[0]}". Type "help" for list of valid commands.`;
        isError = true;
      }
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      output = `Error executing command: ${errorMsg}`;
      isError = true;
    }

    this.cliHistory.update(list => [
      ...list,
      {
        command: trimmed,
        timestamp: timeStr,
        output,
        isError,
        tableData
      }
    ]);
  }
}
