import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import { ConstellationDigitalTwin } from './app/core/simulation/constellation-digital-twin';
import { SYNTHETIC_SCENARIOS } from './app/core/data/synthetic-dataset';

const browserDistFolder = join(import.meta.dirname, '../browser');


const app = express();
app.use(express.json());

// Server-side singleton instance of Constellation Digital Twin
const serverTwin = new ConstellationDigitalTwin('global');

// Auto-tick background simulation loop on server
let simInterval: NodeJS.Timeout | null = null;
const startServerSim = () => {
  if (!simInterval) {
    simInterval = setInterval(() => {
      if (serverTwin.isRunning) {
        serverTwin.advanceSimulation(serverTwin.config.timeStepSec * serverTwin.speedMultiplier);
      }
    }, 1000);
  }
};
startServerSim();

// ==========================================
// REST API ENDPOINTS
// ==========================================

app.get('/api/constellation', (req, res) => {
  res.json({
    status: 'ONLINE',
    system: 'STARLINK.NET.OS',
    config: serverTwin.config,
    simTimeSec: serverTwin.simTimeSec,
    simTimeFormatted: serverTwin.formatSimTime(serverTwin.simTimeSec),
    isRunning: serverTwin.isRunning,
    speedMultiplier: serverTwin.speedMultiplier,
    activeScenario: serverTwin.activeScenario,
    routingPolicy: serverTwin.routingPolicy
  });
});

app.get('/api/satellites', (req, res) => {
  const plane = req.query['plane'] ? Number(req.query['plane']) : undefined;
  const health = req.query['health'] as string | undefined;

  let list = serverTwin.satellites;
  if (plane !== undefined) list = list.filter(s => s.planeIndex === plane);
  if (health) list = list.filter(s => s.health === health);

  res.json({
    total: list.length,
    satellites: list
  });
});

app.get('/api/satellites/:id', (req, res) => {
  const sat = serverTwin.satellites.find(s => s.id.toLowerCase() === req.params.id.toLowerCase());
  if (!sat) {
    res.status(404).json({ error: `Satellite ${req.params.id} not found` });
    return;
  }
  res.json(sat);
});

app.get('/api/ground-stations', (req, res) => {
  res.json({
    total: serverTwin.groundStations.length,
    groundStations: serverTwin.groundStations
  });
});

app.get('/api/users', (req, res) => {
  res.json({
    total: serverTwin.terminals.length,
    terminals: serverTwin.terminals
  });
});

app.get('/api/coverage', (req, res) => {
  const coveragePct = serverTwin.calculateCoveragePercentage();
  res.json({
    timestamp: Date.now(),
    simTimeSec: serverTwin.simTimeSec,
    globalCoveragePct: coveragePct,
    minElevationDeg: serverTwin.config.minElevationDeg,
    altitudeKm: serverTwin.config.altitudeKm,
    activeSatellites: serverTwin.satellites.filter(s => s.health !== 'OFFLINE').length
  });
});

app.get('/api/links', (req, res) => {
  res.json({
    total: serverTwin.islLinks.length,
    activeLinks: serverTwin.islLinks.filter(l => l.status === 'ACTIVE').length,
    links: serverTwin.islLinks
  });
});

app.get('/api/routes', (req, res) => {
  res.json({
    total: serverTwin.activeRoutes.length,
    policy: serverTwin.routingPolicy,
    routes: serverTwin.activeRoutes
  });
});

app.get('/api/metrics', (req, res) => {
  res.json({
    current: serverTwin.currentMetrics,
    history: serverTwin.metricsHistory.slice(-30)
  });
});

app.get('/api/events', (req, res) => {
  const limit = req.query['limit'] ? Number(req.query['limit']) : 50;
  res.json({
    total: serverTwin.events.length,
    events: serverTwin.events.slice(0, limit)
  });
});

app.post('/api/simulation/start', (req, res) => {
  serverTwin.isRunning = true;
  if (req.body?.speed) serverTwin.speedMultiplier = Number(req.body.speed);
  res.json({ status: 'STARTED', isRunning: true, speedMultiplier: serverTwin.speedMultiplier });
});

app.post('/api/simulation/stop', (req, res) => {
  serverTwin.isRunning = false;
  res.json({ status: 'STOPPED', isRunning: false });
});

app.post('/api/simulation/step', (req, res) => {
  const step = req.body?.stepSec ? Number(req.body.stepSec) : serverTwin.config.timeStepSec;
  serverTwin.advanceSimulation(step);
  res.json({
    status: 'STEPPED',
    simTimeSec: serverTwin.simTimeSec,
    simTimeFormatted: serverTwin.formatSimTime(serverTwin.simTimeSec)
  });
});

app.post('/api/simulation/reset', (req, res) => {
  const preset = req.body?.preset || 'global';
  serverTwin.changeConstellationPreset(preset);
  res.json({ status: 'RESET', preset, config: serverTwin.config });
});

app.post('/api/failure', (req, res) => {
  const { target } = req.body || {};
  if (!target) {
    res.status(400).json({ error: 'Missing target ID' });
    return;
  }

  const sat = serverTwin.satellites.find(s => s.id === target);
  const gs = serverTwin.groundStations.find(g => g.id === target);

  if (sat) {
    sat.health = 'OFFLINE';
    serverTwin.advanceSimulation(0);
    res.json({ status: 'INJECTED', entity: 'SATELLITE', id: sat.id, health: 'OFFLINE' });
  } else if (gs) {
    gs.availability = 'OFFLINE';
    serverTwin.advanceSimulation(0);
    res.json({ status: 'INJECTED', entity: 'GROUND_STATION', id: gs.id, availability: 'OFFLINE' });
  } else {
    res.status(404).json({ error: `Entity ${target} not found` });
  }
});

app.post('/api/scenario', (req, res) => {
  const code = req.body?.code;
  const scen = SYNTHETIC_SCENARIOS.find(s => s.code === code);
  if (!scen) {
    res.status(404).json({ error: `Scenario code ${code} not found` });
    return;
  }
  serverTwin.setScenario(scen);
  res.json({ status: 'ACTIVATED', scenario: scen });
});

app.get('/api/export/parquet', (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', 'attachment; filename="starlink_net_os_metrics.json"');
  res.send(serverTwin.exportParquetReadyDataset());
});

const angularApp = new AngularNodeAppEngine();

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);

