// Hydrogen Combustion Chemistry & Thermal Kinetics Engine
import { ChemicalEquilibrium, HydrogenCombustorPerformance } from '../types';

export const H2_LHV_J_KG = 120.0e6; // 120.0 MJ/kg
export const H2_STOICH_FAR = 0.02916; // (f/a)_stoich approx 1 / 34.28
export const CP_AIR = 1005; // J/(kg*K)
export const CP_GAS = 1150; // J/(kg*K) combustion products
export const GAMMA_GAS = 1.33;

/**
 * Calculates hydrogen combustion state, flame temperature, thermal NOx, and equilibrium products.
 */
export function calculateHydrogenCombustion(
  airMassFlowKgS: number,
  h2MassFlowKgS: number,
  t3K: number, // Combustor inlet total temp from compressor
  p3Pa: number // Combustor inlet total pressure
): { combustor: HydrogenCombustorPerformance; equilibrium: ChemicalEquilibrium } {
  const far = h2MassFlowKgS / Math.max(0.01, airMassFlowKgS);
  const equivalenceRatioPhi = far / H2_STOICH_FAR;

  // Realistic combustion efficiency model for micromix lean hydrogen burner
  const combustionEfficiencyEta = Math.min(0.9995, Math.max(0.85, 0.999 - 0.04 * Math.max(0, 0.2 - equivalenceRatioPhi)));

  // Heat release rate in Megawatts
  const heatReleaseRateMw = (h2MassFlowKgS * H2_LHV_J_KG * combustionEfficiencyEta) / 1e6;

  // Theoretical adiabatic flame temperature for H2-air mixture (empirical polynomial fit from chemical equilibrium)
  let adiabaticFlameTempK: number;
  if (equivalenceRatioPhi <= 1.0) {
    // Lean to stoichiometric
    adiabaticFlameTempK = t3K + (equivalenceRatioPhi * 2100) * (1 - 0.08 * (1 - equivalenceRatioPhi));
  } else {
    // Rich
    adiabaticFlameTempK = t3K + 2100 * (1 - 0.25 * (equivalenceRatioPhi - 1));
  }
  adiabaticFlameTempK = Math.min(2700, adiabaticFlameTempK);

  // Mean Combustor Exit Total Temperature T4 (Turbine Inlet Temperature TIT)
  // Conserving energy: m_dot_total * cp_gas * (T4 - T_ref) = m_dot_air * cp_air * (T3 - T_ref) + m_dot_f * LHV * eta_b
  const totalFlow = airMassFlowKgS + h2MassFlowKgS;
  const deltaT = (h2MassFlowKgS * H2_LHV_J_KG * combustionEfficiencyEta) / (totalFlow * CP_GAS);
  const combustorExitTempT4K = Math.min(2250, t3K + deltaT);

  // Combustor internal pressure drop (delta P / P3)
  const pressureLossDeltaPPercent = 4.0 + 0.5 * (far / H2_STOICH_FAR);

  // Laminar & turbulent flame speed correlation for hydrogen
  const flameSpeedMs = Math.max(0.3, 2.4 * Math.exp(-Math.pow((equivalenceRatioPhi - 1.6) / 0.9, 2)) * Math.pow(t3K / 300, 1.4));

  // Flashback safety margin index (higher is safer, micromix injector velocity / flame speed)
  const injectorJetVelocityMs = 120.0; // Designed sonic/high-speed micro-jets
  const flashbackSafetyIndex = Number((injectorJetVelocityMs / Math.max(1.0, flameSpeedMs * 15)).toFixed(2));

  // Thermal NOx formation via extended Zeldovich mechanism (strongly dependent on peak flame temp)
  // Low equivalence ratio (phi ~ 0.38) yields near-zero single-digit ppm NOx
  const zeldovichFactor = Math.exp(-38000 / adiabaticFlameTempK);
  const thermalNOxEmissionPpm = Math.max(0.2, Number((8.5e6 * zeldovichFactor * Math.sqrt(p3Pa / 101325)).toFixed(1)));

  // Unburned hydrogen slip (ppm)
  const unburnedH2SlipPpm = Number(((1 - combustionEfficiencyEta) * 1e6 * (far / (1 + far))).toFixed(1));

  // Chemical equilibrium mole fractions
  // At lean H2-air combustion, products are mainly N2, H2O, excess O2, and trace dissociation radicals
  const xN2 = 0.74 * (1 - 0.15 * equivalenceRatioPhi);
  const xH2O = 0.24 * equivalenceRatioPhi;
  const xO2 = Math.max(0.005, 0.21 * (1 - equivalenceRatioPhi));
  const xOH = 0.002 * Math.min(1.0, equivalenceRatioPhi);
  const xNO = thermalNOxEmissionPpm * 1e-6;
  const xNO2 = xNO * 0.12;
  const xH2 = unburnedH2SlipPpm * 1e-6;
  const xH = 0.0005 * equivalenceRatioPhi;
  const xO = 0.0008 * equivalenceRatioPhi;

  const sumRad = xN2 + xH2O + xO2 + xOH + xNO + xNO2 + xH2 + xH + xO;
  const normN2 = xN2 / sumRad;
  const normH2O = xH2O / sumRad;
  const normO2 = xO2 / sumRad;
  const normOH = xOH / sumRad;
  const normNO = xNO / sumRad;
  const normNO2 = xNO2 / sumRad;
  const normH2 = xH2 / sumRad;
  const normH = xH / sumRad;
  const normO = xO / sumRad;

  const meanMolecularWeightGmol =
    normN2 * 28.013 +
    normH2O * 18.015 +
    normO2 * 31.999 +
    normOH * 17.008 +
    normNO * 30.006 +
    normNO2 * 46.005 +
    normH2 * 2.016 +
    normH * 1.008 +
    normO * 15.999;

  return {
    combustor: {
      combustorType: 'micromix_lean_premix',
      fuelMassFlowKgS: h2MassFlowKgS,
      equivalenceRatioPhi: Number(equivalenceRatioPhi.toFixed(4)),
      adiabaticFlameTempK: Math.round(adiabaticFlameTempK),
      combustorExitTempT4K: Math.round(combustorExitTempT4K),
      pressureLossDeltaPPercent: Number(pressureLossDeltaPPercent.toFixed(2)),
      combustionEfficiencyEta: Number(combustionEfficiencyEta.toFixed(4)),
      heatReleaseRateMw: Number(heatReleaseRateMw.toFixed(2)),
      thermalNOxEmissionPpm,
      unburnedH2SlipPpm,
      flameSpeedMs: Number(flameSpeedMs.toFixed(2)),
      flashbackSafetyIndex,
    },
    equilibrium: {
      moleFractions: {
        H2: Number(normH2.toFixed(6)),
        O2: Number(normO2.toFixed(4)),
        N2: Number(normN2.toFixed(4)),
        H2O: Number(normH2O.toFixed(4)),
        OH: Number(normOH.toFixed(5)),
        O: Number(normO.toFixed(5)),
        H: Number(normH.toFixed(5)),
        NO: Number(normNO.toFixed(6)),
        NO2: Number(normNO2.toFixed(7)),
      },
      meanMolecularWeightGmol: Number(meanMolecularWeightGmol.toFixed(2)),
      specificHeatRatioGamma: GAMMA_GAS,
    },
  };
}
