// Compressible Flow Gas Dynamics — Oblique & Normal Shock Waves, Isentropic Relations & Expansion
import { GAMMA_AIR } from './atmosphere';

export type NormalShockResult = {
  m1: number;
  m2: number;
  p2OverP1: number;
  t2OverT1: number;
  pt2OverPt1: number; // Stagnation pressure recovery across shock
  rho2OverRho1: number;
};

export type ObliqueShockResult = {
  m1: number;
  thetaRad: number; // Deflection angle
  betaRad: number; // Wave shock angle
  mn1: number;
  mn2: number;
  m2: number;
  p2OverP1: number;
  t2OverT1: number;
  pt2OverPt1: number;
  rho2OverRho1: number;
};

/**
 * Normal shock wave relations for ideal gas with constant gamma
 */
export function solveNormalShock(m1: number, gamma: number = GAMMA_AIR): NormalShockResult {
  if (m1 <= 1.0) {
    return { m1, m2: m1, p2OverP1: 1, t2OverT1: 1, pt2OverPt1: 1, rho2OverRho1: 1 };
  }

  const gp1 = gamma + 1;
  const gm1 = gamma - 1;
  const m1Sq = m1 * m1;

  const m2Sq = (1 + (gm1 / 2) * m1Sq) / (gamma * m1Sq - gm1 / 2);
  const m2 = Math.sqrt(Math.max(0.01, m2Sq));

  const p2OverP1 = 1 + (2 * gamma / gp1) * (m1Sq - 1);
  const rho2OverRho1 = (gp1 * m1Sq) / (2 + gm1 * m1Sq);
  const t2OverT1 = p2OverP1 / rho2OverRho1;

  // Stagnation pressure ratio across normal shock (Rayleigh Pitot formula)
  const term1 = Math.pow((gp1 * m1Sq) / (2 + gm1 * m1Sq), gamma / gm1);
  const term2 = Math.pow(gp1 / (2 * gamma * m1Sq - gm1), 1 / gm1);
  const pt2OverPt1 = term1 * term2;

  return {
    m1,
    m2,
    p2OverP1,
    t2OverT1,
    pt2OverPt1: Math.min(1.0, Math.max(0.001, pt2OverPt1)),
    rho2OverRho1,
  };
}

/**
 * Solves the theta-beta-M relation for an oblique shock given upstream Mach M1 and ramp deflection theta.
 * Uses Newton-Raphson to find the weak shock solution for beta.
 */
export function solveObliqueShock(
  m1: number,
  thetaDeg: number,
  gamma: number = GAMMA_AIR
): ObliqueShockResult {
  const thetaRad = (thetaDeg * Math.PI) / 180;
  if (m1 <= 1.001 || thetaDeg <= 0.01) {
    return {
      m1,
      thetaRad: 0,
      betaRad: Math.asin(1 / Math.max(1.001, m1)),
      mn1: 1,
      mn2: 1,
      m2: m1,
      p2OverP1: 1,
      t2OverT1: 1,
      pt2OverPt1: 1,
      rho2OverRho1: 1,
    };
  }

  const m1Sq = m1 * m1;
  const gp1 = gamma + 1;
  const gm1 = gamma - 1;

  // Initial estimate for weak shock beta: Mach angle + 0.8 * theta
  const mu = Math.asin(1 / m1);
  let beta = mu + 0.8 * thetaRad;

  // Newton-Raphson iteration on f(beta) = tan(theta) - 2*cot(beta)*(M1^2*sin(beta)^2 - 1)/(M1^2*(gamma + cos(2*beta)) + 2)
  for (let i = 0; i < 20; i++) {
    const sinB = Math.sin(beta);
    const cosB = Math.cos(beta);
    const cotB = 1 / Math.tan(beta);
    const sin2B = sinB * sinB;
    const cos2B = Math.cos(2 * beta);

    const num = m1Sq * sin2B - 1;
    const den = m1Sq * (gamma + cos2B) + 2;
    if (den <= 0) break;

    const rhs = 2 * cotB * (num / den);
    const f = Math.tan(thetaRad) - rhs;

    if (Math.abs(f) < 1e-6) break;

    // Numerical derivative
    const dBeta = 1e-4;
    const sinBp = Math.sin(beta + dBeta);
    const cosBp = Math.cos(beta + dBeta);
    const cotBp = 1 / Math.tan(beta + dBeta);
    const rhsp = 2 * cotBp * ((m1Sq * sinBp * sinBp - 1) / (m1Sq * (gamma + Math.cos(2 * (beta + dBeta))) + 2));
    const df = (Math.tan(thetaRad) - rhsp - f) / dBeta;

    if (Math.abs(df) > 1e-7) {
      beta = beta - f / df;
      // Clamp to valid range (Mach wave angle to 90 degrees)
      beta = Math.max(mu + 0.01, Math.min(Math.PI / 2 - 0.01, beta));
    }
  }

  const mn1 = m1 * Math.sin(beta);
  const normalResult = solveNormalShock(mn1, gamma);
  const mn2 = normalResult.m2;
  const m2 = mn2 / Math.sin(Math.max(0.01, beta - thetaRad));

  return {
    m1,
    thetaRad,
    betaRad: beta,
    mn1,
    mn2,
    m2,
    p2OverP1: normalResult.p2OverP1,
    t2OverT1: normalResult.t2OverT1,
    pt2OverPt1: normalResult.pt2OverPt1,
    rho2OverRho1: normalResult.rho2OverRho1,
  };
}

/**
 * Prandtl-Meyer expansion angle nu(M) in radians
 */
export function prandtlMeyerNu(m: number, gamma: number = GAMMA_AIR): number {
  if (m <= 1.0) return 0;
  const gp1 = gamma + 1;
  const gm1 = gamma - 1;
  const fac = Math.sqrt(gp1 / gm1);
  return (
    fac * Math.atan(Math.sqrt((gm1 / gp1) * (m * m - 1))) -
    Math.atan(Math.sqrt(m * m - 1))
  );
}

/**
 * Isentropic Area ratio A / A* for compressible flow
 */
export function isentropicAreaRatio(m: number, gamma: number = GAMMA_AIR): number {
  if (m <= 0.01) return 100;
  const gp1 = gamma + 1;
  const gm1 = gamma - 1;
  const term = (2 / gp1) * (1 + (gm1 / 2) * m * m);
  return (1 / m) * Math.pow(term, gp1 / (2 * gm1));
}
