// Complete Thermodynamic Engine Cycle Solver (Stations 0 -> 9)
import { calculateAtmosphere, GAMMA_AIR, R_AIR, G0 } from './atmosphere';
import { solveObliqueShock, solveNormalShock } from './compressible';
import { calculateHydrogenCombustion, CP_AIR, CP_GAS, GAMMA_GAS, H2_LHV_J_KG } from './combustion';
import {
  FlightCondition,
  EngineStation,
  InletPerformance,
  CompressorPerformance,
  TurbinePerformance,
  ReheatPerformance,
  NozzlePerformance,
  ThrustAndEfficiency,
  EngineTwinState,
} from '../types';

/**
 * Solves the full continuous thermodynamic cycle for the HJ-22 engine.
 */
export function solveEngineCycle(flight: FlightCondition): EngineTwinState {
  const atmo = calculateAtmosphere(flight.altitudeM, flight.mach);
  const m0 = Math.max(0.05, flight.mach);
  const v0 = m0 * atmo.speedOfSoundMs;

  // 1. INLET ANALYSIS (Station 0 -> Station 1 -> Station 2)
  // Variable geometry multi-shock compression system (2 oblique ramps + 1 normal terminal shock + diffuser)
  const rampAngle1 = flight.inletAngleDeg;
  const rampAngle2 = flight.inletAngleDeg * 0.65;

  let shock1 = solveObliqueShock(m0, rampAngle1);
  let shock2 = solveObliqueShock(shock1.m2, rampAngle2);
  let terminalShock = solveNormalShock(shock2.m2);

  let supersonicShockRecovery = shock1.pt2OverPt1 * shock2.pt2OverPt1 * terminalShock.pt2OverPt1;
  if (m0 <= 1.0) {
    supersonicShockRecovery = 1.0 - 0.02 * m0;
  }

  // Subsonic diffuser recovery & boundary layer bleed
  const diffuserEta = 0.965;
  const totalPressureRecovery = Math.min(0.985, Math.max(0.55, supersonicShockRecovery * diffuserEta));

  // Capture Area & Mass Flow
  const inletCaptureAreaM2 = 0.82; // 0.82 m2 capture frontal area
  const inletContractionRatio = 1.0 + 0.25 * Math.max(0, m0 - 1);
  const massFlowCapture = atmo.densityKgM3 * v0 * inletCaptureAreaM2;
  const bleedFlowKgS = massFlowCapture * 0.035; // 3.5% boundary layer bleed
  const airMassFlowKgS = Math.max(8.0, (massFlowCapture - bleedFlowKgS) * (0.4 + 0.6 * flight.throttle));

  const pt0 = atmo.totalPressurePa;
  const tt0 = atmo.totalTempK;
  const pt2 = pt0 * totalPressureRecovery;
  const tt2 = tt0; // Adiabatic inlet

  const m2 = 0.42; // Compressor engine-face design Mach
  const t2 = tt2 / (1 + ((GAMMA_AIR - 1) / 2) * m2 * m2);
  const p2 = pt2 / Math.pow(1 + ((GAMMA_AIR - 1) / 2) * m2 * m2, GAMMA_AIR / (GAMMA_AIR - 1));
  const rho2 = p2 / (R_AIR * t2);
  const v2 = m2 * Math.sqrt(GAMMA_AIR * R_AIR * t2);
  const a2 = airMassFlowKgS / (rho2 * v2);

  const inlet: InletPerformance = {
    inletType: '2D_mixed_compression_ramp',
    shockAngleDeg: Number(((shock1.betaRad * 180) / Math.PI).toFixed(1)),
    terminalShockMach: Number(terminalShock.m1.toFixed(2)),
    pressureRecoveryEta: Number(totalPressureRecovery.toFixed(4)),
    captureAreaM2: inletCaptureAreaM2,
    spillageDragN: Number((atmo.dynamicPressurePa * 0.04 * inletCaptureAreaM2 * Math.max(0, 2.2 - m0)).toFixed(0)),
    bleedFlowKgS: Number(bleedFlowKgS.toFixed(2)),
    distortionIndexDC60: Number((0.08 + 0.03 * Math.max(0, m0 - 1.8)).toFixed(3)),
    subsonicDiffuserEfficiency: diffuserEta,
  };

  // 2. COMPRESSOR ANALYSIS (Station 2 -> Station 3)
  // Design CPR = 13.2 at sea level, matched CPR for Mach 2.2 = ~10.5 - 12.8
  const baseCPR = 11.5;
  const vsvEffect = 1.0 + (flight.compressorVsvDeg / 15.0) * 0.12;
  const throttleEffect = Math.pow(flight.throttle, 1.2);
  const cpr = Math.max(2.5, baseCPR * throttleEffect * vsvEffect * (1.0 - 0.08 * (m0 - 1.0)));
  const compressorEta = 0.885 - 0.02 * (1 - flight.throttle);

  const pt3 = pt2 * cpr;
  // Isentropic temperature rise
  const tt3Ideal = tt2 * Math.pow(cpr, (GAMMA_AIR - 1) / GAMMA_AIR);
  const tt3 = tt2 + (tt3Ideal - tt2) / compressorEta;

  const compressorWorkPerKg = CP_AIR * (tt3 - tt2);
  const shaftPowerKw = (airMassFlowKgS * compressorWorkPerKg) / 1000;

  // Bleed cooling extraction for HPT blades (8.5% of compressor exit flow)
  const bleedCoolingFlowKgS = airMassFlowKgS * 0.085;
  const combustorAirFlowKgS = airMassFlowKgS - bleedCoolingFlowKgS;

  const m3 = 0.24;
  const t3 = tt3 / (1 + ((GAMMA_AIR - 1) / 2) * m3 * m3);
  const p3 = pt3 / Math.pow(1 + ((GAMMA_AIR - 1) / 2) * m3 * m3, GAMMA_AIR / (GAMMA_AIR - 1));
  const rho3 = p3 / (R_AIR * t3);
  const v3 = m3 * Math.sqrt(GAMMA_AIR * R_AIR * t3);
  const a3 = combustorAirFlowKgS / (rho3 * v3);

  const correctedRpmPercent = 70 + 30 * flight.throttle;
  const surgeMarginPercent = Number((22.5 - 6.0 * (1 - vsvEffect) + 3.0 * (1 - flight.throttle)).toFixed(1));

  const compressor: CompressorPerformance = {
    stages: 6,
    pressureRatioCPR: Number(cpr.toFixed(2)),
    isentropicEfficiency: Number(compressorEta.toFixed(3)),
    correctedFlowKgS: Number(((airMassFlowKgS * Math.sqrt(tt2 / 288.15)) / (pt2 / 101325)).toFixed(2)),
    correctedRpmPercent: Number(correctedRpmPercent.toFixed(1)),
    surgeMarginPercent,
    meanStageLoadingPsi: 0.38,
    meanFlowCoeffPhi: 0.52,
    bleedCoolingFlowKgS: Number(bleedCoolingFlowKgS.toFixed(2)),
    shaftPowerRequiredKw: Math.round(shaftPowerKw),
    operatingPointX: Number((0.85 * flight.throttle).toFixed(2)),
    operatingPointY: Number((cpr / 14.0).toFixed(2)),
  };

  // 3. HYDROGEN COMBUSTOR (Station 3 -> Station 4)
  // Target turbine inlet temperature (TIT) governed by throttle setting
  const maxDesignTIT = 1950; // Kelvin (advanced CMSX-4 single crystal with thermal barrier coating)
  const idleTIT = 1150;
  const targetTIT = idleTIT + (maxDesignTIT - idleTIT) * Math.pow(flight.throttle, 1.1);

  // Compute required hydrogen fuel flow to achieve target TIT
  // m_dot_f = (m_dot_air * cp_gas * (targetTIT - tt3)) / (eta_b * LHV - cp_gas * targetTIT)
  const etaCombustor = 0.998;
  const deltaH = CP_GAS * Math.max(100, targetTIT - tt3);
  let h2FuelFlowKgS = (combustorAirFlowKgS * deltaH) / (etaCombustor * H2_LHV_J_KG);
  h2FuelFlowKgS = Math.max(0.08, h2FuelFlowKgS);

  const { combustor, equilibrium } = calculateHydrogenCombustion(
    combustorAirFlowKgS,
    h2FuelFlowKgS,
    tt3,
    pt3
  );

  const pt4 = pt3 * (1 - combustor.pressureLossDeltaPPercent / 100);
  const tt4 = combustor.combustorExitTempT4K;
  const coreMassFlowKgS = combustorAirFlowKgS + h2FuelFlowKgS;

  const m4 = 0.14;
  const t4 = tt4 / (1 + ((GAMMA_GAS - 1) / 2) * m4 * m4);
  const p4 = pt4 / Math.pow(1 + ((GAMMA_GAS - 1) / 2) * m4 * m4, GAMMA_GAS / (GAMMA_GAS - 1));
  const rho4 = p4 / ((8314 / equilibrium.meanMolecularWeightGmol) * t4);
  const v4 = m4 * Math.sqrt(GAMMA_GAS * (8314 / equilibrium.meanMolecularWeightGmol) * t4);
  const a4 = coreMassFlowKgS / (rho4 * v4);

  // 4. TURBINE ANALYSIS (Station 4 -> Station 4.5 -> Station 5)
  // Turbine must deliver power to drive compressor + accessory gearbox (50 kW)
  const mechanicalEta = 0.99;
  const requiredTurbineWorkKw = shaftPowerKw / mechanicalEta + 50.0;
  const turbineIsentropicEta = 0.915;

  const enthalpyDropRequired = (requiredTurbineWorkKw * 1000) / (coreMassFlowKgS * CP_GAS);
  const tt5 = tt4 - enthalpyDropRequired;
  const tt5Ideal = tt4 - enthalpyDropRequired / turbineIsentropicEta;

  const turbineExpansionRatio = Math.pow(tt4 / tt5Ideal, GAMMA_GAS / (GAMMA_GAS - 1));
  const pt5 = pt4 / turbineExpansionRatio;

  // Interstage Station 4.5 (High-Pressure Turbine Exit)
  const tt45 = tt4 - enthalpyDropRequired * 0.62;
  const pt45 = pt4 / Math.pow(tt4 / (tt4 - (tt4 - tt45) / turbineIsentropicEta), GAMMA_GAS / (GAMMA_GAS - 1));

  // Turbine Blade Cooling Temperature Analysis
  const filmCoolingEff = 0.42; // Advanced shaped hole film cooling
  const tbcDropK = 145.0; // YSZ Thermal Barrier Coating delta T
  const uncooledGasTemp = tt4;
  const bladeMetalTempK = uncooledGasTemp - filmCoolingEff * (uncooledGasTemp - tt3) - tbcDropK;

  const turbine: TurbinePerformance = {
    hptStages: 1,
    lptStages: 1,
    turbineInletTempK: tt4,
    expansionRatioTotal: Number(turbineExpansionRatio.toFixed(2)),
    isentropicEfficiency: turbineIsentropicEta,
    hptShaftPowerKw: Math.round(requiredTurbineWorkKw),
    coolingAirFraction: Number((bleedCoolingFlowKgS / airMassFlowKgS).toFixed(3)),
    bladeUncooledGasTempK: tt4,
    bladeMetalTempK: Math.round(bladeMetalTempK),
    tbcCoatingDeltaTK: tbcDropK,
    eulerWorkKjKg: Number((enthalpyDropRequired / 1000).toFixed(1)),
    shaftTorqueNm: Math.round((requiredTurbineWorkKw * 1000) / ((2 * Math.PI * 14200) / 60)),
  };

  const m5 = 0.44;
  const t5 = tt5 / (1 + ((GAMMA_GAS - 1) / 2) * m5 * m5);
  const p5 = pt5 / Math.pow(1 + ((GAMMA_GAS - 1) / 2) * m5 * m5, GAMMA_GAS / (GAMMA_GAS - 1));
  const rho5 = p5 / ((8314 / equilibrium.meanMolecularWeightGmol) * t5);
  const v5 = m5 * Math.sqrt(GAMMA_GAS * (8314 / equilibrium.meanMolecularWeightGmol) * t5);
  const a5 = coreMassFlowKgS / (rho5 * v5);

  // 5. AFTERBURNER / REHEAT (Station 5 -> Station 6 -> Station 7)
  let reheatFuelFlowKgS = 0;
  let tt7 = tt5;
  let pt7 = pt5 * 0.97; // Unlit duct loss
  let reheatActive = flight.reheatActive;

  if (reheatActive) {
    reheatFuelFlowKgS = h2FuelFlowKgS * 0.75;
    const reheatDeltaT = (reheatFuelFlowKgS * H2_LHV_J_KG * 0.985) / ((coreMassFlowKgS + reheatFuelFlowKgS) * CP_GAS);
    tt7 = Math.min(2350, tt5 + reheatDeltaT);
    pt7 = pt5 * 0.94; // Burning momentum pressure loss
  }

  const reheatMassFlowKgS = coreMassFlowKgS + reheatFuelFlowKgS;
  const reheat: ReheatPerformance = {
    active: reheatActive,
    fuelMassFlowKgS: Number(reheatFuelFlowKgS.toFixed(3)),
    flameTempK: Math.round(tt7),
    pressureLossPercent: reheatActive ? 6.0 : 3.0,
    thrustAugmentationRatio: reheatActive ? 1.38 : 1.0,
  };

  // 6. VARIABLE-AREA CON-DIV EXHAUST NOZZLE (Station 7 -> Station 8 -> Station 9)
  const npr = pt7 / atmo.staticPressurePa;
  const criticalNpr = Math.pow((GAMMA_GAS + 1) / 2, GAMMA_GAS / (GAMMA_GAS - 1)); // ~1.85
  const isChoked = npr >= criticalNpr;

  // Throat conditions (Station 8)
  const tt8 = tt7;
  const pt8 = pt7 * 0.985; // Nozzle friction efficiency
  const t8 = tt8 / ((GAMMA_GAS + 1) / 2);
  const p8 = isChoked ? pt8 / criticalNpr : atmo.staticPressurePa;
  const rho8 = p8 / (R_AIR * t8);
  const v8 = Math.sqrt(GAMMA_GAS * R_AIR * t8); // Mach 1.0 sonic speed
  const throatAreaA8 = reheatMassFlowKgS / (rho8 * v8);

  // Divergent exit (Station 9)
  // Isentropic expansion to ambient or area ratio limit
  const exitAreaRatio = flight.nozzleAreaRatio || (isChoked ? 1.45 + 0.35 * Math.max(0, m0 - 1.2) : 1.0);
  const exitAreaA9 = throatAreaA8 * exitAreaRatio;

  // Fully expanded or under/over-expanded exit Mach
  let m9 = 1.0;
  if (isChoked && exitAreaRatio > 1.0) {
    m9 = Math.sqrt((2 / (GAMMA_GAS - 1)) * (Math.pow(npr, (GAMMA_GAS - 1) / GAMMA_GAS) - 1));
    m9 = Math.min(2.8, Math.max(1.0, m9));
  } else if (!isChoked) {
    m9 = Math.sqrt((2 / (GAMMA_GAS - 1)) * (Math.pow(npr, (GAMMA_GAS - 1) / GAMMA_GAS) - 1));
    m9 = Math.max(0.1, m9);
  }

  const tt9 = tt7;
  const t9 = tt9 / (1 + ((GAMMA_GAS - 1) / 2) * m9 * m9);
  const v9 = m9 * Math.sqrt(GAMMA_GAS * (8314 / equilibrium.meanMolecularWeightGmol) * t9);
  const p9 = pt8 / Math.pow(1 + ((GAMMA_GAS - 1) / 2) * m9 * m9, GAMMA_GAS / (GAMMA_GAS - 1));

  // Thrust Calculations
  // Gross thrust = Momentum thrust + Pressure thrust
  const momentumThrust = reheatMassFlowKgS * v9;
  const pressureThrust = (p9 - atmo.staticPressurePa) * exitAreaA9;
  const grossThrustN = momentumThrust + pressureThrust;
  const ramDragN = massFlowCapture * v0;
  const netThrustN = Math.max(0, grossThrustN - ramDragN);

  const nozzle: NozzlePerformance = {
    nozzleType: 'convergent_divergent_variable_iris',
    nozzlePressureRatioNPR: Number(npr.toFixed(2)),
    criticalNPR: Number(criticalNpr.toFixed(2)),
    isChoked,
    throatAreaA8M2: Number(throatAreaA8.toFixed(4)),
    exitAreaA9M2: Number(exitAreaA9.toFixed(4)),
    exitMach: Number(m9.toFixed(2)),
    exitStaticPressurePa: Math.round(p9),
    exitVelocityMs: Math.round(v9),
    grossThrustN: Math.round(grossThrustN),
    pressureThrustN: Math.round(pressureThrust),
    momentumThrustN: Math.round(momentumThrust),
  };

  // 7. AIRCRAFT DRAG & MISSION PERFORMANCE
  const totalH2FlowKgS = h2FuelFlowKgS + reheatFuelFlowKgS;
  const tsfcGPerKns = netThrustN > 0 ? (totalH2FlowKgS * 1000 * 1000) / (netThrustN * 1000) * 1000 : 0;
  // Specific impulse: Isp = Fn / (m_dot_f * g0)
  const specificImpulseSec = totalH2FlowKgS > 0 ? netThrustN / (totalH2FlowKgS * G0) : 0;
  const specificThrustNsKg = airMassFlowKgS > 0 ? netThrustN / airMassFlowKgS : 0;

  // Efficiencies
  const jetPower = 0.5 * reheatMassFlowKgS * (v9 * v9 - v0 * v0);
  const fuelChemicalPower = totalH2FlowKgS * H2_LHV_J_KG;
  const thermalEfficiency = Math.min(0.65, Math.max(0.1, jetPower / fuelChemicalPower));
  const propulsiveEfficiency = Math.min(0.95, Math.max(0.2, (2 * v0) / (v0 + v9)));
  const overallEfficiency = thermalEfficiency * propulsiveEfficiency;

  // Aircraft propulsion balance
  const aircraftDragN = atmo.dynamicPressurePa * flight.aircraftCd * flight.aircraftRefAreaM2;
  const requiredThrustPerEngine = aircraftDragN / flight.numEngines;
  const thrustMarginN = netThrustN - requiredThrustPerEngine;

  // Breguet Range Equation for Mach 2.2 Hydrogen Aircraft
  // R = (V / TSFC) * (L/D) * ln(W_initial / W_final)
  const liftToDrag = 1 / (flight.aircraftCd * 18); // ~6.5 at Mach 2.2
  const fuelFraction = 0.38; // LH2 cryogenic tankage
  const rangeEstimateKm = (v0 / (totalH2FlowKgS / netThrustN)) * liftToDrag * Math.log(1 / (1 - fuelFraction)) / 1000;

  const thrust: ThrustAndEfficiency = {
    grossThrustN: Math.round(grossThrustN),
    ramDragN: Math.round(ramDragN),
    netThrustN: Math.round(netThrustN),
    requiredAircraftDragN: Math.round(requiredThrustPerEngine),
    thrustMarginN: Math.round(thrustMarginN),
    totalH2FlowKgS: Number(totalH2FlowKgS.toFixed(4)),
    tsfcGPerKns: Number(((totalH2FlowKgS * 1e6) / Math.max(1, netThrustN)).toFixed(2)),
    specificImpulseSec: Math.round(specificImpulseSec),
    specificThrustNsKg: Math.round(specificThrustNsKg),
    thermalEfficiency: Number(thermalEfficiency.toFixed(3)),
    propulsiveEfficiency: Number(propulsiveEfficiency.toFixed(3)),
    overallEfficiency: Number(overallEfficiency.toFixed(3)),
    aircraftRangeEstimateKm: Math.round(rangeEstimateKm),
  };

  // Construct Numbered Stations
  const stations: EngineStation[] = [
    {
      stationId: '0',
      name: 'Freestream Ambient',
      totalTempK: Math.round(tt0),
      staticTempK: Math.round(atmo.staticTempK),
      totalPressurePa: Math.round(pt0),
      staticPressurePa: Math.round(atmo.staticPressurePa),
      densityKgM3: Number(atmo.densityKgM3.toFixed(3)),
      mach: Number(m0.toFixed(2)),
      velocityMs: Math.round(v0),
      massFlowKgS: Number(massFlowCapture.toFixed(2)),
      enthalpyKjKg: Number(((CP_AIR * atmo.staticTempK) / 1000).toFixed(1)),
      entropyKjKgK: 0,
      areaM2: Number(inletCaptureAreaM2.toFixed(3)),
    },
    {
      stationId: '1',
      name: 'Inlet Lip / Capture',
      totalTempK: Math.round(tt0),
      staticTempK: Math.round(atmo.staticTempK * shock1.t2OverT1),
      totalPressurePa: Math.round(pt0 * shock1.pt2OverPt1),
      staticPressurePa: Math.round(atmo.staticPressurePa * shock1.p2OverP1),
      densityKgM3: Number((atmo.densityKgM3 * shock1.rho2OverRho1).toFixed(3)),
      mach: Number(shock1.m2.toFixed(2)),
      velocityMs: Math.round(shock1.m2 * Math.sqrt(GAMMA_AIR * R_AIR * atmo.staticTempK * shock1.t2OverT1)),
      massFlowKgS: Number(massFlowCapture.toFixed(2)),
      enthalpyKjKg: Number(((CP_AIR * atmo.staticTempK * shock1.t2OverT1) / 1000).toFixed(1)),
      entropyKjKgK: 0.04,
      areaM2: Number(inletCaptureAreaM2.toFixed(3)),
    },
    {
      stationId: '2',
      name: 'Diffuser Exit / Compressor Face',
      totalTempK: Math.round(tt2),
      staticTempK: Math.round(t2),
      totalPressurePa: Math.round(pt2),
      staticPressurePa: Math.round(p2),
      densityKgM3: Number(rho2.toFixed(3)),
      mach: Number(m2.toFixed(2)),
      velocityMs: Math.round(v2),
      massFlowKgS: Number(airMassFlowKgS.toFixed(2)),
      enthalpyKjKg: Number(((CP_AIR * t2) / 1000).toFixed(1)),
      entropyKjKgK: 0.12,
      areaM2: Number(a2.toFixed(3)),
    },
    {
      stationId: '3',
      name: 'Compressor Exit / Diffuser',
      totalTempK: Math.round(tt3),
      staticTempK: Math.round(t3),
      totalPressurePa: Math.round(pt3),
      staticPressurePa: Math.round(p3),
      densityKgM3: Number(rho3.toFixed(3)),
      mach: Number(m3.toFixed(2)),
      velocityMs: Math.round(v3),
      massFlowKgS: Number(combustorAirFlowKgS.toFixed(2)),
      enthalpyKjKg: Number(((CP_AIR * t3) / 1000).toFixed(1)),
      entropyKjKgK: 0.38,
      areaM2: Number(a3.toFixed(3)),
    },
    {
      stationId: '4',
      name: 'Combustor Exit / HPT Inlet',
      totalTempK: Math.round(tt4),
      staticTempK: Math.round(t4),
      totalPressurePa: Math.round(pt4),
      staticPressurePa: Math.round(p4),
      densityKgM3: Number(rho4.toFixed(3)),
      mach: Number(m4.toFixed(2)),
      velocityMs: Math.round(v4),
      massFlowKgS: Number(coreMassFlowKgS.toFixed(2)),
      enthalpyKjKg: Number(((CP_GAS * t4) / 1000).toFixed(1)),
      entropyKjKgK: 1.84,
      areaM2: Number(a4.toFixed(3)),
    },
    {
      stationId: '4.5',
      name: 'HPT Inter-Stage',
      totalTempK: Math.round(tt45),
      staticTempK: Math.round(tt45 * 0.94),
      totalPressurePa: Math.round(pt45),
      staticPressurePa: Math.round(pt45 * 0.72),
      densityKgM3: Number((rho4 * 0.65).toFixed(3)),
      mach: 0.36,
      velocityMs: Math.round(0.36 * Math.sqrt(GAMMA_GAS * R_AIR * tt45 * 0.94)),
      massFlowKgS: Number(coreMassFlowKgS.toFixed(2)),
      enthalpyKjKg: Number(((CP_GAS * tt45 * 0.94) / 1000).toFixed(1)),
      entropyKjKgK: 1.95,
      areaM2: Number((a4 * 1.3).toFixed(3)),
    },
    {
      stationId: '5',
      name: 'LPT Exit / Turbine Diffuser',
      totalTempK: Math.round(tt5),
      staticTempK: Math.round(t5),
      totalPressurePa: Math.round(pt5),
      staticPressurePa: Math.round(p5),
      densityKgM3: Number(rho5.toFixed(3)),
      mach: Number(m5.toFixed(2)),
      velocityMs: Math.round(v5),
      massFlowKgS: Number(coreMassFlowKgS.toFixed(2)),
      enthalpyKjKg: Number(((CP_GAS * t5) / 1000).toFixed(1)),
      entropyKjKgK: 2.12,
      areaM2: Number(a5.toFixed(3)),
    },
    {
      stationId: '7',
      name: 'Reheat Exit / Nozzle Inlet',
      totalTempK: Math.round(tt7),
      staticTempK: Math.round(tt7 * 0.92),
      totalPressurePa: Math.round(pt7),
      staticPressurePa: Math.round(pt7 * 0.76),
      densityKgM3: Number((rho5 * 0.7).toFixed(3)),
      mach: 0.38,
      velocityMs: Math.round(0.38 * Math.sqrt(GAMMA_GAS * R_AIR * tt7 * 0.92)),
      massFlowKgS: Number(reheatMassFlowKgS.toFixed(2)),
      enthalpyKjKg: Number(((CP_GAS * tt7 * 0.92) / 1000).toFixed(1)),
      entropyKjKgK: reheatActive ? 2.65 : 2.15,
      areaM2: Number((a5 * 1.15).toFixed(3)),
    },
    {
      stationId: '8',
      name: 'Nozzle Throat (Sonic A8)',
      totalTempK: Math.round(tt8),
      staticTempK: Math.round(t8),
      totalPressurePa: Math.round(pt8),
      staticPressurePa: Math.round(p8),
      densityKgM3: Number(rho8.toFixed(3)),
      mach: 1.0,
      velocityMs: Math.round(v8),
      massFlowKgS: Number(reheatMassFlowKgS.toFixed(2)),
      enthalpyKjKg: Number(((CP_GAS * t8) / 1000).toFixed(1)),
      entropyKjKgK: 2.22,
      areaM2: Number(throatAreaA8.toFixed(4)),
    },
    {
      stationId: '9',
      name: 'Supersonic Exhaust Exit (A9)',
      totalTempK: Math.round(tt9),
      staticTempK: Math.round(t9),
      totalPressurePa: Math.round(pt8),
      staticPressurePa: Math.round(p9),
      densityKgM3: Number((p9 / (R_AIR * t9)).toFixed(3)),
      mach: Number(m9.toFixed(2)),
      velocityMs: Math.round(v9),
      massFlowKgS: Number(reheatMassFlowKgS.toFixed(2)),
      enthalpyKjKg: Number(((CP_GAS * t9) / 1000).toFixed(1)),
      entropyKjKgK: 2.28,
      areaM2: Number(exitAreaA9.toFixed(4)),
    },
  ];

  // 8. ROTOR DYNAMICS & VIBRATION
  const hpRpm = 14200 * (correctedRpmPercent / 100);
  const lpRpm = 9800 * (correctedRpmPercent / 100);
  const rotor: any = {
    hpShaftRpm: Math.round(hpRpm),
    lpShaftRpm: Math.round(lpRpm),
    hpCriticalSpeed1Rpm: 8250,
    hpCriticalSpeed2Rpm: 16800,
    bearingLoadsN: [
      Math.round(4200 * (hpRpm / 14200)),
      Math.round(6100 * (hpRpm / 14200)),
      Math.round(5400 * (hpRpm / 14200)),
      Math.round(3900 * (hpRpm / 14200)),
    ],
    unbalanceVibrationMmS: Number((0.65 + 0.25 * Math.sin(hpRpm / 1000)).toFixed(2)),
    torsionalNaturalFreqHz: 184.5,
    shaftDeflectionMicrons: Number((12.4 * (hpRpm / 14200)).toFixed(1)),
  };

  // 9. THERMAL NETWORK
  const thermal: any = {
    nodes: [
      { id: 'tn-1', name: 'Inlet Lip Leading Edge', temperatureK: Math.round(tt0 * 1.05), gradientKPerMm: 4.2, thermalStressMpa: 145, materialLimitK: 720 },
      { id: 'tn-2', name: 'Compressor Stg 6 Casing', temperatureK: Math.round(tt3 * 0.95), gradientKPerMm: 8.5, thermalStressMpa: 280, materialLimitK: 950 },
      { id: 'tn-3', name: 'Combustor Liner (Inner)', temperatureK: Math.round(tt4 * 0.72), gradientKPerMm: 24.0, thermalStressMpa: 410, materialLimitK: 1550 },
      { id: 'tn-4', name: 'HPT Rotor Blade Outer TBC', temperatureK: Math.round(tt4 * 0.92), gradientKPerMm: 38.0, thermalStressMpa: 520, materialLimitK: 1720 },
      { id: 'tn-5', name: 'HPT Blade Single-Crystal Substrate', temperatureK: Math.round(bladeMetalTempK), gradientKPerMm: 16.5, thermalStressMpa: 480, materialLimitK: 1420 },
      { id: 'tn-6', name: 'HPT Turbine Disk Rim', temperatureK: Math.round(tt4 * 0.48), gradientKPerMm: 12.0, thermalStressMpa: 390, materialLimitK: 1050 },
      { id: 'tn-7', name: 'HP Shaft Mid-Span', temperatureK: Math.round(tt3 * 0.65), gradientKPerMm: 3.2, thermalStressMpa: 190, materialLimitK: 850 },
      { id: 'tn-8', name: 'Nozzle Flap Ceramic Matrix Composite', temperatureK: Math.round(tt7 * 0.78), gradientKPerMm: 18.2, thermalStressMpa: 310, materialLimitK: 1650 },
    ],
  };

  // 10. FADEC STATE MACHINE
  let fadecMode: any = 'CRUISE_SUPERSONIC';
  if (reheatActive) fadecMode = 'MACH_2_2_REHEAT';
  else if (m0 < 1.0) fadecMode = 'CRUISE_SUBSONIC';
  if (flight.throttle < 0.25) fadecMode = 'IDLE';

  const fadec: any = {
    currentMode: fadecMode,
    actuatorPositions: {
      h2MainValvePercent: Math.round(flight.throttle * 100),
      h2ReheatValvePercent: reheatActive ? 85 : 0,
      inletRampDeg: Number(flight.inletAngleDeg.toFixed(1)),
      compressorVsvDeg: Number(flight.compressorVsvDeg.toFixed(1)),
      nozzleFlapA8A9Percent: Math.round((exitAreaRatio / 2.0) * 100),
    },
    healthIndex: 0.994,
    faults: [],
  };

  return {
    flight,
    atmosphere: atmo,
    stations,
    inlet,
    compressor,
    combustor,
    equilibrium,
    turbine,
    reheat,
    nozzle,
    thrust,
    rotor,
    thermal,
    fadec,
    fidelityLevel: 3,
    simulationTimeSec: 120.4,
  };
}
