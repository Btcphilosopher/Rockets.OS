// Atmosphere Model — ISA 1976 & Supersonic Gas Dynamics Properties
import { AtmosphereState } from '../types';

export const GAMMA_AIR = 1.4;
export const R_AIR = 287.058; // J/(kg*K)
export const SEA_LEVEL_TEMP = 288.15; // K (15 C)
export const SEA_LEVEL_PRESSURE = 101325; // Pa (101.325 kPa)
export const SEA_LEVEL_DENSITY = 1.225; // kg/m^3
export const G0 = 9.80665; // m/s^2

/**
 * Computes authoritative ISA 1976 atmospheric state and supersonic total stagnation conditions.
 */
export function calculateAtmosphere(altitudeM: number, mach: number): AtmosphereState {
  let staticTempK: number;
  let staticPressurePa: number;

  const h = Math.max(0, Math.min(30000, altitudeM)); // Clamped 0 to 30 km

  if (h <= 11000) {
    // Troposphere (0 - 11 km)
    const lapseRate = -0.0065; // K/m
    staticTempK = SEA_LEVEL_TEMP + lapseRate * h;
    staticPressurePa = SEA_LEVEL_PRESSURE * Math.pow(staticTempK / SEA_LEVEL_TEMP, -G0 / (lapseRate * R_AIR));
  } else if (h <= 20000) {
    // Lower Stratosphere / Isothermal Layer (11 - 20 km)
    const T11 = SEA_LEVEL_TEMP - 0.0065 * 11000; // 216.65 K
    const P11 = SEA_LEVEL_PRESSURE * Math.pow(T11 / SEA_LEVEL_TEMP, -G0 / (-0.0065 * R_AIR)); // 22632 Pa
    staticTempK = T11;
    staticPressurePa = P11 * Math.exp(-G0 * (h - 11000) / (R_AIR * T11));
  } else {
    // Upper Stratosphere (20 - 32 km)
    const T11 = 216.65;
    const P11 = 22632;
    const P20 = P11 * Math.exp(-G0 * (20000 - 11000) / (R_AIR * T11)); // ~5474 Pa
    const lapseRate20 = 0.0010; // K/m inversion
    staticTempK = T11 + lapseRate20 * (h - 20000);
    staticPressurePa = P20 * Math.pow(staticTempK / T11, -G0 / (lapseRate20 * R_AIR));
  }

  const densityKgM3 = staticPressurePa / (R_AIR * staticTempK);
  const speedOfSoundMs = Math.sqrt(GAMMA_AIR * R_AIR * staticTempK);
  const trueAirspeedMs = mach * speedOfSoundMs;
  const dynamicPressurePa = 0.5 * densityKgM3 * trueAirspeedMs * trueAirspeedMs;

  // Stagnation / Total Flow Quantities
  const tempRatio = 1 + ((GAMMA_AIR - 1) / 2) * mach * mach;
  const totalTempK = staticTempK * tempRatio;
  const pressureRatio = Math.pow(tempRatio, GAMMA_AIR / (GAMMA_AIR - 1));
  const totalPressurePa = staticPressurePa * pressureRatio;
  const totalDensityKgM3 = totalPressurePa / (R_AIR * totalTempK);

  // Sutherland's Law for dynamic viscosity
  const mu0 = 1.716e-5; // Pa*s at T0 = 273.15 K
  const sutherlandS = 110.4; // K
  const tRef = 273.15;
  const viscosityPaS = mu0 * Math.pow(staticTempK / tRef, 1.5) * ((tRef + sutherlandS) / (staticTempK + sutherlandS));

  return {
    altitudeM: h,
    staticTempK,
    staticPressurePa,
    densityKgM3,
    speedOfSoundMs,
    dynamicPressurePa,
    totalTempK,
    totalPressurePa,
    totalDensityKgM3,
    viscosityPaS,
    gamma: GAMMA_AIR,
    gasConstantJkgK: R_AIR,
  };
}
