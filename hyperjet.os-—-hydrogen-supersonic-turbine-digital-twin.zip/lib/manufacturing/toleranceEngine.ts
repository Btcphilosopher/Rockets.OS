// GD&T Tolerance Stack-Up Engine & Monte Carlo Performance Propagation

export type ToleranceContributor = {
  name: string;
  nominalMm: number;
  toleranceMm: number; // +/- tolerance
  distribution: 'NORMAL' | 'UNIFORM';
};

export type StackUpResult = {
  nominalTotalMm: number;
  worstCaseMinMm: number;
  worstCaseMaxMm: number;
  rssMinMm: number; // Root Sum of Squares (Statistical)
  rssMaxMm: number;
  monteCarloMeanMm: number;
  monteCarloSigmaMm: number;
  cpk: number; // Process capability index
  impactOnEfficiencyPercent: number; // Downstream cycle efficiency impact
  impactOnThrustKn: number; // Downstream thrust delta
  histogramBins: { binMm: number; count: number }[];
};

/**
 * Runs 1,000-run Monte Carlo stack-up simulation for compressor blade tip clearance
 */
export function calculateTipClearanceStackUp(
  rotorRunoutTol: number = 0.015,
  bladeLengthTol: number = 0.025,
  casingBoreTol: number = 0.030,
  bearingPlayTol: number = 0.010
): StackUpResult {
  const nominalGap = 0.65; // Nominal 0.65 mm tip clearance at Stage 1

  const worstCaseMin = nominalGap - (rotorRunoutTol + bladeLengthTol + casingBoreTol + bearingPlayTol);
  const worstCaseMax = nominalGap + (rotorRunoutTol + bladeLengthTol + casingBoreTol + bearingPlayTol);

  const rssTol = Math.sqrt(
    rotorRunoutTol * rotorRunoutTol +
    bladeLengthTol * bladeLengthTol +
    casingBoreTol * casingBoreTol +
    bearingPlayTol * bearingPlayTol
  );

  const rssMin = nominalGap - rssTol;
  const rssMax = nominalGap + rssTol;

  // Run 1000 Monte Carlo iterations (Box-Muller gaussian generator)
  const iterations = 1000;
  const samples: number[] = [];
  let sum = 0;

  for (let i = 0; i < iterations; i++) {
    // 4 normally distributed contributors (assuming +/- 3 sigma is tolerance)
    const u1 = Math.random();
    const u2 = Math.random();
    const u3 = Math.random();
    const u4 = Math.random();

    const z1 = Math.sqrt(-2.0 * Math.log(Math.max(1e-9, u1))) * Math.cos(2.0 * Math.PI * u2);
    const z2 = Math.sqrt(-2.0 * Math.log(Math.max(1e-9, u3))) * Math.cos(2.0 * Math.PI * u4);

    const deltaRotor = (z1 * rotorRunoutTol) / 3.0;
    const deltaBlade = (z2 * bladeLengthTol) / 3.0;
    const deltaCasing = ((Math.random() - 0.5) * 2 * casingBoreTol) / 1.5;
    const deltaBearing = ((Math.random() - 0.5) * 2 * bearingPlayTol) / 1.5;

    const gap = nominalGap + deltaCasing - (deltaRotor + deltaBlade + deltaBearing);
    samples.push(gap);
    sum += gap;
  }

  const monteCarloMean = sum / iterations;
  let variance = 0;
  for (const s of samples) {
    variance += (s - monteCarloMean) * (s - monteCarloMean);
  }
  const monteCarloSigma = Math.sqrt(variance / iterations);

  // Process capability Cpk (Lower spec limit = 0.50mm rub limit, Upper = 0.80mm aero limit)
  const lsl = 0.50;
  const usl = 0.80;
  const cpk = Math.min((usl - monteCarloMean) / (3 * monteCarloSigma), (monteCarloMean - lsl) / (3 * monteCarloSigma));

  // Downstream aerodynamic impact:
  // Rule of thumb in turbomachinery: 1% span clearance increase = ~1.2% stage efficiency drop
  const deltaClearanceMm = monteCarloMean - nominalGap;
  const impactOnEfficiencyPercent = -1.5 * (deltaClearanceMm / 0.1); // ~ -0.15% per 0.01mm gap growth
  const impactOnThrustKn = impactOnEfficiencyPercent * 1.8; // ~ -0.27 kN per 0.1% eff loss

  // Build histogram
  const minVal = Math.min(...samples);
  const maxVal = Math.max(...samples);
  const numBins = 12;
  const binWidth = (maxVal - minVal) / numBins;
  const bins: { binMm: number; count: number }[] = [];

  for (let b = 0; b < numBins; b++) {
    const binCenter = minVal + (b + 0.5) * binWidth;
    bins.push({ binMm: Number(binCenter.toFixed(3)), count: 0 });
  }

  for (const s of samples) {
    const bIndex = Math.min(numBins - 1, Math.floor((s - minVal) / binWidth));
    bins[bIndex].count++;
  }

  return {
    nominalTotalMm: nominalGap,
    worstCaseMinMm: Number(worstCaseMin.toFixed(3)),
    worstCaseMaxMm: Number(worstCaseMax.toFixed(3)),
    rssMinMm: Number(rssMin.toFixed(3)),
    rssMaxMm: Number(rssMax.toFixed(3)),
    monteCarloMeanMm: Number(monteCarloMean.toFixed(3)),
    monteCarloSigmaMm: Number(monteCarloSigma.toFixed(4)),
    cpk: Number(cpk.toFixed(2)),
    impactOnEfficiencyPercent: Number(impactOnEfficiencyPercent.toFixed(3)),
    impactOnThrustKn: Number(impactOnThrustKn.toFixed(2)),
    histogramBins: bins,
  };
}
