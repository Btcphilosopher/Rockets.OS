// Test Cell Instrumentation, Physical Sensor Suite & Fault Injection
import { TestCellSensor, FaultEvent, EngineTwinState } from '../types';

export const INITIAL_TEST_SENSORS: TestCellSensor[] = [
  { id: 'SEN-PT0', tag: 'PT0', name: 'Inlet Pitot Stagnation Pressure', station: '0', physicalType: 'PRESSURE_PIEZO', unit: 'kPa', measuredValue: 120.4, modelledValue: 120.4, calibratedValue: 120.4, uncertainty: 0.15, status: 'NOMINAL' },
  { id: 'SEN-TT0', tag: 'TT0', name: 'Inlet Stagnation Total Temp', station: '0', physicalType: 'TEMPERATURE_TC', unit: 'K', measuredValue: 426.0, modelledValue: 426.0, calibratedValue: 426.0, uncertainty: 0.8, status: 'NOMINAL' },
  { id: 'SEN-PT2', tag: 'PT2', name: 'Compressor Inlet Face Total Pressure', station: '2', physicalType: 'PRESSURE_PIEZO', unit: 'kPa', measuredValue: 106.8, modelledValue: 106.8, calibratedValue: 106.8, uncertainty: 0.20, status: 'NOMINAL' },
  { id: 'SEN-TT2', tag: 'TT2', name: 'Compressor Inlet Face Total Temp', station: '2', physicalType: 'TEMPERATURE_TC', unit: 'K', measuredValue: 426.0, modelledValue: 426.0, calibratedValue: 426.0, uncertainty: 0.5, status: 'NOMINAL' },
  { id: 'SEN-PT3', tag: 'PT3', name: 'Compressor Discharge Total Pressure', station: '3', physicalType: 'PRESSURE_PIEZO', unit: 'kPa', measuredValue: 1228.0, modelledValue: 1228.0, calibratedValue: 1228.0, uncertainty: 1.5, status: 'NOMINAL' },
  { id: 'SEN-TT3', tag: 'TT3', name: 'Compressor Discharge Total Temp', station: '3', physicalType: 'TEMPERATURE_TC', unit: 'K', measuredValue: 884.0, modelledValue: 884.0, calibratedValue: 884.0, uncertainty: 1.2, status: 'NOMINAL' },
  { id: 'SEN-T4-PYRO', tag: 'T4_OPT', name: 'HPT Blade Pyrometer Optical Temp', station: '4', physicalType: 'OPTICAL_PYROMETER', unit: 'K', measuredValue: 1948.0, modelledValue: 1950.0, calibratedValue: 1950.0, uncertainty: 4.5, status: 'NOMINAL' },
  { id: 'SEN-PT5', tag: 'PT5', name: 'Turbine Exit Core Total Pressure', station: '5', physicalType: 'PRESSURE_PIEZO', unit: 'kPa', measuredValue: 242.0, modelledValue: 242.0, calibratedValue: 242.0, uncertainty: 0.6, status: 'NOMINAL' },
  { id: 'SEN-TT5', tag: 'TT5', name: 'Turbine Exit Core Total Temp (EGT)', station: '5', physicalType: 'TEMPERATURE_TC', unit: 'K', measuredValue: 1410.0, modelledValue: 1410.0, calibratedValue: 1410.0, uncertainty: 2.0, status: 'NOMINAL' },
  { id: 'SEN-TT7', tag: 'TT7', name: 'Reheat Exit Flame Total Temp', station: '7', physicalType: 'TEMPERATURE_TC', unit: 'K', measuredValue: 2240.0, modelledValue: 2240.0, calibratedValue: 2240.0, uncertainty: 5.0, status: 'NOMINAL' },
  { id: 'SEN-H2-FLOW', tag: 'H2_MFM', name: 'Coriolis Cryogenic H2 Mass Flow', station: 'Fuel', physicalType: 'FLOW_CORIOLIS', unit: 'kg/s', measuredValue: 0.642, modelledValue: 0.640, calibratedValue: 0.640, uncertainty: 0.002, status: 'NOMINAL' },
  { id: 'SEN-THRUST', tag: 'F_LOAD', name: 'Multi-Axis Test Stand Thrust Loadcell', station: 'Stand', physicalType: 'THRUST_LOADCELL', unit: 'kN', measuredValue: 114.2, modelledValue: 114.2, calibratedValue: 114.2, uncertainty: 0.35, status: 'NOMINAL' },
  { id: 'SEN-VIB-BRG1', tag: 'VIB1', name: 'Bearing #1 Radial Accelerometer', station: 'Rotor', physicalType: 'VIBRATION_ACCEL', unit: 'mm/s', measuredValue: 0.72, modelledValue: 0.68, calibratedValue: 0.68, uncertainty: 0.05, status: 'NOMINAL' },
  { id: 'SEN-VIB-BRG3', tag: 'VIB3', name: 'Bearing #3 Turbine Accelerometer', station: 'Rotor', physicalType: 'VIBRATION_ACCEL', unit: 'mm/s', measuredValue: 0.85, modelledValue: 0.82, calibratedValue: 0.82, uncertainty: 0.05, status: 'NOMINAL' },
];

export type InjectableFaultType =
  | 'NONE'
  | 'H2_FUEL_LEAK'
  | 'TBC_SPALLATION'
  | 'COMPRESSOR_FOULING'
  | 'COMBUSTION_INSTABILITY'
  | 'INLET_UNSTART'
  | 'BEARING_OIL_STARVATION';

export function simulateTestCellSensors(
  twinState: EngineTwinState,
  activeFault: InjectableFaultType = 'NONE'
): { sensors: TestCellSensor[]; faults: FaultEvent[] } {
  const faults: FaultEvent[] = [];
  const sensors = INITIAL_TEST_SENSORS.map((s) => {
    let modelledVal = 0;
    if (s.tag === 'PT0') modelledVal = twinState.atmosphere.totalPressurePa / 1000;
    else if (s.tag === 'TT0') modelledVal = twinState.atmosphere.totalTempK;
    else if (s.tag === 'PT2') modelledVal = (twinState.stations.find((st) => st.stationId === '2')?.totalPressurePa || 100000) / 1000;
    else if (s.tag === 'TT2') modelledVal = twinState.stations.find((st) => st.stationId === '2')?.totalTempK || 400;
    else if (s.tag === 'PT3') modelledVal = (twinState.stations.find((st) => st.stationId === '3')?.totalPressurePa || 1000000) / 1000;
    else if (s.tag === 'TT3') modelledVal = twinState.stations.find((st) => st.stationId === '3')?.totalTempK || 800;
    else if (s.tag === 'T4_OPT') modelledVal = twinState.combustor.combustorExitTempT4K;
    else if (s.tag === 'PT5') modelledVal = (twinState.stations.find((st) => st.stationId === '5')?.totalPressurePa || 200000) / 1000;
    else if (s.tag === 'TT5') modelledVal = twinState.stations.find((st) => st.stationId === '5')?.totalTempK || 1300;
    else if (s.tag === 'TT7') modelledVal = twinState.stations.find((st) => st.stationId === '7')?.totalTempK || 1600;
    else if (s.tag === 'H2_MFM') modelledVal = twinState.thrust.totalH2FlowKgS;
    else if (s.tag === 'F_LOAD') modelledVal = twinState.thrust.netThrustN / 1000;
    else if (s.tag === 'VIB1') modelledVal = twinState.rotor.unbalanceVibrationMmS;
    else if (s.tag === 'VIB3') modelledVal = twinState.rotor.unbalanceVibrationMmS * 1.2;

    // Apply active fault effects to sensor channels
    let measuredVal = modelledVal + (Math.random() - 0.5) * s.uncertainty;
    let status: 'NOMINAL' | 'CALIBRATING' | 'DRIFT_WARNING' | 'OUT_OF_BOUNDS' = 'NOMINAL';

    if (activeFault === 'H2_FUEL_LEAK' && s.tag === 'H2_MFM') {
      measuredVal *= 1.18; // Extra flow detected due to downstream line breach
      status = 'OUT_OF_BOUNDS';
    } else if (activeFault === 'TBC_SPALLATION' && s.tag === 'T4_OPT') {
      measuredVal += 135.0; // Localized hot spot
      status = 'DRIFT_WARNING';
    } else if (activeFault === 'COMPRESSOR_FOULING' && s.tag === 'PT3') {
      measuredVal *= 0.88; // Drop in compressor pressure ratio
      status = 'DRIFT_WARNING';
    } else if (activeFault === 'INLET_UNSTART' && s.tag === 'PT2') {
      measuredVal *= 0.68; // Shock expulsion pressure drop
      status = 'OUT_OF_BOUNDS';
    } else if (activeFault === 'BEARING_OIL_STARVATION' && s.tag === 'VIB3') {
      measuredVal = 4.85; // High vibration > 4.5 mm/s ISO limit
      status = 'OUT_OF_BOUNDS';
    }

    return {
      ...s,
      modelledValue: Number(modelledVal.toFixed(3)),
      measuredValue: Number(measuredVal.toFixed(3)),
      calibratedValue: Number((measuredVal * 0.999).toFixed(3)),
      status,
    };
  });

  // Generate Fault Notifications if active
  if (activeFault === 'H2_FUEL_LEAK') {
    faults.push({
      id: 'FLT-001',
      timestamp: 'T+00:12:44.200',
      severity: 'CRITICAL',
      subsystem: 'FUEL_MANIFOLD',
      code: 'ERR_H2_DELTA_P_LOSS',
      message: 'Hydrogen manifold pressure drop 18% below commanded flow curve. Micro-leak detected in Sector 3 rail.',
      consequence: 'Risk of local combustor flame leaning and fuel accumulation in nacelle cavity.',
      mitigation: 'FADEC auto-isolated Sector 3 manifold branch; triggered inert N2 purge sequence.',
    });
  } else if (activeFault === 'TBC_SPALLATION') {
    faults.push({
      id: 'FLT-002',
      timestamp: 'T+00:18:02.110',
      severity: 'WARNING',
      subsystem: 'HPT_TURBINE',
      code: 'WRN_TBC_PYRO_HOTSPOT',
      message: 'Optical pyrometer detected +135K localized substrate thermal spike on HPT Blade #28.',
      consequence: 'Accelerated thermal fatigue and creep rupture accumulation on CMSX-4 substrate.',
      mitigation: 'FADEC derated max TIT by 60K; increased cooling bleed air schedule +1.5%.',
    });
  } else if (activeFault === 'INLET_UNSTART') {
    faults.push({
      id: 'FLT-003',
      timestamp: 'T+00:04:15.890',
      severity: 'CRITICAL',
      subsystem: 'SUPERSONIC_INLET',
      code: 'ERR_INLET_SHOCK_EXPULSION',
      message: 'Terminal normal shock wave expelled upstream of cowl lip. Pressure recovery dropped to 0.68.',
      consequence: 'Severe inlet flow distortion DC60 > 0.35, high dynamic hammer shock load.',
      mitigation: 'Active bypass doors opened 100%; inlet variable ramp angle pitched down 3.5 deg to re-swallow shock.',
    });
  } else if (activeFault === 'BEARING_OIL_STARVATION') {
    faults.push({
      id: 'FLT-004',
      timestamp: 'T+00:22:30.000',
      severity: 'CRITICAL',
      subsystem: 'ROTOR_BEARING',
      code: 'ERR_BRG3_VIB_EXCEEDED',
      message: 'Bearing #3 accelerometer reached 4.85 mm/s (> ISO 10816 Zone D trip threshold).',
      consequence: 'Hydrodynamic film breakdown, ceramic roller cage micro-spalling.',
      mitigation: 'Initiated controlled engine spool-down to IDLE mode; auxiliary scavenge pump engaged.',
    });
  }

  return { sensors, faults };
}
