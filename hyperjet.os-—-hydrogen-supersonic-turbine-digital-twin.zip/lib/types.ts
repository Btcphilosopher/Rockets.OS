// HYPERJET.OS — Core Data Types and Digital Twin Interfaces

export type FlightCondition = {
  altitudeM: number; // Altitude in meters (e.g. 16,764m = 55,000ft)
  mach: number; // Flight Mach number (Design cruise = 2.2)
  throttle: number; // Throttle lever angle 0.0 - 1.0
  reheatActive: boolean; // Hydrogen afterburner reheat engaged
  aircraftMassKg: number; // Airframe gross mass (e.g. 45,000 kg)
  aircraftCd: number; // Zero-lift + induced drag coefficient
  aircraftRefAreaM2: number; // Wing reference area S_ref (e.g. 120 m2)
  numEngines: number; // Typically 2 for supersonic transport / twin-jet
  inletAngleDeg: number; // Variable ramp deflection angle (e.g. 8.5 deg)
  compressorVsvDeg: number; // Variable stator vane schedule angle
  nozzleAreaRatio: number; // A9/A8 expansion ratio schedule
  h2StorageMode: 'cryogenic_liquid' | 'supercritical_gh2'; // LH2 (20K) vs GH2 (300bar)
};

export type AtmosphereState = {
  altitudeM: number;
  staticTempK: number;
  staticPressurePa: number;
  densityKgM3: number;
  speedOfSoundMs: number;
  dynamicPressurePa: number;
  totalTempK: number;
  totalPressurePa: number;
  totalDensityKgM3: number;
  viscosityPaS: number;
  gamma: number;
  gasConstantJkgK: number;
};

export type EngineStation = {
  stationId: string; // e.g., "0", "1", "2", "3", "4", "4.5", "5", "6", "7", "8", "9"
  name: string; // e.g., "Free-stream", "Inlet Throat", "Compressor Exit", etc.
  totalTempK: number;
  staticTempK: number;
  totalPressurePa: number;
  staticPressurePa: number;
  densityKgM3: number;
  mach: number;
  velocityMs: number;
  massFlowKgS: number;
  enthalpyKjKg: number;
  entropyKjKgK: number;
  areaM2: number;
};

export type InletPerformance = {
  inletType: '2D_mixed_compression_ramp' | 'axisymmetric_spike' | 'external_compression';
  shockAngleDeg: number;
  terminalShockMach: number;
  pressureRecoveryEta: number; // Total pressure recovery Pt2/Pt0
  captureAreaM2: number;
  spillageDragN: number;
  bleedFlowKgS: number;
  distortionIndexDC60: number;
  subsonicDiffuserEfficiency: number;
};

export type CompressorPerformance = {
  stages: number; // e.g. 6 stages
  pressureRatioCPR: number; // e.g. 12.5 at Mach 2.2
  isentropicEfficiency: number; // e.g. 0.885
  correctedFlowKgS: number;
  correctedRpmPercent: number;
  surgeMarginPercent: number;
  meanStageLoadingPsi: number;
  meanFlowCoeffPhi: number;
  bleedCoolingFlowKgS: number; // Bleed extracted for turbine cooling
  shaftPowerRequiredKw: number;
  operatingPointX: number; // Normalized flow on compressor map
  operatingPointY: number; // Normalized pressure ratio
};

export type HydrogenCombustorPerformance = {
  combustorType: 'micromix_lean_premix' | 'staged_diffusion' | 'ultra_lean_cavitating';
  fuelMassFlowKgS: number;
  equivalenceRatioPhi: number; // e.g. 0.38 (lean)
  adiabaticFlameTempK: number;
  combustorExitTempT4K: number; // Turbine Inlet Temperature (TIT)
  pressureLossDeltaPPercent: number; // e.g. 4.2%
  combustionEfficiencyEta: number; // e.g. 0.998
  heatReleaseRateMw: number; // LHV * fuelFlow
  thermalNOxEmissionPpm: number; // Hydrogen ultra-low NOx prediction
  unburnedH2SlipPpm: number;
  flameSpeedMs: number;
  flashbackSafetyIndex: number;
};

export type ChemicalEquilibrium = {
  moleFractions: {
    H2: number;
    O2: number;
    N2: number;
    H2O: number;
    OH: number;
    O: number;
    H: number;
    NO: number;
    NO2: number;
  };
  meanMolecularWeightGmol: number;
  specificHeatRatioGamma: number;
};

export type TurbinePerformance = {
  hptStages: number;
  lptStages: number;
  turbineInletTempK: number;
  expansionRatioTotal: number;
  isentropicEfficiency: number;
  hptShaftPowerKw: number;
  coolingAirFraction: number;
  bladeUncooledGasTempK: number;
  bladeMetalTempK: number;
  tbcCoatingDeltaTK: number; // Temperature drop across thermal barrier coating
  eulerWorkKjKg: number;
  shaftTorqueNm: number;
};

export type ReheatPerformance = {
  active: boolean;
  fuelMassFlowKgS: number;
  flameTempK: number;
  pressureLossPercent: number;
  thrustAugmentationRatio: number;
};

export type NozzlePerformance = {
  nozzleType: 'convergent_divergent_variable_iris';
  nozzlePressureRatioNPR: number;
  criticalNPR: number;
  isChoked: boolean;
  throatAreaA8M2: number;
  exitAreaA9M2: number;
  exitMach: number;
  exitStaticPressurePa: number;
  exitVelocityMs: number;
  grossThrustN: number;
  pressureThrustN: number;
  momentumThrustN: number;
};

export type ThrustAndEfficiency = {
  grossThrustN: number;
  ramDragN: number;
  netThrustN: number;
  requiredAircraftDragN: number;
  thrustMarginN: number;
  totalH2FlowKgS: number;
  tsfcGPerKns: number; // Thrust Specific Fuel Consumption (g/kN-s)
  specificImpulseSec: number; // Specific Impulse (s) = F_net / (m_dot_f * g0)
  specificThrustNsKg: number; // F_net / m_dot_air
  thermalEfficiency: number;
  propulsiveEfficiency: number;
  overallEfficiency: number;
  aircraftRangeEstimateKm: number;
};

export type RotorDynamicsState = {
  hpShaftRpm: number;
  lpShaftRpm: number;
  hpCriticalSpeed1Rpm: number;
  hpCriticalSpeed2Rpm: number;
  bearingLoadsN: [number, number, number, number]; // 4 main bearings
  unbalanceVibrationMmS: number; // ISO vibration severity
  torsionalNaturalFreqHz: number;
  shaftDeflectionMicrons: number;
};

export type ThermalNetworkState = {
  nodes: {
    id: string;
    name: string;
    temperatureK: number;
    gradientKPerMm: number;
    thermalStressMpa: number;
    materialLimitK: number;
  }[];
};

export type FadecState = {
  currentMode:
    | 'OFF'
    | 'PURGE'
    | 'LIGHT_OFF'
    | 'IDLE'
    | 'ACCEL'
    | 'CRUISE_SUBSONIC'
    | 'CRUISE_SUPERSONIC'
    | 'MACH_2_2_REHEAT'
    | 'DECEL'
    | 'SHUTDOWN_COOLDOWN'
    | 'EMERGENCY_SAFE_SHUTDOWN';
  actuatorPositions: {
    h2MainValvePercent: number;
    h2ReheatValvePercent: number;
    inletRampDeg: number;
    compressorVsvDeg: number;
    nozzleFlapA8A9Percent: number;
  };
  healthIndex: number; // 0.0 - 1.0 (100% nominal)
  faults: FaultEvent[];
};

export type FaultEvent = {
  id: string;
  timestamp: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  subsystem: string;
  code: string;
  message: string;
  consequence: string;
  mitigation: string;
};

// DIGITAL THREAD & EBOM/MBOM Interfaces

export type DigitalThreadNode = {
  id: string;
  partNumber: string;
  name: string;
  category: 'STRUCTURE' | 'AERODYNAMIC' | 'ROTATING' | 'COMBUSTION' | 'FUEL' | 'CONTROL' | 'METROLOGY' | 'FASTENER';
  revision: string;
  material: string;
  materialSpec: string;
  massKg: number;
  designRequirement: string;
  cadModelRef: string;
  manufacturingRoute: string[];
  machineToolId: string;
  assignedCell: string;
  gdtToleranceSpecs: {
    feature: string;
    nominalMm: number;
    plusToleranceMm: number;
    minusToleranceMm: number;
    measuredCmmMm: number;
    pass: boolean;
  }[];
  fastenerTorqueSpecNm?: number;
  fastenerTorqueMeasuredNm?: number;
  installedSerialNumber: string;
  batchHeatLotNumber: string;
  inspectionCertificateId: string;
  operatingHours: number;
  healthStatePercent: number;
  thermalCyclesCount: number;
  subcomponents?: DigitalThreadNode[];
};

export type FactoryCell = {
  id: string;
  name: string;
  type: 'MACHINING_5AXIS' | 'ADDITIVE_SLM' | 'HEAT_TREAT_VACUUM' | 'PLASMA_TBC' | 'METROLOGY_CMM' | 'CLEANROOM_ASSEMBLY' | 'ROTOR_BALANCING' | 'TEST_CELL';
  activePartId: string;
  status: 'RUNNING' | 'CALIBRATING' | 'IDLE' | 'MAINTENANCE';
  utilizationPercent: number;
  cycleTimeMin: number;
  queueCount: number;
  yieldPercent: number;
  powerKw: number;
  ambientTempC: number;
  operatorId: string;
};

export type TestCellSensor = {
  id: string;
  tag: string;
  name: string;
  station: string;
  physicalType: 'TEMPERATURE_TC' | 'PRESSURE_PIEZO' | 'FLOW_CORIOLIS' | 'THRUST_LOADCELL' | 'OPTICAL_PYROMETER' | 'VIBRATION_ACCEL';
  unit: string;
  measuredValue: number;
  modelledValue: number;
  calibratedValue: number;
  uncertainty: number;
  status: 'NOMINAL' | 'CALIBRATING' | 'DRIFT_WARNING' | 'OUT_OF_BOUNDS';
};

export type OptimizationGoal = {
  objective: 'MAX_NET_THRUST' | 'MIN_TSFC' | 'MAX_SURGE_MARGIN' | 'MIN_BLADE_TEMP' | 'MIN_FACTORY_COST' | 'MAX_MDO_EFFICIENCY';
  weight: number;
};

export type EngineTwinState = {
  flight: FlightCondition;
  atmosphere: AtmosphereState;
  stations: EngineStation[];
  inlet: InletPerformance;
  compressor: CompressorPerformance;
  combustor: HydrogenCombustorPerformance;
  equilibrium: ChemicalEquilibrium;
  turbine: TurbinePerformance;
  reheat: ReheatPerformance;
  nozzle: NozzlePerformance;
  thrust: ThrustAndEfficiency;
  rotor: RotorDynamicsState;
  thermal: ThermalNetworkState;
  fadec: FadecState;
  fidelityLevel: number; // Level 0 to Level 6
  simulationTimeSec: number;
};
