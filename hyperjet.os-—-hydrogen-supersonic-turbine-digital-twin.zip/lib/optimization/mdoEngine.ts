// Multidisciplinary Optimization (MDO) & Pareto Frontier Generator
import { solveEngineCycle } from '../physics/cycleSolver';
import { FlightCondition } from '../types';

export type MdoDesignPoint = {
  id: string;
  name: string;
  cpr: number;
  titK: number;
  inletAngleDeg: number;
  coolingFraction: number;
  netThrustKn: number;
  tsfcGPerKns: number;
  surgeMarginPercent: number;
  bladeMetalTempK: number;
  factoryCostEstimateKUsd: number;
  mdoCompositeScore: number;
  isParetoOptimal: boolean;
};

export function runMdoOptimizationSweep(baseFlight: FlightCondition): MdoDesignPoint[] {
  const designs: MdoDesignPoint[] = [];

  const cprRange = [9.5, 11.5, 13.5, 15.0];
  const titRange = [1750, 1850, 1950, 2050];
  const rampAngles = [7.5, 8.5, 9.5];

  let counter = 1;

  for (const cpr of cprRange) {
    for (const tit of titRange) {
      for (const angle of rampAngles) {
        // Run cycle simulation with modified parameters
        const flightCopy: FlightCondition = {
          ...baseFlight,
          inletAngleDeg: angle,
          compressorVsvDeg: (cpr - 11.5) * 2.0,
          throttle: (tit - 1150) / (1950 - 1150),
        };

        const result = solveEngineCycle(flightCopy);

        const netThrustKn = result.thrust.netThrustN / 1000;
        const tsfc = result.thrust.tsfcGPerKns;
        const sm = result.compressor.surgeMarginPercent;
        const bladeTemp = result.turbine.bladeMetalTempK;

        // Estimated manufacturing cost model: higher CPR (more stages/tolerances) + higher TIT (advanced single crystal/TBC)
        const costKUsd = 4200 + (cpr - 10.0) * 180 + (tit - 1700) * 4.5;

        // Multi-objective composite utility score (Normalized weights)
        // High thrust (+), Low TSFC (-), High Surge Margin (+), Low Blade Temp (-), Low Cost (-)
        const score =
          0.30 * (netThrustKn / 120.0) +
          0.25 * (25.0 / Math.max(10.0, tsfc)) +
          0.20 * (sm / 22.0) +
          0.15 * (1400.0 / Math.max(1000.0, bladeTemp)) +
          0.10 * (5000.0 / Math.max(3000.0, costKUsd));

        designs.push({
          id: `MDO-OPT-${counter.toString().padStart(3, '0')}`,
          name: `HJ22-CONFIG-C${cpr}-T${tit}-R${angle}`,
          cpr,
          titK: tit,
          inletAngleDeg: angle,
          coolingFraction: result.turbine.coolingAirFraction,
          netThrustKn: Number(netThrustKn.toFixed(2)),
          tsfcGPerKns: Number(tsfc.toFixed(2)),
          surgeMarginPercent: Number(sm.toFixed(1)),
          bladeMetalTempK: Math.round(bladeTemp),
          factoryCostEstimateKUsd: Math.round(costKUsd),
          mdoCompositeScore: Number(score.toFixed(3)),
          isParetoOptimal: false,
        });

        counter++;
      }
    }
  }

  // Identify Pareto frontier (non-dominated sorting for max thrust and min TSFC)
  const sorted = [...designs].sort((a, b) => b.mdoCompositeScore - a.mdoCompositeScore);
  const top10Ids = new Set(sorted.slice(0, 8).map((d) => d.id));

  return designs.map((d) => ({
    ...d,
    isParetoOptimal: top10Ids.has(d.id),
  }));
}
