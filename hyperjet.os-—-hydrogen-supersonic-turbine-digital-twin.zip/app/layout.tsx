import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'HYPERJET.OS — Hydrogen Supersonic Turbine Digital Twin (Mach 2.2)',
  description: 'Mach 2.2 Hydrogen-Fuelled Supersonic Propulsion Design, Cycle Simulator, Digital Thread, Manufacturing & Test Platform',
  openGraph: {
    title: 'HYPERJET.OS — Hydrogen Supersonic Turbine Digital Twin',
    description: 'Mach 2.2 Hydrogen-Fuelled Supersonic Propulsion Design, Cycle Simulator, Digital Thread, Manufacturing & Test Platform',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'HYPERJET.OS — Hydrogen Supersonic Turbine Digital Twin',
    description: 'Mach 2.2 Hydrogen Propulsion Engineering Digital Twin',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark">
      <body className="bg-[#0b0f17] text-[#d4dce8] antialiased selection:bg-amber-500/30 selection:text-amber-200 overflow-x-hidden" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
