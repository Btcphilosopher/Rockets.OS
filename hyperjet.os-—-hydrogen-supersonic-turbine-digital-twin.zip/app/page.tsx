'use client';

import React, { useState, useMemo, useEffect } from 'react';
import { solveEngineCycle } from '../lib/physics/cycleSolver';
import { FlightCondition, EngineTwinState } from '../lib/types';
import EngineTwinView from '../components/modules/EngineTwinView';
import ThermodynamicsView from '../components/modules/ThermodynamicsView';
import InletShockView from '../components/modules/InletShockView';
import CombustionView from '../components/modules/CombustionView';
import TurbomachineryView from '../components/modules/TurbomachineryView';
import DigitalThreadView from '../components/modules/DigitalThreadView';
import ManufacturingView from '../components/modules/ManufacturingView';
import TestCellView from '../components/modules/TestCellView';
import MdoOptimizationView from '../components/modules/MdoOptimizationView';
import EngineeringReportView from '../components/modules/EngineeringReportView';

import {
  Activity,
  Award,
  BookOpen,
  Compass,
  Cpu,
  Database,
  Factory,
  FileText,
  Flame,
  Gauge,
  Layers,
  Pause,
  Play,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  Wind,
  Zap,
} from 'lucide-react';

type ModuleTab =
  | '3D_TWIN'
  | 'THERMODYNAMICS'
  | 'INLET_SHOCK'
  | 'COMBUSTION'
  | 'TURBOMACHINERY'
  | 'DIGITAL_THREAD'
  | 'MANUFACTURING'
  | 'TEST_CELL'
  | 'MDO'
  | 'REPORT';

const MISSION_PRESETS: Record<string, FlightCondition> = {
  'M2.2_CRUISE': {
    mach: 2.2,
    altitudeM: 18500,
    throttle: 0.92,
    inletAngleDeg: 8.5,
    compressorVsvDeg: 0.0,
    reheatActive: false,
    nozzleAreaRatio: 1.85,
    aircraftMassKg: 45000,
    aircraftCd: 0.0185,
    aircraftRefAreaM2: 120,
    numEngines: 2,
    h2StorageMode: 'cryogenic_liquid',
  },
  'TRANSONIC_ACCEL': {
    mach: 1.15,
    altitudeM: 9000,
    throttle: 1.0,
    inletAngleDeg: 5.5,
    compressorVsvDeg: -4.0,
    reheatActive: true,
    nozzleAreaRatio: 1.35,
    aircraftMassKg: 45000,
    aircraftCd: 0.0240,
    aircraftRefAreaM2: 120,
    numEngines: 2,
    h2StorageMode: 'cryogenic_liquid',
  },
  'HIGH_ALT_DASH': {
    mach: 2.5,
    altitudeM: 21000,
    throttle: 1.0,
    inletAngleDeg: 10.5,
    compressorVsvDeg: 2.0,
    reheatActive: true,
    nozzleAreaRatio: 2.2,
    aircraftMassKg: 42000,
    aircraftCd: 0.0175,
    aircraftRefAreaM2: 120,
    numEngines: 2,
    h2StorageMode: 'cryogenic_liquid',
  },
  'SEA_LEVEL_TAKEOFF': {
    mach: 0.25,
    altitudeM: 0,
    throttle: 1.0,
    inletAngleDeg: 4.0,
    compressorVsvDeg: -8.0,
    reheatActive: true,
    nozzleAreaRatio: 1.15,
    aircraftMassKg: 48000,
    aircraftCd: 0.0280,
    aircraftRefAreaM2: 120,
    numEngines: 2,
    h2StorageMode: 'cryogenic_liquid',
  },
  'SUBSONIC_LOITER': {
    mach: 0.78,
    altitudeM: 11000,
    throttle: 0.65,
    inletAngleDeg: 4.0,
    compressorVsvDeg: -6.0,
    reheatActive: false,
    nozzleAreaRatio: 1.25,
    aircraftMassKg: 40000,
    aircraftCd: 0.0160,
    aircraftRefAreaM2: 120,
    numEngines: 2,
    h2StorageMode: 'cryogenic_liquid',
  },
};

export default function HomePage() {
  const [activeTab, setActiveTab] = useState<ModuleTab>('3D_TWIN');
  const [flight, setFlight] = useState<FlightCondition>(MISSION_PRESETS['M2.2_CRUISE']);
  const [viewMode, setViewMode] = useState<'CUTAWAY' | 'THERMAL' | 'AIRFLOW' | 'MANUFACTURING' | 'EXTERIOR' | 'EXPLODED'>('CUTAWAY');
  const [selectedComponentId, setSelectedComponentId] = useState<string | null>('MOD-COMPRESSOR');
  const [isSimRunning, setIsSimRunning] = useState<boolean>(true);
  const [activePreset, setActivePreset] = useState<string>('M2.2_CRUISE');

  // Compute live physics digital twin state
  const twinState: EngineTwinState = useMemo(() => {
    return solveEngineCycle(flight);
  }, [flight]);

  const updateFlight = (partial: Partial<FlightCondition>) => {
    setFlight((prev) => ({ ...prev, ...partial }));
    setActivePreset('CUSTOM');
  };

  const handleApplyPreset = (key: string) => {
    if (MISSION_PRESETS[key]) {
      setFlight(MISSION_PRESETS[key]);
      setActivePreset(key);
    }
  };

  const handleSelectComponent = (componentId: string) => {
    setSelectedComponentId(componentId);
    setActiveTab('DIGITAL_THREAD');
  };

  return (
    <div className="min-h-screen bg-[#0C0C0C] text-[#E6E6E6] flex flex-col font-sans selection:bg-[#F2A200] selection:text-black">
      {/* Top Engineering Command Header - High Density Aesthetic */}
      <header className="sticky top-0 z-50 bg-[#0C0C0C] border-b border-[#2A2A2A] px-3 lg:px-5 py-2 flex flex-wrap items-center justify-between gap-2 shadow-xl">
        {/* Left: Branding & Core Twin Identity */}
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 bg-[#141414] border border-[#F2A200] flex items-center justify-center font-mono font-black text-[#F2A200] text-xs shadow-sm">
            HJ
          </div>
          <div className="flex items-center gap-2">
            <span className="font-mono text-sm font-extrabold tracking-widest text-[#E6E6E6] uppercase">
              HYPERJET.OS
            </span>
            <span className="font-mono text-[9px] px-2 py-0.5 border border-[#F2A200] text-[#F2A200] tracking-wider uppercase font-semibold hidden sm:inline-block">
              FIDELITY LEVEL 4: ENGINEERING DIGITAL TWIN
            </span>
          </div>
        </div>

        {/* Center: Mission Profile Quick Switcher */}
        <div className="flex items-center gap-1 bg-[#141414] p-1 border border-[#2A2A2A] overflow-x-auto">
          <span className="text-[9px] font-mono text-[#666666] px-1.5 uppercase font-bold">MISSION:</span>
          {[
            { key: 'M2.2_CRUISE', label: 'M2.2 CRUISE' },
            { key: 'TRANSONIC_ACCEL', label: 'TRANSONIC' },
            { key: 'HIGH_ALT_DASH', label: 'M2.5 DASH' },
            { key: 'SEA_LEVEL_TAKEOFF', label: 'TAKEOFF' },
            { key: 'SUBSONIC_LOITER', label: 'LOITER' },
          ].map((preset) => (
            <button
              key={preset.key}
              id={`btn-preset-${preset.key.toLowerCase()}`}
              onClick={() => handleApplyPreset(preset.key)}
              className={`px-2 py-0.5 text-[10px] font-mono transition-all whitespace-nowrap ${
                activePreset === preset.key
                  ? 'bg-[#F2A200] text-black font-bold'
                  : 'text-[#888888] hover:text-[#E6E6E6] hover:bg-[#1E1E1E]'
              }`}
            >
              {preset.label}
            </button>
          ))}
        </div>

        {/* Right: Live Telemetry HUD Strip */}
        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="hidden sm:flex flex-col items-end border-r border-[#2A2A2A] pr-3">
            <span className="text-[9px] text-[#666666] uppercase">Fn (Net Thrust)</span>
            <span className="text-[#00FF41] font-bold text-xs font-mono-num">
              {(twinState.thrust.netThrustN / 1000).toFixed(1)} kN
            </span>
          </div>

          <div className="hidden md:flex flex-col items-end border-r border-[#2A2A2A] pr-3">
            <span className="text-[9px] text-[#666666] uppercase">TIT (Station 4)</span>
            <span className="text-[#F2A200] font-bold text-xs font-mono-num">
              {twinState.combustor.combustorExitTempT4K} K
            </span>
          </div>

          <div className="hidden lg:flex flex-col items-end border-r border-[#2A2A2A] pr-3">
            <span className="text-[9px] text-[#666666] uppercase">Surge Margin</span>
            <span className="text-[#38BDF8] font-bold text-xs font-mono-num">
              {twinState.compressor.surgeMarginPercent}%
            </span>
          </div>

          <div className="flex items-center gap-1.5 pl-1 text-[10px] font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00FF41] animate-pulse" />
            <span className="text-[#00FF41] font-bold tracking-wider">● SYSTEMS SYNCED</span>
          </div>
        </div>
      </header>

      {/* Main Tab Navigation Bar - High Density Bar */}
      <nav className="bg-[#101010] border-b border-[#2A2A2A] px-2 lg:px-4 py-1 overflow-x-auto flex items-center gap-1 shadow-sm">
        {[
          { id: '3D_TWIN', label: '3D ENGINE TWIN', icon: Layers },
          { id: 'THERMODYNAMICS', label: 'THERMODYNAMICS & CYCLE', icon: Activity },
          { id: 'INLET_SHOCK', label: 'SUPERSONIC INLET & SHOCKS', icon: Wind },
          { id: 'COMBUSTION', label: 'H2 COMBUSTION', icon: Flame },
          { id: 'TURBOMACHINERY', label: 'TURBOMACHINERY & ROTOR', icon: Gauge },
          { id: 'DIGITAL_THREAD', label: 'DIGITAL THREAD (EBOM/MBOM)', icon: Database },
          { id: 'MANUFACTURING', label: 'MANUFACTURING & GD&T', icon: Factory },
          { id: 'TEST_CELL', label: 'TEST CELL & FAULTS', icon: ShieldCheck },
          { id: 'MDO', label: 'MDO & OPTIMIZATION', icon: TrendingUp },
          { id: 'REPORT', label: 'CERTIFICATION REPORT', icon: FileText },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`tab-${tab.id.toLowerCase()}`}
              onClick={() => setActiveTab(tab.id as ModuleTab)}
              className={`flex items-center gap-1.5 px-2.5 py-1 font-mono text-[11px] transition-all whitespace-nowrap border-b-2 ${
                isActive
                  ? 'bg-[#181818] border-[#F2A200] text-[#F2A200] font-bold'
                  : 'border-transparent text-[#888888] hover:text-[#E6E6E6] hover:bg-[#141414]'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#F2A200]' : 'text-[#666666]'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Main Workspace Dynamic Module Content */}
      <main className="flex-1 p-3 lg:p-4 max-w-[1600px] w-full mx-auto">
        {activeTab === '3D_TWIN' && (
          <EngineTwinView
            twinState={twinState}
            viewMode={viewMode}
            setViewMode={setViewMode}
            selectedComponentId={selectedComponentId}
            onSelectComponent={handleSelectComponent}
            onUpdateFlight={updateFlight}
          />
        )}

        {activeTab === 'THERMODYNAMICS' && (
          <ThermodynamicsView twinState={twinState} />
        )}

        {activeTab === 'INLET_SHOCK' && (
          <InletShockView twinState={twinState} onUpdateFlight={updateFlight} />
        )}

        {activeTab === 'COMBUSTION' && (
          <CombustionView twinState={twinState} />
        )}

        {activeTab === 'TURBOMACHINERY' && (
          <TurbomachineryView twinState={twinState} />
        )}

        {activeTab === 'DIGITAL_THREAD' && (
          <DigitalThreadView
            selectedComponentId={selectedComponentId}
            onSelectComponent={setSelectedComponentId}
          />
        )}

        {activeTab === 'MANUFACTURING' && (
          <ManufacturingView />
        )}

        {activeTab === 'TEST_CELL' && (
          <TestCellView twinState={twinState} />
        )}

        {activeTab === 'MDO' && (
          <MdoOptimizationView twinState={twinState} />
        )}

        {activeTab === 'REPORT' && (
          <EngineeringReportView twinState={twinState} />
        )}
      </main>

      {/* Global Engineering Status Footer - High Density */}
      <footer className="bg-[#080808] border-t border-[#2A2A2A] px-3 lg:px-5 py-2 text-[#666666] font-mono text-[10px] flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-3">
          <span className="text-[#888888] font-bold">&copy; 2024 ANGLO-FUTURIST AEROSPACE — HYPERJET.OS v3.8.4</span>
          <span>|</span>
          <span className="text-[#666666]">ISA 1976 + OBLIQUE SHOCK EXACT MODEL</span>
          <span>|</span>
          <span className="text-[#F2A200]">H2 CRYO PROPELLANT (120.0 MJ/kg)</span>
        </div>
        <div className="flex items-center gap-3">
          <span>LATENCY: 4.2ms</span>
          <span>|</span>
          <span>NODE: UK-LAB-01</span>
          <span>|</span>
          <span className="text-[#00FF41] font-bold">● SYSTEMS SYNCED</span>
        </div>
      </footer>
    </div>
  );
}
