'use client';

import React from 'react';
import { EngineTwinState } from '../../lib/types';
import { Flame, ShieldCheck, Zap, AlertTriangle, CheckCircle } from 'lucide-react';

interface CombustionViewProps {
  twinState: EngineTwinState;
}

export default function CombustionView({ twinState }: CombustionViewProps) {
  const { combustor, equilibrium } = twinState;

  const speciesList = [
    { species: 'H2O', name: 'Water Vapour (Exhaust)', moleFraction: equilibrium.moleFractions.H2O },
    { species: 'N2', name: 'Nitrogen (Inert Carrier)', moleFraction: equilibrium.moleFractions.N2 },
    { species: 'O2', name: 'Excess Oxygen (Lean)', moleFraction: equilibrium.moleFractions.O2 },
    { species: 'OH', name: 'Hydroxyl Radical', moleFraction: equilibrium.moleFractions.OH },
    { species: 'H2', name: 'Unburned Hydrogen Slip', moleFraction: equilibrium.moleFractions.H2 },
    { species: 'NO', name: 'Nitric Oxide', moleFraction: equilibrium.moleFractions.NO },
    { species: 'NO2', name: 'Nitrogen Dioxide', moleFraction: equilibrium.moleFractions.NO2 },
  ];

  return (
    <div className="flex flex-col gap-3">
      {/* Top Banner Metric Cards - High Density Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Equivalence Ratio (Φ)</span>
          <div className="text-xl font-bold font-mono text-[#38BDF8] mt-0.5 font-mono-num">
            {combustor.equivalenceRatioPhi.toFixed(3)}
          </div>
          <span className="text-[9px] text-[#00FF41] font-mono">Ultra-Lean Premixed (0.35-0.55)</span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Thermal NOx Emission</span>
          <div className="text-xl font-bold font-mono text-[#00FF41] mt-0.5 font-mono-num">
            {combustor.thermalNOxEmissionPpm.toFixed(2)} ppm
          </div>
          <span className="text-[9px] text-[#888888] font-mono">CAEP/10 Compliant (&lt; 5.0 ppm)</span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Laminar Flame Speed (S_L)</span>
          <div className="text-xl font-bold font-mono text-[#F2A200] mt-0.5 font-mono-num">
            {combustor.flameSpeedMs.toFixed(2)} m/s
          </div>
          <span className="text-[9px] text-[#888888] font-mono">Sonic Injection: 120 m/s</span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Heat Release Rate (Q_dot)</span>
          <div className="text-xl font-bold font-mono text-[#E6E6E6] mt-0.5 font-mono-num">
            {combustor.heatReleaseRateMw} MW
          </div>
          <span className="text-[9px] text-[#888888] font-mono">Efficiency: {(combustor.combustionEfficiencyEta * 100).toFixed(1)}%</span>
        </div>
      </div>

      {/* Micromix Hydrogen Injector Architecture & Chemical Equilibrium Mole Fractions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Left: Chemical Equilibrium Mole Fractions Matrix (6 cols) */}
        <div className="lg:col-span-6 bg-[#141414] border border-[#2A2A2A] p-3 flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-1.5">
            <div className="flex items-center gap-2">
              <Flame className="w-3.5 h-3.5 text-[#F2A200]" />
              <span className="font-mono text-[10px] font-bold text-[#E6E6E6] uppercase tracking-wider">
                COMBUSTION PRODUCTS CHEMICAL EQUILIBRIUM
              </span>
            </div>
            <span className="text-[9px] font-mono text-[#00FF41]">● ZERO CARBON / ZERO SOx</span>
          </div>

          <div className="flex flex-col gap-2 font-mono text-[11px]">
            {speciesList.map((sp) => {
              const percent = sp.moleFraction * 100;
              return (
                <div key={sp.species} className="flex flex-col gap-0.5">
                  <div className="flex justify-between items-center text-[#888888]">
                    <span className="font-bold text-[#E6E6E6]">{sp.species} ({sp.name})</span>
                    <span className="text-[#38BDF8] font-mono-num font-bold">
                      {percent >= 0.01 ? `${percent.toFixed(2)}%` : `${(sp.moleFraction * 1e6).toFixed(1)} ppm`}
                    </span>
                  </div>
                  <div className="w-full bg-[#080808] h-1.5 overflow-hidden border border-[#2A2A2A]">
                    <div
                      className={`h-full transition-all duration-500 ${
                        sp.species === 'H2O'
                          ? 'bg-[#38BDF8]'
                          : sp.species === 'N2'
                          ? 'bg-[#888888]'
                          : sp.species === 'O2'
                          ? 'bg-[#00FF41]'
                          : sp.species === 'NO' || sp.species === 'NO2'
                          ? 'bg-[#F2A200]'
                          : 'bg-[#00FF41]'
                      }`}
                      style={{ width: `${Math.min(100, Math.max(2, percent * 1.3))}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A] text-[10px] font-mono text-[#888888]">
            <span className="text-[#E6E6E6] font-bold">H2 Combustion Stoichiometry:</span>
            <p className="mt-0.5 text-[#CCCCCC]">
              2 H₂ + (O₂ + 3.76 N₂) → 2 H₂O + 3.76 N₂ + 241.8 kJ/mol
            </p>
          </div>
        </div>

        {/* Right: Flashback Protection & Micromix Sonic Injection Physics (6 cols) */}
        <div className="lg:col-span-6 bg-[#141414] border border-[#2A2A2A] p-3 flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-1.5">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-3.5 h-3.5 text-[#00FF41]" />
              <span className="font-mono text-[10px] font-bold text-[#E6E6E6] uppercase tracking-wider">
                MICROMIX FLASHBACK SAFETY & THERMAL NOX
              </span>
            </div>
            <span className="text-[9px] font-mono border border-[#00FF41] text-[#00FF41] px-1.5 py-0.5 font-bold">
              MARGIN 50x
            </span>
          </div>

          <div className="bg-[#0C0C0C] p-3 border border-[#2A2A2A] flex flex-col gap-2 font-mono text-[10px]">
            <div className="flex justify-between border-b border-[#1E1E1E] pb-1.5">
              <span className="text-[#888888]">H2 Jet Injection Velocity:</span>
              <span className="text-[#00FF41] font-bold font-mono-num">120.0 m/s (Sonic Choked)</span>
            </div>
            <div className="flex justify-between border-b border-[#1E1E1E] pb-1.5">
              <span className="text-[#888888]">Laminar Flame Speed:</span>
              <span className="text-[#F2A200] font-bold font-mono-num">{combustor.flameSpeedMs.toFixed(2)} m/s</span>
            </div>
            <div className="flex justify-between border-b border-[#1E1E1E] pb-1.5">
              <span className="text-[#888888]">Flashback Safety Margin:</span>
              <span className="text-[#38BDF8] font-bold font-mono-num">
                {(120.0 / Math.max(0.1, combustor.flameSpeedMs)).toFixed(0)}x Margin
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#888888]">Combustor Liner Material:</span>
              <span className="text-[#E6E6E6] font-bold">C/C-SiC Ceramic Matrix Composite</span>
            </div>
          </div>

          <div className="bg-[#0C0C0C] p-2.5 border border-[#2A2A2A] text-[10px] font-mono flex flex-col gap-1 text-[#888888]">
            <span className="text-[#F2A200] font-bold text-[10px]">Extended Zeldovich Thermal NOx Mechanism:</span>
            <p className="text-[9px] text-[#CCCCCC]">
              d[NO]/dt = 2 k1 [O][N2] where k1 = 1.8 × 10⁸ exp(-38370 / T) m³/(kmol·s)
            </p>
            <p className="text-[9px] text-[#888888]">
              Because micromix diffusion flame residence time is &lt; 0.4 ms, thermal NOx is suppressed to {combustor.thermalNOxEmissionPpm.toFixed(2)} ppm.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
