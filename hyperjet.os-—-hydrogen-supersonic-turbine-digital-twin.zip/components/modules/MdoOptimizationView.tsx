'use client';

import React, { useState } from 'react';
import { EngineTwinState } from '../../lib/types';
import { runMdoOptimizationSweep, MdoDesignPoint } from '../../lib/optimization/mdoEngine';
import { Award, BarChart3, CheckCircle2, ChevronRight, Gauge, Layers, Sparkles, TrendingUp, Zap } from 'lucide-react';

interface MdoOptimizationViewProps {
  twinState: EngineTwinState;
}

export default function MdoOptimizationView({ twinState }: MdoOptimizationViewProps) {
  const [designs] = useState<MdoDesignPoint[]>(() => runMdoOptimizationSweep(twinState.flight));
  const [selectedPointId, setSelectedPointId] = useState<string>(designs[0]?.id || '');

  const selectedPoint = designs.find((d) => d.id === selectedPointId) || designs[0];

  return (
    <div className="flex flex-col gap-3">
      {/* Top Banner */}
      <div className="bg-[#141414] border border-[#2A2A2A] p-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 bg-[#1A1405] border border-[#F2A200] text-[#F2A200]">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-mono text-xs font-bold text-[#E6E6E6] uppercase tracking-wider">
              MULTIDISCIPLINARY DESIGN OPTIMIZATION (MDO) & PARETO FRONTIER
            </h3>
            <p className="text-[10px] text-[#888888]">
              Simultaneous optimization of Aerodynamics, Thermodynamic Cycle, Hydrogen Combustion, Creep, and Cost
            </p>
          </div>
        </div>
        <span className="text-[9px] font-mono text-[#00FF41] border border-[#00FF41] px-2 py-0.5 font-bold">
          {designs.length} DESIGNS EVALUATED
        </span>
      </div>

      {/* Main 2-Column Split View: Pareto Frontier Scatter Plot (7 cols) & Design Inspector (5 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Left: Interactive Pareto Frontier Scatter Plot (7 cols) */}
        <div className="lg:col-span-7 bg-[#141414] border border-[#2A2A2A] p-3 flex flex-col gap-2">
          <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-1.5">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-3.5 h-3.5 text-[#F2A200]" />
              <span className="font-mono text-[10px] font-bold text-[#E6E6E6] uppercase tracking-wider">
                PARETO FRONTIER: NET THRUST (FN) VS TSFC VS COST
              </span>
            </div>
            <span className="text-[9px] font-mono text-[#F2A200]">● GOLD = PARETO OPTIMAL</span>
          </div>

          {/* Scatter Plot SVG */}
          <div className="h-60 w-full bg-[#080808] p-2 relative flex items-center justify-center border border-[#2A2A2A]">
            <svg viewBox="0 0 500 240" className="w-full h-full">
              {/* Axes */}
              <line x1="50" y1="200" x2="470" y2="200" stroke="#2A2A2A" strokeWidth="1.5" />
              <line x1="50" y1="20" x2="50" y2="200" stroke="#2A2A2A" strokeWidth="1.5" />

              <text x="400" y="225" fill="#666666" fontSize="9" fontFamily="monospace">Net Thrust Fn (kN)</text>
              <text x="15" y="30" fill="#666666" fontSize="9" fontFamily="monospace" transform="rotate(-90, 15, 30)">TSFC (g/kN-s)</text>

              {/* Data Points */}
              {designs.map((d) => {
                const cx = 60 + ((d.netThrustKn - 80) / 60) * 400;
                const cy = 185 - ((d.tsfcGPerKns - 10) / 15) * 150;
                const isSelected = d.id === selectedPoint.id;

                return (
                  <g
                    key={d.id}
                    onClick={() => setSelectedPointId(d.id)}
                    className="cursor-pointer"
                  >
                    <circle
                      cx={cx}
                      cy={cy}
                      r={isSelected ? 6 : d.isParetoOptimal ? 5 : 3}
                      fill={d.isParetoOptimal ? '#F2A200' : '#38BDF8'}
                      stroke={isSelected ? '#FFFFFF' : d.isParetoOptimal ? '#F2A200' : '#1E40AF'}
                      strokeWidth={isSelected ? 2 : 1}
                      opacity={d.isParetoOptimal || isSelected ? 1 : 0.6}
                    />
                  </g>
                );
              })}
            </svg>
          </div>

          <div className="flex justify-between text-[10px] font-mono text-[#888888]">
            <span>Selected Config: <strong className="text-[#38BDF8]">{selectedPoint.name}</strong></span>
            <span>Composite Score: <strong className="text-[#F2A200]">{selectedPoint.mdoCompositeScore}</strong></span>
          </div>
        </div>

        {/* Right: Selected Design Detailed Breakdown (5 cols) */}
        <div className="lg:col-span-5 bg-[#141414] border border-[#2A2A2A] p-3 flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-1.5">
            <div>
              <span className="text-[9px] font-mono text-[#F2A200] font-bold">{selectedPoint.id}</span>
              <h4 className="font-mono text-xs font-bold text-[#E6E6E6]">{selectedPoint.name}</h4>
            </div>
            {selectedPoint.isParetoOptimal && (
              <span className="text-[9px] font-mono text-[#F2A200] border border-[#F2A200] px-1.5 py-0.5 flex items-center gap-1 font-bold">
                <Award className="w-3 h-3" />
                PARETO
              </span>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2 font-mono text-[10px]">
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] text-[8px] block uppercase">COMPRESSOR CPR</span>
              <span className="text-[#38BDF8] font-bold">{selectedPoint.cpr.toFixed(1)} : 1</span>
            </div>
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] text-[8px] block uppercase">TURBINE TIT</span>
              <span className="text-[#F2A200] font-bold">{selectedPoint.titK} K</span>
            </div>
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] text-[8px] block uppercase">NET THRUST (FN)</span>
              <span className="text-[#00FF41] font-bold">{selectedPoint.netThrustKn} kN</span>
            </div>
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] text-[8px] block uppercase">TSFC</span>
              <span className="text-[#38BDF8] font-bold">{selectedPoint.tsfcGPerKns} g/kN-s</span>
            </div>
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] text-[8px] block uppercase">SURGE MARGIN</span>
              <span className="text-[#00FF41] font-bold">{selectedPoint.surgeMarginPercent}%</span>
            </div>
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] text-[8px] block uppercase">BLADE METAL TEMP</span>
              <span className="text-[#F2A200] font-bold">{selectedPoint.bladeMetalTempK} K</span>
            </div>
          </div>

          <div className="bg-[#0C0C0C] p-2.5 border border-[#2A2A2A] flex justify-between items-center font-mono text-[10px]">
            <span className="text-[#888888]">Estimated Unit Cost:</span>
            <span className="text-[#E6E6E6] font-bold font-mono-num">
              ${(selectedPoint.factoryCostEstimateKUsd / 1000).toFixed(2)}M USD
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
