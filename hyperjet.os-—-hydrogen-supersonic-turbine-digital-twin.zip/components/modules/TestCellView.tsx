'use client';

import React, { useState } from 'react';
import { EngineTwinState } from '../../lib/types';
import { simulateTestCellSensors, InjectableFaultType } from '../../lib/testCell/testEngine';
import { Activity, AlertOctagon, AlertTriangle, CheckCircle2, Cpu, Gauge, RefreshCw, ShieldAlert, Zap } from 'lucide-react';

interface TestCellViewProps {
  twinState: EngineTwinState;
}

export default function TestCellView({ twinState }: TestCellViewProps) {
  const [activeFault, setActiveFault] = useState<InjectableFaultType>('NONE');

  const { sensors, faults } = simulateTestCellSensors(twinState, activeFault);

  return (
    <div className="flex flex-col gap-3">
      {/* Top Banner Metric Cards - High Density Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Sensors Instrumented</span>
          <div className="text-xl font-bold font-mono text-[#38BDF8] mt-0.5 font-mono-num">
            {sensors.length} CHANNELS
          </div>
          <span className="text-[9px] text-[#00FF41] font-mono">100% Calibrated & Active</span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">FADEC Redundancy</span>
          <div className="text-xl font-bold font-mono text-[#00FF41] mt-0.5 font-mono-num">
            DUAL CHANNEL A/B
          </div>
          <span className="text-[9px] text-[#888888] font-mono">DO-178C Level A</span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Active Test Bed Faults</span>
          <div className="text-xl font-bold font-mono mt-0.5 font-mono-num flex items-center gap-1.5">
            <span className={faults.length > 0 ? 'text-[#FF4D4D]' : 'text-[#00FF41]'}>
              {faults.length} FAULT{faults.length === 1 ? '' : 'S'}
            </span>
          </div>
          <span className="text-[9px] text-[#888888] font-mono">
            {activeFault === 'NONE' ? 'Nominal Baseline Run' : activeFault}
          </span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Test Stand Thrust Load</span>
          <div className="text-xl font-bold font-mono text-[#F2A200] mt-0.5 font-mono-num">
            {(twinState.thrust.netThrustN / 1000).toFixed(1)} kN
          </div>
          <span className="text-[9px] text-[#888888] font-mono">Pyramidal Load Bed</span>
        </div>
      </div>

      {/* Fault Injection Console */}
      <div className="bg-[#141414] border border-[#2A2A2A] p-3 flex flex-col gap-2">
        <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-1.5">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-3.5 h-3.5 text-[#F2A200]" />
            <h3 className="font-mono text-[10px] font-bold text-[#E6E6E6] uppercase tracking-wider">
              REAL-TIME AEROSPACE FAULT INJECTION & SAFETY CONTAINMENT
            </h3>
          </div>
          <span className="text-[9px] font-mono text-[#666666]">SELECT FAULT TO INJECT</span>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {[
            { id: 'NONE', label: 'NOMINAL (NO FAULT)' },
            { id: 'H2_FUEL_LEAK', label: 'H2 FUEL RAIL MICRO-LEAK' },
            { id: 'TBC_SPALLATION', label: 'HPT BLADE TBC SPALLATION' },
            { id: 'INLET_UNSTART', label: 'INLET SHOCK EXPULSION (UNSTART)' },
            { id: 'COMPRESSOR_FOULING', label: 'COMPRESSOR TIP FOULING' },
            { id: 'BEARING_OIL_STARVATION', label: 'BEARING #3 OIL STARVATION' },
          ].map((f) => (
            <button
              key={f.id}
              id={`btn-fault-${f.id.toLowerCase()}`}
              onClick={() => setActiveFault(f.id as InjectableFaultType)}
              className={`px-2.5 py-1 text-[10px] font-mono font-bold transition-all ${
                activeFault === f.id
                  ? f.id === 'NONE'
                    ? 'bg-[#00FF41] text-[#000000] border border-[#00FF41]'
                    : 'bg-[#FF4D4D] text-[#FFFFFF] border border-[#FF4D4D]'
                  : 'bg-[#0C0C0C] text-[#888888] hover:text-[#E6E6E6] border border-[#2A2A2A]'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Active Fault Diagnostic Alert Banner */}
        {faults.length > 0 && (
          <div className="mt-1 bg-[#1A0A0A] border border-[#FF4D4D] p-3 flex flex-col gap-1.5 font-mono text-[10px]">
            {faults.map((flt) => (
              <div key={flt.id} className="flex flex-col gap-1">
                <div className="flex items-center justify-between text-[#FF4D4D] font-bold">
                  <span className="flex items-center gap-1.5">
                    <AlertOctagon className="w-3.5 h-3.5 text-[#FF4D4D]" />
                    {flt.code} • {flt.subsystem}
                  </span>
                  <span className="text-[9px] text-[#FF8888]">{flt.timestamp}</span>
                </div>
                <p className="text-[#E6E6E6] font-sans text-[11px]">{flt.message}</p>
                <div className="text-[10px] text-[#F2A200]">
                  <span className="font-bold">CONSEQUENCE:</span> {flt.consequence}
                </div>
                <div className="text-[10px] text-[#00FF41]">
                  <span className="font-bold">FADEC AUTO-MITIGATION:</span> {flt.mitigation}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 14 Instrumented Test Stand Sensors Matrix */}
      <div className="bg-[#141414] border border-[#2A2A2A] p-3 flex flex-col gap-2">
        <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-1.5">
          <div className="flex items-center gap-2">
            <Activity className="w-3.5 h-3.5 text-[#F2A200]" />
            <h3 className="font-mono text-[10px] font-bold text-[#E6E6E6] uppercase tracking-wider">
              TEST STAND INSTRUMENTED SENSOR ARRAY (PHYSICAL DAQ VS PHYSICS MODEL)
            </h3>
          </div>
          <span className="text-[9px] font-mono text-[#666666]">20 MS DAQ RATE</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-[10px] border-collapse">
            <thead>
              <tr className="border-b border-[#2A2A2A] text-[#666666] bg-[#0C0C0C]">
                <th className="py-2 px-2.5">Tag</th>
                <th className="py-2 px-2.5">Sensor Description</th>
                <th className="py-2 px-2.5">Station</th>
                <th className="py-2 px-2.5">Type</th>
                <th className="py-2 px-2.5">Modelled</th>
                <th className="py-2 px-2.5">Measured</th>
                <th className="py-2 px-2.5">Calibrated</th>
                <th className="py-2 px-2.5">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E1E1E] font-mono-num">
              {sensors.map((s) => (
                <tr key={s.id} className="hover:bg-[#1A1A1A] transition-colors">
                  <td className="py-2 px-2.5 font-bold text-[#F2A200]">{s.tag}</td>
                  <td className="py-2 px-2.5 text-[#CCCCCC] font-sans text-[11px]">{s.name}</td>
                  <td className="py-2 px-2.5 text-[#888888]">ST-{s.station}</td>
                  <td className="py-2 px-2.5 text-[#666666] text-[9px]">{s.physicalType}</td>
                  <td className="py-2 px-2.5 text-[#38BDF8]">{s.modelledValue} {s.unit}</td>
                  <td className={`py-2 px-2.5 font-bold ${s.status === 'OUT_OF_BOUNDS' ? 'text-[#FF4D4D]' : 'text-[#E6E6E6]'}`}>
                    {s.measuredValue} {s.unit}
                  </td>
                  <td className="py-2 px-2.5 text-[#00FF41]">{s.calibratedValue} {s.unit}</td>
                  <td className="py-2 px-2.5">
                    <span
                      className={`px-1.5 py-0.2 text-[8px] font-bold border ${
                        s.status === 'NOMINAL'
                          ? 'border-[#00FF41] text-[#00FF41]'
                          : s.status === 'DRIFT_WARNING'
                          ? 'border-[#F2A200] text-[#F2A200]'
                          : 'border-[#FF4D4D] text-[#FF4D4D]'
                      }`}
                    >
                      {s.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
