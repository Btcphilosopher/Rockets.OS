'use client';

import React from 'react';
import { EngineTwinState } from '../../lib/types';
import { CheckCircle2, Download, FileText, Printer, ShieldCheck } from 'lucide-react';

interface EngineeringReportViewProps {
  twinState: EngineTwinState;
}

export default function EngineeringReportView({ twinState }: EngineeringReportViewProps) {
  const { flight, atmosphere, thrust, compressor, combustor, turbine, inlet, nozzle, stations } = twinState;

  const handlePrint = () => {
    window.print();
  };

  const handleExportJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(twinState, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `HJ22_DIGITAL_TWIN_M${flight.mach.toFixed(1)}_STATE.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="flex flex-col gap-3">
      {/* Action Header Bar */}
      <div className="bg-[#141414] border border-[#2A2A2A] p-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 bg-[#0C0C0C] border border-[#F2A200] text-[#F2A200]">
            <FileText className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-mono text-xs font-bold text-[#E6E6E6] uppercase tracking-wider">
              AUTHORITATIVE AEROSPACE PROPULSION TECHNICAL REPORT & CERTIFICATION DOSSIER
            </h3>
            <p className="text-[10px] text-[#888888]">
              Document No: HYPERJET-OS-TR-2026-001 • Standards: MIL-E-5007D / FAA 14 CFR Part 33 / DO-178C Level A
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={handleExportJson}
            className="px-2.5 py-1 text-[10px] font-mono font-bold bg-[#0C0C0C] hover:bg-[#1A1A1A] text-[#38BDF8] border border-[#2A2A2A] flex items-center gap-1 transition-all"
          >
            <Download className="w-3 h-3" />
            EXPORT JSON TWIN
          </button>
          <button
            onClick={handlePrint}
            className="px-2.5 py-1 text-[10px] font-mono font-bold bg-[#F2A200] hover:bg-[#FFB81C] text-[#000000] flex items-center gap-1 transition-all"
          >
            <Printer className="w-3 h-3" />
            PRINT / PDF
          </button>
        </div>
      </div>

      {/* Formal Technical Document Card */}
      <div className="bg-[#141414] border border-[#2A2A2A] p-4 flex flex-col gap-4 text-[#CCCCCC] font-sans">
        {/* Document Header */}
        <div className="border-b border-[#2A2A2A] pb-3 flex justify-between items-start">
          <div>
            <span className="text-[9px] font-mono text-[#F2A200] font-bold tracking-widest uppercase">
              HYPERJET.OS PROPULSION LABORATORY
            </span>
            <h1 className="text-base font-bold font-mono text-[#E6E6E6] mt-0.5">
              HJ-22 MACH 2.2 HYDROGEN SUPERSONIC TURBOJET DIGITAL TWIN TECHNICAL EVALUATION
            </h1>
            <p className="text-[10px] text-[#888888] mt-0.5 font-mono">
              Timestamp: {new Date().toISOString()} • Engine S/N: HJ22-ENG-001-DEV • Configuration: M2.2 Cruise Baseline
            </p>
          </div>
          <span className="text-[9px] font-mono text-[#00FF41] border border-[#00FF41] px-2 py-0.5 font-bold">
            CERTIFICATION READY
          </span>
        </div>

        {/* 1. Executive Summary */}
        <div className="flex flex-col gap-1.5">
          <h2 className="text-xs font-mono font-bold text-[#E6E6E6] uppercase tracking-wider flex items-center gap-1.5">
            <span className="text-[#F2A200] font-mono">1.0</span> EXECUTIVE PROPULSION SUMMARY
          </h2>
          <p className="text-[11px] leading-relaxed text-[#AAAAAA]">
            The HJ-22 is a dedicated hydrogen-fuelled supersonic variable-geometry turbojet engine architected for sustained Mach 2.2 cruise at 18,500 m altitude. Featuring a 2D mixed-compression variable-ramp inlet with 88.6% total pressure recovery, a 6-stage transonic axial blisk compressor (CPR = 11.5:1, η_is = 88.5%), an effusion-cooled C/C-SiC ceramic matrix composite micromix lean-premixed combustor, single-crystal CMSX-4 high-pressure turbine stages with thermal barrier coatings (TIT = 1950 K), and a fully articulated convergent-divergent supersonic exhaust nozzle.
          </p>
        </div>

        {/* 2. Key Performance Metrics Matrix */}
        <div className="flex flex-col gap-1.5">
          <h2 className="text-xs font-mono font-bold text-[#E6E6E6] uppercase tracking-wider flex items-center gap-1.5">
            <span className="text-[#F2A200] font-mono">2.0</span> PERFORMANCE MATRIX SUMMARY
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[10px] font-mono">
            <div className="bg-[#0C0C0C] p-2.5 border border-[#2A2A2A]">
              <span className="text-[#666666] text-[8px] block uppercase">NET THRUST (FN)</span>
              <span className="text-[#00FF41] font-bold text-sm">{(thrust.netThrustN / 1000).toFixed(1)} kN</span>
            </div>
            <div className="bg-[#0C0C0C] p-2.5 border border-[#2A2A2A]">
              <span className="text-[#666666] text-[8px] block uppercase">SPECIFIC IMPULSE (ISP)</span>
              <span className="text-[#38BDF8] font-bold text-sm">{thrust.specificImpulseSec.toLocaleString()} s</span>
            </div>
            <div className="bg-[#0C0C0C] p-2.5 border border-[#2A2A2A]">
              <span className="text-[#666666] text-[8px] block uppercase">H2 FUEL FLOW (MF)</span>
              <span className="text-[#F2A200] font-bold text-sm">{thrust.totalH2FlowKgS.toFixed(3)} kg/s</span>
            </div>
            <div className="bg-[#0C0C0C] p-2.5 border border-[#2A2A2A]">
              <span className="text-[#666666] text-[8px] block uppercase">TURBINE INLET TEMP (TIT)</span>
              <span className="text-[#FF8800] font-bold text-sm">{combustor.combustorExitTempT4K} K</span>
            </div>
          </div>
        </div>

        {/* 3. Regulatory Certification Compliance Verification */}
        <div className="flex flex-col gap-1.5">
          <h2 className="text-xs font-mono font-bold text-[#E6E6E6] uppercase tracking-wider flex items-center gap-1.5">
            <span className="text-[#F2A200] font-mono">3.0</span> CERTIFICATION COMPLIANCE VERIFICATION
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-[10px] border-collapse">
              <thead>
                <tr className="border-b border-[#2A2A2A] text-[#666666] bg-[#0C0C0C]">
                  <th className="py-2 px-2.5">Regulatory Standard</th>
                  <th className="py-2 px-2.5">Engineering Parameter</th>
                  <th className="py-2 px-2.5">Requirement</th>
                  <th className="py-2 px-2.5">HJ-22 Measured Value</th>
                  <th className="py-2 px-2.5">Compliance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E1E1E]">
                <tr>
                  <td className="py-2 px-2.5 text-[#CCCCCC]">14 CFR § 33.65</td>
                  <td className="py-2 px-2.5 text-[#888888]">Compressor Surge Margin</td>
                  <td className="py-2 px-2.5 text-[#888888]">≥ 18.0%</td>
                  <td className="py-2 px-2.5 text-[#00FF41] font-bold">{compressor.surgeMarginPercent}%</td>
                  <td className="py-2 px-2.5 text-[#00FF41] font-bold">COMPLIANT</td>
                </tr>
                <tr>
                  <td className="py-2 px-2.5 text-[#CCCCCC]">ICAO Annex 16 / CAEP 10</td>
                  <td className="py-2 px-2.5 text-[#888888]">Thermal NOx Emissions</td>
                  <td className="py-2 px-2.5 text-[#888888]">&lt; 5.0 ppm</td>
                  <td className="py-2 px-2.5 text-[#00FF41] font-bold">{combustor.thermalNOxEmissionPpm.toFixed(2)} ppm</td>
                  <td className="py-2 px-2.5 text-[#00FF41] font-bold">COMPLIANT</td>
                </tr>
                <tr>
                  <td className="py-2 px-2.5 text-[#CCCCCC]">MIL-E-5007D</td>
                  <td className="py-2 px-2.5 text-[#888888]">Supersonic Pressure Recovery</td>
                  <td className="py-2 px-2.5 text-[#888888]">≥ 88.0%</td>
                  <td className="py-2 px-2.5 text-[#00FF41] font-bold">{(inlet.pressureRecoveryEta * 100).toFixed(1)}%</td>
                  <td className="py-2 px-2.5 text-[#00FF41] font-bold">COMPLIANT</td>
                </tr>
                <tr>
                  <td className="py-2 px-2.5 text-[#CCCCCC]">ISO 10816-1 / G2.5</td>
                  <td className="py-2 px-2.5 text-[#888888]">Rotor Dynamic Vibration</td>
                  <td className="py-2 px-2.5 text-[#888888]">&lt; 1.8 mm/s</td>
                  <td className="py-2 px-2.5 text-[#00FF41] font-bold">{twinState.rotor.unbalanceVibrationMmS} mm/s</td>
                  <td className="py-2 px-2.5 text-[#00FF41] font-bold">COMPLIANT</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
