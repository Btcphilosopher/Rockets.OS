'use client';

import React from 'react';
import { EngineTwinState } from '../../lib/types';
import EngineVisualizer from '../engine3d/EngineVisualizer';
import { Activity, Flame, Gauge, Layers, ShieldCheck, Wind, Zap } from 'lucide-react';

interface EngineTwinViewProps {
  twinState: EngineTwinState;
  viewMode: 'CUTAWAY' | 'THERMAL' | 'AIRFLOW' | 'MANUFACTURING' | 'EXTERIOR' | 'EXPLODED';
  setViewMode: (mode: 'CUTAWAY' | 'THERMAL' | 'AIRFLOW' | 'MANUFACTURING' | 'EXTERIOR' | 'EXPLODED') => void;
  selectedComponentId: string | null;
  onSelectComponent: (id: string) => void;
  onUpdateFlight: (partial: Partial<EngineTwinState['flight']>) => void;
}

export default function EngineTwinView({
  twinState,
  viewMode,
  setViewMode,
  selectedComponentId,
  onSelectComponent,
  onUpdateFlight,
}: EngineTwinViewProps) {
  const { flight, atmosphere, thrust, compressor, combustor, turbine, inlet, nozzle } = twinState;

  return (
    <div className="flex flex-col gap-3">
      {/* 3D Visualizer & Quick Mission Flight Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Left 3D Viewport (8 Cols) */}
        <div className="lg:col-span-8 flex flex-col gap-2">
          <div className="h-[460px] w-full border border-[#2A2A2A] bg-[#050505]">
            <EngineVisualizer
              twinState={twinState}
              viewMode={viewMode}
              selectedComponentId={selectedComponentId}
              onSelectComponent={onSelectComponent}
            />
          </div>

          {/* 3D View Mode Filter Selector - High Density Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 p-1.5 bg-[#141414] border border-[#2A2A2A]">
            <div className="text-[10px] font-mono text-[#888888] font-bold px-2 uppercase flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-[#F2A200]" />
              <span>VISUAL RENDER MODE:</span>
            </div>
            <div className="flex flex-wrap gap-1">
              {(['CUTAWAY', 'THERMAL', 'AIRFLOW', 'MANUFACTURING', 'EXTERIOR'] as const).map((mode) => (
                <button
                  key={mode}
                  id={`btn-viewmode-${mode.toLowerCase()}`}
                  onClick={() => setViewMode(mode)}
                  className={`px-2.5 py-0.5 text-[10px] font-mono transition-all ${
                    viewMode === mode
                      ? 'bg-[#F2A200] text-black font-bold shadow-sm'
                      : 'bg-[#1E1E1E] text-[#888888] hover:text-[#E6E6E6] hover:bg-[#282828] border border-[#2A2A2A]'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Live Actuator & Flight Controls (4 Cols) */}
        <div className="lg:col-span-4 flex flex-col gap-2">
          <div className="bg-[#141414] border border-[#2A2A2A] p-3 flex flex-col gap-3">
            <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-2">
              <div className="flex items-center gap-2">
                <Gauge className="w-3.5 h-3.5 text-[#F2A200]" />
                <h3 className="font-mono text-[11px] font-bold uppercase tracking-wider text-[#E6E6E6]">
                  FLIGHT ACTUATORS & FADEC
                </h3>
              </div>
              <span className="text-[9px] font-mono border border-[#F2A200] text-[#F2A200] px-1.5 py-0.5 font-bold">
                ONLINE
              </span>
            </div>

            {/* Mach Slider */}
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-[11px] font-mono">
                <span className="text-[#888888] uppercase">Flight Mach:</span>
                <span className="text-[#F2A200] font-bold font-mono-num">{flight.mach.toFixed(2)} M</span>
              </div>
              <input
                id="slider-flight-mach"
                type="range"
                min="0.4"
                max="2.8"
                step="0.05"
                value={flight.mach}
                onChange={(e) => onUpdateFlight({ mach: parseFloat(e.target.value) })}
                className="w-full accent-[#F2A200] bg-[#222222] h-1.5 cursor-pointer"
              />
              <div className="flex justify-between text-[9px] text-[#666666] font-mono">
                <span>0.4 (SUB)</span>
                <span>2.2 (CRUISE)</span>
                <span>2.8 (MAX)</span>
              </div>
            </div>

            {/* Altitude Slider */}
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-[11px] font-mono">
                <span className="text-[#888888] uppercase">Altitude (m / ft):</span>
                <span className="text-[#38BDF8] font-bold font-mono-num">
                  {flight.altitudeM.toLocaleString()} m ({(flight.altitudeM * 3.28084).toFixed(0)} ft)
                </span>
              </div>
              <input
                id="slider-flight-altitude"
                type="range"
                min="0"
                max="24000"
                step="500"
                value={flight.altitudeM}
                onChange={(e) => onUpdateFlight({ altitudeM: parseFloat(e.target.value) })}
                className="w-full accent-[#38BDF8] bg-[#222222] h-1.5 cursor-pointer"
              />
            </div>

            {/* Throttle Lever Slider */}
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-[11px] font-mono">
                <span className="text-[#888888] uppercase">FADEC Throttle PLA:</span>
                <span className="text-[#00FF41] font-bold font-mono-num">{(flight.throttle * 100).toFixed(0)}%</span>
              </div>
              <input
                id="slider-flight-throttle"
                type="range"
                min="0.15"
                max="1.0"
                step="0.01"
                value={flight.throttle}
                onChange={(e) => onUpdateFlight({ throttle: parseFloat(e.target.value) })}
                className="w-full accent-[#00FF41] bg-[#222222] h-1.5 cursor-pointer"
              />
            </div>

            {/* Variable Ramp Pitch Angle */}
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-[11px] font-mono">
                <span className="text-[#888888] uppercase">Inlet Ramp Deflection:</span>
                <span className="text-[#F2A200] font-bold font-mono-num">{flight.inletAngleDeg.toFixed(1)}°</span>
              </div>
              <input
                id="slider-inlet-ramp"
                type="range"
                min="4.0"
                max="14.0"
                step="0.2"
                value={flight.inletAngleDeg}
                onChange={(e) => onUpdateFlight({ inletAngleDeg: parseFloat(e.target.value) })}
                className="w-full accent-[#F2A200] bg-[#222222] h-1.5 cursor-pointer"
              />
            </div>

            {/* Hydrogen Reheat Toggle */}
            <div className="pt-2 border-t border-[#2A2A2A] flex items-center justify-between">
              <div className="flex flex-col">
                <span className="text-[11px] font-mono font-bold text-[#E6E6E6]">H2 REHEAT AUGMENTOR</span>
                <span className="text-[9px] text-[#666666]">Thrust boost +38%</span>
              </div>
              <button
                id="btn-toggle-reheat"
                onClick={() => onUpdateFlight({ reheatActive: !flight.reheatActive })}
                className={`px-2.5 py-1 text-[10px] font-mono font-bold tracking-wider transition-all flex items-center gap-1.5 ${
                  flight.reheatActive
                    ? 'bg-[#F2A200] text-black shadow-md'
                    : 'bg-[#1E1E1E] text-[#888888] hover:text-[#E6E6E6] border border-[#2A2A2A]'
                }`}
              >
                <Flame className={`w-3 h-3 ${flight.reheatActive ? 'text-black' : 'text-[#666666]'}`} />
                {flight.reheatActive ? 'REHEAT ON' : 'REHEAT OFF'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Real-time Propulsion & Key Parameters Strip - High Density Metric Cells */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
        <div className="bg-[#141414] p-3 border border-[#2A2A2A] flex flex-col justify-between">
          <span className="text-[9px] font-mono text-[#666666] uppercase">Net Thrust (Fn)</span>
          <div className="flex items-baseline gap-1 my-1">
            <span className="text-xl font-bold font-mono text-[#00FF41] font-mono-num">
              {(thrust.netThrustN / 1000).toFixed(1)}
            </span>
            <span className="text-[10px] font-mono text-[#888888]">kN</span>
          </div>
          <span className="text-[9px] text-[#666666] font-mono">
            Gross: {(thrust.grossThrustN / 1000).toFixed(1)} kN
          </span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A] flex flex-col justify-between">
          <span className="text-[9px] font-mono text-[#666666] uppercase">Specific Impulse (Isp)</span>
          <div className="flex items-baseline gap-1 my-1">
            <span className="text-xl font-bold font-mono text-[#38BDF8] font-mono-num">
              {thrust.specificImpulseSec.toLocaleString()}
            </span>
            <span className="text-[10px] font-mono text-[#888888]">s</span>
          </div>
          <span className="text-[9px] text-[#F2A200] font-mono">~3.2x vs Jet-A Kerosene</span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A] flex flex-col justify-between">
          <span className="text-[9px] font-mono text-[#666666] uppercase">H2 Fuel Flow (m_f)</span>
          <div className="flex items-baseline gap-1 my-1">
            <span className="text-xl font-bold font-mono text-[#E6E6E6] font-mono-num">
              {thrust.totalH2FlowKgS.toFixed(3)}
            </span>
            <span className="text-[10px] font-mono text-[#888888]">kg/s</span>
          </div>
          <span className="text-[9px] text-[#666666] font-mono">
            TSFC: {thrust.tsfcGPerKns.toFixed(1)} g/kN·s
          </span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A] flex flex-col justify-between">
          <span className="text-[9px] font-mono text-[#666666] uppercase">Turbine Temp (TIT / T4)</span>
          <div className="flex items-baseline gap-1 my-1">
            <span className="text-xl font-bold font-mono text-[#F2A200] font-mono-num">
              {combustor.combustorExitTempT4K}
            </span>
            <span className="text-[10px] font-mono text-[#888888]">K</span>
          </div>
          <span className="text-[9px] text-[#666666] font-mono">
            Blade Metal: {turbine.bladeMetalTempK} K
          </span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A] flex flex-col justify-between">
          <span className="text-[9px] font-mono text-[#666666] uppercase">Pressure Ratio (CPR)</span>
          <div className="flex items-baseline gap-1 my-1">
            <span className="text-xl font-bold font-mono text-[#E6E6E6] font-mono-num">
              {compressor.pressureRatioCPR.toFixed(2)}
            </span>
            <span className="text-[10px] font-mono text-[#888888]">: 1</span>
          </div>
          <span className="text-[9px] text-[#666666] font-mono">
            Surge Margin: {compressor.surgeMarginPercent}%
          </span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A] flex flex-col justify-between">
          <span className="text-[9px] font-mono text-[#666666] uppercase">Inlet Recovery (Pt2/Pt0)</span>
          <div className="flex items-baseline gap-1 my-1">
            <span className="text-xl font-bold font-mono text-[#00FF41] font-mono-num">
              {(inlet.pressureRecoveryEta * 100).toFixed(1)}%
            </span>
            <span className="text-[10px] font-mono text-[#888888]">η</span>
          </div>
          <span className="text-[9px] text-[#666666] font-mono">
            Distortion DC60: {inlet.distortionIndexDC60}
          </span>
        </div>
      </div>

      {/* Station Streamline Flow Strip - High Density */}
      <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
        <div className="flex items-center justify-between mb-2 pb-1.5 border-b border-[#2A2A2A]">
          <div className="flex items-center gap-2">
            <Activity className="w-3.5 h-3.5 text-[#F2A200]" />
            <span className="font-mono text-[10px] font-bold uppercase text-[#E6E6E6] tracking-wider">
              STATION-BY-STATION THERMODYNAMIC STATE PROPAGATION (0 → 9)
            </span>
          </div>
          <span className="text-[9px] font-mono text-[#00FF41]">● CONSERVATION OF MASS & ENERGY CONVERGED</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-1.5 overflow-x-auto">
          {twinState.stations.map((st) => (
            <div
              key={st.stationId}
              className="bg-[#0C0C0C] p-2 border border-[#2A2A2A] flex flex-col gap-0.5 text-[10px] font-mono"
            >
              <div className="flex items-center justify-between border-b border-[#1E1E1E] pb-0.5 mb-0.5">
                <span className="text-[#F2A200] font-bold">ST-{st.stationId}</span>
                <span className="text-[8px] text-[#666666] truncate max-w-[55px]" title={st.name}>
                  {st.name}
                </span>
              </div>
              <div className="flex justify-between text-[#888888]">
                <span>Tt:</span>
                <span className="text-[#E6E6E6] font-bold font-mono-num">{st.totalTempK} K</span>
              </div>
              <div className="flex justify-between text-[#888888]">
                <span>Pt:</span>
                <span className="text-[#E6E6E6] font-mono-num">{(st.totalPressurePa / 1000).toFixed(0)} kPa</span>
              </div>
              <div className="flex justify-between text-[#888888]">
                <span>Mach:</span>
                <span className="text-[#38BDF8] font-mono-num">{st.mach.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-[#888888]">
                <span>Vel:</span>
                <span className="text-[#00FF41] font-mono-num">{st.velocityMs} m/s</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
