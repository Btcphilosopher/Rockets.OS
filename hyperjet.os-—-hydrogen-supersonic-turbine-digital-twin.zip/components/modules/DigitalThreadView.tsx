'use client';

import React, { useState } from 'react';
import { HJ22_DIGITAL_THREAD_HIERARCHY } from '../../lib/digitalThread/engineHierarchy';
import { DigitalThreadNode } from '../../lib/types';
import { CheckCircle2, ChevronRight, Cpu, Database, FileText, Layers, ShieldCheck, Wrench } from 'lucide-react';

interface DigitalThreadViewProps {
  selectedComponentId: string | null;
  onSelectComponent: (id: string) => void;
}

export default function DigitalThreadView({
  selectedComponentId,
  onSelectComponent,
}: DigitalThreadViewProps) {
  const [activeNodeId, setActiveNodeId] = useState<string>(
    selectedComponentId || 'MOD-COMPRESSOR'
  );

  // Find active node recursively
  function findNode(nodes: DigitalThreadNode[], id: string): DigitalThreadNode | null {
    for (const n of nodes) {
      if (n.id === id) return n;
      if (n.subcomponents) {
        const found = findNode(n.subcomponents, id);
        if (found) return found;
      }
    }
    return null;
  }

  const activeNode = findNode(HJ22_DIGITAL_THREAD_HIERARCHY, activeNodeId) || HJ22_DIGITAL_THREAD_HIERARCHY[1];

  return (
    <div className="flex flex-col gap-3">
      {/* Top Banner */}
      <div className="bg-[#141414] border border-[#2A2A2A] p-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 bg-[#1A1405] border border-[#F2A200] text-[#F2A200]">
            <Database className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-mono text-xs font-bold text-[#E6E6E6] uppercase tracking-wider">
              ENGINEERING & MANUFACTURING DIGITAL THREAD (EBOM & MBOM)
            </h3>
            <p className="text-[10px] text-[#888888]">
              Traceability: Requirement → CAD Model → Superalloy Lot → 5-Axis CNC / AM SLM → CMM Metrology → Test Stand
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[9px] font-mono text-[#00FF41] border border-[#00FF41] px-2 py-0.5 font-bold">
            100% AS-BUILT MATCH
          </span>
        </div>
      </div>

      {/* Main 2-Column Split View: Hierarchy Tree (5 cols) & As-Built Digital Certificate (7 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Left: Interactive Assembly Tree */}
        <div className="lg:col-span-5 bg-[#141414] border border-[#2A2A2A] p-3 flex flex-col gap-2">
          <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-1.5">
            <span className="font-mono text-[10px] font-bold text-[#E6E6E6] uppercase tracking-wider">
              ENGINE SUBSYSTEM HIERARCHY (EBOM)
            </span>
            <span className="text-[9px] font-mono text-[#666666]">CLICK TO INSPECT</span>
          </div>

          <div className="flex flex-col gap-1 max-h-[520px] overflow-y-auto pr-1">
            {HJ22_DIGITAL_THREAD_HIERARCHY.map((module) => (
              <div key={module.id} className="flex flex-col gap-0.5">
                <button
                  id={`btn-node-${module.id}`}
                  onClick={() => {
                    setActiveNodeId(module.id);
                    onSelectComponent(module.id);
                  }}
                  className={`flex items-center justify-between p-2 text-left font-mono text-[11px] transition-all border ${
                    activeNodeId === module.id
                      ? 'bg-[#1E1A0E] text-[#F2A200] border-[#F2A200] font-bold'
                      : 'bg-[#0C0C0C] text-[#E6E6E6] hover:bg-[#1E1E1E] border-[#2A2A2A]'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Layers className="w-3.5 h-3.5 text-[#F2A200]" />
                    <div>
                      <div className="font-bold">{module.id}</div>
                      <div className="text-[10px] text-[#888888] font-sans truncate max-w-[180px]">{module.name}</div>
                    </div>
                  </div>
                  <span className="text-[9px] text-[#666666]">{module.revision}</span>
                </button>

                {/* Child parts */}
                {module.subcomponents && (
                  <div className="pl-4 flex flex-col gap-0.5 border-l border-[#2A2A2A] ml-2">
                    {module.subcomponents.map((sub) => (
                      <button
                        key={sub.id}
                        id={`btn-node-${sub.id}`}
                        onClick={() => {
                          setActiveNodeId(sub.id);
                          onSelectComponent(sub.id);
                        }}
                        className={`flex items-center justify-between p-1.5 text-left font-mono text-[10px] transition-all border ${
                          activeNodeId === sub.id
                            ? 'bg-[#1E1A0E] text-[#F2A200] border-[#F2A200] font-bold'
                            : 'bg-[#080808] text-[#888888] hover:bg-[#1A1A1A] border-[#222222]'
                        }`}
                      >
                        <span className="truncate max-w-[170px]">{sub.name}</span>
                        <span className="text-[8px] text-[#666666]">{sub.revision}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Right: Comprehensive As-Built Digital Twin Passport */}
        <div className="lg:col-span-7 bg-[#141414] border border-[#2A2A2A] p-3 flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-2">
            <div>
              <div className="text-[10px] font-mono text-[#F2A200] font-bold">{activeNode.partNumber} • {activeNode.revision}</div>
              <h3 className="font-mono text-sm font-bold text-[#E6E6E6]">{activeNode.name}</h3>
            </div>
            <span className="text-[9px] font-mono text-[#00FF41] border border-[#00FF41] px-2 py-0.5 flex items-center gap-1 font-bold">
              <CheckCircle2 className="w-3 h-3" />
              CONFORMS
            </span>
          </div>

          {/* Traceability Grid */}
          <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] block text-[8px] uppercase">INSTALLED SERIAL NUMBER</span>
              <span className="text-[#F2A200] font-bold">{activeNode.installedSerialNumber}</span>
            </div>
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] block text-[8px] uppercase">BATCH HEAT LOT NUMBER</span>
              <span className="text-[#38BDF8] font-bold">{activeNode.batchHeatLotNumber}</span>
            </div>
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] block text-[8px] uppercase">MACHINE TOOL ID</span>
              <span className="text-[#E6E6E6] font-bold">{activeNode.machineToolId}</span>
            </div>
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] block text-[8px] uppercase">INSPECTION CERTIFICATE ID</span>
              <span className="text-[#00FF41] font-bold">{activeNode.inspectionCertificateId}</span>
            </div>
          </div>

          {/* Material & Requirements Specification */}
          <div className="bg-[#0C0C0C] p-2.5 border border-[#2A2A2A] flex flex-col gap-1.5 text-[10px] font-mono">
            <div>
              <span className="text-[#666666] text-[8px] block uppercase">MATERIAL SPECIFICATION</span>
              <span className="text-[#E6E6E6] font-bold">{activeNode.material}</span>
              <p className="text-[#888888] text-[10px] font-sans mt-0.5">{activeNode.materialSpec}</p>
            </div>
            <div className="pt-1.5 border-t border-[#1E1E1E]">
              <span className="text-[#666666] text-[8px] block uppercase">TRACEABLE REQUIREMENT</span>
              <span className="text-[#38BDF8] font-sans">{activeNode.designRequirement}</span>
            </div>
          </div>

          {/* GD&T Coordinate Metrology Inspection Table */}
          <div className="bg-[#0C0C0C] p-2.5 border border-[#2A2A2A] flex flex-col gap-1.5">
            <span className="text-[10px] font-mono font-bold text-[#E6E6E6] uppercase">
              CMM Coordinate Metrology Inspection (GD&T)
            </span>
            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-[10px]">
                <thead>
                  <tr className="text-[#666666] border-b border-[#2A2A2A]">
                    <th className="py-1">Feature</th>
                    <th className="py-1">Nominal</th>
                    <th className="py-1">Tolerance</th>
                    <th className="py-1">Measured CMM</th>
                    <th className="py-1">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1A1A1A]">
                  {activeNode.gdtToleranceSpecs.map((g, idx) => (
                    <tr key={idx}>
                      <td className="py-1 text-[#CCCCCC]">{g.feature}</td>
                      <td className="py-1 text-[#888888]">{g.nominalMm} mm</td>
                      <td className="py-1 text-[#888888]">+{g.plusToleranceMm}/-{g.minusToleranceMm} mm</td>
                      <td className="py-1 text-[#38BDF8] font-bold">{g.measuredCmmMm} mm</td>
                      <td className="py-1 text-[#00FF41] font-bold">PASS</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
