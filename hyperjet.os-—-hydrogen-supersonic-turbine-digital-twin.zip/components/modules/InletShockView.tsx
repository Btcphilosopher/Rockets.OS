'use client';

import React from 'react';
import { EngineTwinState } from '../../lib/types';
import { solveObliqueShock, solveNormalShock } from '../../lib/physics/compressible';
import { Compass, Gauge, ShieldAlert, Wind, Zap } from 'lucide-react';

interface InletShockViewProps {
  twinState: EngineTwinState;
  onUpdateFlight: (partial: Partial<EngineTwinState['flight']>) => void;
}

export default function InletShockView({ twinState, onUpdateFlight }: InletShockViewProps) {
  const { flight, inlet, atmosphere } = twinState;

  // Calculate live oblique shock parameters for Ramp 1 and Ramp 2
  const m0 = flight.mach;
  const ramp1Angle = flight.inletAngleDeg;
  const ramp2Angle = flight.inletAngleDeg * 0.65;

  const shock1 = solveObliqueShock(m0, ramp1Angle);
  const shock2 = solveObliqueShock(shock1.m2, ramp2Angle);
  const terminalShock = solveNormalShock(shock2.m2);

  const shock1WaveAngleDeg = (shock1.betaRad * 180) / Math.PI;
  const shock2WaveAngleDeg = (shock2.betaRad * 180) / Math.PI;

  return (
    <div className="flex flex-col gap-3">
      {/* Top Banner Metric Cards - High Density Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Total Pressure Recovery (Pt2/Pt0)</span>
          <div className="text-xl font-bold font-mono text-[#00FF41] mt-0.5 font-mono-num">
            {(inlet.pressureRecoveryEta * 100).toFixed(1)}%
          </div>
          <span className="text-[9px] text-[#888888] font-mono">MIL-E-5007D Class Standard</span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Terminal Shock Mach (M_term)</span>
          <div className="text-xl font-bold font-mono text-[#F2A200] mt-0.5 font-mono-num">
            {terminalShock.m1.toFixed(2)}
          </div>
          <span className="text-[9px] text-[#888888] font-mono">Exit: {terminalShock.m2.toFixed(2)} (Subsonic)</span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Inlet Capture Flow Rate</span>
          <div className="text-xl font-bold font-mono text-[#E6E6E6] mt-0.5 font-mono-num">
            {(atmosphere.densityKgM3 * flight.mach * atmosphere.speedOfSoundMs * inlet.captureAreaM2).toFixed(1)} kg/s
          </div>
          <span className="text-[9px] text-[#888888] font-mono">A_capture = {inlet.captureAreaM2} m²</span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Boundary Layer Bleed (3.5%)</span>
          <div className="text-xl font-bold font-mono text-[#38BDF8] mt-0.5 font-mono-num">
            {inlet.bleedFlowKgS} kg/s
          </div>
          <span className="text-[9px] text-[#888888] font-mono">Distortion DC60: {inlet.distortionIndexDC60}</span>
        </div>
      </div>

      {/* Interactive Shockwave & Ramp Geometric Solver Visualizer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Left: 2D Supersonic Ramp Wave Geometry Schematic (7 cols) */}
        <div className="lg:col-span-7 bg-[#141414] border border-[#2A2A2A] p-3 flex flex-col gap-2">
          <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-1.5">
            <div className="flex items-center gap-2">
              <Compass className="w-3.5 h-3.5 text-[#F2A200]" />
              <span className="font-mono text-[10px] font-bold text-[#E6E6E6] uppercase tracking-wider">
                SUPERSONIC 2D MIXED-COMPRESSION RAMP SHOCK SCHEMATIC
              </span>
            </div>
            <span className="text-[9px] font-mono border border-[#F2A200] text-[#F2A200] px-1.5 py-0.5 font-bold">
              MACH {flight.mach.toFixed(2)}
            </span>
          </div>

          <div className="h-60 w-full bg-[#080808] border border-[#2A2A2A] p-2 relative flex items-center justify-center overflow-hidden">
            <svg viewBox="0 0 520 220" className="w-full h-full">
              {/* Freestream Airflow Arrows */}
              <defs>
                <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                  <path d="M 0 0 L 10 5 L 0 10 z" fill="#38BDF8" />
                </marker>
              </defs>

              <line x1="20" y1="60" x2="110" y2="60" stroke="#38BDF8" strokeWidth="1.5" markerEnd="url(#arrow)" />
              <line x1="20" y1="110" x2="110" y2="110" stroke="#38BDF8" strokeWidth="1.5" markerEnd="url(#arrow)" />
              <line x1="20" y1="160" x2="110" y2="160" stroke="#38BDF8" strokeWidth="1.5" markerEnd="url(#arrow)" />
              <text x="25" y="45" fill="#38BDF8" fontSize="10" fontFamily="monospace" fontWeight="bold">
                M0 = {flight.mach.toFixed(2)}
              </text>

              {/* Upper Cowl Lip */}
              <path d="M 330 40 L 500 40 L 500 55 L 340 55 Z" fill="#262626" stroke="#444444" strokeWidth="1.5" />
              <text x="360" y="32" fill="#888888" fontSize="9" fontFamily="monospace">Cowl Leading Edge Lip</text>

              {/* Lower Variable Compression Ramps */}
              <path d="M 120 180 L 230 145 L 340 120 L 500 120 L 500 195 L 120 195 Z" fill="#1C1C1C" stroke="#444444" strokeWidth="1.5" />
              
              {/* Oblique Shock Wave 1 (from ramp 1 tip) */}
              <line
                x1="120"
                y1="180"
                x2="330"
                y2="40"
                stroke="#F2A200"
                strokeWidth="2.5"
                strokeDasharray="4,2"
              />
              <text x="185" y="95" fill="#F2A200" fontSize="9" fontFamily="monospace" fontWeight="bold">
                Shock 1 (β1 = {shock1WaveAngleDeg.toFixed(1)}°)
              </text>

              {/* Oblique Shock Wave 2 (from ramp 2 vertex) */}
              <line
                x1="230"
                y1="145"
                x2="330"
                y2="40"
                stroke="#38BDF8"
                strokeWidth="2.5"
                strokeDasharray="4,2"
              />
              <text x="260" y="80" fill="#38BDF8" fontSize="9" fontFamily="monospace" fontWeight="bold">
                Shock 2 (β2 = {shock2WaveAngleDeg.toFixed(1)}°)
              </text>

              {/* Terminal Normal Shock Disc at Throat */}
              <line
                x1="330"
                y1="40"
                x2="340"
                y2="120"
                stroke="#EF4444"
                strokeWidth="3"
              />
              <text x="348" y="85" fill="#EF4444" fontSize="9" fontFamily="monospace" fontWeight="bold">
                Terminal Shock
              </text>

              {/* Subsonic Diffuser Passage */}
              <text x="400" y="85" fill="#00FF41" fontSize="10" fontFamily="monospace" fontWeight="bold">
                Subsonic Diffuser (M ≈ 0.42)
              </text>
            </svg>
          </div>

          <div className="grid grid-cols-3 gap-1.5 text-[10px] font-mono">
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] block text-[8px] uppercase">OBLIQUE SHOCK 1</span>
              <span className="text-[#F2A200] font-bold">M: {m0.toFixed(2)} → {shock1.m2.toFixed(2)}</span>
              <span className="text-[#888888] block text-[8px]">Pt Rec: {(shock1.pt2OverPt1 * 100).toFixed(1)}%</span>
            </div>
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] block text-[8px] uppercase">OBLIQUE SHOCK 2</span>
              <span className="text-[#38BDF8] font-bold">M: {shock1.m2.toFixed(2)} → {shock2.m2.toFixed(2)}</span>
              <span className="text-[#888888] block text-[8px]">Pt Rec: {(shock2.pt2OverPt1 * 100).toFixed(1)}%</span>
            </div>
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] block text-[8px] uppercase">NORMAL SHOCK</span>
              <span className="text-[#EF4444] font-bold">M: {terminalShock.m1.toFixed(2)} → {terminalShock.m2.toFixed(2)}</span>
              <span className="text-[#888888] block text-[8px]">Pt Rec: {(terminalShock.pt2OverPt1 * 100).toFixed(1)}%</span>
            </div>
          </div>
        </div>

        {/* Right: Variable Geometry Control & Off-Design Performance (5 cols) */}
        <div className="lg:col-span-5 bg-[#141414] border border-[#2A2A2A] p-3 flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-1.5">
            <div className="flex items-center gap-2">
              <Gauge className="w-3.5 h-3.5 text-[#F2A200]" />
              <span className="font-mono text-[10px] font-bold text-[#E6E6E6] uppercase tracking-wider">
                VARIABLE RAMP ACTUATOR CONTROLS
              </span>
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between text-[11px] font-mono">
              <span className="text-[#888888] uppercase">Ramp 1 Pitch (θ1):</span>
              <span className="text-[#F2A200] font-bold font-mono-num">{flight.inletAngleDeg.toFixed(1)}°</span>
            </div>
            <input
              id="slider-inlet-angle"
              type="range"
              min="4.0"
              max="14.0"
              step="0.2"
              value={flight.inletAngleDeg}
              onChange={(e) => onUpdateFlight({ inletAngleDeg: parseFloat(e.target.value) })}
              className="w-full accent-[#F2A200] bg-[#222222] h-1.5 cursor-pointer"
            />
            <div className="flex justify-between text-[9px] text-[#666666] font-mono">
              <span>Transonic (4.0°)</span>
              <span>Design (8.5°)</span>
              <span>Max Pitch (14.0°)</span>
            </div>
          </div>

          {/* Shock-on-Lip Condition Analysis */}
          <div className="bg-[#0C0C0C] p-2.5 border border-[#2A2A2A] text-[10px] font-mono flex flex-col gap-1">
            <div className="flex items-center justify-between">
              <span className="text-[#E6E6E6] font-bold">Shock-on-Lip Focus:</span>
              <span className="text-[#00FF41] font-bold">OPTIMAL CAPTURE</span>
            </div>
            <p className="text-[10px] text-[#888888] leading-relaxed font-sans">
              At Mach 2.2 with θ1 = 8.5°, the first oblique shock wave intercepts precisely at the cowl lip tip (X=330mm), minimizing spillage drag to 0.4% and maximizing capture efficiency.
            </p>
          </div>

          {/* Compressible Aerodynamic Equations */}
          <div className="bg-[#0C0C0C] p-2.5 border border-[#2A2A2A] text-[10px] font-mono flex flex-col gap-1 text-[#888888]">
            <span className="text-[#F2A200] font-bold text-[10px]">Exact θ-β-M Taylor-Maccoll Relation:</span>
            <p className="text-[9px] text-[#CCCCCC]">
              tan(θ) = 2 cot(β) · [(M1² sin²β - 1) / (M1²(γ + cos 2β) + 2)]
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
