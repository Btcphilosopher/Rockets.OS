'use client';

import React, { useState } from 'react';
import { HJ22_FACTORY_CELLS } from '../../lib/manufacturing/factorySimulation';
import { calculateTipClearanceStackUp } from '../../lib/manufacturing/toleranceEngine';
import { Activity, BarChart3, CheckCircle2, Cpu, Factory, RefreshCw, Zap } from 'lucide-react';

export default function ManufacturingView() {
  const [rotorRunoutTol, setRotorRunoutTol] = useState(0.015);
  const [bladeLengthTol, setBladeLengthTol] = useState(0.025);
  const [casingBoreTol, setCasingBoreTol] = useState(0.030);

  const stackUpResult = calculateTipClearanceStackUp(
    rotorRunoutTol,
    bladeLengthTol,
    casingBoreTol,
    0.010
  );

  return (
    <div className="flex flex-col gap-3">
      {/* Top Banner Metric Cards - High Density Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Active Factory Cells</span>
          <div className="text-xl font-bold font-mono text-[#00FF41] mt-0.5 font-mono-num">
            8 / 8 RUNNING
          </div>
          <span className="text-[9px] text-[#00FF41] font-mono">100% Operational Readiness</span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">First-Pass Yield</span>
          <div className="text-xl font-bold font-mono text-[#00FF41] mt-0.5 font-mono-num">
            99.1%
          </div>
          <span className="text-[9px] text-[#888888] font-mono">AS9100D Certified</span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Monte Carlo Cpk Capability</span>
          <div className="text-xl font-bold font-mono text-[#F2A200] mt-0.5 font-mono-num">
            {stackUpResult.cpk.toFixed(2)}
          </div>
          <span className="text-[9px] text-[#888888] font-mono">Target Cpk &gt; 1.33 (6-Sigma)</span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Manufacturing Plant Power</span>
          <div className="text-xl font-bold font-mono text-[#38BDF8] mt-0.5 font-mono-num">
            473.5 kW
          </div>
          <span className="text-[9px] text-[#888888] font-mono">Cleanroom Temp: 20.0°C</span>
        </div>
      </div>

      {/* 8 Factory Production Cells Grid */}
      <div className="bg-[#141414] border border-[#2A2A2A] p-3 flex flex-col gap-3">
        <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-1.5">
          <div className="flex items-center gap-2">
            <Factory className="w-3.5 h-3.5 text-[#F2A200]" />
            <h3 className="font-mono text-[10px] font-bold text-[#E6E6E6] uppercase tracking-wider">
              HJ-22 ADVANCED PROPULSION PRODUCTION PLANT FLOOR
            </h3>
          </div>
          <span className="text-[9px] font-mono text-[#00FF41] font-bold">● ALL STATIONS SYNCHRONIZED</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2">
          {HJ22_FACTORY_CELLS.map((cell) => (
            <div
              key={cell.id}
              className="bg-[#0C0C0C] p-2.5 border border-[#2A2A2A] flex flex-col gap-1.5 font-mono text-[10px] hover:border-[#F2A200] transition-all"
            >
              <div className="flex items-start justify-between">
                <span className="text-[#666666] text-[9px]">{cell.id}</span>
                <span className="border border-[#00FF41] text-[#00FF41] text-[8px] px-1 py-0.2 font-bold">
                  {cell.status}
                </span>
              </div>
              <h4 className="font-sans font-bold text-[#E6E6E6] text-[11px] line-clamp-1">{cell.name}</h4>

              <div className="grid grid-cols-2 gap-1.5 text-[9px] pt-1.5 border-t border-[#1E1E1E]">
                <div>
                  <span className="text-[#666666] text-[8px] block">UTILIZATION</span>
                  <span className="text-[#38BDF8] font-bold">{cell.utilizationPercent}%</span>
                </div>
                <div>
                  <span className="text-[#666666] text-[8px] block">CYCLE TIME</span>
                  <span className="text-[#CCCCCC]">{cell.cycleTimeMin} min</span>
                </div>
                <div>
                  <span className="text-[#666666] text-[8px] block">QUEUE</span>
                  <span className="text-[#F2A200] font-bold">{cell.queueCount} parts</span>
                </div>
                <div>
                  <span className="text-[#666666] text-[8px] block">YIELD</span>
                  <span className="text-[#00FF41] font-bold">{cell.yieldPercent}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* GD&T Tolerance Stack-Up Engine & 1,000-Run Monte Carlo Simulation */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Left: Tolerance Sliders & Parameters (5 cols) */}
        <div className="lg:col-span-5 bg-[#141414] border border-[#2A2A2A] p-3 flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-1.5">
            <div className="flex items-center gap-2">
              <Zap className="w-3.5 h-3.5 text-[#F2A200]" />
              <span className="font-mono text-[10px] font-bold text-[#E6E6E6] uppercase tracking-wider">
                COMPRESSOR TIP GAP GD&T TOLERANCE STACK-UP
              </span>
            </div>
          </div>

          <div className="flex flex-col gap-2 font-mono text-[10px]">
            {/* Rotor Runout */}
            <div className="flex flex-col gap-0.5">
              <div className="flex justify-between">
                <span className="text-[#888888]">Rotor Drum Runout Tol (±mm):</span>
                <span className="text-[#38BDF8] font-bold">{rotorRunoutTol.toFixed(3)} mm</span>
              </div>
              <input
                type="range"
                min="0.005"
                max="0.035"
                step="0.002"
                value={rotorRunoutTol}
                onChange={(e) => setRotorRunoutTol(parseFloat(e.target.value))}
                className="w-full accent-[#F2A200] bg-[#222222] h-1.5 cursor-pointer"
              />
            </div>

            {/* Blade Length */}
            <div className="flex flex-col gap-0.5">
              <div className="flex justify-between">
                <span className="text-[#888888]">Blade Length Machining Tol (±mm):</span>
                <span className="text-[#F2A200] font-bold">{bladeLengthTol.toFixed(3)} mm</span>
              </div>
              <input
                type="range"
                min="0.010"
                max="0.050"
                step="0.005"
                value={bladeLengthTol}
                onChange={(e) => setBladeLengthTol(parseFloat(e.target.value))}
                className="w-full accent-[#F2A200] bg-[#222222] h-1.5 cursor-pointer"
              />
            </div>

            {/* Casing Bore */}
            <div className="flex flex-col gap-0.5">
              <div className="flex justify-between">
                <span className="text-[#888888]">Casing Bore Roundness Tol (±mm):</span>
                <span className="text-[#00FF41] font-bold">{casingBoreTol.toFixed(3)} mm</span>
              </div>
              <input
                type="range"
                min="0.010"
                max="0.060"
                step="0.005"
                value={casingBoreTol}
                onChange={(e) => setCasingBoreTol(parseFloat(e.target.value))}
                className="w-full accent-[#F2A200] bg-[#222222] h-1.5 cursor-pointer"
              />
            </div>
          </div>

          <div className="bg-[#0C0C0C] p-2.5 border border-[#2A2A2A] flex flex-col gap-1.5 font-mono text-[10px]">
            <span className="text-[#E6E6E6] font-bold">Downstream Cycle Impact:</span>
            <div className="flex justify-between text-[#888888]">
              <span>Stage Efficiency (Δη):</span>
              <span className="text-[#38BDF8] font-bold">{stackUpResult.impactOnEfficiencyPercent.toFixed(3)}%</span>
            </div>
            <div className="flex justify-between text-[#888888]">
              <span>Net Thrust Delta (ΔFn):</span>
              <span className="text-[#F2A200] font-bold">{stackUpResult.impactOnThrustKn.toFixed(2)} kN</span>
            </div>
          </div>
        </div>

        {/* Right: Monte Carlo 1000-Run Probability Distribution Histogram (7 cols) */}
        <div className="lg:col-span-7 bg-[#141414] border border-[#2A2A2A] p-3 flex flex-col gap-2">
          <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-1.5">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-3.5 h-3.5 text-[#F2A200]" />
              <span className="font-mono text-[10px] font-bold text-[#E6E6E6] uppercase tracking-wider">
                MONTE CARLO 1,000-RUN TIP CLEARANCE HISTOGRAM
              </span>
            </div>
            <span className="text-[9px] font-mono text-[#38BDF8]">
              Mean: {stackUpResult.monteCarloMeanMm} mm (σ = {stackUpResult.monteCarloSigmaMm} mm)
            </span>
          </div>

          {/* Histogram Chart */}
          <div className="h-44 w-full bg-[#080808] p-2 flex items-end justify-between gap-1 border border-[#2A2A2A]">
            {stackUpResult.histogramBins.map((bin, idx) => {
              const maxCount = Math.max(...stackUpResult.histogramBins.map((b) => b.count));
              const heightPercent = (bin.count / Math.max(1, maxCount)) * 100;
              return (
                <div key={idx} className="flex-1 flex flex-col items-center gap-0.5 h-full justify-end">
                  <span className="text-[8px] font-mono text-[#666666]">{bin.count}</span>
                  <div
                    className="w-full bg-[#F2A200] hover:bg-[#FFB81C] transition-all"
                    style={{ height: `${heightPercent}%` }}
                    title={`Gap: ${bin.binMm} mm, Count: ${bin.count}`}
                  />
                  <span className="text-[7px] font-mono text-[#666666] truncate w-full text-center">
                    {bin.binMm}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-3 gap-1.5 text-[10px] font-mono">
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] text-[8px] block uppercase">WORST CASE</span>
              <span className="text-[#E6E6E6] font-bold">{stackUpResult.worstCaseMinMm} - {stackUpResult.worstCaseMaxMm} mm</span>
            </div>
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] text-[8px] block uppercase">STATISTICAL RSS</span>
              <span className="text-[#38BDF8] font-bold">{stackUpResult.rssMinMm} - {stackUpResult.rssMaxMm} mm</span>
            </div>
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] text-[8px] block uppercase">CPK CAPABILITY</span>
              <span className="text-[#00FF41] font-bold">{stackUpResult.cpk} (Pass)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
