'use client';

import React from 'react';
import { EngineTwinState } from '../../lib/types';
import { Activity, BookOpen, CheckCircle2, Flame, Gauge, Sparkles } from 'lucide-react';

interface ThermodynamicsViewProps {
  twinState: EngineTwinState;
}

export default function ThermodynamicsView({ twinState }: ThermodynamicsViewProps) {
  const { stations, thrust, compressor, combustor, turbine, nozzle, inlet } = twinState;

  return (
    <div className="flex flex-col gap-3">
      {/* Header Metric Cards - High Density Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Thermal Efficiency (η_th)</span>
          <div className="text-xl font-bold font-mono text-[#38BDF8] mt-0.5 font-mono-num">
            {(thrust.thermalEfficiency * 100).toFixed(1)}%
          </div>
          <span className="text-[9px] text-[#888888] font-mono">η_th = ΔKE_jet / (m_f · LHV)</span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Propulsive Efficiency (η_p)</span>
          <div className="text-xl font-bold font-mono text-[#00FF41] mt-0.5 font-mono-num">
            {(thrust.propulsiveEfficiency * 100).toFixed(1)}%
          </div>
          <span className="text-[9px] text-[#888888] font-mono">η_p = 2V_0 / (V_0 + V_9)</span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Overall Cycle Efficiency (η_o)</span>
          <div className="text-xl font-bold font-mono text-[#F2A200] mt-0.5 font-mono-num">
            {(thrust.overallEfficiency * 100).toFixed(1)}%
          </div>
          <span className="text-[9px] text-[#888888] font-mono">η_o = η_th · η_p</span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Combustor Heat Release (Q_in)</span>
          <div className="text-xl font-bold font-mono text-[#E6E6E6] mt-0.5 font-mono-num">
            {combustor.heatReleaseRateMw} MW
          </div>
          <span className="text-[9px] text-[#888888] font-mono">LHV_H2 = 120.0 MJ/kg</span>
        </div>
      </div>

      {/* Complete Engine Stations (0 to 9) Thermodynamic State Table - High Density */}
      <div className="bg-[#141414] border border-[#2A2A2A] p-3">
        <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-2 mb-2">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#F2A200]" />
            <h3 className="font-mono text-[11px] font-bold text-[#E6E6E6] uppercase tracking-wider">
              AUTHORITATIVE ENGINE STATION THERMODYNAMIC STATE MATRIX
            </h3>
          </div>
          <span className="text-[10px] font-mono text-[#00FF41] flex items-center gap-1 font-bold">
            <CheckCircle2 className="w-3 h-3" />
            CONSERVATION CHECKS CONVERGED (0.00% ERROR)
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-[11px] border-collapse">
            <thead>
              <tr className="border-b border-[#2A2A2A] text-[#888888] bg-[#0C0C0C]">
                <th className="py-1.5 px-2 font-bold uppercase text-[9px]">Station</th>
                <th className="py-1.5 px-2 uppercase text-[9px]">Location Name</th>
                <th className="py-1.5 px-2 uppercase text-[9px]">Tt (K)</th>
                <th className="py-1.5 px-2 uppercase text-[9px]">Ts (K)</th>
                <th className="py-1.5 px-2 uppercase text-[9px]">Pt (kPa)</th>
                <th className="py-1.5 px-2 uppercase text-[9px]">Ps (kPa)</th>
                <th className="py-1.5 px-2 uppercase text-[9px]">Mach</th>
                <th className="py-1.5 px-2 uppercase text-[9px]">Vel (m/s)</th>
                <th className="py-1.5 px-2 uppercase text-[9px]">Flow (kg/s)</th>
                <th className="py-1.5 px-2 uppercase text-[9px]">Enthalpy (kJ/kg)</th>
                <th className="py-1.5 px-2 uppercase text-[9px]">Area (m²)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F1F1F] font-mono-num">
              {stations.map((st) => (
                <tr key={st.stationId} className="hover:bg-[#1C1C1C] transition-colors">
                  <td className="py-1.5 px-2 font-bold text-[#F2A200]">ST-{st.stationId}</td>
                  <td className="py-1.5 px-2 text-[#CCCCCC] font-sans">{st.name}</td>
                  <td className="py-1.5 px-2 text-[#E6E6E6] font-bold">{st.totalTempK}</td>
                  <td className="py-1.5 px-2 text-[#888888]">{st.staticTempK}</td>
                  <td className="py-1.5 px-2 text-[#00FF41] font-semibold">{(st.totalPressurePa / 1000).toFixed(1)}</td>
                  <td className="py-1.5 px-2 text-[#888888]">{(st.staticPressurePa / 1000).toFixed(1)}</td>
                  <td className="py-1.5 px-2 text-[#38BDF8]">{st.mach.toFixed(2)}</td>
                  <td className="py-1.5 px-2 text-[#E6E6E6]">{st.velocityMs}</td>
                  <td className="py-1.5 px-2 text-[#CCCCCC]">{st.massFlowKgS}</td>
                  <td className="py-1.5 px-2 text-[#888888]">{st.enthalpyKjKg}</td>
                  <td className="py-1.5 px-2 text-[#888888]">{st.areaM2}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Thermodynamic Visual Diagrams (T-s & P-v Cycle) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        {/* T-s Diagram SVG */}
        <div className="bg-[#141414] border border-[#2A2A2A] p-3 flex flex-col gap-2">
          <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-1.5">
            <span className="font-mono text-[10px] font-bold text-[#E6E6E6] uppercase tracking-wider">
              TEMPERATURE - ENTROPY (T-S) BRAYTON CYCLE
            </span>
            <span className="text-[9px] font-mono text-[#F2A200]">STATIONS 0 → 9</span>
          </div>

          <div className="h-52 w-full bg-[#080808] border border-[#2A2A2A] p-2 relative flex items-center justify-center">
            <svg viewBox="0 0 500 220" className="w-full h-full">
              {/* Grid Lines */}
              <line x1="40" y1="190" x2="480" y2="190" stroke="#2A2A2A" strokeWidth="1" />
              <line x1="40" y1="20" x2="40" y2="190" stroke="#2A2A2A" strokeWidth="1" />

              {/* Axis Labels */}
              <text x="470" y="210" fill="#666666" fontSize="9" fontFamily="monospace">s (kJ/kg·K)</text>
              <text x="15" y="30" fill="#666666" fontSize="9" fontFamily="monospace" transform="rotate(-90, 15, 30)">T (K)</text>

              {/* Isobar Curves (Pt2, Pt3, Pt4, Pt5, P0) */}
              <path d="M 60 180 Q 200 160 450 140" fill="none" stroke="#222222" strokeDasharray="3,3" strokeWidth="1" />
              <path d="M 60 140 Q 200 90 450 60" fill="none" stroke="#222222" strokeDasharray="3,3" strokeWidth="1" />

              {/* Actual Cycle Path */}
              <polyline
                points="70,175 110,160 170,105 340,35 410,95 460,150"
                fill="none"
                stroke="#F2A200"
                strokeWidth="2.5"
              />

              {/* Reheat path if active */}
              {twinState.reheat.active && (
                <polyline
                  points="410,95 445,45 475,120"
                  fill="none"
                  stroke="#EF4444"
                  strokeWidth="2.5"
                  strokeDasharray="4,2"
                />
              )}

              {/* Station Markers */}
              <circle cx="70" cy="175" r="4" fill="#38BDF8" />
              <text x="65" y="195" fill="#38BDF8" fontSize="9" fontFamily="monospace">ST-0</text>

              <circle cx="110" cy="160" r="4" fill="#38BDF8" />
              <text x="105" y="152" fill="#38BDF8" fontSize="9" fontFamily="monospace">ST-2</text>

              <circle cx="170" cy="105" r="4" fill="#E6E6E6" />
              <text x="155" y="98" fill="#E6E6E6" fontSize="9" fontFamily="monospace">ST-3</text>

              <circle cx="340" cy="35" r="5" fill="#F2A200" />
              <text x="330" y="25" fill="#F2A200" fontSize="10" fontWeight="bold" fontFamily="monospace">ST-4 (TIT {combustor.combustorExitTempT4K}K)</text>

              <circle cx="410" cy="95" r="4" fill="#E6E6E6" />
              <text x="415" y="95" fill="#E6E6E6" fontSize="9" fontFamily="monospace">ST-5</text>

              <circle cx="460" cy="150" r="4" fill="#00FF41" />
              <text x="450" y="168" fill="#00FF41" fontSize="9" fontFamily="monospace">ST-9</text>
            </svg>
          </div>
          <div className="flex justify-between text-[10px] font-mono text-[#888888]">
            <span>Compression Work: {((stations[3].enthalpyKjKg - stations[2].enthalpyKjKg)).toFixed(1)} kJ/kg</span>
            <span>Turbine Extraction: {((stations[4].enthalpyKjKg - stations[5].enthalpyKjKg)).toFixed(1)} kJ/kg</span>
          </div>
        </div>

        {/* Governing Equations & Scientific Deductions */}
        <div className="bg-[#141414] border border-[#2A2A2A] p-3 flex flex-col gap-2">
          <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-1.5">
            <div className="flex items-center gap-2">
              <BookOpen className="w-3.5 h-3.5 text-[#F2A200]" />
              <span className="font-mono text-[10px] font-bold text-[#E6E6E6] uppercase tracking-wider">
                GOVERNING EQUATIONS & REFERENCE THERMODYNAMICS
              </span>
            </div>
          </div>

          <div className="flex flex-col gap-1.5 text-[10px] font-mono">
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#F2A200] font-bold">1. Stagnation Energy Balance:</span>
              <p className="text-[#888888] mt-0.5">
                Tt = Ts · [1 + (γ - 1)/2 · M²] , Pt = Ps · [1 + (γ - 1)/2 · M²]^(γ / (γ - 1))
              </p>
            </div>
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#38BDF8] font-bold">2. Hydrogen Heat Addition:</span>
              <p className="text-[#888888] mt-0.5">
                m_total · Cp_gas · (T4 - T3) = m_f · LHV_H2 · η_b (LHV = 120.0 MJ/kg)
              </p>
            </div>
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#00FF41] font-bold">3. Momentum Net Thrust Equation:</span>
              <p className="text-[#888888] mt-0.5">
                Fn = m_9 · V_9 + (P_9 - P_0) · A_9 - m_0 · V_0 (Unchoked/Choked expansion)
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
