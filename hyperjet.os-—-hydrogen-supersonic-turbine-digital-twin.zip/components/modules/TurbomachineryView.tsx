'use client';

import React from 'react';
import { EngineTwinState } from '../../lib/types';
import { Activity, Gauge, ShieldCheck, Thermometer, Zap } from 'lucide-react';

interface TurbomachineryViewProps {
  twinState: EngineTwinState;
}

export default function TurbomachineryView({ twinState }: TurbomachineryViewProps) {
  const { compressor, turbine, rotor } = twinState;

  return (
    <div className="flex flex-col gap-3">
      {/* Top Banner Metric Cards - High Density Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Pressure Ratio (CPR)</span>
          <div className="text-xl font-bold font-mono text-[#38BDF8] mt-0.5 font-mono-num">
            {compressor.pressureRatioCPR.toFixed(2)} : 1
          </div>
          <span className="text-[9px] text-[#888888] font-mono">Isentropic: {(compressor.isentropicEfficiency * 100).toFixed(1)}%</span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Surge Margin (SM)</span>
          <div className="text-xl font-bold font-mono text-[#00FF41] mt-0.5 font-mono-num">
            {compressor.surgeMarginPercent}%
          </div>
          <span className="text-[9px] text-[#00FF41] font-mono">FAR 33 Certified (&gt; 18.0%)</span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Blade Substrate Temp (CMSX-4)</span>
          <div className="text-xl font-bold font-mono text-[#F2A200] mt-0.5 font-mono-num">
            {turbine.bladeMetalTempK} K
          </div>
          <span className="text-[9px] text-[#888888] font-mono">Creep Limit: 1420 K (Margin +40K)</span>
        </div>

        <div className="bg-[#141414] p-3 border border-[#2A2A2A]">
          <span className="text-[10px] font-mono text-[#666666] uppercase">Shaft Speed / Vibration</span>
          <div className="text-xl font-bold font-mono text-[#E6E6E6] mt-0.5 font-mono-num">
            {rotor.hpShaftRpm.toLocaleString()} RPM
          </div>
          <span className="text-[9px] text-[#00FF41] font-mono">Vib: {rotor.unbalanceVibrationMmS} mm/s (ISO G2.5)</span>
        </div>
      </div>

      {/* Compressor Performance Map & Turbine Thermal Gradient */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Left: 6-Stage Compressor Performance Map (7 cols) */}
        <div className="lg:col-span-7 bg-[#141414] border border-[#2A2A2A] p-3 flex flex-col gap-2">
          <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-1.5">
            <div className="flex items-center gap-2">
              <Activity className="w-3.5 h-3.5 text-[#F2A200]" />
              <span className="font-mono text-[10px] font-bold text-[#E6E6E6] uppercase tracking-wider">
                COMPRESSOR AERODYNAMIC MAP & SURGE BOUNDARY
              </span>
            </div>
            <span className="text-[9px] font-mono text-[#00FF41] font-bold">● OPERATING ON STABLE LINE</span>
          </div>

          {/* Compressor Map SVG */}
          <div className="h-60 w-full bg-[#080808] border border-[#2A2A2A] p-2 relative flex items-center justify-center">
            <svg viewBox="0 0 500 240" className="w-full h-full">
              {/* Axes */}
              <line x1="50" y1="200" x2="470" y2="200" stroke="#2A2A2A" strokeWidth="1.5" />
              <line x1="50" y1="30" x2="50" y2="200" stroke="#2A2A2A" strokeWidth="1.5" />

              <text x="420" y="225" fill="#666666" fontSize="9" fontFamily="monospace">Corrected Flow (kg/s)</text>
              <text x="15" y="40" fill="#666666" fontSize="9" fontFamily="monospace" transform="rotate(-90, 15, 40)">CPR</text>

              {/* Surge Line */}
              <path
                d="M 120 180 Q 220 90 380 40"
                fill="none"
                stroke="#EF4444"
                strokeWidth="2.5"
                strokeDasharray="5,3"
              />
              <text x="135" y="140" fill="#EF4444" fontSize="9" fontFamily="monospace" fontWeight="bold">
                SURGE BOUNDARY
              </text>

              {/* Speed Lines */}
              <path d="M 120 185 Q 160 170 200 120" fill="none" stroke="#333333" strokeWidth="1.5" />
              <text x="205" y="125" fill="#666666" fontSize="9" fontFamily="monospace">70% N</text>

              <path d="M 180 185 Q 240 160 280 90" fill="none" stroke="#333333" strokeWidth="1.5" />
              <text x="285" y="95" fill="#666666" fontSize="9" fontFamily="monospace">85% N</text>

              <path d="M 260 185 Q 340 145 380 55" fill="none" stroke="#38BDF8" strokeWidth="2" />
              <text x="385" y="60" fill="#38BDF8" fontSize="9" fontFamily="monospace">100% N (Design)</text>

              {/* Steady-State Running Line */}
              <path
                d="M 140 185 Q 260 165 370 75"
                fill="none"
                stroke="#00FF41"
                strokeWidth="2"
              />
              <text x="270" y="160" fill="#00FF41" fontSize="9" fontFamily="monospace" fontWeight="bold">
                Operating Line (SM = {compressor.surgeMarginPercent}%)
              </text>

              {/* Active Operating Point */}
              <circle cx="370" cy="75" r="5" fill="#F2A200" stroke="#FFFFFF" strokeWidth="1.5" />
              <text x="350" y="62" fill="#F2A200" fontSize="9" fontFamily="monospace" fontWeight="bold">
                CURRENT (CPR {compressor.pressureRatioCPR.toFixed(1)})
              </text>
            </svg>
          </div>

          <div className="grid grid-cols-3 gap-1.5 text-[10px] font-mono">
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] block text-[8px] uppercase">STAGE 1 TIP MACH</span>
              <span className="text-[#38BDF8] font-bold">1.25 (Transonic)</span>
            </div>
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] block text-[8px] uppercase">CORRECTED MASS FLOW</span>
              <span className="text-[#E6E6E6] font-bold">{compressor.correctedFlowKgS.toFixed(1)} kg/s</span>
            </div>
            <div className="bg-[#0C0C0C] p-2 border border-[#2A2A2A]">
              <span className="text-[#666666] block text-[8px] uppercase">ISENTROPIC EFFICIENCY</span>
              <span className="text-[#00FF41] font-bold">{(compressor.isentropicEfficiency * 100).toFixed(1)}%</span>
            </div>
          </div>
        </div>

        {/* Right: Turbine Film Cooling & TBC Thermal Gradient (5 cols) */}
        <div className="lg:col-span-5 bg-[#141414] border border-[#2A2A2A] p-3 flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-1.5">
            <div className="flex items-center gap-2">
              <Thermometer className="w-3.5 h-3.5 text-[#F2A200]" />
              <span className="font-mono text-[10px] font-bold text-[#E6E6E6] uppercase tracking-wider">
                HPT BLADE 1D THERMAL GRADIENT
              </span>
            </div>
          </div>

          {/* Thermal Layer Gradient Bar */}
          <div className="flex flex-col gap-1.5 font-mono text-[10px]">
            <div className="flex justify-between items-center bg-[#1A0A0A] p-2 border border-[#441111]">
              <span className="text-[#EF4444]">Hot Mainstream Gas (T4)</span>
              <span className="text-[#EF4444] font-bold">{twinState.combustor.combustorExitTempT4K} K</span>
            </div>

            <div className="flex justify-between items-center bg-[#1A1405] p-2 border border-[#443311]">
              <span className="text-[#F2A200]">TBC Outer Surface (YSZ)</span>
              <span className="text-[#F2A200] font-bold">{turbine.bladeMetalTempK + turbine.tbcCoatingDeltaTK} K</span>
            </div>

            <div className="flex justify-between items-center bg-[#141414] p-2 border border-[#2A2A2A]">
              <span className="text-[#E6E6E6]">Single-Crystal Metal (CMSX-4)</span>
              <span className="text-[#E6E6E6] font-bold">{turbine.bladeMetalTempK} K</span>
            </div>

            <div className="flex justify-between items-center bg-[#081520] p-2 border border-[#113344]">
              <span className="text-[#38BDF8]">Internal Cooling Bleed Air (T3)</span>
              <span className="text-[#38BDF8] font-bold">{twinState.stations[3].totalTempK} K</span>
            </div>
          </div>

          <div className="bg-[#0C0C0C] p-2.5 border border-[#2A2A2A] text-[10px] font-mono text-[#888888]">
            <span className="text-[#E6E6E6] font-bold">Euler Turbine Work Output:</span>
            <p className="mt-0.5 text-[#CCCCCC]">
              P_turb = {(turbine.hptShaftPowerKw / 1000).toFixed(2)} MW (Compressor Drive Shaft)
            </p>
            <p className="mt-0.5 text-[#888888]">
              Cooling bleed fraction: {(turbine.coolingAirFraction * 100).toFixed(1)}% air from compressor exit.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
