'use client';

import React, { useCallback, useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { EngineTwinState } from '../../lib/types';

interface EngineVisualizerProps {
  twinState: EngineTwinState;
  viewMode: 'CUTAWAY' | 'THERMAL' | 'AIRFLOW' | 'MANUFACTURING' | 'EXTERIOR' | 'EXPLODED';
  selectedComponentId: string | null;
  onSelectComponent: (componentId: string) => void;
}

export default function EngineVisualizer({
  twinState,
  viewMode,
  selectedComponentId,
  onSelectComponent,
}: EngineVisualizerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rotorGroupRef = useRef<THREE.Group | null>(null);
  const flameGroupRef = useRef<THREE.Group | null>(null);
  const reheatFlameRef = useRef<THREE.Mesh | null>(null);
  const particlesRef = useRef<THREE.Points | null>(null);
  const shockGroupRef = useRef<THREE.Group | null>(null);
  const componentMeshesRef = useRef<Map<string, THREE.Object3D>>(new Map());

  const [hoveredName, setHoveredName] = useState<string | null>(null);
  const isDraggingRef = useRef(false);
  const previousMousePositionRef = useRef({ x: 0, y: 0 });
  const cameraAnglesRef = useRef({ theta: Math.PI / 4, phi: Math.PI / 3.2, radius: 14.5 });
  const onSelectComponentRef = useRef(onSelectComponent);

  useEffect(() => {
    onSelectComponentRef.current = onSelectComponent;
  }, [onSelectComponent]);

  const updateCameraPosition = useCallback(() => {
    if (!cameraRef.current) return;
    const { theta, phi, radius } = cameraAnglesRef.current;
    cameraRef.current.position.x = radius * Math.sin(phi) * Math.cos(theta);
    cameraRef.current.position.y = radius * Math.cos(phi);
    cameraRef.current.position.z = radius * Math.sin(phi) * Math.sin(theta);
    cameraRef.current.lookAt(0, 0, 0);
  }, []);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // 1. Scene Setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x080c14);
    sceneRef.current = scene;

    // 2. Camera Setup
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 500;
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    cameraRef.current = camera;
    updateCameraPosition();

    // 3. WebGL Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    rendererRef.current = renderer;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 4. Lighting Rig (Technical Aerospace Studio)
    const ambientLight = new THREE.AmbientLight(0xdde5f4, 0.7);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xfff8ee, 1.4);
    dirLight1.position.set(10, 15, 12);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x4488ff, 0.8);
    dirLight2.position.set(-10, -5, -10);
    scene.add(dirLight2);

    const combustorPointLight = new THREE.PointLight(0xff7700, 2.5, 8);
    combustorPointLight.position.set(0.2, 0, 0);
    scene.add(combustorPointLight);

    // Engineering Ground Grid
    const gridHelper = new THREE.GridHelper(24, 24, 0x1e293b, 0x0f172a);
    gridHelper.position.y = -3.2;
    scene.add(gridHelper);

    // 5. Build Complete HJ-22 Engine Model Geometry
    const masterEngineGroup = new THREE.Group();
    scene.add(masterEngineGroup);

    const rotorGroup = new THREE.Group();
    masterEngineGroup.add(rotorGroup);
    rotorGroupRef.current = rotorGroup;

    const shockGroup = new THREE.Group();
    masterEngineGroup.add(shockGroup);
    shockGroupRef.current = shockGroup;

    const flameGroup = new THREE.Group();
    masterEngineGroup.add(flameGroup);
    flameGroupRef.current = flameGroup;

    // Helper Materials
    const titaniumMat = new THREE.MeshStandardMaterial({
      color: 0x8294a8,
      metalness: 0.88,
      roughness: 0.28,
    });

    const polishedSteelMat = new THREE.MeshStandardMaterial({
      color: 0xccd6e0,
      metalness: 0.95,
      roughness: 0.15,
    });

    const cmcCarbonMat = new THREE.MeshStandardMaterial({
      color: 0x22262c,
      metalness: 0.3,
      roughness: 0.7,
    });

    const copperCryoMat = new THREE.MeshStandardMaterial({
      color: 0xd97736,
      metalness: 0.85,
      roughness: 0.25,
    });

    const turbineGlowMat = new THREE.MeshStandardMaterial({
      color: 0xff4500,
      emissive: 0xcc2200,
      emissiveIntensity: 0.8,
      metalness: 0.6,
      roughness: 0.35,
    });

    // Subsystem 1: Supersonic Inlet Assembly (X: -5.5 to -3.2)
    const inletGroup = new THREE.Group();
    inletGroup.name = 'MOD-INLET';
    masterEngineGroup.add(inletGroup);
    componentMeshesRef.current.set('MOD-INLET', inletGroup);

    // 2D Supersonic Ramp System
    const rampGeo = new THREE.BoxGeometry(2.4, 0.12, 1.8);
    const rampMesh = new THREE.Mesh(rampGeo, titaniumMat);
    rampMesh.position.set(-4.5, 0.65, 0);
    rampMesh.rotation.z = 0.14; // Default ramp pitch
    inletGroup.add(rampMesh);

    // Porous boundary layer bleed duct
    const bleedGeo = new THREE.BoxGeometry(1.2, 0.08, 1.7);
    const bleedMesh = new THREE.Mesh(bleedGeo, titaniumMat);
    bleedMesh.position.set(-4.0, 0.72, 0);
    inletGroup.add(bleedMesh);

    // Inlet Cowl Lip
    const cowlGeo = new THREE.CylinderGeometry(1.05, 1.05, 2.2, 32, 1, true, 0, Math.PI);
    const cowlMesh = new THREE.Mesh(cowlGeo, titaniumMat);
    cowlMesh.rotation.z = Math.PI / 2;
    cowlMesh.position.set(-4.4, 0, 0);
    inletGroup.add(cowlMesh);

    // Supersonic Oblique Shock Wave Planes (Translucent)
    const shockMat = new THREE.MeshBasicMaterial({
      color: 0x06b6d4,
      transparent: true,
      opacity: 0.35,
      side: THREE.DoubleSide,
    });
    const shock1Geo = new THREE.PlaneGeometry(2.8, 2.2);
    const shock1Mesh = new THREE.Mesh(shock1Geo, shockMat);
    shock1Mesh.rotation.y = Math.PI / 2;
    shock1Mesh.rotation.x = -0.55;
    shock1Mesh.position.set(-5.6, 0.4, 0);
    shockGroup.add(shock1Mesh);

    const shock2Mesh = new THREE.Mesh(new THREE.PlaneGeometry(2.0, 2.0), shockMat);
    shock2Mesh.rotation.y = Math.PI / 2;
    shock2Mesh.rotation.x = -0.85;
    shock2Mesh.position.set(-4.2, 0.2, 0);
    shockGroup.add(shock2Mesh);

    // Subsystem 2: 6-Stage Compressor (X: -3.2 to -0.8)
    const compGroup = new THREE.Group();
    compGroup.name = 'MOD-COMPRESSOR';
    masterEngineGroup.add(compGroup);
    componentMeshesRef.current.set('MOD-COMPRESSOR', compGroup);

    // Compressor Casing (Cutaway half-shell)
    const compCasingGeo = new THREE.CylinderGeometry(1.0, 0.82, 2.4, 32, 1, true, 0, Math.PI);
    const compCasingMesh = new THREE.Mesh(compCasingGeo, titaniumMat);
    compCasingMesh.rotation.z = Math.PI / 2;
    compCasingMesh.position.set(-2.0, 0, 0);
    compGroup.add(compCasingMesh);

    // 6 Blisk Rotor Stages (Attached to rotorGroup so they spin!)
    const stageRadii = [0.95, 0.90, 0.86, 0.82, 0.78, 0.75];
    const stagePositions = [-3.0, -2.6, -2.2, -1.8, -1.4, -1.0];

    stageRadii.forEach((radius, i) => {
      const diskGeo = new THREE.CylinderGeometry(radius * 0.45, radius * 0.45, 0.08, 24);
      const diskMesh = new THREE.Mesh(diskGeo, polishedSteelMat);
      diskMesh.rotation.z = Math.PI / 2;
      diskMesh.position.set(stagePositions[i], 0, 0);
      rotorGroup.add(diskMesh);

      // Blades on disk perimeter (20 aerofoil blades per stage)
      const numBlades = 18;
      for (let b = 0; b < numBlades; b++) {
        const bladeGeo = new THREE.BoxGeometry(0.04, radius * 0.55, 0.12);
        const bladeMesh = new THREE.Mesh(bladeGeo, titaniumMat);
        const angle = (b / numBlades) * Math.PI * 2;
        bladeMesh.position.set(
          stagePositions[i],
          Math.cos(angle) * (radius * 0.68),
          Math.sin(angle) * (radius * 0.68)
        );
        bladeMesh.rotation.x = angle;
        bladeMesh.rotation.y = 0.35; // Stagger angle
        rotorGroup.add(bladeMesh);
      }
    });

    // Subsystem 3: Hydrogen Combustor & Micromix Injectors (X: -0.8 to +0.8)
    const combGroup = new THREE.Group();
    combGroup.name = 'MOD-COMBUSTOR';
    masterEngineGroup.add(combGroup);
    componentMeshesRef.current.set('MOD-COMBUSTOR', combGroup);

    // Toroidal Hydrogen Fuel Manifold
    const fuelRailGeo = new THREE.TorusGeometry(0.88, 0.035, 16, 32);
    const fuelRailMesh = new THREE.Mesh(fuelRailGeo, copperCryoMat);
    fuelRailMesh.rotation.y = Math.PI / 2;
    fuelRailMesh.position.set(-0.75, 0, 0);
    combGroup.add(fuelRailMesh);

    // 36 Micromix Injector Lances
    for (let inj = 0; inj < 16; inj++) {
      const injAngle = (inj / 16) * Math.PI * 2;
      const injLanceGeo = new THREE.CylinderGeometry(0.015, 0.015, 0.28, 8);
      const injLanceMesh = new THREE.Mesh(injLanceGeo, copperCryoMat);
      injLanceMesh.position.set(
        -0.65,
        Math.cos(injAngle) * 0.65,
        Math.sin(injAngle) * 0.65
      );
      injLanceMesh.rotation.x = injAngle;
      combGroup.add(injLanceMesh);
    }

    // Combustor Liner (CMC Perforated Shell)
    const linerGeo = new THREE.CylinderGeometry(0.78, 0.74, 1.4, 32, 1, true, 0, Math.PI);
    const linerMesh = new THREE.Mesh(linerGeo, cmcCarbonMat);
    linerMesh.rotation.z = Math.PI / 2;
    linerMesh.position.set(0.0, 0, 0);
    combGroup.add(linerMesh);

    // Dynamic Hydrogen Combustion Flame Volume
    const flameGeo = new THREE.ConeGeometry(0.65, 1.3, 16, 1, true);
    const flameMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8, // Lean hydrogen blue-violet core
      transparent: true,
      opacity: 0.65,
      side: THREE.DoubleSide,
    });
    const flameMesh = new THREE.Mesh(flameGeo, flameMat);
    flameMesh.rotation.z = -Math.PI / 2;
    flameMesh.position.set(0.1, 0, 0);
    flameGroup.add(flameMesh);

    // Subsystem 4: High & Low Pressure Turbine Module (X: +0.8 to +2.4)
    const turbGroup = new THREE.Group();
    turbGroup.name = 'MOD-TURBINE';
    masterEngineGroup.add(turbGroup);
    componentMeshesRef.current.set('MOD-TURBINE', turbGroup);

    // Turbine Casing
    const turbCasingGeo = new THREE.CylinderGeometry(0.76, 0.85, 1.6, 32, 1, true, 0, Math.PI);
    const turbCasingMesh = new THREE.Mesh(turbCasingGeo, cmcCarbonMat);
    turbCasingMesh.rotation.z = Math.PI / 2;
    turbCasingMesh.position.set(1.6, 0, 0);
    turbGroup.add(turbCasingMesh);

    // HPT & LPT Turbine Rotor Stages (Single Crystal CMSX-4 Glowing)
    const turbStages = [1.0, 1.5, 2.0];
    const turbRadii = [0.72, 0.75, 0.80];

    turbStages.forEach((pos, idx) => {
      const diskGeo = new THREE.CylinderGeometry(turbRadii[idx] * 0.45, turbRadii[idx] * 0.45, 0.09, 24);
      const diskMesh = new THREE.Mesh(diskGeo, polishedSteelMat);
      diskMesh.rotation.z = Math.PI / 2;
      diskMesh.position.set(pos, 0, 0);
      rotorGroup.add(diskMesh);

      for (let tb = 0; tb < 16; tb++) {
        const tbGeo = new THREE.BoxGeometry(0.045, turbRadii[idx] * 0.55, 0.13);
        const tbMesh = new THREE.Mesh(tbGeo, turbineGlowMat);
        const angle = (tb / 16) * Math.PI * 2;
        tbMesh.position.set(
          pos,
          Math.cos(angle) * (turbRadii[idx] * 0.68),
          Math.sin(angle) * (turbRadii[idx] * 0.68)
        );
        tbMesh.rotation.x = angle;
        tbMesh.rotation.y = -0.42;
        rotorGroup.add(tbMesh);
      }
    });

    // Subsystem 5: Concentric Dual Shaft System
    const shaftGroup = new THREE.Group();
    shaftGroup.name = 'MOD-ROTOR-SHAFT';
    masterEngineGroup.add(shaftGroup);
    componentMeshesRef.current.set('MOD-ROTOR-SHAFT', shaftGroup);

    // HP Outer Shaft + LP Inner Shaft
    const shaftGeo = new THREE.CylinderGeometry(0.18, 0.18, 6.2, 24);
    const shaftMesh = new THREE.Mesh(shaftGeo, polishedSteelMat);
    shaftMesh.rotation.z = Math.PI / 2;
    shaftMesh.position.set(-0.5, 0, 0);
    rotorGroup.add(shaftMesh);

    // 4 Main Bearing Housings
    const bearingPositions = [-3.1, -1.1, 0.9, 2.3];
    bearingPositions.forEach((bPos) => {
      const brgGeo = new THREE.TorusGeometry(0.32, 0.05, 12, 24);
      const brgMesh = new THREE.Mesh(brgGeo, polishedSteelMat);
      brgMesh.rotation.y = Math.PI / 2;
      brgMesh.position.set(bPos, 0, 0);
      shaftGroup.add(brgMesh);
    });

    // Subsystem 6: Variable-Area Supersonic Exhaust Nozzle (X: +2.4 to +5.2)
    const nozGroup = new THREE.Group();
    nozGroup.name = 'MOD-NOZZLE';
    masterEngineGroup.add(nozGroup);
    componentMeshesRef.current.set('MOD-NOZZLE', nozGroup);

    // Convergent-Divergent Petal Iris
    const nozGeo = new THREE.CylinderGeometry(0.85, 1.05, 2.6, 32, 1, true, 0, Math.PI);
    const nozMesh = new THREE.Mesh(nozGeo, titaniumMat);
    nozMesh.rotation.z = Math.PI / 2;
    nozMesh.position.set(3.8, 0, 0);
    nozGroup.add(nozMesh);

    // Hydrogen Reheat Supersonic Exhaust Plume (Shock Diamonds)
    const reheatGeo = new THREE.ConeGeometry(0.95, 3.8, 20, 1, true);
    const reheatMat = new THREE.MeshBasicMaterial({
      color: 0x60a5fa,
      transparent: true,
      opacity: 0.75,
      side: THREE.DoubleSide,
    });
    const reheatMesh = new THREE.Mesh(reheatGeo, reheatMat);
    reheatMesh.rotation.z = -Math.PI / 2;
    reheatMesh.position.set(5.8, 0, 0);
    masterEngineGroup.add(reheatMesh);
    reheatFlameRef.current = reheatMesh;

    // Subsystem 7: Airflow Particle Streamlines
    const particleCount = 450;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    const particleColors = new Float32Array(particleCount * 3);

    for (let p = 0; p < particleCount; p++) {
      const x = (Math.random() - 0.5) * 14.0;
      const radius = Math.random() * 0.9;
      const angle = Math.random() * Math.PI * 2;
      const y = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;

      particlePositions[p * 3] = x;
      particlePositions[p * 3 + 1] = y;
      particlePositions[p * 3 + 2] = z;

      // Color coding by Mach / temperature
      particleColors[p * 3] = 0.2 + (x + 7.0) / 14.0;
      particleColors[p * 3 + 1] = 0.6;
      particleColors[p * 3 + 2] = 0.9 - (x + 7.0) / 16.0;
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    particleGeo.setAttribute('color', new THREE.BufferAttribute(particleColors, 3));

    const particleMat = new THREE.PointsMaterial({
      size: 0.08,
      vertexColors: true,
      transparent: true,
      opacity: 0.65,
    });

    const particles = new THREE.Points(particleGeo, particleMat);
    masterEngineGroup.add(particles);
    particlesRef.current = particles;

    // Mouse Interaction Handlers for Orbit / Pan
    const onMouseDown = (e: MouseEvent) => {
      isDraggingRef.current = true;
      previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e: MouseEvent) => {
      if (isDraggingRef.current) {
        const deltaX = e.clientX - previousMousePositionRef.current.x;
        const deltaY = e.clientY - previousMousePositionRef.current.y;

        cameraAnglesRef.current.theta -= deltaX * 0.008;
        cameraAnglesRef.current.phi = Math.max(0.1, Math.min(Math.PI - 0.1, cameraAnglesRef.current.phi - deltaY * 0.008));

        updateCameraPosition();
        previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
      }

      // Raycast for hover selection
      const rect = container.getBoundingClientRect();
      const mouse = new THREE.Vector2(
        ((e.clientX - rect.left) / container.clientWidth) * 2 - 1,
        -((e.clientY - rect.top) / container.clientHeight) * 2 + 1
      );

      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(masterEngineGroup.children, true);

      if (intersects.length > 0) {
        let parent: THREE.Object3D | null = intersects[0].object;
        while (parent && !parent.name.startsWith('MOD-') && parent !== masterEngineGroup) {
          parent = parent.parent;
        }
        if (parent && parent.name.startsWith('MOD-')) {
          setHoveredName(parent.name);
          container.style.cursor = 'pointer';
          return;
        }
      }
      setHoveredName(null);
      container.style.cursor = isDraggingRef.current ? 'grabbing' : 'grab';
    };

    const onMouseUp = () => {
      isDraggingRef.current = false;
      container.style.cursor = 'grab';
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      cameraAnglesRef.current.radius = Math.max(5.0, Math.min(28.0, cameraAnglesRef.current.radius + e.deltaY * 0.015));
      updateCameraPosition();
    };

    const onClick = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const mouse = new THREE.Vector2(
        ((e.clientX - rect.left) / container.clientWidth) * 2 - 1,
        -((e.clientY - rect.top) / container.clientHeight) * 2 + 1
      );

      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(masterEngineGroup.children, true);

      if (intersects.length > 0) {
        let parent: THREE.Object3D | null = intersects[0].object;
        while (parent && !parent.name.startsWith('MOD-') && parent !== masterEngineGroup) {
          parent = parent.parent;
        }
        if (parent && parent.name.startsWith('MOD-')) {
          onSelectComponentRef.current(parent.name);
        }
      }
    };

    container.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    container.addEventListener('wheel', onWheel, { passive: false });
    container.addEventListener('click', onClick);

    // Resize Handler
    const handleResize = () => {
      if (!container || !rendererRef.current || !cameraRef.current) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(container);

    // Animation Loop
    let animationFrameId: number;
    let clock = 0;

    const animate = () => {
      clock += 0.016;

      // Spin rotors proportional to HP Shaft RPM (Nominal 14,200 RPM scaled for visual clarity)
      if (rotorGroupRef.current) {
        rotorGroupRef.current.rotation.x += 0.12 * (twinState.compressor.correctedRpmPercent / 100);
      }

      // Flame flicker & heat shimmer
      if (flameGroupRef.current) {
        const scale = 1.0 + 0.08 * Math.sin(clock * 25);
        flameGroupRef.current.scale.set(1.0, scale, scale);
      }

      // Reheat visibility and shock diamonds
      if (reheatFlameRef.current) {
        reheatFlameRef.current.visible = twinState.reheat.active;
        if (twinState.reheat.active) {
          const reheatPulse = 1.0 + 0.12 * Math.sin(clock * 35);
          reheatFlameRef.current.scale.set(1.0, reheatPulse, reheatPulse);
        }
      }

      // Streamline particles forward flow
      if (particlesRef.current) {
        const positions = particlesRef.current.geometry.attributes.position.array as Float32Array;
        const speed = 0.18 * (twinState.flight.mach / 2.2);

        for (let i = 0; i < particleCount; i++) {
          positions[i * 3] += speed;
          if (positions[i * 3] > 7.0) {
            positions[i * 3] = -7.0;
          }
        }
        particlesRef.current.geometry.attributes.position.needsUpdate = true;
      }

      // Variable Ramp Angle update from physics state
      if (rampMesh) {
        rampMesh.rotation.z = 0.10 + (twinState.flight.inletAngleDeg / 180) * Math.PI;
      }

      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      container.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      container.removeEventListener('wheel', onWheel);
      container.removeEventListener('click', onClick);
      resizeObserver.disconnect();
      if (rendererRef.current) {
        rendererRef.current.dispose();
      }
    };
  }, [
    twinState.flight.mach,
    twinState.flight.inletAngleDeg,
    twinState.compressor.correctedRpmPercent,
    twinState.reheat.active,
    updateCameraPosition,
  ]);

  // Update view mode display (Cutaway, Thermal, Airflow, etc.)
  useEffect(() => {
    const shock = shockGroupRef.current;
    const particles = particlesRef.current;
    if (shock) shock.visible = viewMode === 'AIRFLOW' || viewMode === 'CUTAWAY';
    if (particles) particles.visible = viewMode === 'AIRFLOW';
  }, [viewMode]);

  return (
    <div className="relative w-full h-full min-h-[420px] bg-[#070b12] rounded-xl overflow-hidden border border-slate-800 shadow-2xl select-none">
      <div ref={containerRef} className="w-full h-full cursor-grab" />

      {/* 3D Viewport HUD Overlays */}
      <div className="absolute top-4 left-4 flex flex-col gap-1.5 pointer-events-none">
        <div className="flex items-center gap-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-700/60 text-xs">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-mono text-slate-300 font-semibold tracking-wider">HJ-22 DIGITAL TWIN 3D</span>
          <span className="text-slate-500">|</span>
          <span className="font-mono text-amber-400">MACH {twinState.flight.mach.toFixed(2)}</span>
          <span className="text-slate-500">|</span>
          <span className="font-mono text-cyan-400">{viewMode} MODE</span>
        </div>
        {hoveredName && (
          <div className="bg-cyan-950/90 backdrop-blur-md px-3 py-1 rounded border border-cyan-500/40 text-[11px] font-mono text-cyan-300 shadow-lg">
            INSPECT: <span className="font-bold text-white">{hoveredName}</span> (CLICK TO TRACE DIGITAL THREAD)
          </div>
        )}
      </div>

      {/* 3D Viewport Controls Guide */}
      <div className="absolute bottom-3 right-4 bg-slate-900/80 backdrop-blur-md px-3 py-1 rounded border border-slate-800 text-[10px] font-mono text-slate-400 pointer-events-none">
        LEFT DRAG: ORBIT • WHEEL: ZOOM • CLICK: SELECT COMPONENT
      </div>
    </div>
  );
}
