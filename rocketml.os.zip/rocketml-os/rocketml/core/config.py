"""
Rocket, Stage, Engine, Environment, and Mission configurations.
Compatible with Pydantic v2 and provides zero-dependency fallback.
"""

from typing import List, Optional, Any, Dict
from dataclasses import dataclass, field
import copy

try:
    from pydantic import BaseModel, Field
except ImportError:
    class BaseModel:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
        def model_copy(self, update: Dict[str, Any] = None):
            obj = copy.deepcopy(self)
            if update:
                for k, v in update.items():
                    setattr(obj, k, v)
            return obj
    def Field(default=None, description=""):
        return default

class EngineConfig(BaseModel):
    def __init__(
        self,
        name: str = "Merlin-1D-Vacuum-Equivalent",
        thrust_vac: float = 845000.0,
        thrust_sl: float = 760000.0,
        isp_vac: float = 311.0,
        isp_sl: float = 282.0,
        exit_area: float = 0.95,
        min_throttle: float = 0.40,
        max_throttle: float = 1.00,
        gimbal_limit_deg: float = 5.0,
        **kwargs
    ):
        self.name = name
        self.thrust_vac = thrust_vac
        self.thrust_sl = thrust_sl
        self.isp_vac = isp_vac
        self.isp_sl = isp_sl
        self.exit_area = exit_area
        self.min_throttle = min_throttle
        self.max_throttle = max_throttle
        self.gimbal_limit_deg = gimbal_limit_deg
        super().__init__(**kwargs)

class StageConfig(BaseModel):
    def __init__(
        self,
        name: str = "Stage 1",
        dry_mass: float = 25000.0,
        propellant_mass: float = 395000.0,
        engine_count: int = 9,
        engine: Optional[EngineConfig] = None,
        burn_time: float = 162.0,
        **kwargs
    ):
        self.name = name
        self.dry_mass = dry_mass
        self.propellant_mass = propellant_mass
        self.engine_count = engine_count
        self.engine = engine or EngineConfig()
        self.burn_time = burn_time
        super().__init__(**kwargs)

class RocketConfig(BaseModel):
    def __init__(
        self,
        name: str = "Falcon-Class Two-Stage Booster",
        stages: Optional[List[StageConfig]] = None,
        payload_mass: float = 5000.0,
        fairing_mass: float = 1750.0,
        reference_area: float = 10.5,
        diameter: float = 3.66,
        length: float = 70.0,
        cd_subsonic: float = 0.28,
        cd_transonic_peak: float = 0.68,
        cd_supersonic: float = 0.35,
        **kwargs
    ):
        self.name = name
        self.stages = stages if stages is not None else [StageConfig()]
        self.payload_mass = payload_mass
        self.fairing_mass = fairing_mass
        self.reference_area = reference_area
        self.diameter = diameter
        self.length = length
        self.cd_subsonic = cd_subsonic
        self.cd_transonic_peak = cd_transonic_peak
        self.cd_supersonic = cd_supersonic
        super().__init__(**kwargs)

class EnvironmentConfig(BaseModel):
    def __init__(
        self,
        name: str = "US-Standard-1976",
        surface_temperature_k: float = 288.15,
        surface_pressure_pa: float = 101325.0,
        wind_speed_ms: float = 0.0,
        wind_heading_deg: float = 0.0,
        turbulence_intensity: float = 0.02,
        coriolis_enabled: bool = True,
        launch_latitude_deg: float = 28.5,
        **kwargs
    ):
        self.name = name
        self.surface_temperature_k = surface_temperature_k
        self.surface_pressure_pa = surface_pressure_pa
        self.wind_speed_ms = wind_speed_ms
        self.wind_heading_deg = wind_heading_deg
        self.turbulence_intensity = turbulence_intensity
        self.coriolis_enabled = coriolis_enabled
        self.launch_latitude_deg = launch_latitude_deg
        super().__init__(**kwargs)

class MissionConfig(BaseModel):
    def __init__(
        self,
        target_apogee_m: float = 200000.0,
        target_velocity_ms: float = 7800.0,
        pitch_kick_time_s: float = 12.0,
        pitch_kick_angle_deg: float = 2.5,
        gravity_turn_exponent: float = 0.65,
        max_q_limit_pa: float = 45000.0,
        max_accel_limit_g: float = 5.0,
        time_limit_s: float = 600.0,
        **kwargs
    ):
        self.target_apogee_m = target_apogee_m
        self.target_velocity_ms = target_velocity_ms
        self.pitch_kick_time_s = pitch_kick_time_s
        self.pitch_kick_angle_deg = pitch_kick_angle_deg
        self.gravity_turn_exponent = gravity_turn_exponent
        self.max_q_limit_pa = max_q_limit_pa
        self.max_accel_limit_g = max_accel_limit_g
        self.time_limit_s = time_limit_s
        super().__init__(**kwargs)
