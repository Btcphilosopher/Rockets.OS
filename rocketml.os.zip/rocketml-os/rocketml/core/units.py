"""
Constants and explicit unit conversion factors for aerospace computations.
Internally, ROCKETML.OS strictly utilizes SI units (m, kg, s, N, Pa, K, rad).
"""

# Earth Gravitational and Geodetic Constants
EARTH_RADIUS = 6371000.0        # Mean Earth Radius [m]
EARTH_MU = 3.986004418e14       # Earth standard gravitational parameter GM [m^3/s^2]
STANDARD_GRAVITY = 9.80665      # Standard acceleration of gravity g0 [m/s^2]
EARTH_ROTATION_RATE = 7.2921159e-5 # Earth angular velocity [rad/s]

# Sea level standard atmosphere
SEA_LEVEL_PRESSURE = 101325.0   # [Pa]
SEA_LEVEL_TEMPERATURE = 288.15  # [K]
SEA_LEVEL_DENSITY = 1.225       # [kg/m^3]
GAS_CONSTANT_AIR = 287.05287    # Specific gas constant for dry air [J/(kg*K)]
GAMMA_AIR = 1.40                # Ratio of specific heats for dry air

def km_to_m(km: float) -> float:
    return km * 1000.0

def m_to_km(m: float) -> float:
    return m / 1000.0

def deg_to_rad(deg: float) -> float:
    import math
    return deg * (math.pi / 180.0)

def rad_to_deg(rad: float) -> float:
    import math
    return rad * (180.0 / math.pi)

def bar_to_pa(bar: float) -> float:
    return bar * 1e5

def pa_to_bar(pa: float) -> float:
    return pa / 1e5

def lbf_to_n(lbf: float) -> float:
    return lbf * 4.4482216152605
