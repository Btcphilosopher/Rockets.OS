"""
Vector and numerical utilities with zero-dependency fallback when NumPy is not installed.
"""

import math
import random

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    class PseudoNumpy:
        ndarray = list
        @staticmethod
        def array(data, dtype=None):
            return list(data)
        @staticmethod
        def zeros(shape):
            if isinstance(shape, int):
                return [0.0] * shape
            return [[0.0] * shape[1] for _ in range(shape[0])]
        @staticmethod
        def diag(vals):
            n = len(vals)
            res = [[0.0] * n for _ in range(n)]
            for i in range(n):
                res[i][i] = float(vals[i])
            return res
        @staticmethod
        def eye(n):
            return PseudoNumpy.diag([1.0] * n)
        @staticmethod
        def linspace(start, stop, num=50):
            if num <= 1:
                return [start]
            step = (stop - start) / (num - 1)
            return [start + i * step for i in range(num)]
        @staticmethod
        def max(arr):
            return max(arr)
        @staticmethod
        def mean(arr):
            return sum(arr) / max(1, len(arr))
        @staticmethod
        def dot(a, b):
            return sum(x * y for x, y in zip(a, b))
        @staticmethod
        def maximum(a, b):
            if isinstance(b, (int, float)):
                return [max(x, b) for x in a]
            return [max(x, y) for x, y in zip(a, b)]
        
        class random:
            @staticmethod
            def seed(s):
                random.seed(s)
            @staticmethod
            def randn(*shape):
                if len(shape) == 1:
                    return [random.gauss(0, 1) for _ in range(shape[0])]
                elif len(shape) == 2:
                    return [[random.gauss(0, 1) for _ in range(shape[1])] for _ in range(shape[0])]
                return [random.gauss(0, 1)]

        class RandomState:
            def __init__(self, seed=42):
                self.rng = random.Random(seed)
            def uniform(self, low, high):
                return self.rng.uniform(low, high)
            def normal(self, mean, std):
                return self.rng.gauss(mean, std)

    np = PseudoNumpy()
