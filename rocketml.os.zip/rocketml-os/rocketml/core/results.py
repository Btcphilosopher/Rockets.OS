"""
Engineering Result Container exposing explicit physics units, assumptions, and equations.
"""

from typing import Any, Dict, Optional
from dataclasses import dataclass, field

@dataclass
class EngineeringResult:
    """
    Structured physical result satisfying ROCKETML.OS Engineering Principles.
    Every calculation must expose equations, inputs, validity range, and uncertainty.
    """
    value: float
    unit: str
    equation: str
    inputs: Dict[str, Any] = field(default_factory=dict)
    assumptions: str = ""
    validity_range: str = ""
    uncertainty: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "value": self.value,
            "unit": self.unit,
            "equation": self.equation,
            "inputs": self.inputs,
            "assumptions": self.assumptions,
            "validity_range": self.validity_range,
            "uncertainty": self.uncertainty
        }

    def __repr__(self) -> str:
        return (
            f"EngineeringResult({self.value:.4g} {self.unit} "
            f"| Eq: '{self.equation}' | Uncertainty: ±{self.uncertainty:.3g})"
        )
