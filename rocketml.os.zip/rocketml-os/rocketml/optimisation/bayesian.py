"""
AI Trajectory Optimizer: Bayesian Surrogate Optimization and Physics Validation Loop.
"""

from typing import Dict, Any, List, Tuple
import math
from rocketml.core.num import np

from rocketml.core.config import RocketConfig, MissionConfig, EnvironmentConfig
from rocketml.trajectory.solver import TrajectorySolver
from rocketml.guidance.constraints import ConstraintEngine
from rocketml.ml.surrogate import TrajectorySurrogateModel

class AITrajectoryOptimizer:
    """
    Implements the Hybrid Optimization Loop:
    Parameters -> ML Surrogate -> Candidate Trajectories -> Constraint Check
               -> Physics Simulation -> Ground Truth -> Error Analysis -> Accept / Reject
    """

    def __init__(self, rocket: RocketConfig, mission: MissionConfig, environment: EnvironmentConfig):
        self.rocket = rocket
        self.mission = mission
        self.environment = environment
        self.surrogate = TrajectorySurrogateModel()
        self.constraint_engine = ConstraintEngine(mission)

    def optimize_pitch_schedule(self, n_iterations: int = 15) -> Dict[str, Any]:
        """
        Searches for optimal (pitch_kick_time_s, pitch_kick_angle_deg) that maximizes
        apogee altitude while strictly adhering to Max-Q and Max-G constraints.
        """
        best_candidate = None
        best_score = -float('inf')
        best_trajectory = None
        history: List[Dict[str, Any]] = []

        kick_times = np.linspace(8.0, 20.0, 5)
        kick_angles = np.linspace(1.5, 4.5, 4)

        for kick_t in kick_times:
            for kick_a in kick_angles:
                # 1. Surrogate fast pre-screening
                surrogate_eval = self.surrogate.predict_summary({
                    "pitch_kick_time_s": float(kick_t),
                    "pitch_kick_angle_deg": float(kick_a)
                })

                predicted_q = surrogate_eval["predicted_max_dynamic_pressure_pa"]
                # Soft penalty rather than hard skip for surrogate
                if predicted_q > self.mission.max_q_limit_pa * 1.5:
                    continue

                # 2. Physics ground-truth verification
                temp_mission = self.mission.model_copy()
                temp_mission.pitch_kick_time_s = float(kick_t)
                temp_mission.pitch_kick_angle_deg = float(kick_a)

                solver = TrajectorySolver(self.rocket, self.environment, temp_mission, integrator_method="RK4")
                phys_traj = solver.solve(dt=1.0, time_limit_s=300.0)

                # 3. Hard constraint check
                constraints = self.constraint_engine.evaluate(phys_traj)
                summary = phys_traj.summary()
                alt = summary.get("max_altitude_m", 0.0)

                is_valid = constraints["is_valid"]
                score = alt if is_valid else (alt - 100000.0)

                iteration_record = {
                    "kick_time_s": round(float(kick_t), 2),
                    "kick_angle_deg": round(float(kick_a), 2),
                    "surrogate_predicted_alt_m": round(surrogate_eval["predicted_max_altitude_m"], 1),
                    "physics_ground_truth_alt_m": round(alt, 1),
                    "surrogate_error_percent": round(abs(surrogate_eval["predicted_max_altitude_m"] - alt) / max(1.0, alt) * 100.0, 2),
                    "max_dynamic_pressure_pa": round(summary.get("max_dynamic_pressure_pa", 0.0), 1),
                    "constraint_status": constraints["status"],
                    "score": round(score, 1)
                }
                history.append(iteration_record)

                if (is_valid and score > best_score) or best_candidate is None:
                    best_score = score
                    best_candidate = iteration_record
                    best_trajectory = phys_traj

                if len(history) >= n_iterations:
                    break
            if len(history) >= n_iterations:
                break

        return {
            "status": "OPTIMIZATION_COMPLETE",
            "optimal_parameters": best_candidate,
            "best_score": best_score,
            "total_evaluations": len(history),
            "history": history,
            "summary": best_trajectory.summary() if best_trajectory else {}
        }
