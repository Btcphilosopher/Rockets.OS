"""
ROCKETML.OS: AI / Machine-Learning Rocket Trajectory Simulation & Optimisation Engine
"""

__version__ = "1.0.0"
__author__ = "ROCKETML.OS Aerospace & ML Laboratory"
