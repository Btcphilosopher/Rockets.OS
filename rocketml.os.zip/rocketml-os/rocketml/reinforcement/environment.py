"""
Reinforcement Learning Environment (RocketTrajectoryEnv) with Physical Safety Boundary.
"""

from typing import Tuple, Dict, Any, List
import math
from rocketml.core.num import np

from rocketml.core.config import RocketConfig, MissionConfig, EnvironmentConfig
from rocketml.physics.atmosphere import USStandardAtmosphere
from rocketml.physics.gravity import GravityModel
from rocketml.physics.propulsion import PropulsionModel
from rocketml.physics.aerodynamics import AerodynamicModel

class RocketTrajectoryEnv:
    """
    Gymnasium-compatible trajectory control environment with strict safety boundary.
    """

    def __init__(self, rocket: RocketConfig = None, mission: MissionConfig = None):
        self.rocket = rocket or RocketConfig()
        self.mission = mission or MissionConfig()
        self.stage1 = self.rocket.stages[0]
        self.prop = PropulsionModel(self.stage1.engine, count=self.stage1.engine_count)
        self.aero = AerodynamicModel(self.rocket)
        self.dt = 1.0
        self.reset()

    def reset(self, seed: int = None) -> List[float]:
        self.time = 0.0
        self.x = 0.0
        self.z = 0.0
        self.vx = 0.0
        self.vz = 0.0
        self.pitch = math.pi / 2.0  # start 90 deg vertical
        self.mass = self.stage1.dry_mass + self.stage1.propellant_mass + self.rocket.payload_mass
        self.fuel = self.stage1.propellant_mass
        self.done = False
        return self._get_obs()

    def _get_obs(self) -> List[float]:
        speed = math.sqrt(self.vx**2 + self.vz**2)
        fpa = math.atan2(self.vz, max(0.1, self.vx)) if speed > 1.0 else self.pitch
        alpha = self.pitch - fpa
        T, P, rho, a = USStandardAtmosphere.state(self.z)
        aero = self.aero.calculate_aerodynamics(speed, rho, a, alpha)
        
        return [
            self.z / 100000.0,
            self.vx / 1000.0,
            self.vz / 1000.0,
            self.mass / 100000.0,
            self.fuel / 100000.0,
            self.pitch,
            alpha,
            aero["dynamic_pressure_pa"] / 50000.0,
            aero["mach"],
            (self.mission.target_apogee_m - self.z) / 100000.0,
            (self.mission.target_velocity_ms - speed) / 1000.0
        ]

    def step(self, action: Any) -> Tuple[List[float], float, bool, Dict[str, Any]]:
        raw_throttle, raw_pitch_rate = float(action[0]), float(action[1])

        # RL Safety Boundary: Filter and clip unsafe actions
        safe_throttle = max(self.stage1.engine.min_throttle, min(self.stage1.engine.max_throttle, raw_throttle))
        if self.fuel <= 0.0:
            safe_throttle = 0.0

        max_pitch_rate = math.radians(4.0)
        safe_pitch_rate = max(-max_pitch_rate, min(max_pitch_rate, raw_pitch_rate))

        self.pitch = max(math.radians(3.0), min(math.pi / 2.0, self.pitch + safe_pitch_rate * self.dt))

        T, P, rho, a = USStandardAtmosphere.state(self.z)
        thrust_n, m_dot, _ = self.prop.calculate_thrust_and_flow(P, safe_throttle)
        speed = math.sqrt(self.vx**2 + self.vz**2)
        fpa = math.atan2(self.vz, max(0.1, self.vx)) if speed > 1.0 else self.pitch
        alpha = self.pitch - fpa

        aero = self.aero.calculate_aerodynamics(speed, rho, a, alpha)
        drag_mag = aero["drag_n"]
        g = GravityModel.local_gravity(self.z)

        fx = thrust_n * math.cos(self.pitch) - (drag_mag * (self.vx / speed) if speed > 1e-2 else 0.0)
        fz = thrust_n * math.sin(self.pitch) - (drag_mag * (self.vz / speed) if speed > 1e-2 else 0.0) - self.mass * g

        ax = fx / self.mass
        az = fz / self.mass

        self.x += self.vx * self.dt
        self.z += self.vz * self.dt
        self.vx += ax * self.dt
        self.vz += az * self.dt
        self.mass -= m_dot * self.dt
        self.fuel = max(0.0, self.fuel - m_dot * self.dt)
        self.time += self.dt

        q = aero["dynamic_pressure_pa"]
        accel_g = math.sqrt(ax**2 + az**2) / 9.80665
        
        reward = (self.vz * 0.001) + (self.vx * 0.002) - (m_dot * 0.0001)
        if q > self.mission.max_q_limit_pa:
            reward -= 5.0
        if accel_g > self.mission.max_accel_limit_g:
            reward -= 5.0

        if self.z > self.mission.target_apogee_m:
            reward += 100.0
            self.done = True
        elif self.time >= 350.0 or (self.z < 0.0 and self.time > 5.0):
            self.done = True

        info = {
            "time_s": self.time,
            "altitude_m": self.z,
            "speed_ms": speed,
            "dynamic_pressure_pa": q,
            "accel_g": accel_g,
            "fuel_kg": self.fuel
        }
        return self._get_obs(), reward, self.done, info
