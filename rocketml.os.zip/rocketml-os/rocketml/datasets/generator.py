"""
Synthetic Dataset Generator and Monte Carlo Dispersion Engine.
Produces high-volume physics ground-truth trajectories for ML training and statistical dispersion analysis.
"""

from typing import List, Dict, Any
from rocketml.core.num import np

from rocketml.core.config import RocketConfig, MissionConfig, EnvironmentConfig
from rocketml.trajectory.solver import TrajectorySolver

class TrajectoryDatasetGenerator:
    """
    Generates parameterized trajectory datasets.
    """

    def __init__(self, base_rocket: RocketConfig = None, base_mission: MissionConfig = None):
        self.base_rocket = base_rocket or RocketConfig()
        self.base_mission = base_mission or MissionConfig()

    def generate_batch(self, n_samples: int = 100, seed: int = 42) -> List[Dict[str, Any]]:
        rng = np.RandomState(seed)
        dataset: List[Dict[str, Any]] = []

        for i in range(n_samples):
            mass_mult = rng.uniform(0.92, 1.08)
            thrust_mult = rng.uniform(0.95, 1.05)
            isp_mult = rng.uniform(0.97, 1.03)
            cd_mult = rng.uniform(0.85, 1.20)
            kick_t = rng.uniform(10.0, 16.0)
            kick_angle = rng.uniform(1.8, 3.8)

            r_copy = self.base_rocket.model_copy()
            stage1 = r_copy.stages[0].model_copy()
            stage1.dry_mass *= mass_mult
            stage1.engine.thrust_vac *= thrust_mult
            stage1.engine.isp_vac *= isp_mult
            r_copy.stages = [stage1]
            r_copy.cd_transonic_peak *= cd_mult

            m_copy = self.base_mission.model_copy()
            m_copy.pitch_kick_time_s = kick_t
            m_copy.pitch_kick_angle_deg = kick_angle

            solver = TrajectorySolver(r_copy, None, m_copy, integrator_method="RK4")
            traj = solver.solve(dt=1.5, time_limit_s=250.0)
            summary = traj.summary()

            dataset.append({
                "sample_id": f"SIM-{i:05d}",
                "dry_mass_kg": stage1.dry_mass,
                "thrust_vac_n": stage1.engine.thrust_vac,
                "isp_vac_s": stage1.engine.isp_vac,
                "cd_peak": r_copy.cd_transonic_peak,
                "kick_time_s": kick_t,
                "kick_angle_deg": kick_angle,
                "max_altitude_m": summary.get("max_altitude_m", 0.0),
                "max_velocity_ms": summary.get("max_velocity_ms", 0.0),
                "max_dynamic_pressure_pa": summary.get("max_dynamic_pressure_pa", 0.0),
                "final_downrange_m": summary.get("final_downrange_m", 0.0),
                "fuel_remaining_kg": summary.get("fuel_remaining_kg", 0.0)
            })

        return dataset
