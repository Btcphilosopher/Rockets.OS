"""
ROCKETML.OS Backend JSON API Bridge.
Provides structured JSON input/output for the Aerospace Simulation & ML Workbench UI.
"""

import sys
import os
import json

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from rocketml.core.config import RocketConfig, MissionConfig, EnvironmentConfig
from rocketml.trajectory.solver import TrajectorySolver
from rocketml.guidance.constraints import ConstraintEngine
from rocketml.ml.surrogate import TrajectorySurrogateModel
from rocketml.optimisation.bayesian import AITrajectoryOptimizer
from rocketml.telemetry.sensors import TelemetrySensors
from rocketml.estimation.ekf import RocketExtendedKalmanFilter
from rocketml.datasets.generator import TrajectoryDatasetGenerator

def handle_simulate(params):
    rocket = RocketConfig()
    stage1 = rocket.stages[0]
    if "thrust_vac" in params:
        stage1.engine.thrust_vac = float(params["thrust_vac"])
    if "isp_vac" in params:
        stage1.engine.isp_vac = float(params["isp_vac"])
    if "dry_mass" in params:
        stage1.dry_mass = float(params["dry_mass"])
    if "propellant_mass" in params:
        stage1.propellant_mass = float(params["propellant_mass"])

    mission = MissionConfig()
    if "pitch_kick_time_s" in params:
        mission.pitch_kick_time_s = float(params["pitch_kick_time_s"])
    if "pitch_kick_angle_deg" in params:
        mission.pitch_kick_angle_deg = float(params["pitch_kick_angle_deg"])

    solver = TrajectorySolver(rocket, None, mission, integrator_method=params.get("integrator", "RK4"))
    dt = float(params.get("dt", 0.5))
    time_limit = float(params.get("time_limit", 250.0))
    traj = solver.solve(dt=dt, time_limit_s=time_limit)
    
    engine = ConstraintEngine(mission)
    constraints = engine.evaluate(traj)

    # Downsample points for efficient web transmission (~60-100 points)
    step_skip = max(1, len(traj.points) // 80)
    sampled_points = [traj.points[i].to_dict() for i in range(0, len(traj.points), step_skip)]
    if traj.points and sampled_points[-1]["time"] != traj.points[-1].time:
        sampled_points.append(traj.points[-1].to_dict())

    return {
        "summary": traj.summary(),
        "constraints": constraints,
        "points": sampled_points
    }

def handle_surrogate(params):
    surrogate = TrajectorySurrogateModel()
    pred = surrogate.predict_summary(params)
    return pred

def handle_optimize(params):
    rocket = RocketConfig()
    mission = MissionConfig()
    env = EnvironmentConfig()
    opt = AITrajectoryOptimizer(rocket, mission, env)
    n_iters = int(params.get("iterations", 8))
    return opt.optimize_pitch_schedule(n_iterations=n_iters)

def handle_ekf(params):
    rocket = RocketConfig()
    mission = MissionConfig()
    solver = TrajectorySolver(rocket, None, mission, integrator_method="RK4")
    traj = solver.solve(dt=0.5, time_limit_s=150.0)

    noise_std = float(params.get("alt_noise_std", 25.0))
    sensors = TelemetrySensors(alt_noise_std=noise_std)
    ekf = RocketExtendedKalmanFilter()

    results = []
    step_skip = max(1, len(traj.points) // 50)
    for i in range(0, len(traj.points), step_skip):
        pt = traj.points[i]
        frame = sensors.generate_telemetry_frame(pt.altitude, pt.speed, pt.thrust / max(1.0, pt.mass) - pt.gravity, pt.time)
        est = ekf.step(frame["measured_altitude_m"], frame["measured_accel_ms2"], dt=0.5, g=pt.gravity)
        results.append({
            "time_s": pt.time,
            "true_altitude_m": round(pt.altitude, 1),
            "measured_altitude_m": round(frame["measured_altitude_m"], 1),
            "estimated_altitude_m": round(est["estimated_altitude_m"], 1),
            "error_m": round(abs(est["estimated_altitude_m"] - pt.altitude), 2)
        })

    return {"frames": results}

def main():
    if len(sys.argv) < 2:
        print(json.dumps({"error": "Missing command argument"}))
        sys.exit(1)

    cmd = sys.argv[1]
    raw_params = sys.argv[2] if len(sys.argv) > 2 else "{}"
    try:
        params = json.loads(raw_params)
    except Exception:
        params = {}

    if cmd == "simulate":
        res = handle_simulate(params)
    elif cmd == "surrogate":
        res = handle_surrogate(params)
    elif cmd == "optimize":
        res = handle_optimize(params)
    elif cmd == "ekf":
        res = handle_ekf(params)
    else:
        res = {"error": f"Unknown command {cmd}"}

    print(json.dumps(res))

if __name__ == "__main__":
    main()
