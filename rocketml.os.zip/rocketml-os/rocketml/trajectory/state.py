"""
Trajectory State and Trajectory Point Containers.
"""

from dataclasses import dataclass
from typing import List, Dict, Any
from rocketml.core.num import np

@dataclass
class TrajectoryPoint:
    """
    Complete physical telemetry point at a given simulation epoch t.
    """
    time: float
    position_x: float
    position_y: float
    position_z: float
    velocity_x: float
    velocity_y: float
    velocity_z: float
    speed: float
    altitude: float
    vertical_velocity: float
    horizontal_velocity: float
    mass: float
    thrust: float
    drag: float
    gravity: float
    dynamic_pressure: float
    mach: float
    angle_of_attack: float
    pitch: float
    yaw: float
    roll: float
    fuel_remaining: float

    def to_dict(self) -> Dict[str, Any]:
        return {
            "time": round(self.time, 3),
            "position_x": round(self.position_x, 2),
            "position_y": round(self.position_y, 2),
            "position_z": round(self.position_z, 2),
            "velocity_x": round(self.velocity_x, 2),
            "velocity_y": round(self.velocity_y, 2),
            "velocity_z": round(self.velocity_z, 2),
            "speed": round(self.speed, 2),
            "altitude": round(self.altitude, 2),
            "vertical_velocity": round(self.vertical_velocity, 2),
            "horizontal_velocity": round(self.horizontal_velocity, 2),
            "mass": round(self.mass, 2),
            "thrust": round(self.thrust, 1),
            "drag": round(self.drag, 1),
            "gravity": round(self.gravity, 3),
            "dynamic_pressure": round(self.dynamic_pressure, 1),
            "mach": round(self.mach, 3),
            "angle_of_attack": round(self.angle_of_attack, 4),
            "pitch": round(self.pitch, 3),
            "yaw": round(self.yaw, 3),
            "roll": round(self.roll, 3),
            "fuel_remaining": round(self.fuel_remaining, 2)
        }

class Trajectory:
    """
    Container storing trajectory history efficiently as point lists.
    """
    def __init__(self, points: List[TrajectoryPoint] = None):
        self.points: List[TrajectoryPoint] = points or []

    def append(self, point: TrajectoryPoint):
        self.points.append(point)

    @property
    def times(self) -> List[float]:
        return [p.time for p in self.points]

    @property
    def altitudes(self) -> List[float]:
        return [p.altitude for p in self.points]

    @property
    def downranges(self) -> List[float]:
        return [p.position_x for p in self.points]

    @property
    def velocities(self) -> List[float]:
        return [p.speed for p in self.points]

    @property
    def dynamic_pressures(self) -> List[float]:
        return [p.dynamic_pressure for p in self.points]

    def summary(self) -> Dict[str, Any]:
        if not self.points:
            return {}
        alts = self.altitudes
        speeds = self.velocities
        qs = self.dynamic_pressures
        final = self.points[-1]
        return {
            "duration_s": final.time,
            "max_altitude_m": float(max(alts)),
            "max_velocity_ms": float(max(speeds)),
            "max_dynamic_pressure_pa": float(max(qs)),
            "final_altitude_m": final.altitude,
            "final_downrange_m": final.position_x,
            "final_velocity_ms": final.speed,
            "final_mass_kg": final.mass,
            "fuel_remaining_kg": final.fuel_remaining
        }
