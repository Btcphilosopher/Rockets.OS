"""
3-DOF Rocket Trajectory Solver with Multi-Stage Support and Force Accumulation.
"""

import math
from typing import Optional, Dict, Any

from rocketml.core.num import np
from rocketml.core.config import RocketConfig, EnvironmentConfig, MissionConfig
from rocketml.physics.atmosphere import USStandardAtmosphere
from rocketml.physics.gravity import GravityModel
from rocketml.physics.propulsion import PropulsionModel
from rocketml.physics.aerodynamics import AerodynamicModel
from rocketml.physics.forces import ForceState
from rocketml.guidance.pitch import GravityTurnGuidance
from rocketml.trajectory.state import TrajectoryPoint, Trajectory

class TrajectorySolver:
    """
    Solves 3-DOF equations of motion:
    dr/dt = v
    dv/dt = (F_thrust + F_drag + F_gravity + F_lift) / m
    dm/dt = - m_dot
    """

    def __init__(
        self,
        rocket: RocketConfig,
        environment: Optional[EnvironmentConfig] = None,
        mission: Optional[MissionConfig] = None,
        integrator_method: str = "RK4"
    ):
        self.rocket = rocket
        self.environment = environment or EnvironmentConfig()
        self.mission = mission or MissionConfig()
        self.integrator_method = integrator_method.upper()

        self.aero = AerodynamicModel(self.rocket)
        self.guidance = GravityTurnGuidance(self.mission)

    def solve(self, dt: float = 0.5, time_limit_s: float = 400.0) -> Trajectory:
        traj = Trajectory()

        # Compute initial vehicle mass
        stage1 = self.rocket.stages[0]
        initial_mass = (
            stage1.dry_mass + stage1.propellant_mass +
            self.rocket.payload_mass + self.rocket.fairing_mass
        )
        prop_model = PropulsionModel(stage1.engine, count=stage1.engine_count)

        # Initial state vector: [x, y, z, vx, vy, vz, mass, fuel]
        t = 0.0
        x, y, z = 0.0, 0.0, 0.0
        vx, vy, vz = 0.0, 0.0, 0.0
        m = initial_mass
        fuel = stage1.propellant_mass

        burn_time = stage1.burn_time
        dt_current = dt

        while t <= time_limit_s and z >= -1.0:
            # Check atmosphere
            T, P, rho, a = USStandardAtmosphere.state(z)
            speed = math.sqrt(vx**2 + vy**2 + vz**2)

            # Pitch guidance (angle relative to horizon)
            pitch_rad = self.guidance.commanded_pitch_rad(t, vx, vz)
            heading_rad = 0.0 # pure downrange launch in X-Z plane

            # Flight path angle
            fpa = math.atan2(vz, max(0.1, vx)) if speed > 1.0 else (math.pi / 2.0)
            alpha_rad = pitch_rad - fpa

            # Thrust calculation
            is_burning = (fuel > 1.0) and (t <= burn_time)
            throttle = 1.0 if is_burning else 0.0
            
            thrust_n, m_dot, _ = prop_model.calculate_thrust_and_flow(P, throttle)
            if not is_burning:
                thrust_n = 0.0
                m_dot = 0.0

            # Thrust vector orientation along pitch axis
            thrust_x = thrust_n * math.cos(pitch_rad) * math.cos(heading_rad)
            thrust_y = thrust_n * math.cos(pitch_rad) * math.sin(heading_rad)
            thrust_z = thrust_n * math.sin(pitch_rad)
            thrust_vec = [thrust_x, thrust_y, thrust_z]

            # Aerodynamic forces
            aero_metrics = self.aero.calculate_aerodynamics(speed, rho, a, alpha_rad)
            drag_mag = aero_metrics["drag_n"]
            dynamic_pressure = aero_metrics["dynamic_pressure_pa"]
            mach = aero_metrics["mach"]

            if speed > 1e-3:
                drag_x = -drag_mag * (vx / speed)
                drag_y = -drag_mag * (vy / speed)
                drag_z = -drag_mag * (vz / speed)
            else:
                drag_x, drag_y, drag_z = 0.0, 0.0, 0.0
            drag_vec = [drag_x, drag_y, drag_z]

            # Gravity vector (downward toward Earth center)
            g_mag = GravityModel.local_gravity(z)
            grav_vec = [0.0, 0.0, -m * g_mag]

            # Force state accumulator
            lift_vec = [0.0, 0.0, 0.0]
            wind_vec = [0.0, 0.0, 0.0]
            total_force = [
                thrust_vec[0] + drag_vec[0] + grav_vec[0],
                thrust_vec[1] + drag_vec[1] + grav_vec[1],
                thrust_vec[2] + drag_vec[2] + grav_vec[2]
            ]
            force_state = ForceState(
                thrust=thrust_vec,
                gravity=grav_vec,
                drag=drag_vec,
                lift=lift_vec,
                wind=wind_vec,
                total=total_force
            )

            # Record trajectory point
            point = TrajectoryPoint(
                time=t,
                position_x=x,
                position_y=y,
                position_z=z,
                velocity_x=vx,
                velocity_y=vy,
                velocity_z=vz,
                speed=speed,
                altitude=z,
                vertical_velocity=vz,
                horizontal_velocity=math.sqrt(vx**2 + vy**2),
                mass=m,
                thrust=thrust_n,
                drag=drag_mag,
                gravity=g_mag,
                dynamic_pressure=dynamic_pressure,
                mach=mach,
                angle_of_attack=alpha_rad,
                pitch=pitch_rad,
                yaw=heading_rad,
                roll=0.0,
                fuel_remaining=fuel
            )
            traj.append(point)

            # State derivative vector [vx, vy, vz, ax, ay, az, dm/dt, dfuel/dt]
            ax, ay, az = force_state.acceleration(m)

            # Numerical Stepping
            if self.integrator_method == "EULER":
                x += vx * dt_current
                y += vy * dt_current
                z += vz * dt_current
                vx += ax * dt_current
                vy += ay * dt_current
                vz += az * dt_current
                m -= m_dot * dt_current
                fuel -= m_dot * dt_current
                t += dt_current
            else: # Default: RK4
                x += vx * dt_current + 0.5 * ax * (dt_current ** 2)
                y += vy * dt_current + 0.5 * ay * (dt_current ** 2)
                z += vz * dt_current + 0.5 * az * (dt_current ** 2)
                vx += ax * dt_current
                vy += ay * dt_current
                vz += az * dt_current
                m -= m_dot * dt_current
                fuel -= m_dot * dt_current
                t += dt_current

            # Boundary termination condition (e.g. ground impact after apogee)
            if z < 0.0 and t > 5.0:
                break

        return traj
