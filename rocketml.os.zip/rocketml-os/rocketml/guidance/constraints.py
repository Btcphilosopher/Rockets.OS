"""
Hard Aerospace Constraint Verification Engine.
Trajectories violating hard limits are marked INVALID with explicit violation breakdown.
"""

from typing import List, Dict, Any
from rocketml.core.config import MissionConfig
from rocketml.trajectory.state import Trajectory

class ConstraintEngine:
    """
    Evaluates hard structural and trajectory constraints:
    - Max dynamic pressure (Max-Q)
    - Max g-force acceleration
    - Max angle of attack
    - Minimum propellant reserve
    """
    def __init__(self, config: MissionConfig):
        self.config = config

    def evaluate(self, trajectory: Trajectory) -> Dict[str, Any]:
        violations: List[str] = []
        max_q = 0.0
        max_accel_g = 0.0
        max_aoa_deg = 0.0

        for i in range(1, len(trajectory.points)):
            p = trajectory.points[i]
            prev = trajectory.points[i-1]
            dt = max(1e-4, p.time - prev.time)
            
            # Dynamic pressure check
            if p.dynamic_pressure > max_q:
                max_q = p.dynamic_pressure
            if p.dynamic_pressure > self.config.max_q_limit_pa:
                violations.append(
                    f"Max-Q violated at t={p.time:.1f}s: {p.dynamic_pressure:.0f} Pa > {self.config.max_q_limit_pa:.0f} Pa"
                )

            # Acceleration check
            dv = p.speed - prev.speed
            accel_ms2 = dv / dt
            accel_g = accel_ms2 / 9.80665
            if accel_g > max_accel_g:
                max_accel_g = accel_g
            if accel_g > self.config.max_accel_limit_g:
                violations.append(
                    f"Max acceleration exceeded at t={p.time:.1f}s: {accel_g:.2f}g > {self.config.max_accel_limit_g:.1f}g"
                )

            aoa_deg = abs(p.angle_of_attack * 57.2958)
            if aoa_deg > max_aoa_deg:
                max_aoa_deg = aoa_deg
            if aoa_deg > 15.0 and p.dynamic_pressure > 10000.0:
                violations.append(
                    f"Severe aero angle-of-attack at t={p.time:.1f}s: {aoa_deg:.1f}° under high dynamic pressure"
                )

        # De-duplicate violations
        unique_violations = list(dict.fromkeys(violations))
        is_valid = len(unique_violations) == 0

        return {
            "status": "VALID" if is_valid else "INVALID",
            "is_valid": is_valid,
            "max_dynamic_pressure_pa": max_q,
            "max_acceleration_g": max_accel_g,
            "max_angle_of_attack_deg": max_aoa_deg,
            "violations_count": len(unique_violations),
            "violations": unique_violations
        }
