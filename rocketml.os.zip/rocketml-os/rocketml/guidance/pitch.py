"""
Pitch Program and Gravity Turn Guidance.
"""

import math
from rocketml.core.config import MissionConfig

class GravityTurnGuidance:
    """
    Computes commanded pitch angle theta(t) during vertical climb and gravity turn:
    Phase 1: Vertical ascent until t_kick
    Phase 2: Pitch-over kick initiation
    Phase 3: Natural gravity turn pitch curve asymptotic to orbital injection angle
    """
    def __init__(self, config: MissionConfig):
        self.config = config

    def commanded_pitch_rad(self, time_s: float, velocity_x: float, velocity_z: float) -> float:
        """
        Pitch measured from horizontal (0 rad = horizontal downrange, pi/2 rad = 90 deg vertical).
        """
        if time_s < self.config.pitch_kick_time_s:
            # Strictly vertical ascent
            return math.pi / 2.0

        # After pitch-over, guidance follows velocity flight path angle or commanded program
        speed_horiz = max(0.1, velocity_x)
        speed_vert = max(0.0, velocity_z)
        
        # Flight path angle gamma = atan2(Vz, Vx)
        gamma = math.atan2(speed_vert, speed_horiz)

        # Smooth pitch schedule
        t_rel = time_s - self.config.pitch_kick_time_s
        burn_decay = math.exp(-t_rel / 75.0)
        
        # Desired pitch is blended between flight path angle and target orbital angle
        commanded = gamma * 0.7 + (math.pi / 2.0) * burn_decay * 0.3
        
        # Clamp to minimum safe pitch angle (e.g. 5 degrees above horizontal during powered ascent)
        return max(math.radians(5.0), min(math.pi / 2.0, commanded))
