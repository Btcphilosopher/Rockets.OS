"""
Telemetry Sensor Simulation with Synthetic Noise, Bias, Drift, and Dropouts.
"""

from typing import Dict, Any, List
from rocketml.core.num import np

class TelemetrySensors:
    """
    Simulates real avionics telemetry stream from true physical states:
    - IMU Accelerometer: a_meas = a_true + bias + noise
    - Barometric / Radar Altimeter: alt_meas = alt_true + alt_noise
    - GPS Position & Velocity
    """

    def __init__(self, accel_noise_std: float = 0.45, alt_noise_std: float = 25.0, seed: int = 42):
        self.accel_noise_std = accel_noise_std
        self.alt_noise_std = alt_noise_std
        self.accel_bias = 0.12 # constant sensor bias [m/s^2]
        self.rng = np.RandomState(seed)

    def generate_telemetry_frame(self, true_alt: float, true_speed: float, true_accel: float, time_s: float) -> Dict[str, float]:
        noise_a = float(self.rng.normal(0, self.accel_noise_std))
        noise_alt = float(self.rng.normal(0, self.alt_noise_std))
        
        drift = 0.0005 * time_s

        measured_accel = true_accel + self.accel_bias + drift + noise_a
        measured_alt = max(0.0, true_alt + noise_alt)
        measured_speed = max(0.0, true_speed + float(self.rng.normal(0, 1.2)))

        return {
            "time_s": time_s,
            "measured_altitude_m": measured_alt,
            "measured_speed_ms": measured_speed,
            "measured_accel_ms2": measured_accel,
            "true_altitude_m": true_alt,
            "true_speed_ms": true_speed,
            "true_accel_ms2": true_accel
        }
