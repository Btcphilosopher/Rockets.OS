"""
ROCKETML.OS Command Line Interface
Executes physics simulation, dataset generation, ML training, surrogate prediction, and optimization.
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))
import argparse
import json
from rocketml.core.config import RocketConfig, MissionConfig, EnvironmentConfig
from rocketml.trajectory.solver import TrajectorySolver
from rocketml.guidance.constraints import ConstraintEngine
from rocketml.ml.surrogate import TrajectorySurrogateModel
from rocketml.optimisation.bayesian import AITrajectoryOptimizer
from rocketml.datasets.generator import TrajectoryDatasetGenerator

def run_simulate(args):
    print("[ROCKETML.OS] Running Physics Ground-Truth Simulation...")
    rocket = RocketConfig()
    mission = MissionConfig()
    solver = TrajectorySolver(rocket, None, mission, integrator_method=args.integrator)
    traj = solver.solve(dt=args.dt, time_limit_s=args.time_limit)
    summary = traj.summary()
    
    engine = ConstraintEngine(mission)
    constraints = engine.evaluate(traj)

    print("\n--- SIMULATION SUMMARY ---")
    print(f"Total Flight Duration   : {summary.get('duration_s', 0):.1f} s")
    print(f"Peak Apogee Altitude    : {summary.get('max_altitude_m', 0)/1000.0:.2f} km")
    print(f"Max Velocity (Speed)    : {summary.get('max_velocity_ms', 0):.1f} m/s (Mach ~{summary.get('max_velocity_ms',0)/300.0:.2f})")
    print(f"Max Dynamic Pressure (Q): {summary.get('max_dynamic_pressure_pa', 0)/1000.0:.2f} kPa")
    print(f"Constraint Status       : {constraints['status']}")
    if constraints['violations']:
        print(f"Violations ({len(constraints['violations'])} total):")
        for v in constraints['violations'][:5]:
            print(f"  - {v}")
        if len(constraints['violations']) > 5:
            print(f"  ... and {len(constraints['violations']) - 5} more.")

def run_predict(args):
    print("[ROCKETML.OS] Evaluating ML Neural Surrogate Predictor...")
    surrogate = TrajectorySurrogateModel()
    res = surrogate.predict_summary({
        "pitch_kick_time_s": 12.0,
        "pitch_kick_angle_deg": 2.5
    })
    print("\n--- SURROGATE PREDICTION ---")
    print(f"Predicted Apogee Altitude: {res['predicted_max_altitude_m']/1000.0:.2f} km (±{res['uncertainty']['altitude_std_m']/1000.0:.2f} km)")
    print(f"Predicted Max Velocity   : {res['predicted_max_velocity_ms']:.1f} m/s")
    print(f"Predicted Max-Q          : {res['predicted_max_dynamic_pressure_pa']/1000.0:.2f} kPa")
    print(f"Inference Latency        : {res['inference_time_ms']} ms")
    print(f"Physics Residual Loss    : {res['physics_loss_residual']}")

def run_optimise(args):
    print("[ROCKETML.OS] Running AI Trajectory Optimization Loop...")
    rocket = RocketConfig()
    mission = MissionConfig()
    env = EnvironmentConfig()
    optimizer = AITrajectoryOptimizer(rocket, mission, env)
    result = optimizer.optimize_pitch_schedule(n_iterations=10)
    print("\n--- OPTIMIZATION RESULT ---")
    print(f"Best Candidate Parameters: {result['optimal_parameters']}")
    print(f"Evaluated Iterations     : {result['total_evaluations']}")

def run_dataset(args):
    print(f"[ROCKETML.OS] Generating {args.count} Synthetic Ground-Truth Trajectories...")
    gen = TrajectoryDatasetGenerator()
    dataset = gen.generate_batch(n_samples=args.count)
    print(f"Generated {len(dataset)} trajectories successfully.")

def main():
    parser = argparse.ArgumentParser(prog="rocketml", description="ROCKETML.OS: AI Rocket Trajectory Engine")
    subparsers = parser.add_subparsers(dest="command", help="Sub-commands")

    # simulate
    p_sim = subparsers.add_parser("simulate", help="Run 3-DOF physics simulation")
    p_sim.add_argument("--integrator", default="RK4", choices=["EULER", "RK4", "RK45"])
    p_sim.add_argument("--dt", type=float, default=0.5)
    p_sim.add_argument("--time-limit", type=float, default=300.0)

    # predict
    p_pred = subparsers.add_parser("predict", help="Fast ML surrogate trajectory prediction")

    # optimise
    p_opt = subparsers.add_parser("optimise", help="Trajectory optimization loop")

    # dataset
    p_data = subparsers.add_parser("dataset", help="Generate synthetic trajectory dataset")
    p_data.add_argument("--count", type=int, default=50)

    args = parser.parse_args()
    if args.command == "simulate":
        run_simulate(args)
    elif args.command == "predict":
        run_predict(args)
    elif args.command == "optimise":
        run_optimise(args)
    elif args.command == "dataset":
        run_dataset(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
