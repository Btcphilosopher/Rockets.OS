"""
Extended Kalman Filter (EKF) for Rocket State Estimation from Noisy Telemetry.
Tracks state vector x = [altitude, velocity, bias] with continuous-discrete updates.
"""

from typing import Dict, Any, List
from rocketml.core.num import np

class RocketExtendedKalmanFilter:
    """
    1D Vertical Ascent EKF:
    State: x = [h (altitude), v (velocity), b (accel bias)]^T
    """

    def __init__(self, init_alt: float = 0.0, init_vel: float = 0.0):
        # State vector: [alt, vel, bias]
        self.x = [init_alt, init_vel, 0.0]
        self.p_alt = 100.0
        self.p_vel = 10.0
        self.p_bias = 0.1
        self.q_alt = 0.1
        self.q_vel = 0.8
        self.r_meas = 625.0 # (25m std dev)^2

    def step(self, measured_alt: float, measured_accel: float, dt: float, g: float = 9.81) -> Dict[str, float]:
        """
        EKF Predict-Update cycle for one timestep dt.
        """
        # 1. Prediction
        h, v, b = self.x
        effective_accel = measured_accel - b - g
        
        h_pred = h + v * dt + 0.5 * effective_accel * (dt ** 2)
        v_pred = v + effective_accel * dt
        b_pred = b

        p_alt_pred = self.p_alt + 2.0 * dt * self.p_vel + self.q_alt * dt
        p_vel_pred = self.p_vel + self.q_vel * dt

        # 2. Measurement Update with altimeter
        residual = measured_alt - h_pred
        s_cov = p_alt_pred + self.r_meas
        k_alt = p_alt_pred / s_cov
        k_vel = (self.p_vel * dt) / s_cov

        self.x[0] = h_pred + k_alt * residual
        self.x[1] = v_pred + k_vel * residual
        self.x[2] = b_pred

        self.p_alt = (1.0 - k_alt) * p_alt_pred
        self.p_vel = p_vel_pred

        return {
            "estimated_altitude_m": float(self.x[0]),
            "estimated_velocity_ms": float(self.x[1]),
            "estimated_accel_bias": float(self.x[2]),
            "innovation_residual": float(residual),
            "altitude_variance": float(self.p_alt)
        }
