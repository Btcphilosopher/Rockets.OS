"""
Aerodynamics Subsystem: Transonic Drag Coefficient Cd(M), Dynamic Pressure, and Aerodynamic Forces.
"""

import math
from rocketml.core.results import EngineeringResult
from rocketml.core.config import RocketConfig

class AerodynamicModel:
    """
    Computes Mach number, dynamic pressure q = 0.5 * rho * V^2,
    Mach-dependent drag coefficient Cd(Mach), and drag force D = q * Cd * S.
    """
    def __init__(self, config: RocketConfig):
        self.config = config

    def drag_coefficient(self, mach: float, alpha_rad: float = 0.0) -> float:
        """
        Calculates total drag coefficient including wave drag rise and induced drag from angle of attack.
        """
        cd_0 = self.config.cd_subsonic
        peak = self.config.cd_transonic_peak
        super_cd = self.config.cd_supersonic

        if mach < 0.8:
            cd_base = cd_0
        elif mach <= 1.05:
            # Transonic drag rise steep slope
            frac = (mach - 0.8) / 0.25
            cd_base = cd_0 + (peak - cd_0) * math.sin(frac * math.pi / 2.0)
        elif mach <= 1.8:
            # Transonic post-shock decay
            frac = (mach - 1.05) / 0.75
            cd_base = peak - (peak - super_cd) * (1.0 - math.exp(-2.5 * frac))
        else:
            # Supersonic asymptotic tail
            cd_base = super_cd / math.sqrt(max(1.0, mach**2 - 1.0)) * 1.414

        # Induced drag increment due to angle-of-attack: Cd = Cd0 + k * alpha^2
        cd_induced = 1.8 * (alpha_rad ** 2)
        return float(cd_base + cd_induced)

    def calculate_aerodynamics(self, velocity_ms: float, density_kg_m3: float, speed_of_sound_ms: float, alpha_rad: float = 0.0):
        speed = max(0.0, velocity_ms)
        mach = speed / max(1e-3, speed_of_sound_ms)
        dynamic_pressure_pa = 0.5 * density_kg_m3 * (speed ** 2)
        cd = self.drag_coefficient(mach, alpha_rad)
        drag_force_n = dynamic_pressure_pa * cd * self.config.reference_area
        
        # Lift / normal force proxy: L = q * Cl_alpha * alpha * S
        cl_alpha = 2.0 * math.pi  # Slender body potential lift slope approximation
        lift_force_n = dynamic_pressure_pa * cl_alpha * alpha_rad * self.config.reference_area
        
        return {
            "mach": mach,
            "dynamic_pressure_pa": dynamic_pressure_pa,
            "cd": cd,
            "drag_n": drag_force_n,
            "lift_n": lift_force_n
        }

    def dynamic_pressure_result(self, velocity_ms: float, density_kg_m3: float) -> EngineeringResult:
        q = 0.5 * density_kg_m3 * (velocity_ms ** 2)
        return EngineeringResult(
            value=q,
            unit="Pa",
            equation="q = 0.5 * rho * V^2",
            inputs={"velocity_ms": velocity_ms, "density_kg_m3": density_kg_m3},
            assumptions="Incompressible formulation for local dynamic pressure stagnation condition",
            validity_range="rho >= 0, V >= 0",
            uncertainty=0.02 * q
        )
