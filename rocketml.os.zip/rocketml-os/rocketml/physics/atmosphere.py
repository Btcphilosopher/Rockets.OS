"""
US Standard Atmosphere 1976 Model
Calculates temperature T(h), pressure P(h), density rho(h), and speed of sound a(h).
"""

import math
from typing import Tuple
from rocketml.core.units import (
    SEA_LEVEL_PRESSURE, SEA_LEVEL_TEMPERATURE, SEA_LEVEL_DENSITY,
    GAS_CONSTANT_AIR, GAMMA_AIR, STANDARD_GRAVITY, EARTH_RADIUS
)
from rocketml.core.results import EngineeringResult

class USStandardAtmosphere:
    """
    Standard barometric lapse-rate model for altitudes 0 to 86,000 meters.
    """

    # Atmospheric layers: (base_geopotential_m, base_temperature_K, lapse_rate_K_per_m)
    LAYERS = [
        (0.0, 288.15, -0.0065),      # Troposphere
        (11000.0, 216.65, 0.0),       # Tropopause
        (20000.0, 216.65, 0.0010),    # Stratosphere 1
        (32000.0, 228.65, 0.0028),    # Stratosphere 2
        (47000.0, 270.65, 0.0),       # Stratopause
        (51000.0, 270.65, -0.0028),   # Mesosphere 1
        (71000.0, 214.65, -0.0020),   # Mesosphere 2
        (84852.0, 186.87, 0.0)        # Mesopause
    ]

    @classmethod
    def geometric_to_geopotential(cls, h_geom: float) -> float:
        """Converts geometric altitude to geopotential altitude using Earth radius."""
        return (EARTH_RADIUS * max(0.0, h_geom)) / (EARTH_RADIUS + max(0.0, h_geom))

    @classmethod
    def state(cls, altitude_m: float) -> Tuple[float, float, float, float]:
        """
        Returns (temperature_K, pressure_Pa, density_kg_m3, speed_of_sound_ms).
        """
        h_geom = max(0.0, altitude_m)
        if h_geom > 120000.0:
            # Beyond thermosphere / exosphere boundary for aerodynamic purposes
            T = 186.87
            P = 1e-6
            rho = 1e-9
            a = math.sqrt(GAMMA_AIR * GAS_CONSTANT_AIR * T)
            return T, P, rho, a

        h = cls.geometric_to_geopotential(h_geom)
        
        # Determine active layer
        P_base = SEA_LEVEL_PRESSURE
        T_base = SEA_LEVEL_TEMPERATURE
        h_base = 0.0
        L = -0.0065
        
        for i in range(len(cls.LAYERS)):
            layer_h, layer_T, layer_L = cls.LAYERS[i]
            if h >= layer_h:
                h_base = layer_h
                T_base = layer_T
                L = layer_L
            else:
                break

        dh = h - h_base
        if abs(L) < 1e-12:
            # Isothermal layer
            T = T_base
            P = P_base * math.exp(-STANDARD_GRAVITY * dh / (GAS_CONSTANT_AIR * T))
        else:
            # Linear temperature gradient layer
            T = T_base + L * dh
            # Clamp T to prevent numerical instability
            T = max(150.0, T)
            exponent = -STANDARD_GRAVITY / (L * GAS_CONSTANT_AIR)
            P = P_base * math.pow(T / T_base, exponent)

        rho = P / (GAS_CONSTANT_AIR * T)
        speed_of_sound = math.sqrt(GAMMA_AIR * GAS_CONSTANT_AIR * T)
        return T, P, rho, speed_of_sound

    @classmethod
    def density_result(cls, altitude_m: float) -> EngineeringResult:
        T, P, rho, a = cls.state(altitude_m)
        return EngineeringResult(
            value=rho,
            unit="kg/m^3",
            equation="rho = P / (R_spec * T)",
            inputs={"altitude_m": altitude_m, "temperature_K": T, "pressure_Pa": P},
            assumptions="US Standard Atmosphere 1976 ideal gas hydrostatic equilibrium",
            validity_range="0 <= h <= 120000 m",
            uncertainty=0.03 * rho
        )
