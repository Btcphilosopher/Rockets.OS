"""
Rocket Propulsion and Thrust Model
Calculates thrust, Isp, and mass flow rate as a function of ambient atmospheric pressure and throttle.
"""

from rocketml.core.units import STANDARD_GRAVITY
from rocketml.core.results import EngineeringResult
from rocketml.core.config import EngineConfig

class PropulsionModel:
    """
    Computes effective thrust varying with altitude back-pressure:
    F(P_amb) = F_vac - A_e * P_amb
    and mass flow rate m_dot = F_vac / (Isp_vac * g0) * throttle
    """
    def __init__(self, config: EngineConfig, count: int = 1):
        self.config = config
        self.count = count

    def calculate_thrust_and_flow(self, ambient_pressure_pa: float, throttle: float) -> tuple[float, float, float]:
        """
        Returns (thrust_N, mass_flow_kg_s, effective_isp_s).
        """
        # Clamp throttle within allowed operational boundaries
        eff_throttle = max(self.config.min_throttle, min(self.config.max_throttle, throttle))
        
        # Single engine nominal mass flow at 100% throttle
        m_dot_100 = self.config.thrust_vac / (self.config.isp_vac * STANDARD_GRAVITY)
        m_dot = m_dot_100 * eff_throttle * self.count
        
        # Pressure back-thrust loss on nozzle exit area
        # F = m_dot * v_e + (P_e - P_a) * A_e
        # In engineering formulation: F(h) = F_vac - A_e * P_a
        thrust_loss_per_engine = self.config.exit_area * ambient_pressure_pa
        single_thrust = max(0.0, self.config.thrust_vac - thrust_loss_per_engine) * eff_throttle
        total_thrust = single_thrust * self.count
        
        eff_isp = total_thrust / (m_dot * STANDARD_GRAVITY) if m_dot > 1e-6 else self.config.isp_vac
        return total_thrust, m_dot, eff_isp

    def thrust_result(self, ambient_pressure_pa: float, throttle: float) -> EngineeringResult:
        thrust, m_dot, isp = self.calculate_thrust_and_flow(ambient_pressure_pa, throttle)
        return EngineeringResult(
            value=thrust,
            unit="N",
            equation="F = (F_vac - A_e * P_amb) * throttle * engine_count",
            inputs={"P_amb_pa": ambient_pressure_pa, "throttle": throttle, "count": self.count},
            assumptions="Ideal 1D isentropic nozzle expansion with atmospheric back-pressure",
            validity_range="0 <= throttle <= 1.0",
            uncertainty=0.015 * thrust
        )
