"""
Numerical Integration Subsystem: Euler, RK4, and Adaptive RK45 (Dormand-Prince).
"""

from typing import Callable, Tuple
import numpy as np

class Integrators:
    """
    Collection of explicit ODE stepping algorithms for rocket trajectory integration:
    dy/dt = f(t, y)
    """

    @staticmethod
    def euler_step(f: Callable[[float, np.ndarray], np.ndarray], t: float, y: np.ndarray, dt: float) -> np.ndarray:
        """1st-Order Explicit Euler step."""
        return y + dt * f(t, y)

    @staticmethod
    def rk4_step(f: Callable[[float, np.ndarray], np.ndarray], t: float, y: np.ndarray, dt: float) -> np.ndarray:
        """Classical 4th-Order Runge-Kutta step."""
        k1 = f(t, y)
        k2 = f(t + 0.5 * dt, y + 0.5 * dt * k1)
        k3 = f(t + 0.5 * dt, y + 0.5 * dt * k2)
        k4 = f(t + dt, y + dt * k3)
        return y + (dt / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)

    @staticmethod
    def rk45_step(
        f: Callable[[float, np.ndarray], np.ndarray],
        t: float,
        y: np.ndarray,
        dt: float,
        rtol: float = 1e-6,
        atol: float = 1e-8
    ) -> Tuple[np.ndarray, float, float]:
        """
        Dormand-Prince (RK45) adaptive step with embedded local truncation error estimate.
        Returns: (y_next, dt_next, error_ratio)
        """
        c2, a21 = 1/5, 1/5
        c3, a31, a32 = 3/10, 3/40, 9/40
        c4, a41, a42, a43 = 4/5, 44/45, -56/15, 32/9
        c5, a51, a52, a53, a54 = 8/9, 19372/6561, -25360/2187, 64448/6561, -212/729
        c6, a61, a62, a63, a64, a65 = 1.0, 9017/3168, -355/33, 46732/5247, 49/176, -5103/18656
        c7, a71, a72, a73, a74, a75, a76 = 1.0, 35/384, 0.0, 500/1113, 125/192, -2187/6784, 11/84

        # 5th-order weights
        b1, b3, b4, b5, b6 = 35/384, 500/1113, 125/192, -2187/6784, 11/84
        # 4th-order weights
        b1_hat, b3_hat, b4_hat, b5_hat, b6_hat, b7_hat = (
            5179/57600, 7571/16695, 393/640, -92097/339200, 187/2100, 1/40
        )

        k1 = f(t, y)
        k2 = f(t + c2 * dt, y + dt * (a21 * k1))
        k3 = f(t + c3 * dt, y + dt * (a31 * k1 + a32 * k2))
        k4 = f(t + c4 * dt, y + dt * (a41 * k1 + a42 * k2 + a43 * k3))
        k5 = f(t + c5 * dt, y + dt * (a51 * k1 + a52 * k2 + a53 * k3 + a54 * k4))
        k6 = f(t + c6 * dt, y + dt * (a61 * k1 + a62 * k2 + a63 * k3 + a64 * k4 + a65 * k5))

        y5 = y + dt * (b1 * k1 + b3 * k3 + b4 * k4 + b5 * k5 + b6 * k6)
        
        k7 = f(t + dt, y5)
        y4 = y + dt * (b1_hat * k1 + b3_hat * k3 + b4_hat * k4 + b5_hat * k5 + b6_hat * k6 + b7_hat * k7)

        # Truncation error vector
        err = np.abs(y5 - y4)
        tol = atol + rtol * np.maximum(np.abs(y), np.abs(y5))
        ratio = np.max(err / tol)

        # Propose next timestep
        if ratio > 0:
            scale = 0.9 * (1.0 / ratio)**0.2
            dt_next = max(0.1 * dt, min(5.0 * dt, dt * scale))
        else:
            dt_next = dt * 2.0

        return y5, dt_next, float(ratio)
