"""
Force Accumulator and Explanatory Force State.
"""

from dataclasses import dataclass
from typing import Any
from rocketml.core.num import np

@dataclass
class ForceState:
    """
    Detailed physical force breakdown acting on the rocket center of mass in 3D inertial frame.
    All vectors in Newtons [N].
    """
    thrust: Any    # [Fx, Fy, Fz]
    gravity: Any   # [Fx, Fy, Fz]
    drag: Any      # [Fx, Fy, Fz]
    lift: Any      # [Fx, Fy, Fz]
    wind: Any      # [Fx, Fy, Fz]
    total: Any     # [Fx, Fy, Fz]

    def acceleration(self, mass_kg: float) -> list:
        """Returns acceleration vector a = F_total / m [m/s^2]."""
        m = max(1.0, mass_kg)
        return [self.total[0] / m, self.total[1] / m, self.total[2] / m]

    def to_dict(self) -> dict:
        return {
            "thrust": list(self.thrust),
            "gravity": list(self.gravity),
            "drag": list(self.drag),
            "lift": list(self.lift),
            "wind": list(self.wind),
            "total": list(self.total)
        }
