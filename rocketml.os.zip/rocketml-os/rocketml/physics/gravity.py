"""
Gravity Models: Altitude-Dependent Spherical Harmonic and Newton Gravity.
"""

from rocketml.core.units import EARTH_MU, EARTH_RADIUS
from rocketml.core.results import EngineeringResult

class GravityModel:
    """
    Inverse-square Newtonian gravity field with altitude variation:
    g(h) = GM / (R_E + h)^2
    """
    @staticmethod
    def local_gravity(altitude_m: float) -> float:
        r = EARTH_RADIUS + max(0.0, altitude_m)
        return EARTH_MU / (r * r)

    @staticmethod
    def gravity_result(altitude_m: float) -> EngineeringResult:
        g = GravityModel.local_gravity(altitude_m)
        return EngineeringResult(
            value=g,
            unit="m/s^2",
            equation="g(h) = GM / (R_Earth + h)^2",
            inputs={"altitude_m": altitude_m, "GM": EARTH_MU, "R_Earth": EARTH_RADIUS},
            assumptions="Spherically symmetric central body; Newtonian inverse-square",
            validity_range="h >= 0 m",
            uncertainty=1e-4 * g
        )
