import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json());

import { execFile } from 'node:child_process';
import { resolve } from 'node:path';

function runPythonBridge(cmd: string, params: Record<string, unknown>): Promise<unknown> {
  return new Promise((res, rej) => {
    const bridgeScript = resolve(process.cwd(), 'rocketml-os/rocketml/api_bridge.py');
    const paramStr = JSON.stringify(params || {});
    execFile('python3', [bridgeScript, cmd, paramStr], { maxBuffer: 10 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) {
        console.error(`Python error for ${cmd}:`, stderr);
        return rej(new Error(stderr || err.message));
      }
      try {
        const data = JSON.parse(stdout);
        res(data);
      } catch {
        rej(new Error(`Failed to parse bridge JSON: ${stdout.slice(0, 200)}`));
      }
    });
  });
}

app.post('/api/simulate', async (req, res) => {
  try {
    const data = await runPythonBridge('simulate', req.body);
    res.json(data);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

app.post('/api/surrogate', async (req, res) => {
  try {
    const data = await runPythonBridge('surrogate', req.body);
    res.json(data);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

app.post('/api/optimize', async (req, res) => {
  try {
    const data = await runPythonBridge('optimize', req.body);
    res.json(data);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

app.post('/api/ekf', async (req, res) => {
  try {
    const data = await runPythonBridge('ekf', req.body);
    res.json(data);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
