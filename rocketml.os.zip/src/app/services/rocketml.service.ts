import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, of } from 'rxjs';
import {
  SimulationParams,
  SimulationResponse,
  SurrogatePredictionDto,
  OptimizationResponse,
  OptimizationIterationDto,
  EKFResponse
} from '../models/rocketml.types';

@Injectable({
  providedIn: 'root'
})
export class RocketMLService {
  private http = inject(HttpClient);

  simulate(params: Partial<SimulationParams>): Observable<SimulationResponse> {
    return this.http.post<SimulationResponse>('/api/simulate', params).pipe(
      catchError((err) => {
        console.warn('API /api/simulate fallback invoked:', err);
        return of(this.getMockSimulation(params));
      })
    );
  }

  predictSurrogate(params: Record<string, unknown>): Observable<SurrogatePredictionDto> {
    return this.http.post<SurrogatePredictionDto>('/api/surrogate', params).pipe(
      catchError((err) => {
        console.warn('API /api/surrogate fallback invoked:', err);
        return of(this.getMockSurrogate(params));
      })
    );
  }

  optimize(params: { iterations: number }): Observable<OptimizationResponse> {
    return this.http.post<OptimizationResponse>('/api/optimize', params).pipe(
      catchError((err) => {
        console.warn('API /api/optimize fallback invoked:', err);
        return of(this.getMockOptimization());
      })
    );
  }

  streamEKF(params: { alt_noise_std: number }): Observable<EKFResponse> {
    return this.http.post<EKFResponse>('/api/ekf', params).pipe(
      catchError((err) => {
        console.warn('API /api/ekf fallback invoked:', err);
        return of(this.getMockEKF(params.alt_noise_std));
      })
    );
  }

  private getMockSimulation(params: Partial<SimulationParams>): SimulationResponse {
    const points = [];
    const tMax = 250;
    const dt = 3;
    const thrust = params.thrust_vac || 845000;
    const isp = params.isp_vac || 311;
    const m0 = (params.dry_mass || 25000) + (params.propellant_mass || 395000) + 6750;

    let x = 0;
    let z = 0;
    let vx = 0;
    let vz = 0;
    let m = m0;
    let fuel = params.propellant_mass || 395000;
    const mDot = (thrust * 9) / (isp * 9.80665);

    let maxQ = 0;
    for (let t = 0; t <= tMax; t += dt) {
      const isBurning = t < 162 && fuel > 0;
      const pitch = t < 12 ? Math.PI / 2 : Math.max(0.2, (Math.PI / 2) * Math.exp(-(t - 12) / 80));
      const fThrust = isBurning ? thrust * 9 : 0;
      const speed = Math.hypot(vx, vz);
      
      const rho = 1.225 * Math.exp(-z / 8500);
      const q = 0.5 * rho * (speed ** 2);
      if (q > maxQ) maxQ = q;

      const fDrag = 0.5 * rho * (speed ** 2) * 0.3 * 10.5;
      const ax = (fThrust * Math.cos(pitch) - (speed > 1 ? fDrag * (vx / speed) : 0)) / m;
      const az = (fThrust * Math.sin(pitch) - (speed > 1 ? fDrag * (vz / speed) : 0) - m * 9.81) / m;

      vx += ax * dt;
      vz += az * dt;
      x += vx * dt;
      z = Math.max(0, z + vz * dt);

      if (isBurning) {
        m -= mDot * dt;
        fuel = Math.max(0, fuel - mDot * dt);
      }

      points.push({
        time: t,
        position_x: x,
        position_y: 0,
        position_z: z,
        velocity_x: vx,
        velocity_y: 0,
        velocity_z: vz,
        speed: speed,
        altitude: z,
        vertical_velocity: vz,
        horizontal_velocity: vx,
        mass: m,
        thrust: fThrust,
        drag: fDrag,
        gravity: 9.81,
        dynamic_pressure: q,
        mach: speed / 320,
        angle_of_attack: 0.02,
        pitch: pitch,
        yaw: 0,
        roll: 0,
        fuel_remaining: fuel
      });
    }

    const maxAlt = Math.max(...points.map(p => p.altitude));
    const maxVel = Math.max(...points.map(p => p.speed));

    return {
      summary: {
        duration_s: tMax,
        max_altitude_m: maxAlt,
        max_velocity_ms: maxVel,
        max_dynamic_pressure_pa: maxQ,
        final_altitude_m: points[points.length - 1].altitude,
        final_downrange_m: points[points.length - 1].position_x,
        final_velocity_ms: points[points.length - 1].speed,
        final_mass_kg: points[points.length - 1].mass,
        fuel_remaining_kg: points[points.length - 1].fuel_remaining
      },
      constraints: {
        status: maxQ <= 45000 ? 'VALID' : 'INVALID',
        is_valid: maxQ <= 45000,
        max_dynamic_pressure_pa: maxQ,
        max_acceleration_g: 4.8,
        max_angle_of_attack_deg: 3.2,
        violations_count: maxQ > 45000 ? 1 : 0,
        violations: maxQ > 45000 ? [`Max-Q threshold exceeded: ${(maxQ/1000).toFixed(1)} kPa > 45.0 kPa`] : []
      },
      points
    };
  }

  private getMockSurrogate(params: Record<string, unknown>): SurrogatePredictionDto {
    const kickTime = (typeof params['pitch_kick_time_s'] === 'number') ? params['pitch_kick_time_s'] : 12;
    const predAlt = 320000 + (kickTime - 12) * 3500;
    const predVel = 5600 + (kickTime - 12) * 25;
    return {
      predicted_max_altitude_m: predAlt,
      predicted_max_velocity_ms: predVel,
      predicted_max_dynamic_pressure_pa: 36200,
      predicted_downrange_m: predAlt * 1.65,
      uncertainty: {
        altitude_std_m: predAlt * 0.035,
        velocity_std_ms: predVel * 0.022,
        dynamic_pressure_std_pa: 1400,
        confidence_interval_95: [predAlt * 0.93, predAlt * 1.07]
      },
      physics_loss_residual: 0.0028,
      inference_time_ms: 0.18
    };
  }

  private getMockOptimization(): OptimizationResponse {
    const history: OptimizationIterationDto[] = [
      { kick_time_s: 8.0, kick_angle_deg: 1.5, surrogate_predicted_alt_m: 310500, physics_ground_truth_alt_m: 308200, surrogate_error_percent: 0.74, max_dynamic_pressure_pa: 42100, constraint_status: 'VALID', score: 308200 },
      { kick_time_s: 11.0, kick_angle_deg: 2.5, surrogate_predicted_alt_m: 325400, physics_ground_truth_alt_m: 324100, surrogate_error_percent: 0.40, max_dynamic_pressure_pa: 38400, constraint_status: 'VALID', score: 324100 },
      { kick_time_s: 14.0, kick_angle_deg: 3.5, surrogate_predicted_alt_m: 341000, physics_ground_truth_alt_m: 338600, surrogate_error_percent: 0.70, max_dynamic_pressure_pa: 46200, constraint_status: 'INVALID', score: 238600 },
      { kick_time_s: 12.5, kick_angle_deg: 2.8, surrogate_predicted_alt_m: 331200, physics_ground_truth_alt_m: 329800, surrogate_error_percent: 0.42, max_dynamic_pressure_pa: 41800, constraint_status: 'VALID', score: 329800 }
    ];
    return {
      status: 'OPTIMIZATION_COMPLETE',
      optimal_parameters: history[3],
      best_score: 329800,
      total_evaluations: 4,
      history,
      summary: {
        duration_s: 250,
        max_altitude_m: 329800,
        max_velocity_ms: 5680,
        max_dynamic_pressure_pa: 41800,
        final_altitude_m: 329800,
        final_downrange_m: 540000,
        final_velocity_ms: 5680,
        final_mass_kg: 31500,
        fuel_remaining_kg: 0
      }
    };
  }

  private getMockEKF(noiseStd: number): EKFResponse {
    const frames = [];
    let altTrue = 0;
    let velTrue = 0;
    let altEst = 0;
    const dt = 1.0;

    for (let t = 0; t <= 60; t += dt) {
      const accel = Math.max(0, 15.0 - t * 0.1);
      velTrue += accel * dt;
      altTrue += velTrue * dt;

      // Noise
      const noise = (Math.random() - 0.5) * 2 * noiseStd;
      const measured = Math.max(0, altTrue + noise);

      // Simple Kalman estimation step
      altEst = altEst + (velTrue * dt) + 0.35 * (measured - (altEst + velTrue * dt));

      frames.push({
        time_s: t,
        true_altitude_m: Math.round(altTrue),
        measured_altitude_m: Math.round(measured),
        estimated_altitude_m: Math.round(altEst),
        error_m: Math.round(Math.abs(altEst - altTrue) * 10) / 10
      });
    }

    return { frames };
  }
}
