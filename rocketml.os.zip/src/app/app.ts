import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { RocketMLService } from './services/rocketml.service';
import {
  SimulationResponse,
  SurrogatePredictionDto,
  OptimizationResponse,
  EKFResponse,
  TrajectoryPointDto
} from './models/rocketml.types';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  protected readonly Math = Math;
  private rocketService = inject(RocketMLService);

  // Active Tab: 'physics-vs-ml' | 'optimizer' | 'ekf' | 'rl-env' | 'engineering'
  activeTab = signal<'physics-vs-ml' | 'optimizer' | 'ekf' | 'rl-env' | 'engineering'>('physics-vs-ml');

  // Simulation & ML State Signals
  isLoading = signal<boolean>(false);
  isOptimizing = signal<boolean>(false);
  isStreamingEKF = signal<boolean>(false);

  simulationData = signal<SimulationResponse | null>(null);
  surrogateData = signal<SurrogatePredictionDto | null>(null);
  optimizationData = signal<OptimizationResponse | null>(null);
  ekfData = signal<EKFResponse | null>(null);

  // Selected trajectory point for telemetry inspection
  selectedPoint = signal<TrajectoryPointDto | null>(null);
  ekfNoiseStd = signal<number>(25.0);

  // Reactive Configuration Form
  configForm = new FormGroup({
    thrust_vac: new FormControl<number>(845000),
    isp_vac: new FormControl<number>(311),
    dry_mass: new FormControl<number>(25000),
    propellant_mass: new FormControl<number>(395000),
    pitch_kick_time_s: new FormControl<number>(12),
    pitch_kick_angle_deg: new FormControl<number>(2.5),
    integrator: new FormControl<'EULER' | 'RK4' | 'RK45'>('RK4'),
  });

  // Computed Trajectory Metrics
  summary = computed(() => this.simulationData()?.summary ?? null);
  constraints = computed(() => this.simulationData()?.constraints ?? null);
  points = computed(() => this.simulationData()?.points ?? []);

  // Comparison metrics: Ground Truth vs Surrogate
  apogeeDelta = computed(() => {
    const s = this.summary();
    const ml = this.surrogateData();
    if (!s || !ml) return null;
    const delta = Math.abs(s.max_altitude_m - ml.predicted_max_altitude_m);
    const pct = (delta / s.max_altitude_m) * 100;
    return { deltaKm: delta / 1000, percent: pct };
  });

  velocityDelta = computed(() => {
    const s = this.summary();
    const ml = this.surrogateData();
    if (!s || !ml) return null;
    const delta = Math.abs(s.max_velocity_ms - ml.predicted_max_velocity_ms);
    const pct = (delta / s.max_velocity_ms) * 100;
    return { deltaMs: delta, percent: pct };
  });

  // Trajectory SVG Path generation
  svgTrajectoryPath = computed(() => {
    const pts = this.points();
    if (!pts || pts.length === 0) return '';
    const maxDownrange = Math.max(100000, ...pts.map((p) => p.position_x));
    const maxAlt = Math.max(100000, ...pts.map((p) => p.altitude));

    const width = 800;
    const height = 340;
    const pad = 40;

    return pts
      .map((p, idx) => {
        const x = pad + (p.position_x / maxDownrange) * (width - 2 * pad);
        const y = height - pad - (p.altitude / maxAlt) * (height - 2 * pad);
        return `${idx === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
      })
      .join(' ');
  });

  // Apogee Coordinate for SVG marker
  svgApogeePos = computed(() => {
    const pts = this.points();
    if (!pts || pts.length === 0) return { x: 400, y: 50 };
    const maxDownrange = Math.max(100000, ...pts.map((p) => p.position_x));
    const maxAlt = Math.max(100000, ...pts.map((p) => p.altitude));
    const width = 800;
    const height = 340;
    const pad = 40;

    let highest = pts[0];
    for (const p of pts) {
      if (p.altitude > highest.altitude) highest = p;
    }

    return {
      x: pad + (highest.position_x / maxDownrange) * (width - 2 * pad),
      y: height - pad - (highest.altitude / maxAlt) * (height - 2 * pad),
      altKm: (highest.altitude / 1000).toFixed(1),
    };
  });

  ngOnInit() {
    this.runFullSimulation();
  }

  runFullSimulation() {
    this.isLoading.set(true);
    const val = this.configForm.value;
    const params = {
      thrust_vac: Number(val.thrust_vac) || 845000,
      isp_vac: Number(val.isp_vac) || 311,
      dry_mass: Number(val.dry_mass) || 25000,
      propellant_mass: Number(val.propellant_mass) || 395000,
      pitch_kick_time_s: Number(val.pitch_kick_time_s) || 12,
      pitch_kick_angle_deg: Number(val.pitch_kick_angle_deg) || 2.5,
      integrator: val.integrator || 'RK4',
      dt: 0.5,
      time_limit: 250,
    };

    // Parallel calls: Physics Simulation + ML Surrogate Inference
    this.rocketService.simulate(params).subscribe((simRes) => {
      this.simulationData.set(simRes);
      if (simRes.points.length > 0) {
        this.selectedPoint.set(simRes.points[Math.floor(simRes.points.length / 2)]);
      }
      this.isLoading.set(false);
    });

    this.rocketService.predictSurrogate(params).subscribe((surrRes) => {
      this.surrogateData.set(surrRes);
    });
  }

  runSurrogateOnly() {
    const val = this.configForm.value;
    this.rocketService.predictSurrogate(val).subscribe((surrRes) => {
      this.surrogateData.set(surrRes);
    });
  }

  runOptimization() {
    this.isOptimizing.set(true);
    this.rocketService.optimize({ iterations: 6 }).subscribe((res) => {
      this.optimizationData.set(res);
      this.isOptimizing.set(false);
      this.activeTab.set('optimizer');
    });
  }

  runEKFStream() {
    this.isStreamingEKF.set(true);
    this.rocketService.streamEKF({ alt_noise_std: this.ekfNoiseStd() }).subscribe((res) => {
      this.ekfData.set(res);
      this.isStreamingEKF.set(false);
      this.activeTab.set('ekf');
    });
  }

  updateEKFNoise(event: Event) {
    const target = event.target as HTMLInputElement;
    this.ekfNoiseStd.set(Number(target.value));
    this.runEKFStream();
  }

  selectPoint(pt: TrajectoryPointDto) {
    this.selectedPoint.set(pt);
  }

  setActiveTab(tab: 'physics-vs-ml' | 'optimizer' | 'ekf' | 'rl-env' | 'engineering') {
    this.activeTab.set(tab);
    if (tab === 'ekf' && !this.ekfData()) {
      this.runEKFStream();
    }
    if (tab === 'optimizer' && !this.optimizationData()) {
      this.runOptimization();
    }
  }
}
