export interface SimulationParams {
  thrust_vac: number;
  isp_vac: number;
  dry_mass: number;
  propellant_mass: number;
  pitch_kick_time_s: number;
  pitch_kick_angle_deg: number;
  integrator: 'EULER' | 'RK4' | 'RK45';
  dt: number;
  time_limit: number;
}

export interface TrajectoryPointDto {
  time: number;
  position_x: number;
  position_y: number;
  position_z: number;
  velocity_x: number;
  velocity_y: number;
  velocity_z: number;
  speed: number;
  altitude: number;
  vertical_velocity: number;
  horizontal_velocity: number;
  mass: number;
  thrust: number;
  drag: number;
  gravity: number;
  dynamic_pressure: number;
  mach: number;
  angle_of_attack: number;
  pitch: number;
  yaw: number;
  roll: number;
  fuel_remaining: number;
}

export interface TrajectorySummaryDto {
  duration_s: number;
  max_altitude_m: number;
  max_velocity_ms: number;
  max_dynamic_pressure_pa: number;
  final_altitude_m: number;
  final_downrange_m: number;
  final_velocity_ms: number;
  final_mass_kg: number;
  fuel_remaining_kg: number;
}

export interface ConstraintResultDto {
  status: 'VALID' | 'INVALID';
  is_valid: boolean;
  max_dynamic_pressure_pa: number;
  max_acceleration_g: number;
  max_angle_of_attack_deg: number;
  violations_count: number;
  violations: string[];
}

export interface SimulationResponse {
  summary: TrajectorySummaryDto;
  constraints: ConstraintResultDto;
  points: TrajectoryPointDto[];
}

export interface SurrogatePredictionDto {
  predicted_max_altitude_m: number;
  predicted_max_velocity_ms: number;
  predicted_max_dynamic_pressure_pa: number;
  predicted_downrange_m: number;
  uncertainty: {
    altitude_std_m: number;
    velocity_std_ms: number;
    dynamic_pressure_std_pa: number;
    confidence_interval_95: [number, number];
  };
  physics_loss_residual: number;
  inference_time_ms: number;
}

export interface OptimizationIterationDto {
  kick_time_s: number;
  kick_angle_deg: number;
  surrogate_predicted_alt_m: number;
  physics_ground_truth_alt_m: number;
  surrogate_error_percent: number;
  max_dynamic_pressure_pa: number;
  constraint_status: 'VALID' | 'INVALID';
  score: number;
}

export interface OptimizationResponse {
  status: string;
  optimal_parameters: OptimizationIterationDto;
  best_score: number;
  total_evaluations: number;
  history: OptimizationIterationDto[];
  summary: TrajectorySummaryDto;
}

export interface EKFFrameDto {
  time_s: number;
  true_altitude_m: number;
  measured_altitude_m: number;
  estimated_altitude_m: number;
  error_m: number;
}

export interface EKFResponse {
  frames: EKFFrameDto[];
}
